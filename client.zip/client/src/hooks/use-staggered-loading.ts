import { useState, useEffect } from 'react';

interface StaggeredLoadingOptions {
  priority: number;
  delay?: number;
}

interface LoadingState {
  [key: string]: boolean;
}

export function useStaggeredLoading() {
  const [loadingState, setLoadingState] = useState<LoadingState>({});
  
  const registerComponent = (
    componentName: string, 
    options: StaggeredLoadingOptions
  ) => {
    useEffect(() => {
      const baseDelay = options.priority * 500; // 500ms per priority level
      const customDelay = options.delay || baseDelay;
      
      const timer = setTimeout(() => {
        setLoadingState(prev => ({
          ...prev,
          [componentName]: true
        }));
      }, customDelay);

      return () => clearTimeout(timer);
    }, [componentName, options.priority, options.delay]);
  };

  const isComponentReady = (componentName: string): boolean => {
    return loadingState[componentName] || false;
  };

  const getLoadingProgress = (): number => {
    const totalComponents = Object.keys(loadingState).length;
    const loadedComponents = Object.values(loadingState).filter(Boolean).length;
    
    if (totalComponents === 0) return 0;
    return Math.round((loadedComponents / totalComponents) * 100);
  };

  return {
    registerComponent,
    isComponentReady,
    getLoadingProgress,
    loadingState
  };
}