import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Shield, Eye, Lock, Users, Globe, Mail, Server, FileText, AlertTriangle, CheckCircle2 } from "lucide-react";
import SEOHead from "@/components/seo-head";

export default function Privacy() {
  const lastUpdated = "January 15, 2025";
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <SEOHead 
        title="Privacy Policy - FindMyBizName Data Protection & Security"
        description="Comprehensive privacy policy for FindMyBizName global business platform. GDPR, CCPA, and PIPEDA compliant data protection practices for 430.5M entrepreneurs worldwide."
        keywords="FindMyBizName privacy policy, data protection, GDPR compliance, business data security, entrepreneur privacy rights, global privacy standards"
      />
      <div className="container mx-auto px-4 py-16 pt-32 md:pt-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4" variant="outline">
            <Shield className="w-4 h-4 mr-2" />
            Last Updated: {lastUpdated} • GDPR, CCPA & PIPEDA Compliant
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Privacy Policy & Data Protection
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto mb-8">
            At FindMyBizName, protecting your privacy isn't just a legal requirement—it's fundamental 
            to our mission of empowering underbanked entrepreneurs globally. This comprehensive policy 
            explains how we collect, use, protect, and respect your personal information across our 
            global business operating system.
          </p>
          {/* Quick Overview Cards */}
          <div className="grid md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg">
              <CheckCircle2 className="w-6 h-6 text-green-600 mx-auto mb-2" />
              <div className="text-sm font-medium">Zero Data Sales</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Never sold to third parties</div>
            </div>
            <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
              <Lock className="w-6 h-6 text-blue-600 mx-auto mb-2" />
              <div className="text-sm font-medium">256-bit Encryption</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Bank-level security</div>
            </div>
            <div className="bg-purple-50 dark:bg-purple-950 p-4 rounded-lg">
              <Globe className="w-6 h-6 text-purple-600 mx-auto mb-2" />
              <div className="text-sm font-medium">Global Compliance</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">150+ jurisdictions</div>
            </div>
            <div className="bg-orange-50 dark:bg-orange-950 p-4 rounded-lg">
              <Users className="w-6 h-6 text-orange-600 mx-auto mb-2" />
              <div className="text-sm font-medium">User Control</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Full access & deletion rights</div>
            </div>
          </div>
        </div>
        {/* Privacy Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <Card className="border-2 border-green-200 dark:border-green-800">
            <CardContent className="pt-6 text-center">
              <Lock className="w-10 h-10 text-green-600 mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">Military-Grade Encryption</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                All data transmitted and stored using AES-256 encryption, the same standard used by 
                banks and government agencies worldwide. Zero-knowledge architecture ensures even we 
                cannot access your encrypted business data.
              </p>
            </CardContent>
          </Card>
          <Card className="border-2 border-blue-200 dark:border-blue-800">
            <CardContent className="pt-6 text-center">
              <Eye className="w-10 h-10 text-blue-600 mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">Complete Transparency</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                Real-time data usage dashboard, detailed consent management, and plain-English 
                explanations. You always know exactly what data we collect, why we collect it, 
                and how it benefits your business growth.
              </p>
            </CardContent>
          </Card>
          <Card className="border-2 border-purple-200 dark:border-purple-800">
            <CardContent className="pt-6 text-center">
              <Users className="w-10 h-10 text-purple-600 mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">Ultimate User Control</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                Export all your data in multiple formats, modify any information, or request complete 
                deletion within 24 hours. Your data belongs to you—we're just the secure custodians.
              </p>
            </CardContent>
          </Card>
        </div>
        {/* Main Content */}
        <div className="max-w-5xl mx-auto space-y-10">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <FileText className="w-6 h-6 text-blue-600" />
                1. Information Collection & Purpose
              </CardTitle>
              <CardDescription className="text-base">
                Comprehensive overview of data types we collect and their specific business purposes
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">Account & Profile Information</h4>
                  <ul className="text-sm space-y-2 text-gray-700 dark:text-gray-300">
                    <li><strong>Required:</strong> Email address, chosen username, subscription tier</li>
                    <li><strong>Optional:</strong> Full name, company name, industry, location</li>
                    <li><strong>Purpose:</strong> Service delivery, account management, personalization</li>
                    <li><strong>Legal Basis:</strong> Contract performance & legitimate interests</li>
                  </ul>
                </div>
                <div className="p-5 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-green-800 dark:text-green-200">Business Usage Data</h4>
                  <ul className="text-sm space-y-2 text-gray-700 dark:text-gray-300">
                    <li><strong>Generated:</strong> Business descriptions, name preferences, search queries</li>
                    <li><strong>Behavior:</strong> Feature usage patterns, time spent, interaction flows</li>
                    <li><strong>Purpose:</strong> AI algorithm improvement, personalized recommendations</li>
                    <li><strong>Legal Basis:</strong> Legitimate interests & consent (for personalization)</li>
                  </ul>
                </div>
                <div className="p-5 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-orange-800 dark:text-orange-200">Payment & Billing Information</h4>
                  <ul className="text-sm space-y-2 text-gray-700 dark:text-gray-300">
                    <li><strong>Processed by:</strong> PayPal, Stripe, WiPay, Coinbase Commerce</li>
                    <li><strong>We Store:</strong> Transaction IDs, subscription status, billing history</li>
                    <li><strong>We Never Store:</strong> Credit card numbers, banking details</li>
                    <li><strong>Purpose:</strong> Billing management, fraud prevention, compliance</li>
                  </ul>
                </div>
                <div className="p-5 bg-purple-50 dark:bg-purple-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-purple-800 dark:text-purple-200">Technical & Security Data</h4>
                  <ul className="text-sm space-y-2 text-gray-700 dark:text-gray-300">
                    <li><strong>Automatic:</strong> IP addresses, browser types, device information</li>
                    <li><strong>Security:</strong> Login attempts, security events, threat detection</li>
                    <li><strong>Performance:</strong> Load times, error logs, usage analytics</li>
                    <li><strong>Purpose:</strong> Security, performance optimization, compliance</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-yellow-50 dark:bg-yellow-950 rounded-lg border-l-4 border-yellow-400">
                <h4 className="font-bold mb-2 text-yellow-800 dark:text-yellow-200 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  Special Categories & Sensitive Data
                </h4>
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  We do NOT collect sensitive personal information (racial origin, political opinions, health data, 
                  biometric data, etc.) unless explicitly required for specific regional compliance (e.g., 
                  beneficial ownership registers). Such collection always requires explicit consent with 
                  clear opt-out mechanisms.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Server className="w-6 h-6 text-green-600" />
                2. Data Processing & AI Enhancement
              </CardTitle>
              <CardDescription className="text-base">
                How we use your information to improve our AI and provide better services
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold mb-3 text-lg">Service Delivery & Core Functions</h4>
                  <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-2">
                    <li>Generate AI-powered business name suggestions tailored to your industry and preferences</li>
                    <li>Perform real-time domain availability checking across 50+ TLDs globally</li>
                    <li>Save and sync your favorite names and search history across devices</li>
                    <li>Process payments and manage subscription billing cycles</li>
                    <li>Provide customer support and respond to your inquiries</li>
                    <li>Deliver platform updates and feature announcements</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold mb-3 text-lg">AI Algorithm Enhancement</h4>
                  <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-2">
                    <li>Analyze naming patterns to improve suggestion relevance and creativity</li>
                    <li>Identify emerging industry trends and popular business naming styles</li>
                    <li>Optimize domain checking accuracy and response times</li>
                    <li>Develop new features based on user behavior and feedback patterns</li>
                    <li>Train models for better multilingual support and cultural relevance</li>
                    <li>Enhance trademark screening and legal compliance tools</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">Anonymization & Aggregation Practices</h4>
                <p className="text-sm text-blue-800 dark:text-blue-200 mb-3">
                  For AI training and analytics, we use advanced anonymization techniques:
                </p>
                <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                  <li>• <strong>K-anonymity:</strong> Group data to prevent individual identification</li>
                  <li>• <strong>Differential Privacy:</strong> Add mathematical noise while preserving insights</li>
                  <li>• <strong>Data Synthesis:</strong> Generate artificial datasets that preserve statistical properties</li>
                  <li>• <strong>Federated Learning:</strong> Train AI models without centralizing raw data</li>
                </ul>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Globe className="w-6 h-6 text-purple-600" />
                3. Data Sharing, Transfers & Third Parties
              </CardTitle>
              <CardDescription className="text-base">
                Complete transparency about when and how your data may be shared globally
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-5 bg-red-50 dark:bg-red-950 rounded-lg border-2 border-red-200 dark:border-red-800">
                <h4 className="font-bold mb-2 text-red-800 dark:text-red-200 text-xl flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Iron-Clad Commitment: We Never Sell Your Data
                </h4>
                <p className="text-red-800 dark:text-red-200 font-medium">
                  FindMyBizName has never, does not, and will never sell, rent, lease, or trade your 
                  personal information to data brokers, marketing companies, or any third parties for 
                  their commercial purposes. This commitment is legally binding and monitored by 
                  independent auditors.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold mb-3 text-lg text-green-700 dark:text-green-300">Trusted Service Partners</h4>
                  <div className="space-y-3">
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold">Payment Processors</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">PayPal, Stripe, WiPay, Coinbase Commerce - for secure payment processing only</p>
                    </div>
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold">Cloud Infrastructure</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">AWS, Google Cloud, Replit - for secure hosting and data processing</p>
                    </div>
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold">Domain Registry APIs</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Namecheap, GoDaddy APIs - for real-time domain availability checking</p>
                    </div>
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold">Communication Services</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">SendGrid, Twilio - for essential service emails and SMS</p>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-bold mb-3 text-lg text-orange-700 dark:text-orange-300">International Data Transfers</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-orange-50 dark:bg-orange-950 rounded">
                      <h5 className="font-semibold">Primary Data Centers</h5>
                      <p className="text-sm">United States (AWS US-East-1), Canada (Toronto), Europe (Frankfurt)</p>
                    </div>
                    <div className="p-3 bg-orange-50 dark:bg-orange-950 rounded">
                      <h5 className="font-semibold">Transfer Safeguards</h5>
                      <p className="text-sm">Standard Contractual Clauses (SCCs), adequacy decisions, binding corporate rules</p>
                    </div>
                    <div className="p-3 bg-orange-50 dark:bg-orange-950 rounded">
                      <h5 className="font-semibold">Data Localization</h5>
                      <p className="text-sm">EU users: data primarily processed in Frankfurt. Canadian users: data stays in Toronto</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-gray-50 dark:bg-gray-900 rounded-lg">
                <h4 className="font-bold mb-3">Legal Disclosure Requirements</h4>
                <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                  We may disclose personal information only when legally required:
                </p>
                <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-1">
                  <li>• Valid court orders, subpoenas, or government requests with proper jurisdiction</li>
                  <li>• Emergency situations involving immediate physical danger to individuals</li>
                  <li>• Suspected violations of law that pose material harm to our users or platform</li>
                  <li>• Business transfers (acquisition, merger) with equivalent privacy protections</li>
                </ul>
                <p className="text-xs text-gray-500 mt-3">
                  <strong>Transparency Commitment:</strong> We maintain a transparency report detailing all 
                  government requests and our responses, updated quarterly.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Lock className="w-6 h-6 text-blue-600" />
                4. Security Architecture & Data Protection
              </CardTitle>
              <CardDescription className="text-base">
                Technical and organizational measures protecting your information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h5 className="font-bold mb-2 text-blue-800 dark:text-blue-200">Encryption Standards</h5>
                  <ul className="text-xs space-y-1">
                    <li>• AES-256 encryption at rest</li>
                    <li>• TLS 1.3 for data in transit</li>
                    <li>• End-to-end encryption for sensitive data</li>
                    <li>• Hardware security modules (HSMs)</li>
                  </ul>
                </div>
                <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h5 className="font-bold mb-2 text-green-800 dark:text-green-200">Access Controls</h5>
                  <ul className="text-xs space-y-1">
                    <li>• Multi-factor authentication required</li>
                    <li>• Role-based access permissions</li>
                    <li>• Zero-trust network architecture</li>
                    <li>• Regular access reviews & audits</li>
                  </ul>
                </div>
                <div className="p-4 bg-purple-50 dark:bg-purple-950 rounded-lg">
                  <h5 className="font-bold mb-2 text-purple-800 dark:text-purple-200">Monitoring & Response</h5>
                  <ul className="text-xs space-y-1">
                    <li>• 24/7 security monitoring</li>
                    <li>• Automated threat detection</li>
                    <li>• Incident response team</li>
                    <li>• Penetration testing quarterly</li>
                  </ul>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-yellow-800 dark:text-yellow-200">Data Retention Policies</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong>Active Accounts:</strong> Data retained as long as account is active plus 90 days</p>
                    <p><strong>Deleted Accounts:</strong> Personal data purged within 30 days of deletion request</p>
                    <p><strong>Legal Requirements:</strong> Some data retained for 7 years per financial regulations</p>
                    <p><strong>Anonymized Data:</strong> May be retained indefinitely for research and AI training</p>
                  </div>
                </div>
                <div className="p-5 bg-red-50 dark:bg-red-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-red-800 dark:text-red-200">Breach Notification Procedures</h4>
                  <div className="space-y-2 text-sm">
                    <p><strong>Detection:</strong> Automated systems detect potential breaches within minutes</p>
                    <p><strong>Containment:</strong> Immediate isolation and forensic analysis begins</p>
                    <p><strong>User Notification:</strong> Affected users notified within 72 hours maximum</p>
                    <p><strong>Regulatory Reporting:</strong> Authorities notified per local requirements</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Users className="w-6 h-6 text-green-600" />
                5. Your Privacy Rights & Data Control
              </CardTitle>
              <CardDescription className="text-base">
                Comprehensive rights and easy-to-use controls for managing your personal information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-bold text-lg">Universal Rights (All Users)</h4>
                  <div className="space-y-3">
                    <div className="p-3 border rounded-lg">
                      <h5 className="font-semibold text-blue-700 dark:text-blue-300">Right to Access</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Download all your data in machine-readable formats (JSON, CSV, XML)</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h5 className="font-semibold text-green-700 dark:text-green-300">Right to Rectification</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Correct inaccurate information through your account dashboard or support request</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h5 className="font-semibold text-red-700 dark:text-red-300">Right to Deletion</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Request complete data deletion within 24 hours (subject to legal retention requirements)</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <h4 className="font-bold text-lg">Enhanced Rights (GDPR, CCPA, PIPEDA)</h4>
                  <div className="space-y-3">
                    <div className="p-3 border rounded-lg">
                      <h5 className="font-semibold text-purple-700 dark:text-purple-300">Right to Portability</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Export data in structured formats for transfer to other services</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h5 className="font-semibold text-orange-700 dark:text-orange-300">Right to Object</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Opt out of data processing for legitimate interests or direct marketing</p>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <h5 className="font-semibold text-teal-700 dark:text-teal-300">Right to Restrict Processing</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Limit how we process your data while maintaining account functionality</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">How to Exercise Your Rights</h4>
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <h5 className="font-semibold mb-2">Self-Service Portal</h5>
                    <p className="text-sm">Account Settings → Privacy Controls for immediate access, rectification, and deletion requests</p>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Email Request</h5>
                    <p className="text-sm">privacy@findmybizname.com with identity verification (response within 72 hours)</p>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Regulatory Complaints</h5>
                    <p className="text-sm">Contact your local data protection authority if unsatisfied with our response</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Globe className="w-6 h-6 text-indigo-600" />
                6. Global Compliance & Regional Variations
              </CardTitle>
              <CardDescription className="text-base">
                How we comply with privacy laws across different jurisdictions worldwide
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h5 className="font-bold mb-2 text-blue-800 dark:text-blue-200">European Union (GDPR)</h5>
                  <ul className="text-xs space-y-1">
                    <li>• Data Protection Officer appointed</li>
                    <li>• Privacy by Design principles</li>
                    <li>• Explicit consent mechanisms</li>
                    <li>• Data Processing Impact Assessments</li>
                    <li>• Right to complain to supervisory authority</li>
                  </ul>
                </div>
                <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h5 className="font-bold mb-2 text-green-800 dark:text-green-200">United States (CCPA/CPRA)</h5>
                  <ul className="text-xs space-y-1">
                    <li>• "Do Not Sell My Personal Information"</li>
                    <li>• Right to know categories and sources</li>
                    <li>• Right to delete personal information</li>
                    <li>• Non-discrimination for exercising rights</li>
                    <li>• Sensitive Personal Information protections</li>
                  </ul>
                </div>
                <div className="p-4 bg-purple-50 dark:bg-purple-950 rounded-lg">
                  <h5 className="font-bold mb-2 text-purple-800 dark:text-purple-200">Canada (PIPEDA)</h5>
                  <ul className="text-xs space-y-1">
                    <li>• Privacy Officer designated</li>
                    <li>• Meaningful consent required</li>
                    <li>• Breach notification to Commissioner</li>
                    <li>• Cross-border transfer safeguards</li>
                    <li>• Right to complaint to OPC</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-gray-50 dark:bg-gray-900 rounded-lg">
                <h4 className="font-bold mb-3">Regional Adaptations for Underbanked Entrepreneurs</h4>
                <div className="grid md:grid-cols-2 gap-6 text-sm">
                  <div>
                    <h5 className="font-semibold mb-2 text-blue-700 dark:text-blue-300">Caribbean & Latin America</h5>
                    <ul className="space-y-1">
                      <li>• Trinidad & Tobago Data Protection Act compliance</li>
                      <li>• Jamaica Data Protection Act considerations</li>
                      <li>• LGPD (Brazil) requirements for Brazilian users</li>
                      <li>• Regional payment processor data handling agreements</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2 text-green-700 dark:text-green-300">Africa & Asia-Pacific</h5>
                    <ul className="space-y-1">
                      <li>• POPIA (South Africa) compliance framework</li>
                      <li>• Nigeria Data Protection Regulation adherence</li>
                      <li>• Singapore PDPA requirements</li>
                      <li>• India DPDP Act preparations</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Mail className="w-6 h-6 text-orange-600" />
                7. Contact Information & Privacy Support
              </CardTitle>
              <CardDescription className="text-base">
                Multiple ways to reach our privacy team for questions, concerns, or rights requests
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <h4 className="font-bold mb-3 text-lg">Data Protection Officer</h4>
                    <div className="space-y-2 text-sm">
                      <p><strong>Email:</strong> dpo@findmybizname.com</p>
                      <p><strong>Response Time:</strong> 72 hours maximum</p>
                      <p><strong>Languages:</strong> English, Spanish, French</p>
                      <p><strong>Scope:</strong> GDPR inquiries, data processing questions, complaint investigations</p>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-bold mb-3 text-lg">Privacy Officer (PIPEDA)</h4>
                    <div className="space-y-2 text-sm">
                      <p><strong>Email:</strong> privacy@findmybizname.com</p>
                      <p><strong>Response Time:</strong> 48 hours maximum</p>
                      <p><strong>Languages:</strong> English, French</p>
                      <p><strong>Scope:</strong> Canadian privacy law compliance, consent management</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-bold mb-3 text-lg">Regional Privacy Contacts</h4>
                    <div className="space-y-3 text-sm">
                      <div className="p-3 border rounded">
                        <p><strong>Caribbean Region:</strong> privacy-caribbean@findmybizname.com</p>
                        <p>Trinidad & Tobago, Jamaica, Barbados, and wider Caribbean</p>
                      </div>
                      <div className="p-3 border rounded">
                        <p><strong>Africa:</strong> privacy-africa@findmybizname.com</p>
                        <p>Nigeria, South Africa, Kenya, Ghana, and broader continent</p>
                      </div>
                      <div className="p-3 border rounded">
                        <p><strong>Asia-Pacific:</strong> privacy-apac@findmybizname.com</p>
                        <p>Singapore, Australia, India, and broader region</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-8 p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">Emergency Privacy Incidents</h4>
                <p className="text-sm text-blue-800 dark:text-blue-200 mb-2">
                  For urgent privacy concerns, data breaches, or immediate deletion requests:
                </p>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><strong>24/7 Emergency Line:</strong> +1 (868) 720-9758</p>
                    <p><strong>Signal/WhatsApp:</strong> End-to-end encrypted reporting</p>
                  </div>
                  <div>
                    <p><strong>Emergency Email:</strong> privacy-emergency@findmybizname.com</p>
                    <p><strong>Response Time:</strong> Within 2 hours, 24/7</p>
                  </div>
                </div>
              </div>
              <div className="mt-6 text-center">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
                  <Mail className="w-4 h-4 mr-2" />
                  Contact Privacy Team
                </Button>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-100 dark:from-blue-950 dark:to-indigo-950 border-2 border-blue-200 dark:border-blue-800">
            <CardContent className="pt-6">
              <h3 className="font-bold text-xl mb-4 text-center">Policy Updates & Change Notifications</h3>
              <div className="text-center space-y-3">
                <p className="text-sm">
                  We update this Privacy Policy periodically to reflect changes in our practices, 
                  technology, legal requirements, or other factors. Material changes are announced 
                  with 30+ days advance notice.
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  <Badge variant="outline">Version 4.2</Badge>
                  <Badge variant="outline">Effective {lastUpdated}</Badge>
                  <Badge variant="outline">Next Review: April 2025</Badge>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  By continuing to use FindMyBizName after policy updates, you accept the revised terms. 
                  Check your email and account dashboard for change notifications.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
