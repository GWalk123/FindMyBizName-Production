import { useState } from "react";
import React from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Download, DollarSign, Package, Globe, CreditCard, CheckCircle, ArrowLeft } from "lucide-react";
import SEOHead from "@/components/seo-head";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface DigitalProduct {
  id: number;
  title: string;
  description: string;
  price: number;
  category: string;
  fileName: string;
  downloadCount: number;
  fileSize: number;
  createdAt: string;
}

interface Purchase {
  id: number;
  productId: number;
  purchasePrice: number;
  downloadCount: number;
  createdAt: string;
  product?: DigitalProduct;
}

export default function DigitalProducts() {
  const [activeTab, setActiveTab] = useState("browse");
  const { toast } = useToast();

  // Fetch all products
  const { data: products = [], isLoading: productsLoading, error: productsError } = useQuery<DigitalProduct[]>({
    queryKey: ["/api/digital-products"],
    queryFn: async () => {
      const response = await fetch('/api/digital-products');
      if (!response.ok) throw new Error('Failed to fetch digital products');
      return response.json();
    },
    retry: 3,
    retryDelay: 1000,
    refetchOnWindowFocus: false,
  });

  console.log('Digital Products Data:', products);
  console.log('Digital Products Error:', productsError);
  console.log('Digital Products Loading:', productsLoading);
  
  // Force fetch directly from API as a test
  const [testData, setTestData] = useState(null);
  
  React.useEffect(() => {
    fetch('/api/digital-products')
      .then(res => res.json())
      .then(data => {
        console.log('Direct fetch result:', data);
        setTestData(data);
      })
      .catch(err => console.log('Direct fetch error:', err));
  }, []);

  // Fetch user purchases
  const { data: purchases = [], isLoading: purchasesLoading } = useQuery<Purchase[]>({
    queryKey: ["/api/user/purchases"],
    queryFn: async () => {
      const response = await fetch('/api/user/purchases');
      if (!response.ok) throw new Error('Failed to fetch user purchases');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });

  // Purchase mutation
  const purchaseMutation = useMutation({
    mutationFn: async (productId: number) => {
      const response = await apiRequest("POST", `/api/digital-products/${productId}/purchase`, {
        paymentMethod: "demo",
        paymentId: `demo_${Date.now()}`
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Purchase Successful!",
        description: "Your product is ready for download.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/purchases"] });
      setActiveTab("downloads");
    },
    onError: (error) => {
      toast({
        title: "Purchase Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatPrice = (cents: number) => {
    return `$${(cents / 100).toFixed(2)}`;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes >= 1024 * 1024) {
      return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    }
    return `${(bytes / 1024).toFixed(0)} KB`;
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case "legal":
        return <FileText className="h-5 w-5" />;
      case "finance":
      case "financial":
        return <DollarSign className="h-5 w-5" />;
      case "templates":
      case "branding":
        return <Package className="h-5 w-5" />;
      case "services":
        return <Globe className="h-5 w-5" />;
      default:
        return <FileText className="h-5 w-5" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case "legal":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "finance":
      case "financial":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "templates":
      case "branding":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200";
      case "services":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200";
    }
  };

  const isPurchased = (productId: number) => {
    return purchases.some(p => p.productId === productId);
  };

  const downloadProduct = async (productId: number) => {
    const purchase = purchases.find(p => p.productId === productId);
    if (!purchase) {
      toast({
        title: "Access Denied",
        description: "You must purchase this product first.",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch(`/api/digital-products/${productId}/download?purchaseId=${purchase.id}`);
      if (!response.ok) throw new Error("Download failed");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = purchase.product?.fileName || `product-${productId}.txt`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Download Started",
        description: "Your file is being downloaded.",
      });
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Unable to download the file. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <SEOHead 
        title="Digital Products - Caribbean Business Templates & Tools"
        description="Download professional business templates, legal documents, and financial tools customized for underbanked entrepreneurs. Instant access to proven business resources."
      />
      
      <div className="container mx-auto px-4 py-8">
        {/* Back to Home Navigation */}
        <div className="mb-6">
          <Button variant="ghost" asChild className="text-gray-600 hover:text-gray-900">
            <a href="/" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </a>
          </Button>
        </div>
        
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Digital Business Products
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Professional templates and tools designed specifically for underbanked entrepreneurs. 
            Download instantly and customize for your business needs.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-8">
            <TabsTrigger value="browse">Browse Products</TabsTrigger>
            <TabsTrigger value="downloads">My Downloads</TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-6">
            {productsLoading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <Card key={product.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2 mb-2">
                          {getCategoryIcon(product.category)}
                          <Badge className={getCategoryColor(product.category)}>
                            {product.category}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-primary">
                            {formatPrice(product.price)}
                          </div>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{product.title}</CardTitle>
                      <CardDescription className="text-sm">
                        {formatFileSize(product.fileSize)} • {product.downloadCount} downloads
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent>
                      <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                        {product.description}
                      </p>
                    </CardContent>

                    <CardFooter>
                      {isPurchased(product.id) ? (
                        <div className="w-full space-y-2">
                          <Button 
                            onClick={() => downloadProduct(product.id)}
                            className="w-full"
                            variant="outline"
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </Button>
                          <div className="flex items-center justify-center text-sm text-green-600 dark:text-green-400">
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Purchased
                          </div>
                        </div>
                      ) : (
                        <Button 
                          onClick={() => {
                            const productData = encodeURIComponent(JSON.stringify({
                              id: product.id,
                              title: product.title,
                              price: product.price,
                              category: product.category,
                              description: product.description
                            }));
                            window.location.href = `/purchase-instructions?product=${productData}`;
                          }}
                          className="w-full"
                        >
                          <CreditCard className="h-4 w-4 mr-2" />
                          Purchase Now
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}

            {!productsLoading && products.length === 0 && (
              <div className="text-center py-12">
                <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  No Products Available
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  Digital products are being prepared. Check back soon!
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="downloads" className="space-y-6">
            {purchasesLoading ? (
              <div className="space-y-4">
                {[1, 2].map((i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            ) : purchases.length > 0 ? (
              <div className="space-y-4">
                {purchases.map((purchase) => (
                  <Card key={purchase.id}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">
                            {purchase.product?.title || `Product #${purchase.productId}`}
                          </CardTitle>
                          <CardDescription>
                            Purchased on {new Date(purchase.createdAt).toLocaleDateString()} • 
                            Downloaded {purchase.downloadCount} times
                          </CardDescription>
                        </div>
                        <Badge className={purchase.product ? getCategoryColor(purchase.product.category) : ""}>
                          {purchase.product?.category || "Unknown"}
                        </Badge>
                      </div>
                    </CardHeader>
                    
                    <CardContent>
                      <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                        {purchase.product?.description || "Product description not available"}
                      </p>
                    </CardContent>

                    <CardFooter>
                      <Button 
                        onClick={() => downloadProduct(purchase.productId)}
                        variant="outline"
                        className="w-full"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download Again
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Download className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  No Downloads Yet
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  Purchase products from the Browse tab to access your downloads here.
                </p>
                <Button onClick={() => setActiveTab("browse")} variant="outline">
                  Browse Products
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Value Proposition Section */}
        <div className="mt-16 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg p-8">
          <h2 className="text-2xl font-bold text-center mb-6">Why Choose Our Digital Products?</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-blue-100 dark:bg-blue-900 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <FileText className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="font-semibold mb-2">Caribbean Customized</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                All templates are specifically designed for Caribbean business needs and legal requirements.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 dark:bg-green-900 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <Download className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="font-semibold mb-2">Instant Access</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Download immediately after purchase. No waiting, no complicated setup required.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 dark:bg-purple-900 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                <CreditCard className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="font-semibold mb-2">One-Time Purchase</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Pay once, use forever. No monthly subscriptions or hidden fees.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}