import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Mail, MessageCircle, Phone, MapPin, Clock, CheckCircle, Globe, Users, Zap, Shield, Bot, ArrowRight } from "lucide-react";
import SEOHead from "@/components/seo-head";

const contactSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(100, "Name too long"),
  email: z.string().email("Please enter a valid email address"),
  company: z.string().optional(),
  subject: z.string().min(5, "Subject must be at least 5 characters").max(200, "Subject too long"),
  message: z.string().min(10, "Message must be at least 10 characters").max(2000, "Message too long"),
  category: z.enum(["general", "support", "billing", "partnership", "media", "enterprise", "technical", "legal"]),
  priority: z.enum(["low", "medium", "high", "urgent"]),
  region: z.string().optional(),
});

type ContactForm = z.infer<typeof contactSchema>;

export default function Contact() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();
  
  const form = useForm<ContactForm>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: "",
      email: "",
      company: "",
      subject: "",
      message: "",
      category: "general",
      priority: "medium",
      region: "",
    },
  });

  const onSubmit = async (data: ContactForm) => {
    try {
      await apiRequest("POST", "/api/contact", data);
      setIsSubmitted(true);
      toast({
        title: "Message Sent Successfully!",
        description: "We'll respond based on your priority level within our guaranteed timeframes.",
      });
    } catch (error) {
      toast({
        title: "Error Sending Message",
        description: "Please try WhatsApp or email us directly at sales@findmybizname.com",
        variant: "destructive",
      });
    }
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <SEOHead 
          title="Message Sent Successfully - FindMyBizName Contact"
          description="Your message has been sent to FindMyBizName support team. We'll respond within our guaranteed timeframes."
        />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Thank You for Reaching Out!
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
              Your message has been received by our global support team. We'll respond according to your priority level and region.
            </p>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-lg mb-8">
              <h3 className="text-2xl font-semibold mb-6">What Happens Next?</h3>
              <div className="grid md:grid-cols-3 gap-6 text-left">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600 dark:text-blue-400 text-sm font-bold">1</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Message Review</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Our AI system categorizes and routes your message to the appropriate specialist team member.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600 dark:text-blue-400 text-sm font-bold">2</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Expert Assignment</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">A subject matter expert from your region prepares a comprehensive, personalized response.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600 dark:text-blue-400 text-sm font-bold">3</span>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Guaranteed Response</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">You receive our detailed reply within guaranteed timeframes, with follow-up if needed.</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <h4 className="font-semibold mb-2">Response Time Guarantees</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-red-600">Urgent:</span> 1-2 hours
                  </div>
                  <div>
                    <span className="font-medium text-orange-600">High:</span> 4-6 hours
                  </div>
                  <div>
                    <span className="font-medium text-blue-600">Medium:</span> 12-24 hours
                  </div>
                  <div>
                    <span className="font-medium text-green-600">Low:</span> 24-48 hours
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={() => setIsSubmitted(false)}
                variant="outline"
                size="lg"
              >
                Send Another Message
              </Button>
              <Button 
                onClick={() => window.location.href = "/"}
                className="bg-blue-600 hover:bg-blue-700"
                size="lg"
              >
                Return to Dashboard
              </Button>
              <Button 
                onClick={() => window.open("https://wa.me/18687209758", "_blank")}
                className="bg-green-600 hover:bg-green-700"
                size="lg"
              >
                WhatsApp Support
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <SEOHead 
        title="Contact FindMyBizName - Global Business Platform Support"
        description="Contact FindMyBizName's expert support team. 24/7 multilingual assistance for entrepreneurs worldwide. Based in Trinidad & Tobago, serving globally."
        keywords="FindMyBizName contact, business support, entrepreneur help, global customer service, multilingual support, Caribbean business platform"
      />
      
      <div className="container mx-auto px-4 py-16 pt-32 md:pt-16">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
              CONNECT WITH US
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto mb-8">
              Based in Trinidad & Tobago, serving 430.5M underbanked entrepreneurs worldwide. 
              24/7 AI-powered multilingual support with comprehensive customer service for all 
              business platform inquiries and technical assistance.
            </p>
            
            {/* Global Stats */}
            <div className="grid md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">24/7</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Global Support</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 dark:text-green-400">25+</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Languages</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600 dark:text-purple-400">150+</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Countries</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 dark:text-orange-400">2hr</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Avg Response</div>
              </div>
            </div>
          </div>

          {/* Biz Botz AI Support Section */}
          <div className="max-w-5xl mx-auto mb-16">
            <Card className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950 border-2 border-purple-200 dark:border-purple-800">
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-3 text-2xl">
                  <Bot className="w-8 h-8 text-purple-600" />
                  Start with Biz Botz AI Assistant
                </CardTitle>
                <CardDescription className="text-lg">
                  Get instant answers in 25+ languages, 24/7. Our AI assistant handles most questions immediately.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6 mb-6">
                  <div className="space-y-4">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Zap className="w-5 h-5 text-yellow-600" />
                      Instant AI Support
                    </h4>
                    <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                      <li>• Business naming & branding advice</li>
                      <li>• Payment method guidance</li>
                      <li>• Account setup assistance</li>
                      <li>• Feature explanations</li>
                      <li>• Global market insights</li>
                    </ul>
                  </div>
                  <div className="space-y-4">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Globe className="w-5 h-5 text-blue-600" />
                      Multilingual & Global
                    </h4>
                    <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                      <li>• Available in 25+ languages</li>
                      <li>• Cultural context awareness</li>
                      <li>• Regional payment expertise</li>
                      <li>• Time zone optimized</li>
                      <li>• Escalates to Customer Service when needed</li>
                    </ul>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                    <a href="/biz-botz" className="flex items-center gap-2">
                      <Bot className="w-5 h-5" />
                      Chat with Biz Botz Now
                      <ArrowRight className="w-4 h-4" />
                    </a>
                  </Button>
                  <Button size="lg" variant="outline">
                    Need Customer Service? Continue Below ↓
                  </Button>
                </div>
                
                <div className="mt-4 text-center">
                  <p className="text-xs text-gray-500">
                    🚀 <strong>Smart Escalation:</strong> Complex issues are forwarded to Customer Service - response within 24 hours
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Contact Info */}
            <div className="lg:col-span-1 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle className="w-6 h-6" />
                    Primary Contact Methods
                  </CardTitle>
                  <CardDescription>
                    Choose your preferred communication channel
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-start gap-4 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <Mail className="w-6 h-6 text-blue-600 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold">Email Support (Recommended)</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        sales@findmybizname.com
                      </p>
                      <p className="text-xs text-gray-500">
                        Detailed responses • File attachments • Priority queuing
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4 p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                    <MessageCircle className="w-6 h-6 text-green-600 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold">WhatsApp Business</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        +1 (868) 720-9758
                      </p>
                      <p className="text-xs text-gray-500 mb-2">
                        Text messages • File sharing
                      </p>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        <a href="https://wa.me/18687209758" target="_blank" rel="noopener noreferrer">
                          Start Chat
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="w-6 h-6" />
                    Regional Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-blue-600 mt-1" />
                    <div>
                      <p className="font-medium">Headquarters</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Arouca, Trinidad & Tobago
                      </p>
                      <p className="text-xs text-gray-500">
                        Caribbean business expertise & regional focus
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-blue-600 mt-1" />
                    <div>
                      <p className="font-medium">Operating Hours</p>
                      <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                        <p><strong>AST:</strong> 10 AM - 10 PM</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Users className="w-5 h-5 text-blue-600 mt-1" />
                    <div>
                      <p className="font-medium">Specialized Services Offered</p>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        <p>• Technical Support</p>
                        <p>• Business Naming</p>
                        <p>• Payment and Billing Support</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Service Level Guarantees</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-950 rounded">
                    <span className="font-medium text-red-700 dark:text-red-300">Urgent Issues</span>
                    <span className="text-sm font-bold">1-2 hours</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-orange-50 dark:bg-orange-950 rounded">
                    <span className="font-medium text-orange-700 dark:text-orange-300">High Priority</span>
                    <span className="text-sm font-bold">4-6 hours</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-950 rounded">
                    <span className="font-medium text-blue-700 dark:text-blue-300">Standard</span>
                    <span className="text-sm font-bold">12-24 hours</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-950 rounded">
                    <span className="font-medium text-green-700 dark:text-green-300">General Info</span>
                    <span className="text-sm font-bold">24-48 hours</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl">Send us a Detailed Message</CardTitle>
                  <CardDescription className="text-base">
                    Provide comprehensive details for faster, more accurate assistance. 
                    Our AI-powered routing ensures your message reaches the right expert immediately.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name *</FormLabel>
                              <FormControl>
                                <Input placeholder="Your complete name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Address *</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="your@email.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="company"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Company/Organization (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="Your business name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="region"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Region/Country (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Trinidad & Tobago, USA, UK" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="category"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Category *</FormLabel>
                              <FormControl>
                                <select 
                                  {...field}
                                  className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800"
                                >
                                  <option value="general">General Inquiry</option>
                                  <option value="support">Technical Support</option>
                                  <option value="billing">Billing & Subscriptions</option>
                                  <option value="partnership">Partnership & Business Development</option>
                                  <option value="enterprise">Enterprise Solutions</option>
                                  <option value="technical">Technical Integration/API</option>
                                  <option value="legal">Legal & Compliance</option>
                                  <option value="media">Media & Press Relations</option>
                                </select>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="priority"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Priority Level *</FormLabel>
                              <FormControl>
                                <select 
                                  {...field}
                                  className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800"
                                >
                                  <option value="low">Low - General information</option>
                                  <option value="medium">Medium - Standard support</option>
                                  <option value="high">High - Business critical</option>
                                  <option value="urgent">Urgent - Service disruption</option>
                                </select>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="subject"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Subject Line *</FormLabel>
                            <FormControl>
                              <Input placeholder="Brief, descriptive summary of your inquiry" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Detailed Message *</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Please provide comprehensive details about your inquiry, including:&#10;• Specific issues you're experiencing&#10;• Steps you've already tried&#10;• Your business goals or requirements&#10;• Any error messages or screenshots&#10;• Preferred resolution timeline&#10;&#10;The more detail you provide, the better we can assist you."
                                className="min-h-40 resize-y"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex flex-col sm:flex-row gap-4">
                        <Button 
                          type="submit" 
                          className="flex-1 bg-blue-600 hover:bg-blue-700 h-12 text-lg"
                          disabled={form.formState.isSubmitting}
                        >
                          {form.formState.isSubmitting ? "Sending Message..." : "Send Detailed Message"}
                        </Button>
                        
                        <Button 
                          type="button"
                          variant="outline" 
                          className="flex-1 h-12 text-lg"
                          onClick={() => window.open("https://wa.me/18687209758", "_blank")}
                        >
                          <MessageCircle className="w-5 h-5 mr-2" />
                          Quick WhatsApp
                        </Button>
                      </div>

                      <div className="text-center text-sm text-gray-500">
                        <Shield className="w-4 h-4 inline mr-1" />
                        Your information is protected by 256-bit encryption and never shared with third parties.
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}