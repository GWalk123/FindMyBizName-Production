import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Sparkles, Globe, Shield, Zap, Users, TrendingUp, Clock } from "lucide-react";
import SEOHead from "@/components/seo-head";

export default function Features() {
  const features = [
    {
      icon: <Sparkles className="w-8 h-8 text-blue-600" />,
      title: "AI-Powered Generation",
      description: "Advanced algorithms create unique, brandable business names tailored to your industry and style preferences.",
      details: [
        "Multiple generation algorithms",
        "Industry-specific keywords",
        "Style-based customization",
        "Synonym integration"
      ],
      status: "ACTIVE"
    },
    {
      icon: <Globe className="w-8 h-8 text-green-600" />,
      title: "Real-Time Domain Checking",
      description: "Instantly verify domain availability across multiple TLDs (.com, .net, .org, .io, .ai) with pricing information.",
      details: [
        "Live domain availability via RapidAPI",
        "8 TLD support (.com, .net, .org, .io, .ai, .co, .app, .dev)",
        "Real pricing information",
        "Premium domain access"
      ],
      status: "ACTIVE"
    },
    {
      icon: <Users className="w-8 h-8 text-indigo-600" />,
      title: "Professional CRM System",
      description: "Complete customer relationship management with contact tracking, lead management, and automated workflows.",
      details: [
        "Contact management dashboard",
        "Lead tracking and scoring",
        "Automated follow-up sequences",
        "Customer communication history"
      ],
      status: "READY FOR API"
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-red-600" />,
      title: "SEC EDGAR Business Intelligence",
      description: "Live access to 500,000+ company profiles, financial data, and business intelligence from SEC databases.",
      details: [
        "Real-time company search",
        "Financial data analysis",
        "Trending companies dashboard",
        "Business intelligence insights"
      ],
      status: "READY FOR API"
    },
    {
      icon: <CheckCircle className="w-8 h-8 text-purple-600" />,
      title: "Brand Analysis Suite",
      description: "Comprehensive trademark checking, social media analysis, and brand sentiment evaluation.",
      details: [
        "USPTO trademark verification",
        "Social media handle checking",
        "Brand sentiment analysis", 
        "Pronunciation difficulty scoring"
      ],
      status: "READY FOR API"
    },
    {
      icon: <Clock className="w-8 h-8 text-orange-600" />,
      title: "Invoice Generation System",
      description: "Professional invoice creation with PDF generation, payment tracking, and automated reminders.",
      details: [
        "Professional PDF invoices",
        "Payment status tracking",
        "Automated payment reminders",
        "Multi-currency support"
      ],
      status: "READY FOR API"
    },
    {
      icon: <Users className="w-8 h-8 text-pink-600" />,
      title: "Global Referral Program",
      description: "30% recurring commission system with automated payouts and global tracking infrastructure.",
      details: [
        "30% recurring commissions",
        "Automated payout system",
        "Global tracking dashboard",
        "Multi-tier referral structure"
      ],
      status: "READY FOR API"
    },
    {
      icon: <Shield className="w-8 h-8 text-green-700" />,
      title: "Alternative Payment Systems",
      description: "Multiple payment options optimized for cash-based economies and underbanked entrepreneurs.",
      details: [
        "WiPay Caribbean integration",
        "PayPal global processing",
        "Payoneer international transfers",
        "OneSafe regional support"
      ],
      status: "READY FOR API"
    },
    {
      icon: <Zap className="w-8 h-8 text-yellow-600" />,
      title: "Digital Products Marketplace",
      description: "Instant download system for business templates, legal documents, and financial trackers.",
      details: [
        "Legal template library",
        "Financial tracking tools",
        "Brand guideline templates",
        "Instant download system"
      ],
      status: "READY FOR API"
    }
  ];

  const premiumFeatures = [
    "Unlimited name generation",
    "Premium domain access (.ai, .co, .app)",
    "Advanced logo previews",
    "Trademark screening",
    "Bulk domain checking",
    "Priority customer support",
    "Export to multiple formats",
    "API access for developers"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <SEOHead 
        title="Features - FindMyBizName AI Business Name Generator"
        description="Discover powerful features of FindMyBizName: AI-powered name generation, real-time domain checking, Caribbean market focus, and enterprise security."
      />
      
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4" variant="outline">
            <Sparkles className="w-4 h-4 mr-2" />
            Powered by AI
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Everything You Need to Find the Perfect Business Name
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            From AI-powered generation to real-time domain checking, FindMyBizName provides 
            comprehensive tools for underbanked entrepreneurs and global businesses.
          </p>
        </div>

        {/* Core Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => (
            <Card key={index} className="relative overflow-hidden">
              <CardHeader>
                <div className="mb-4">{feature.icon}</div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
                <CardDescription>{feature.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {feature.details.map((detail, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">{detail}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Premium Features Section */}
        <Card className="mb-16">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Premium Features</CardTitle>
            <CardDescription>
              Unlock advanced capabilities with Premium and Pro plans
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {premiumFeatures.map((feature, index) => (
                <div key={index} className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
            <div className="text-center mt-8">
              <Button size="lg" className="mr-4">
                Start Free Trial
              </Button>
              <Button variant="outline" size="lg">
                View Pricing
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Technical Specs */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card>
            <CardHeader>
              <Clock className="w-8 h-8 text-blue-600 mb-2" />
              <CardTitle>Performance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span>Generation Speed</span>
                <span className="font-semibold">&lt;1 second</span>
              </div>
              <div className="flex justify-between">
                <span>Domain Check</span>
                <span className="font-semibold">&lt;2 seconds</span>
              </div>
              <div className="flex justify-between">
                <span>Uptime SLA</span>
                <span className="font-semibold">99.9%</span>
              </div>
              <div className="flex justify-between">
                <span>Global CDN</span>
                <span className="font-semibold">15+ regions</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Shield className="w-8 h-8 text-green-600 mb-2" />
              <CardTitle>Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span>SSL Encryption</span>
                <span className="font-semibold">256-bit</span>
              </div>
              <div className="flex justify-between">
                <span>Data Compliance</span>
                <span className="font-semibold">GDPR</span>
              </div>
              <div className="flex justify-between">
                <span>Threat Protection</span>
                <span className="font-semibold">Real-time</span>
              </div>
              <div className="flex justify-between">
                <span>Rate Limiting</span>
                <span className="font-semibold">Advanced</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Globe className="w-8 h-8 text-purple-600 mb-2" />
              <CardTitle>Coverage</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span>Domain TLDs</span>
                <span className="font-semibold">50+</span>
              </div>
              <div className="flex justify-between">
                <span>Industries</span>
                <span className="font-semibold">25+</span>
              </div>
              <div className="flex justify-between">
                <span>Name Styles</span>
                <span className="font-semibold">12+</span>
              </div>
              <div className="flex justify-between">
                <span>Languages</span>
                <span className="font-semibold">English</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardContent className="text-center py-12">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Find Your Perfect Business Name?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Join 430.5 million underbanked entrepreneurs worldwide with $5T purchasing power who trust FindMyBizName
            </p>
            <div className="space-x-4">
              <Button size="lg" variant="secondary">
                Try Free Generator
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-blue-600">
                Start Premium Trial
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}