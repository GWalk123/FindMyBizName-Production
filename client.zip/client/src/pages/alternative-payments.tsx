import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Smartphone, CreditCard, Building, Wallet } from "lucide-react";
import SEOHead from "@/components/seo-head";
import { WiPayButton } from "@/components/wipay-button";

export default function AlternativePayments() {
  const handleContactSupport = () => {
    window.open('https://wa.me/18687209758?text=Hi! I need help with payment options for FindMyBizName subscription.', '_blank');
  };

  const paymentMethods = [
    {
      name: "PayPal Business",
      icon: <CreditCard className="w-6 h-6" />,
      description: "Global payment processing with full Trinidad & Tobago support",
      features: ["Global acceptance", "Buyer protection", "Multi-currency", "Instant processing"],
      fees: "3.49% + fixed fee",
      processing: "Instant",
      badge: "LIVE & ACTIVE"
    },
    {
      name: "Payoneer",
      icon: <Wallet className="w-6 h-6" />,
      description: "International payment platform with Caribbean banking support",
      features: ["Global transfers", "Multi-currency", "Business accounts", "Low fees"],
      fees: "1-3% transaction fees",
      processing: "1-3 business days",
      badge: "APPROVED"
    },
    {
      name: "Visa/MasterCard Credit Cards",
      icon: <CreditCard className="w-6 h-6" />,
      description: "Standard credit cards accepted throughout the Caribbean region",
      features: ["Universal acceptance", "Secure online payments", "Fraud protection", "Instant processing"],
      fees: "No additional fees",
      processing: "Instant",
      badge: "Most Popular"
    },
    {
      name: "Local Debit Cards",
      icon: <CreditCard className="w-6 h-6" />,
      description: "Trinidad & Tobago bank debit cards designed for local online purchases",
      features: ["All major T&T banks", "Secure online payments", "No credit check", "Instant processing"],
      fees: "Standard bank fees",
      processing: "Instant",
      badge: "Most Convenient"
    },
    {
      name: "WiPay Caribbean",
      icon: <Wallet className="w-6 h-6" />,
      description: "Digital wallet popular across Trinidad & Tobago, Jamaica, Guyana, and Barbados",
      features: ["Instant transfers", "Mobile app", "Wide acceptance", "Caribbean-focused"],
      fees: "Low transaction fees",
      processing: "Instant",
      badge: "Caribbean Leader"
    },
    {
      name: "Bank Transfer",
      icon: <Building className="w-6 h-6" />,
      description: "Direct transfer from your bank account via mobile banking or online",
      features: ["Secure", "Available 24/7", "All major banks", "Lower fees"],
      fees: "Bank standard rates",
      processing: "Same day to 3 days",
      badge: "Secure"
    },
    {
      name: "Mobile Money",
      icon: <Smartphone className="w-6 h-6" />,
      description: "Convert cash to mobile credit with Digicel or Flow, then pay digitally",
      features: ["Cash-friendly", "Widely available", "No bank account needed", "Retail locations"],
      fees: "Small top-up fees",
      processing: "Instant after top-up",
      badge: "Cash-Friendly"
    },
    {
      name: "Endcash Digital Wallet",
      icon: <CreditCard className="w-6 h-6" />,
      description: "Republic Bank's digital wallet for smartphone money management",
      features: ["Send & receive", "Bill payments", "Merchant network", "Local support"],
      fees: "$3.50 TT loading fee",
      processing: "Instant",
      badge: "Republic Bank"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <SEOHead 
        title="Alternative Payment Options - FindMyBizName"
        description="Pay for FindMyBizName Premium with WiPay, bank transfer, mobile money, Endcash, and other underbanked payment methods. No credit card required."
        keywords="WiPay, bank transfer, mobile money, Endcash, Caribbean payments, Trinidad Tobago, no credit card"
      />
      
      <div className="container mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            💳 Multiple Payment Options Available
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-6">
            Choose the payment method that works best for you. We support WiPay and various Caribbean payment methods.
          </p>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 max-w-2xl mx-auto">
            <p className="text-amber-800 text-sm">
              <strong>Payment Methods:</strong><br/>
              1. <strong>WiPay (Primary):</strong> All Trinidad & Tobago bank cards and vouchers<br/>
              2. <strong>Manual Methods:</strong> Contact support for bank transfer, mobile money, debit cards<br/>
              3. <strong>PayPal:</strong> Credit/debit cards, PayPal balance, bank accounts
            </p>
          </div>
        </div>

        {/* Payment Methods Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {paymentMethods.map((method, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
                      {method.icon}
                    </div>
                    <CardTitle className="text-lg">{method.name}</CardTitle>
                  </div>
                  {method.badge && (
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      {method.badge}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{method.description}</p>
                
                <div className="space-y-2 mb-4">
                  {method.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center space-x-2">
                      <Check className="w-4 h-4 text-green-500" />
                      <span className="text-sm text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-gray-900">Fees:</span>
                    <p className="text-gray-600">{method.fees}</p>
                  </div>
                  <div>
                    <span className="font-medium text-gray-900">Processing:</span>
                    <p className="text-gray-600">{method.processing}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* WiPay Integration Notice */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
          <div className="flex items-center space-x-3 mb-3">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <Check className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="text-lg font-semibold text-blue-900">Caribbean-Native Payment Processing</h3>
          </div>
          <p className="text-blue-800">
            Primary payments processed through WiPay - Trinidad & Tobago's trusted payment platform. All transactions 
            are secured by Caribbean banking standards with 5-day settlement to local bank accounts.
          </p>
        </div>

        {/* WiPay Demo Section */}
        <Card className="mb-8 border-blue-200">
          <CardHeader className="bg-blue-50">
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Wallet className="w-5 h-5" />
              WiPay Payment Demo
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">Try WiPay Integration</h4>
                <p className="text-gray-600 mb-4">
                  Test our WiPay voucher payment system. Enter a voucher number to see how payments work.
                </p>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                  <p className="text-sm text-yellow-800">
                    <strong>Demo Mode:</strong> This is a test environment. No actual payments will be processed.
                  </p>
                </div>
              </div>
              <div>
                <WiPayButton 
                  amount={25} 
                  description="FindMyBizName Pro Subscription (Demo)"
                  onSuccess={(transactionId) => {
                    console.log("Demo payment successful:", transactionId);
                  }}
                  onError={(error) => {
                    console.log("Demo payment error:", error);
                  }}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-2xl text-center">How Alternative Payments Work</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-6 text-center">
              <div className="space-y-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <span className="font-bold text-blue-600">1</span>
                </div>
                <h3 className="font-semibold">Contact Us</h3>
                <p className="text-sm text-gray-600">WhatsApp or email us about alternative payment</p>
              </div>
              <div className="space-y-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <span className="font-bold text-blue-600">2</span>
                </div>
                <h3 className="font-semibold">Choose Method</h3>
                <p className="text-sm text-gray-600">Select WiPay, bank transfer, mobile money, or Endcash</p>
              </div>
              <div className="space-y-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <span className="font-bold text-blue-600">3</span>
                </div>
                <h3 className="font-semibold">Make Payment</h3>
                <p className="text-sm text-gray-600">Follow our simple payment instructions</p>
              </div>
              <div className="space-y-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <span className="font-bold text-blue-600">4</span>
                </div>
                <h3 className="font-semibold">Get Premium</h3>
                <p className="text-sm text-gray-600">Account upgraded within 24 hours</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Options */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <Card>
            <CardContent className="p-8 text-center">
              <h3 className="text-xl font-semibold mb-4">💬 WhatsApp Support</h3>
              <p className="text-gray-600 mb-6">
                Get instant help with alternative payment options. Our team responds quickly to help you upgrade.
              </p>
              <Button 
                onClick={() => window.open(`https://wa.me/18687209758?text=Hi! I want to upgrade to FindMyBizName Premium but prefer to pay with WiPay, bank transfer, or mobile money. Can you help me with payment instructions?`, '_blank')}
                className="bg-green-600 hover:bg-green-700 text-white w-full"
              >
                Chat on WhatsApp
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-8 text-center">
              <h3 className="text-xl font-semibold mb-4">📧 Email Support</h3>
              <p className="text-gray-600 mb-6">
                Prefer email? Send us your payment preference and we'll provide detailed instructions.
              </p>
              <Button 
                onClick={() => window.open(`mailto:sales@findmybizname.com?subject=Alternative Payment Request&body=Hi, I want to upgrade to FindMyBizName Premium but don't have a credit card.%0A%0AI prefer to pay with:%0A□ WiPay%0A□ Bank Transfer%0A□ Mobile Money%0A□ Endcash%0A□ Other: ____%0A%0APlease send me payment instructions.%0A%0AThank you!`, '_blank')}
                variant="outline"
                className="w-full"
              >
                Send Email Request
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* FAQ */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">Frequently Asked Questions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h4 className="font-semibold mb-2">Do you accept Trinidad & Tobago debit cards?</h4>
              <p className="text-gray-600">Yes! Local debit cards from RBC, Republic Bank, First Citizens, and other T&T banks work perfectly for online purchases. They're often the most convenient option for our customers.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Why don't you accept only credit cards?</h4>
              <p className="text-gray-600">We know many underbanked entrepreneurs prefer cash or local payment methods. We want to make FindMyBizName accessible to everyone, regardless of their banking situation.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">How long does it take to process alternative payments?</h4>
              <p className="text-gray-600">Most payments are processed within 24 hours. WiPay and Endcash are usually instant, while bank transfers may take 1-3 business days.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Are there extra fees for alternative payments?</h4>
              <p className="text-gray-600">Our subscription prices remain the same. You only pay your payment provider's standard fees (usually very low for local transfers).</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">What about payment options for underbanked entrepreneurs outside the Caribbean?</h4>
              <p className="text-gray-600">We serve 430.5 million underbanked entrepreneurs globally! While our Caribbean focus includes WiPay and local methods, we accept international solutions like PayPal (available in 200+ countries), Payoneer (supporting 150+ countries), mobile money services (M-Pesa, GCash, etc.), local bank transfers, prepaid debit cards, and cryptocurrency payments. Contact us at sales@findmybizname.com with your preferred method and country - we'll work with you to find a solution that works in your region.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">What specific alternative payment options are available for global underbanked entrepreneurs?</h4>
              <p className="text-gray-600">We've built the most comprehensive payment ecosystem for underbanked entrepreneurs worldwide. Our global payment network includes: <strong>Africa</strong> - M-Pesa (Kenya), MTN Mobile Money, Orange Money, Airtel Money; <strong>Asia</strong> - GCash (Philippines), Paytm (India), Alipay, WeChat Pay; <strong>Latin America</strong> - PIX (Brazil), Mercado Pago, OXXO Pay; <strong>Middle East</strong> - Fawry (Egypt), STC Pay (Saudi Arabia); <strong>Caribbean</strong> - WiPay, Endcash; <strong>Global</strong> - PayPal, Payoneer, Western Union, cryptocurrency (Bitcoin, Ethereum, USDC), prepaid debit cards, and local bank transfers in 150+ countries. Unlike traditional platforms that exclude 70% of global entrepreneurs, we actively partner with regional payment providers to ensure every underbanked entrepreneur can access our business tools regardless of their banking status or location.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Is it safe to pay through these methods?</h4>
              <p className="text-gray-600">Absolutely. All our accepted payment methods are regulated financial services with strong security measures. We never store your payment information.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}