import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, HelpCircle, BookOpen, MessageCircle, Video, Download, Globe, CreditCard, Settings, Zap } from "lucide-react";
import SEOHead from "@/components/seo-head";
import { useState } from "react";

export default function Help() {
  const [searchQuery, setSearchQuery] = useState("");

  const faqs = [
    {
      category: "Getting Started",
      questions: [
        {
          q: "How do I generate my first business name?",
          a: "Enter a description of your business (e.g., 'sustainable coffee roastery'), select your industry category, choose your preferred naming style, and click 'Generate Names'. Our AI will provide 10 unique suggestions with real-time domain availability checking."
        },
        {
          q: "What information should I provide for best results?",
          a: "Be specific about your business focus, target audience, and brand personality. Include 2-3 keywords that capture your business essence. Examples: 'premium pet grooming service', 'innovative tech consulting firm', 'artisanal bakery specializing in gluten-free products'."
        },
        {
          q: "How many names can I generate for free?",
          a: "Free users receive 10 business name generations per month with basic domain checking (.com only). Paid plans ($9.99, $19.99, $29.99, $99.99, and $149.99/month) include unlimited generations with premium domains and advanced business tools."
        },
        {
          q: "Can I use the generated names commercially?",
          a: "Yes, all generated business names are free to use commercially. However, you must verify trademark availability and legal compliance independently. We provide general trademark screening but not legal advice."
        }
      ]
    },
    {
      category: "Domain & Branding",
      questions: [
        {
          q: "Which domain extensions do you check?",
          a: "Free users can check .com only. Premium ($9.99/month) and higher tiers get access to 50+ extensions including .ai, .co, .app, .dev, .io, .tech, .store, .online, and many country-specific domains."
        },
        {
          q: "How accurate is your domain availability checking?",
          a: "We use real-time domain registry APIs for 99.5% accuracy. Domain availability can change rapidly, so we recommend registering your chosen domain immediately after verification."
        },
        {
          q: "Do you register domains directly?",
          a: "We provide availability checking and pricing information, then direct you to trusted registrar partners (GoDaddy, Namecheap, Google Domains) for actual registration with special pricing discounts."
        },
        {
          q: "Can you help with logo design and branding?",
          a: "We provide basic logo preview mockups showing your business name with different color schemes and styles. For professional logo design, we recommend trusted design services or freelance platforms."
        }
      ]
    },
    {
      category: "Payment & Billing",
      questions: [
        {
          q: "What payment methods do you accept globally?",
          a: "We accept PayPal (190+ countries), major credit cards (Visa, MasterCard, American Express), Payoneer (global payment processing), cryptocurrency payments (Bitcoin, Ethereum, USDC), and regional processors including WiPay (Caribbean), M-Pesa (Africa), and Alipay (Asia)."
        },
        {
          q: "Are there regional pricing differences?",
          a: "No, we maintain consistent global pricing to ensure fairness and sustainability. Our rates are already 90%+ more affordable than major competitors while delivering superior tools and features."
        },
        {
          q: "How do cancellations and refunds work?",
          a: "Cancel anytime through your account dashboard or PayPal. We offer 30-day money-back guarantee for new subscribers. Refunds are processed within 5-10 business days to your original payment method."
        },
        {
          q: "Do you offer enterprise or bulk licensing?",
          a: "For solo entrepreneurs and small to mid-level organizations, we provide the $9.99, $19.99, and $29.99 tiers with comprehensive business tools. For larger organizations, our $99.99 and $149.99 plans offer advanced features and integrations. Contact sales@findmybizname.com for volume discounts on multiple user accounts."
        }
      ]
    },
    {
      category: "Business Tools",
      questions: [
        {
          q: "What business tools are included in Pro plans?",
          a: "Pro users access our complete business operating system: CRM with customer management, professional invoice generator with payment processing, business plan templates, legal document generator, financial tracking tools, and market research capabilities."
        },
        {
          q: "Can I integrate FindMyBizName with other business tools?",
          a: "Yes, we offer API integration with popular platforms: Shopify, WordPress, QuickBooks, Mailchimp, HubSpot, and Zapier. Our REST API allows custom integrations for enterprise users."
        },
        {
          q: "Do you provide business registration assistance?",
          a: "Pro users receive guided business registration assistance with state/province-specific requirements, necessary legal document templates, and connections to legal professionals in 50+ countries."
        },
        {
          q: "What market research tools are available?",
          a: "Access our business intelligence platform with 500,000+ company database, competitor analysis, industry trend reports, SEO analysis tools, and social media handle checking across 15+ platforms."
        }
      ]
    },
    {
      category: "Technical Support",
      questions: [
        {
          q: "What if the platform isn't working properly?",
          a: "First, try clearing your browser cache and cookies. Check your internet connection stability. If using mobile, try desktop. For persistent issues, contact support at sales@findmybizname.com with your error details and browser information."
        },
        {
          q: "How do I export my generated names and data?",
          a: "Premium and Pro users can export all generated names, favorites, and business data in multiple formats: CSV, JSON, PDF reports, and formatted Word documents. Access via Account Settings > Data Export."
        },
        {
          q: "Is my data secure and private?",
          a: "Yes, we use bank-level 256-bit SSL encryption, GDPR-compliant data practices, and SOC 2 Type II certified infrastructure. Your data is never sold to third parties. See our Privacy Policy for complete details."
        },
        {
          q: "Do you have mobile apps?",
          a: "Our web platform is fully mobile-responsive and optimized for all devices including phones and tablets. You can add our website to your home screen for an app-like experience. We focus on continuously improving the mobile web experience rather than maintaining separate native apps."
        }
      ]
    }
  ];

  const guides = [
    {
      title: "Complete Business Naming Masterclass",
      description: "Comprehensive guide to creating memorable, brandable business names that drive success",
      duration: "25 min read",
      category: "Strategy",
      level: "Beginner"
    },
    {
      title: "Global Domain Strategy & Registration",
      description: "International domain acquisition, protection strategies, and legal considerations",
      duration: "18 min read",
      category: "Domains",
      level: "Intermediate"
    },
    {
      title: "Trademark Research & Legal Protection",
      description: "Step-by-step trademark searching, registration process, and brand protection",
      duration: "22 min read",
      category: "Legal",
      level: "Advanced"
    },
    {
      title: "Caribbean Business Setup Complete Guide",
      description: "Starting and scaling businesses in Trinidad & Tobago and broader Caribbean region",
      duration: "30 min read",
      category: "Regional",
      level: "Beginner"
    },
    {
      title: "AI-Powered Market Research Techniques",
      description: "Leveraging AI tools for competitor analysis, trend identification, and market validation",
      duration: "20 min read",
      category: "Research",
      level: "Intermediate"
    },
    {
      title: "Building Global Brands from Emerging Markets",
      description: "How underbanked entrepreneurs can create internationally competitive brands",
      duration: "28 min read",
      category: "Strategy",
      level: "Advanced"
    }
  ];

  const filteredFAQs = faqs.map(category => ({
    ...category,
    questions: category.questions.filter(
      q => searchQuery === "" || 
      q.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.a.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <SEOHead 
        title="Help Center - FindMyBizName Support & Comprehensive Business Guides"
        description="Complete help center for FindMyBizName global business platform. Detailed guides, FAQs, and support for business naming, domain registration, and entrepreneur tools."
        keywords="business name generator help, domain registration support, entrepreneur tools, global business platform, trademark help, business registration assistance"
      />
      
      <div className="container mx-auto px-4 py-16 pt-32 md:pt-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4" variant="outline">
            <HelpCircle className="w-4 h-4 mr-2" />
            Comprehensive Support Center
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            How Can We Help You Succeed?
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto mb-8">
            Access our comprehensive knowledge base, step-by-step tutorials, and expert support 
            to build your business with confidence. Serving 430.5M underbanked entrepreneurs globally 
            with localized support in 25+ languages.
          </p>
          
          {/* Search */}
          <div className="max-w-lg mx-auto relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search help articles, guides, and FAQs..."
              className="pl-10 h-12 text-lg"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-4 gap-6 mb-16">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <MessageCircle className="w-10 h-10 text-blue-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">24/7 Live Support</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Real-time assistance from our global support team
              </p>
              <Button variant="outline" size="sm" className="w-full">
                <a href="/contact">Start Chat</a>
              </Button>
            </CardContent>
          </Card>
          
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <Video className="w-10 h-10 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Video Masterclasses</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Interactive tutorials and business strategy sessions
              </p>
              <Button variant="outline" size="sm" className="w-full">
                Watch Library
              </Button>
            </CardContent>
          </Card>
          
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <BookOpen className="w-10 h-10 text-purple-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Business Academy</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Comprehensive entrepreneurship curriculum
              </p>
              <Button variant="outline" size="sm" className="w-full">
                Access Courses
              </Button>
            </CardContent>
          </Card>
          
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <Download className="w-10 h-10 text-orange-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Resource Library</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Templates, checklists, and business tools
              </p>
              <Button variant="outline" size="sm" className="w-full">
                Download Pack
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* FAQ Section */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Frequently Asked Questions</CardTitle>
                <CardDescription className="text-base">
                  Find comprehensive answers to common questions about our global business platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all" className="w-full">
                  <TabsList className="grid w-full grid-cols-6">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="getting-started">Getting Started</TabsTrigger>
                    <TabsTrigger value="domain-branding">Domains</TabsTrigger>
                    <TabsTrigger value="payment-billing">Billing</TabsTrigger>
                    <TabsTrigger value="business-tools">Business Tools</TabsTrigger>
                    <TabsTrigger value="technical-support">Technical</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="all" className="space-y-8 mt-6">
                    {filteredFAQs.map((category, categoryIndex) => (
                      <div key={categoryIndex}>
                        <div className="flex items-center gap-3 mb-4">
                          <h3 className="text-xl font-semibold">{category.category}</h3>
                          <Badge variant="secondary">{category.questions.length} articles</Badge>
                        </div>
                        <div className="space-y-4">
                          {category.questions.map((faq, index) => (
                            <div key={index} className="border rounded-lg p-5 bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
                              <h4 className="font-semibold mb-3 text-lg text-blue-700 dark:text-blue-300">{faq.q}</h4>
                              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{faq.a}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </TabsContent>
                  
                  {faqs.map((category, categoryIndex) => (
                    <TabsContent 
                      key={categoryIndex} 
                      value={category.category.toLowerCase().replace(' & ', '-').replace(' ', '-')}
                      className="space-y-4 mt-6"
                    >
                      {category.questions.map((faq, index) => (
                        <div key={index} className="border rounded-lg p-5 bg-white dark:bg-gray-800">
                          <h4 className="font-semibold mb-3 text-lg text-blue-700 dark:text-blue-300">{faq.q}</h4>
                          <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{faq.a}</p>
                        </div>
                      ))}
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div>
            {/* Popular Guides */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Expert Business Guides</CardTitle>
                <CardDescription>
                  Professional tutorials and strategic insights
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {guides.map((guide, index) => (
                    <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between mb-2">
                        <Badge variant="outline" className="text-xs">
                          {guide.category}
                        </Badge>
                        <div className="flex gap-1">
                          <Badge variant={guide.level === 'Beginner' ? 'default' : guide.level === 'Intermediate' ? 'secondary' : 'destructive'} className="text-xs">
                            {guide.level}
                          </Badge>
                        </div>
                      </div>
                      <h4 className="font-semibold mb-2 leading-tight">{guide.title}</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 leading-relaxed">
                        {guide.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">{guide.duration}</span>
                        <Button variant="outline" size="sm">
                          Read Guide
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Global Support */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />
                  Global Support Network
                </CardTitle>
                <CardDescription>
                  24/7 multilingual support worldwide
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="font-medium">Americas</p>
                    <p className="text-gray-600 dark:text-gray-400">English, Spanish, Portuguese</p>
                  </div>
                  <div>
                    <p className="font-medium">Europe</p>
                    <p className="text-gray-600 dark:text-gray-400">15+ languages</p>
                  </div>
                  <div>
                    <p className="font-medium">Asia-Pacific</p>
                    <p className="text-gray-600 dark:text-gray-400">Mandarin, Hindi, Japanese</p>
                  </div>
                  <div>
                    <p className="font-medium">Africa</p>
                    <p className="text-gray-600 dark:text-gray-400">English, French, Swahili</p>
                  </div>
                </div>
                <Button className="w-full" variant="outline">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Choose Your Language
                </Button>
              </CardContent>
            </Card>

            {/* Contact Card */}
            <Card>
              <CardHeader>
                <CardTitle>Need Personal Assistance?</CardTitle>
                <CardDescription>
                  Connect with our Caribbean-based founder team
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-1 flex items-center gap-2">
                      <MessageCircle className="w-4 h-4" />
                      WhatsApp Business
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      +1 (868) 720-9758
                    </p>
                    <p className="text-xs text-gray-500">MON - FRI 9AM - 5PM EST</p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-1 flex items-center gap-2">
                      <CreditCard className="w-4 h-4" />
                      Premium Support
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      sales@findmybizname.com
                    </p>
                    <p className="text-xs text-gray-500">Priority response within 2 hours</p>
                  </div>
                  
                  <Button className="w-full">
                    <a href="/contact">Contact Support Team</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}