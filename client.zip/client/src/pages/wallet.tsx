import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Wallet, Plus, Minus, ArrowUpRight, ArrowDownLeft, CreditCard, DollarSign, Clock, CheckCircle, AlertTriangle } from "lucide-react";
import SEOHead from "@/components/seo-head";
import { useToast } from "@/hooks/use-toast";

interface DigitalWallet {
  id: number;
  walletAddress: string;
  walletType: string;
  balance: string;
  currency: string;
  isActive: boolean;
  lastTransactionAt: string | null;
  createdAt: string;
}

interface WalletTransaction {
  id: number;
  transactionType: 'credit' | 'debit' | 'transfer';
  amount: string;
  currency: string;
  description: string;
  sourceType: string;
  status: string;
  balanceAfter: string;
  createdAt: string;
}

interface WalletWithdrawal {
  id: number;
  amount: string;
  currency: string;
  withdrawalMethod: string;
  status: string;
  transactionFee: string;
  netAmount: string;
  createdAt: string;
}

export default function WalletPage() {
  const [activeTab, setActiveTab] = useState("overview");
  const [addFundsAmount, setAddFundsAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawalMethod, setWithdrawalMethod] = useState("");
  const [withdrawalDetails, setWithdrawalDetails] = useState("");
  const { toast } = useToast();

  // Fetch wallet data
  const { data: wallet, isLoading: walletLoading, error: walletError } = useQuery<DigitalWallet>({
    queryKey: ["/api/wallet"],
    queryFn: async () => {
      try {
        const response = await fetch('/api/wallet');
        if (!response.ok) {
          if (response.status === 404) {
            return null; // Wallet doesn't exist yet
          }
          console.error('Wallet API error:', response.status, response.statusText);
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('✅ Wallet data received:', data);
        return data;
      } catch (error) {
        console.error('❌ Wallet fetch error:', error);
        throw error;
      }
    },
    retry: 2,
    refetchOnWindowFocus: false,
    staleTime: 30000, // Cache for 30 seconds
  });

  // Fetch transactions
  const { data: transactions = [], isLoading: transactionsLoading } = useQuery<WalletTransaction[]>({
    queryKey: ["/api/wallet/transactions"],
    queryFn: async () => {
      const response = await fetch('/api/wallet/transactions');
      if (!response.ok) throw new Error('Failed to fetch wallet transactions');
      return response.json();
    },
    retry: false,
    refetchOnWindowFocus: false,
  });

  // Fetch withdrawals
  const { data: withdrawals = [], isLoading: withdrawalsLoading } = useQuery<WalletWithdrawal[]>({
    queryKey: ["/api/wallet/withdrawals"],
    queryFn: async () => {
      const response = await fetch('/api/wallet/withdrawals');
      if (!response.ok) throw new Error('Failed to fetch wallet withdrawals');
      return response.json();
    },
    retry: false,
    refetchOnWindowFocus: false,
  });

  // Create wallet mutation
  const createWalletMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/wallet/create", {
        walletType: "personal"
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Wallet Created!",
        description: "Your digital wallet is now ready to use.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet"] });
    },
    onError: (error) => {
      toast({
        title: "Creation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Add funds mutation
  const addFundsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/wallet/add-funds", {
        amount: parseFloat(addFundsAmount),
        description: "Manual deposit",
        sourceType: "deposit"
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Funds Added!",
        description: `$${addFundsAmount} added to your wallet. New balance: $${data.newBalance}`,
      });
      setAddFundsAmount("");
      queryClient.invalidateQueries({ queryKey: ["/api/wallet"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
    },
    onError: (error) => {
      toast({
        title: "Transaction Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Withdraw funds mutation
  const withdrawMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/wallet/withdraw", {
        amount: parseFloat(withdrawAmount),
        withdrawalMethod,
        withdrawalDetails: JSON.parse(withdrawalDetails || "{}")
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal Requested!",
        description: "Your withdrawal request has been submitted for processing.",
      });
      setWithdrawAmount("");
      setWithdrawalMethod("");
      setWithdrawalDetails("");
      queryClient.invalidateQueries({ queryKey: ["/api/wallet"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/withdrawals"] });
    },
    onError: (error) => {
      toast({
        title: "Withdrawal Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatCurrency = (amount: string | undefined | null) => {
    if (!amount) return '$0.00';
    const numericAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    return `$${numericAmount.toFixed(2)}`;
  };

  const formatDate = (dateString: string | undefined | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'credit':
        return <ArrowDownLeft className="h-4 w-4 text-green-500" />;
      case 'debit':
        return <ArrowUpRight className="h-4 w-4 text-red-500" />;
      default:
        return <DollarSign className="h-4 w-4 text-blue-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Completed</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-800"><AlertTriangle className="h-3 w-3 mr-1" />Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (walletLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <>
      <SEOHead 
        title="Digital Wallet - FindMyBizName"
        description="Manage your digital wallet, add funds, withdraw earnings, and track all your financial transactions in one secure place."
      />
      
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8">
        <div className="container mx-auto px-4 max-w-6xl">
          
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              <Wallet className="h-10 w-10 inline-block mr-3 text-blue-600" />
              Digital Wallet
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Secure digital wallet for entrepreneurs worldwide. Add funds, withdraw earnings, and manage your finances with ease.
            </p>
          </div>

          {!wallet ? (
            /* Create Wallet */
            <Card className="max-w-md mx-auto">
              <CardHeader className="text-center">
                <CardTitle>Create Your Digital Wallet</CardTitle>
                <CardDescription>
                  Get started with your secure digital wallet for all your entrepreneur earnings and transactions.
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <Button 
                  onClick={() => createWalletMutation.mutate()}
                  disabled={createWalletMutation.isPending}
                  className="w-full"
                >
                  {createWalletMutation.isPending ? "Creating..." : "Create Wallet"}
                </Button>
              </CardContent>
            </Card>
          ) : (
            /* Wallet Dashboard */
            <div className="space-y-6">
              
              {/* Wallet Overview Card */}
              <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Wallet Balance</span>
                    <CreditCard className="h-6 w-6" />
                  </CardTitle>
                  <CardDescription className="text-blue-100">
                    {wallet.walletAddress}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-2">
                    {formatCurrency(wallet.balance)} {wallet.currency}
                  </div>
                  <div className="text-sm text-blue-100">
                    Last transaction: {wallet.lastTransactionAt ? formatDate(wallet.lastTransactionAt) : 'No transactions yet'}
                  </div>
                </CardContent>
              </Card>

              {/* Wallet Actions & Details */}
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="add-funds">Add Funds</TabsTrigger>
                  <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
                  <TabsTrigger value="history">History</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Current Balance</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-green-600">
                          {formatCurrency(wallet.balance)}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-blue-600">
                          {transactions.length}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium">Pending Withdrawals</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-yellow-600">
                          {withdrawals.filter(w => w.status === 'pending').length}
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Recent Transactions */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Recent Transactions</CardTitle>
                      <CardDescription>Your latest wallet activity</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {transactionsLoading ? (
                        <div className="text-center py-4">Loading transactions...</div>
                      ) : transactions.length === 0 ? (
                        <div className="text-center py-8 text-gray-500">
                          No transactions yet. Add funds to get started!
                        </div>
                      ) : (
                        <div className="space-y-4">
                          {transactions.slice(0, 5).map((transaction) => (
                            <div key={transaction.id} className="flex items-center justify-between p-3 border rounded-lg">
                              <div className="flex items-center space-x-3">
                                {getTransactionIcon(transaction.transactionType)}
                                <div>
                                  <p className="font-medium">{transaction.description}</p>
                                  <p className="text-sm text-gray-500">{formatDate(transaction.createdAt)}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className={`font-medium ${transaction.transactionType === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                                  {transaction.transactionType === 'credit' ? '+' : '-'}{formatCurrency(transaction.amount)}
                                </p>
                                <p className="text-sm text-gray-500">
                                  Balance: {formatCurrency(transaction.balanceAfter)}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="add-funds" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Plus className="h-5 w-5 mr-2 text-green-600" />
                        Add Funds to Wallet
                      </CardTitle>
                      <CardDescription>
                        Add money to your digital wallet for purchases and transactions
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label htmlFor="amount">Amount (USD)</Label>
                        <Input
                          id="amount"
                          type="number"
                          step="0.01"
                          min="0.01"
                          placeholder="25.00"
                          value={addFundsAmount}
                          onChange={(e) => setAddFundsAmount(e.target.value)}
                        />
                      </div>
                      
                      <Button 
                        onClick={() => addFundsMutation.mutate()}
                        disabled={!addFundsAmount || addFundsMutation.isPending || parseFloat(addFundsAmount) <= 0}
                        className="w-full"
                      >
                        {addFundsMutation.isPending ? "Processing..." : `Add $${addFundsAmount || "0.00"}`}
                      </Button>
                      
                      <div className="text-sm text-gray-500 space-y-2">
                        <p><strong>Supported Methods:</strong></p>
                        <ul className="list-disc list-inside space-y-1">
                          <li>PayPal (Instant)</li>
                          <li>Bank Transfer (1-3 business days)</li>
                          <li>Mobile Money (Caribbean/Africa)</li>
                          <li>Cryptocurrency (Bitcoin, Ethereum)</li>
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="withdraw" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Minus className="h-5 w-5 mr-2 text-red-600" />
                        Withdraw Funds
                      </CardTitle>
                      <CardDescription>
                        Withdraw money from your wallet to your preferred payment method
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label htmlFor="withdraw-amount">Amount (USD)</Label>
                        <Input
                          id="withdraw-amount"
                          type="number"
                          step="0.01"
                          min="5.00"
                          placeholder="25.00"
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                        />
                        <p className="text-sm text-gray-500 mt-1">
                          Available: {formatCurrency(wallet.balance)}
                        </p>
                      </div>
                      
                      <div>
                        <Label htmlFor="withdrawal-method">Withdrawal Method</Label>
                        <Select value={withdrawalMethod} onValueChange={setWithdrawalMethod}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select withdrawal method" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                            <SelectItem value="paypal">PayPal</SelectItem>
                            <SelectItem value="mobile_money">Mobile Money</SelectItem>
                            <SelectItem value="payoneer">Payoneer Transfer</SelectItem>
                            <SelectItem value="cryptocurrency">Cryptocurrency</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="withdrawal-details">Payment Details (JSON format)</Label>
                        <Textarea
                          id="withdrawal-details"
                          placeholder='{"accountNumber": "1234567890", "routingNumber": "021000021"}'
                          value={withdrawalDetails}
                          onChange={(e) => setWithdrawalDetails(e.target.value)}
                          className="h-24"
                        />
                        <p className="text-sm text-gray-500 mt-1">
                          Provide account details for your chosen withdrawal method
                        </p>
                      </div>
                      
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                        <p className="text-sm text-yellow-800">
                          <strong>Transaction Fee:</strong> $2.50 (deducted from withdrawal amount)
                        </p>
                        <p className="text-sm text-yellow-800">
                          <strong>Processing Time:</strong> 1-5 business days depending on method
                        </p>
                      </div>
                      
                      <Button 
                        onClick={() => withdrawMutation.mutate()}
                        disabled={
                          !withdrawAmount || 
                          !withdrawalMethod || 
                          !withdrawalDetails ||
                          withdrawMutation.isPending ||
                          parseFloat(withdrawAmount) <= 0 ||
                          parseFloat(withdrawAmount) > parseFloat(wallet.balance)
                        }
                        className="w-full"
                      >
                        {withdrawMutation.isPending ? "Processing..." : `Withdraw $${withdrawAmount || "0.00"}`}
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="history" className="space-y-6">
                  {/* All Transactions */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Transaction History</CardTitle>
                      <CardDescription>Complete record of all wallet transactions</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {transactionsLoading ? (
                        <div className="text-center py-4">Loading transactions...</div>
                      ) : transactions.length === 0 ? (
                        <div className="text-center py-8 text-gray-500">
                          No transactions yet
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {transactions.map((transaction) => (
                            <div key={transaction.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                              <div className="flex items-center space-x-3">
                                {getTransactionIcon(transaction.transactionType)}
                                <div>
                                  <p className="font-medium">{transaction.description}</p>
                                  <p className="text-sm text-gray-500">
                                    {formatDate(transaction.createdAt)} • {transaction.sourceType}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className={`font-medium ${transaction.transactionType === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                                  {transaction.transactionType === 'credit' ? '+' : '-'}{formatCurrency(transaction.amount)}
                                </p>
                                <div className="flex items-center space-x-2">
                                  {getStatusBadge(transaction.status)}
                                  <span className="text-sm text-gray-500">
                                    Balance: {formatCurrency(transaction.balanceAfter)}
                                  </span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Withdrawal History */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Withdrawal History</CardTitle>
                      <CardDescription>Track all your withdrawal requests and their status</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {withdrawalsLoading ? (
                        <div className="text-center py-4">Loading withdrawals...</div>
                      ) : withdrawals.length === 0 ? (
                        <div className="text-center py-8 text-gray-500">
                          No withdrawals yet
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {withdrawals.map((withdrawal) => (
                            <div key={withdrawal.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                              <div>
                                <p className="font-medium">
                                  {withdrawal.withdrawalMethod.replace('_', ' ').toUpperCase()} Withdrawal
                                </p>
                                <p className="text-sm text-gray-500">
                                  {formatDate(withdrawal.createdAt)}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="font-medium text-red-600">
                                  -{formatCurrency(withdrawal.amount)}
                                </p>
                                <p className="text-sm text-gray-500">
                                  Net: {formatCurrency(withdrawal.netAmount)} (Fee: {formatCurrency(withdrawal.transactionFee)})
                                </p>
                                {getStatusBadge(withdrawal.status)}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </div>
      </div>
    </>
  );
}