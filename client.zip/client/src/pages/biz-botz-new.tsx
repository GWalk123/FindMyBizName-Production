import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Bot, MessageCircle, Send, Star } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import SEOHead from "@/components/seo-head";

interface SupportBot {
  id: string;
  name: string;
  description: string;
  specialty: string;
  avatar: string;
  status: 'online' | 'busy' | 'offline';
  responseTime: string;
  accuracy: number;
  totalChats: number;
  languages: string[];
}

interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: string;
  sessionId: string;
  botId?: string;
  metadata?: {
    confidence?: number;
    processingTime?: string;
    source?: string;
  };
}

export default function BizBotzNew() {
  const [selectedBot, setSelectedBot] = useState<string>("");
  const [currentMessage, setCurrentMessage] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeSession, setActiveSession] = useState<string>("");
  const { toast } = useToast();

  // Fetch support bots with direct fetch
  const [supportBots, setSupportBots] = useState<SupportBot[]>([]);
  const [botsLoading, setBotsLoading] = useState(true);

  useEffect(() => {
    const fetchBots = async () => {
      try {
        console.log('🤖 Starting to fetch support bots...');
        const response = await fetch('/api/support-bots');
        console.log('📡 Response status:', response.status);
        const data = await response.json();
        console.log('✅ Fetched bots data:', data);
        console.log('📊 Number of bots:', data.length);
        setSupportBots(Array.isArray(data) ? data : []);
        setBotsLoading(false);
        console.log('🏁 Bot loading complete');
      } catch (error) {
        console.error('❌ Error fetching bots:', error);
        setBotsLoading(false);
      }
    };

    console.log('🚀 useEffect triggered - fetching bots');
    fetchBots();
  }, []);

  const sendMessage = async () => {
    if (!currentMessage.trim() || !selectedBot) {
      console.log('Cannot send - no message or bot selected');
      return;
    }

    console.log('Sending message:', currentMessage, 'to bot:', selectedBot);

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      type: 'user',
      content: currentMessage,
      timestamp: new Date().toISOString(),
      sessionId: activeSession || `session-${Date.now()}`
    };

    // Add user message immediately
    setMessages(prev => [...prev, userMessage]);
    const messageToSend = currentMessage;
    setCurrentMessage("");

    try {
      const response = await apiRequest("POST", "/api/support-bots/chat", {
        botId: selectedBot,
        message: messageToSend,
        sessionId: userMessage.sessionId
      });

      const data = await response.json();

      const botMessage: ChatMessage = {
        id: `bot-${Date.now()}`,
        type: 'bot',
        content: data.response,
        timestamp: new Date().toISOString(),
        sessionId: data.sessionId,
        botId: selectedBot,
        metadata: data.metadata
      };

      setMessages(prev => [...prev, botMessage]);
      
      if (!activeSession) {
        setActiveSession(data.sessionId);
      }

      toast({
        title: "Message Sent",
        description: "Bot responded successfully!",
      });

    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const startNewChat = (botId: string) => {
    console.log('🎯 CLICK DETECTED! Starting new chat with bot:', botId);
    console.log('🔄 Setting selected bot to:', botId);
    setSelectedBot(botId);
    setActiveSession("");
    setMessages([]);
    setCurrentMessage("");
    console.log('✅ Bot selection complete');
  };

  const getBotStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-100 text-green-800';
      case 'busy': return 'bg-yellow-100 text-yellow-800';
      case 'offline': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const selectedBotData = supportBots.find(bot => bot.id === selectedBot);

  if (botsLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="h-96 bg-gray-200 rounded-lg"></div>
            <div className="lg:col-span-2 h-96 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <SEOHead 
        title="Biz Botz - AI Customer Support | FindMyBizName"
        description="24/7 AI-powered customer support for entrepreneurs worldwide. Get expert guidance on business strategy, naming, payments, and global markets."
        keywords="AI customer support, business advice, entrepreneur support, 24/7 chat"
      />

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Biz Botz 🤖
        </h1>
        <p className="text-gray-600">
          AI-powered customer support available 24/7 for all your business questions
        </p>
        
        {/* Debug Info */}
        <div className="mt-4 p-4 bg-gray-100 rounded-lg">
          <h3 className="font-semibold">Debug Info:</h3>
          <p>Bots Loading: {botsLoading ? 'Yes' : 'No'}</p>
          <p>Number of Bots: {supportBots.length}</p>
          <p>Selected Bot: {selectedBot || 'None'}</p>
          <p>Active Session: {activeSession || 'None'}</p>
          <Button onClick={() => console.log('🧪 TEST CLICK DETECTED!')} className="mt-2">
            Test Click Detection
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Bot Selection Sidebar */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold mb-4">Available Support Bots ({supportBots.length})</h3>
          
          {supportBots.map((bot) => (
            <Card 
              key={bot.id} 
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedBot === bot.id ? 'ring-2 ring-blue-500 border-blue-500' : ''
              }`}
              onClick={() => startNewChat(bot.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                      <Bot className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{bot.name}</CardTitle>
                      <CardDescription className="text-sm">{bot.specialty}</CardDescription>
                    </div>
                  </div>
                  <Badge className={getBotStatusColor(bot.status)}>
                    {bot.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">{bot.description}</p>
                
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>~{bot.responseTime} response</span>
                  <span>{bot.accuracy}% accuracy</span>
                </div>
                
                <div className="flex items-center gap-1 mt-2">
                  <Star className="h-3 w-3 text-yellow-500 fill-current" />
                  <span className="text-xs text-gray-600">{bot.totalChats.toLocaleString()} chats</span>
                </div>
                
                <div className="flex flex-wrap gap-1 mt-2">
                  {bot.languages.slice(0, 3).map((lang, index) => (
                    <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                      {lang}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Chat Interface */}
        <div className="lg:col-span-2">
          <Card className="h-[600px] flex flex-col">
            {selectedBot ? (
              <>
                {/* Chat Header */}
                <CardHeader className="border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                        <Bot className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{selectedBotData?.name}</h4>
                        <p className="text-sm text-gray-600">{selectedBotData?.specialty}</p>
                      </div>
                    </div>
                    <Badge className={getBotStatusColor(selectedBotData?.status || 'offline')}>
                      {selectedBotData?.status}
                    </Badge>
                  </div>
                </CardHeader>

                {/* Messages */}
                <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.length === 0 && (
                    <div className="text-center py-8">
                      <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        Start a conversation
                      </h3>
                      <p className="text-gray-600">
                        Ask me anything about your business needs. I'm here to help!
                      </p>
                    </div>
                  )}

                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[80%] rounded-lg p-3 ${
                        message.type === 'user' 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-gray-100 text-gray-900'
                      }`}>
                        <p className="text-sm">{message.content}</p>
                        
                        <div className="flex items-center justify-between mt-2 text-xs opacity-70">
                          <span>{new Date(message.timestamp).toLocaleTimeString()}</span>
                          {message.metadata?.confidence && (
                            <span>
                              {Math.round(message.metadata.confidence * 100)}% confidence
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>

                {/* Message Input */}
                <div className="border-t p-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your message..."
                      value={currentMessage}
                      onChange={(e) => setCurrentMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    />
                    <Button 
                      onClick={sendMessage}
                      disabled={!currentMessage.trim()}
                      size="sm"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                    <span>Press Enter to send</span>
                    <span>Response time: ~{selectedBotData?.responseTime}</span>
                  </div>
                </div>
              </>
            ) : (
              <CardContent className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Select a Support Bot
                  </h3>
                  <p className="text-gray-600">
                    Choose a specialized bot from the sidebar to start getting help with your business questions.
                  </p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>

      {/* Back to Home */}
      <div className="mt-8 text-center">
        <Link href="/">
          <Button variant="outline">
            ← Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}