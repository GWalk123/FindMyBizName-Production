import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DomainInfo {
  available: boolean;
  price?: number;
  premium?: boolean;
}

interface GeneratedName {
  id: number;
  name: string;
  description?: string;
  domains: Record<string, DomainInfo>;
  isFavorite: boolean;
  createdAt: string;
}

export default function StableTest() {
  const [description, setDescription] = useState('coffee shop');
  const [names, setNames] = useState<GeneratedName[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!description.trim()) return;
    
    setIsLoading(true);
    setError(null);
    setNames([]);
    
    try {
      const response = await fetch('/api/generate-names', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: description.trim(),
          checkDomains: true,
        })
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server error: ${response.status} - ${errorText}`);
      }
      
      const result = await response.json();
      console.log('API Response:', result);
      
      if (result && result.names && Array.isArray(result.names) && result.names.length > 0) {
        setNames(result.names);
      } else {
        setError('No names generated - please try a different description');
      }
    } catch (err: any) {
      console.error('Generation error:', err);
      setError(err.message || 'Failed to generate names');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-blue-600 mb-2">FindMyBizName</h1>
          <p className="text-gray-600">Stable Business Name Generator Test</p>
        </div>

        {/* Generator */}
        <Card className="mb-8 border-2 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-700">🚀 Generate Business Names</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Describe your business:
                </label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g., coffee shop, tech startup, restaurant"
                  className="w-full"
                  disabled={isLoading}
                />
              </div>
              
              <Button 
                onClick={handleGenerate}
                disabled={isLoading || !description.trim()}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                {isLoading ? (
                  <span className="flex items-center justify-center">
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                    Generating Names...
                  </span>
                ) : (
                  'Generate Business Names'
                )}
              </Button>
            </div>
            
            {error && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-700 font-medium">Error:</p>
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results */}
        {names.length > 0 && (
          <Card className="border-2 border-green-200">
            <CardHeader>
              <CardTitle className="text-green-700">
                ✅ Generated {names.length} Business Names
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {names.slice(0, 8).map((name) => (
                  <div key={name.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                    <h3 className="text-xl font-bold text-gray-900 mb-3">{name.name}</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {Object.entries(name.domains).map(([tld, info]) => (
                        <div 
                          key={tld}
                          className={`p-2 rounded text-center text-sm font-medium ${
                            info.available 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          <div className="font-bold">.{tld}</div>
                          {info.available ? (
                            <div>${(info.price! / 1000000).toFixed(2)}/yr</div>
                          ) : (
                            <div>Taken</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}