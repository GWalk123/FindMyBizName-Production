import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, ArrowLeft, CreditCard, Shield, Clock, Crown } from "lucide-react";
import { Link } from "wouter";
import SEOHead from "@/components/seo-head";
import { useAnalytics } from "@/components/analytics-tracker";
import { MoneyBackGuarantee } from "@/components/marketing-features";
import PaymentContactForm from "@/components/payment-contact-form";

const PayPalSubscribeForm = ({ plan, planDetails }: { plan: string, planDetails: any }) => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [contactFormOpen, setContactFormOpen] = useState(false);
  const [contactFormType, setContactFormType] = useState<'bank-transfer' | 'mobile-money'>('bank-transfer');

  const handleWiPaySubscribe = async () => {
    // Open manual payment form for WiPay personal account processing
    setContactFormType('bank-transfer');
    setContactFormOpen(true);
  };

  const handlePayPalSubscribe = async () => {
    setIsLoading(true);
    try {
      // Create PayPal subscription
      const response = await apiRequest("POST", "/api/create-paypal-subscription", { plan });
      const data = await response.json();
      
      if (data.approvalUrl) {
        // Redirect to PayPal for approval
        window.location.href = data.approvalUrl;
      } else {
        throw new Error("Failed to create PayPal subscription");
      }
    } catch (error) {
      toast({
        title: "Payment Error",
        description: "Unable to create subscription. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg p-4 mb-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-2 text-center">
          🌍 Supporting Real Entrepreneurs Worldwide
        </h3>
        <p className="text-sm text-gray-600 text-center">
          Caribbean-first platform serving underbanked entrepreneurs globally - we understand cash-based economies
        </p>
      </div>
      
      <div className="space-y-4">
        <div className="text-sm text-gray-700 font-medium">
          What you'll get with {planDetails.name}:
        </div>
        <ul className="space-y-2">
          {planDetails.features.map((feature: string, index: number) => (
            <li key={index} className="flex items-center space-x-2 text-sm">
              <Check className="w-4 h-4 text-green-500" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Payment Option 1: WiPay Personal Account (Week 1 Ready) */}
      <div className="border border-green-200 rounded-lg p-4 bg-green-50">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-green-600" />
            <span className="font-medium text-green-800">🇹🇹 WiPay Personal - Direct Payment</span>
          </div>
          <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Week 1 Ready</span>
        </div>
        <p className="text-sm text-green-700 mb-3">
          Personal WiPay account • All T&T bank cards • Republic Bank transfer • Immediate processing
        </p>
        <Button 
          onClick={handleWiPaySubscribe}
          disabled={isLoading}
          className="w-full bg-green-600 hover:bg-green-700"
        >
          {isLoading ? "Processing..." : `Get WiPay Details - ${planDetails.price}/month`}
        </Button>
      </div>

      {/* Payment Option 2: PayPal (Global Standard) */}
      <div className="border border-blue-200 rounded-lg p-4 bg-blue-50">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <span className="font-medium text-blue-800">🌐 PayPal - Global Standard</span>
          </div>
          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Instant</span>
        </div>
        <p className="text-sm text-blue-700 mb-3">
          Credit/Debit cards worldwide • Instant processing • Secure checkout
        </p>
        <Button 
          onClick={handlePayPalSubscribe}
          disabled={isLoading}
          className="w-full bg-blue-600 hover:bg-blue-700"
        >
          {isLoading ? "Processing..." : `Pay ${planDetails.price}/month with PayPal`}
        </Button>
      </div>

      {/* Payment Option 2: Bank Transfer (Caribbean Trust) */}
      <div className="border border-green-200 rounded-lg p-4 bg-green-50">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-green-600" />
            <span className="font-medium text-green-800">🏦 Bank Transfer - Global Network</span>
          </div>
          <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">1-2 Days</span>
        </div>
        <p className="text-sm text-green-700 mb-3">
          All banks worldwide • SWIFT transfers • Caribbean, Africa, Asia, Europe
        </p>
        <Button 
          onClick={() => {
            setContactFormType('bank-transfer');
            setContactFormOpen(true);
          }}
          variant="outline" 
          className="w-full border-green-600 text-green-700 hover:bg-green-100"
        >
          Get Bank Transfer Details
        </Button>
      </div>

      {/* Payment Option 3: Mobile Money (Local Innovation) */}
      <div className="border border-purple-200 rounded-lg p-4 bg-purple-50">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-purple-600" />
            <span className="font-medium text-purple-800">📱 Mobile Money - Global Innovation</span>
          </div>
          <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded">Instant</span>
        </div>
        <p className="text-sm text-purple-700 mb-3">
          M-Pesa, GCash, MTN, Digicel & more • Phone-based payments • No credit card needed
        </p>
        <Button 
          onClick={() => {
            setContactFormType('mobile-money');
            setContactFormOpen(true);
          }}
          variant="outline" 
          className="w-full border-purple-600 text-purple-700 hover:bg-purple-100"
        >
          Pay with Mobile Money
        </Button>
      </div>
      
      <div className="text-center pt-4 border-t">
        <p className="text-xs text-gray-500">
          🔒 All payment methods are secure and verified. Manual processing within 2 hours during business hours.
        </p>
        <p className="text-xs text-gray-500 mt-1">
          <strong>Empowering entrepreneurs worldwide!</strong> • Cancel anytime • 30-day money-back guarantee
        </p>
      </div>

      <PaymentContactForm
        isOpen={contactFormOpen}
        onClose={() => setContactFormOpen(false)}
        paymentMethod={contactFormType}
        plan={planDetails.name}
        amount={planDetails.price}
      />
    </div>
  );
};

export default function Subscribe() {
  const [plan, setPlan] = useState("premium");
  const [isLoading, setIsLoading] = useState(false);
  const { trackPageView, trackConversion } = useAnalytics();

  useEffect(() => {
    // Get plan from URL params
    const params = new URLSearchParams(window.location.search);
    const planParam = params.get("plan");
    if (planParam) {
      setPlan(planParam);
    }
    
    trackPageView(`subscribe_${plan}`);
  }, [plan, trackPageView]);

  const planDetails = {
    premium: {
      name: "Premium",
      price: "$9.99",
      features: [
        "Unlimited name generations",
        "Premium domains (.ai, .co)",
        "Advanced logo previews",
        "Priority support"
      ]
    },
    pro: {
      name: "Pro",
      price: "$19.99", 
      features: [
        "Everything in Premium",
        "Bulk domain checking",
        "Trademark screening",
        "Competitor analysis"
      ]
    }
  };

  const currentPlan = planDetails[plan as keyof typeof planDetails] || planDetails.premium;



  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <SEOHead 
        title={`Subscribe to ${currentPlan.name} - FindMyBizName`}
        description={`Upgrade to ${currentPlan.name} for unlimited business name generation and premium features. PayPal payment available for Trinidad & Tobago.`}
        keywords="business name generator subscription, PayPal Trinidad Tobago, premium business tools, startup names unlimited"
      />
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to FindMyBizName
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Subscribe to {currentPlan.name}
          </h1>
          <p className="text-gray-600">
            Unlock unlimited business name generation and premium features
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Plan Details */}
          <Card>
            <CardHeader>
              <CardTitle className="text-center">
                {currentPlan.name} Plan
                <div className="text-3xl font-bold text-primary mt-2">
                  {currentPlan.price}
                  <span className="text-sm font-normal text-gray-600">/month</span>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {currentPlan.features.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Payment Form */}
          <Card>
            <CardHeader>
              <CardTitle>Subscribe Now</CardTitle>
            </CardHeader>
            <CardContent>
              <PayPalSubscribeForm plan={plan} planDetails={currentPlan} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}