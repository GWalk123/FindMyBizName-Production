import { useEffect } from "react";
import SEOHead from "@/components/seo-head";
import { Link } from "wouter";

export default function BizBotzDirect() {
  useEffect(() => {
    // Create the page content directly in the DOM to bypass React rendering issues
    const container = document.getElementById('biz-botz-container');
    if (!container) return;

    container.innerHTML = `
      <div class="space-y-6">
        <div class="text-center mb-8">
          <h2 class="text-2xl font-bold text-gray-900 mb-4">Biz Botz - AI Customer Support</h2>
          <p class="text-gray-600">24/7 AI-powered support for entrepreneurs worldwide</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div id="bot-business-advisor" class="bot-card bg-white border-2 border-gray-200 rounded-lg p-6 cursor-pointer hover:border-blue-500 hover:shadow-lg transition-all">
            <div class="flex items-center gap-4 mb-4">
              <div class="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl">🎯</div>
              <div>
                <h3 class="font-bold text-lg">Business Advisor Bot</h3>
                <p class="text-sm text-gray-600">Business Strategy & Planning</p>
              </div>
            </div>
            <p class="text-gray-600 mb-3">Expert guidance on business strategy, planning, and growth for underbanked entrepreneurs</p>
            <div class="flex items-center justify-between">
              <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">Online</span>
              <span class="text-sm text-gray-500">94% accuracy</span>
            </div>
          </div>

          <div id="bot-naming-expert" class="bot-card bg-white border-2 border-gray-200 rounded-lg p-6 cursor-pointer hover:border-blue-500 hover:shadow-lg transition-all">
            <div class="flex items-center gap-4 mb-4">
              <div class="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white text-xl">🏷️</div>
              <div>
                <h3 class="font-bold text-lg">Naming Expert Bot</h3>
                <p class="text-sm text-gray-600">Business Naming & Branding</p>
              </div>
            </div>
            <p class="text-gray-600 mb-3">Specialized AI for business naming, branding, and domain strategy with global market insights</p>
            <div class="flex items-center justify-between">
              <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">Online</span>
              <span class="text-sm text-gray-500">97% accuracy</span>
            </div>
          </div>

          <div id="bot-payment-specialist" class="bot-card bg-white border-2 border-gray-200 rounded-lg p-6 cursor-pointer hover:border-blue-500 hover:shadow-lg transition-all">
            <div class="flex items-center gap-4 mb-4">
              <div class="w-12 h-12 bg-yellow-600 rounded-full flex items-center justify-center text-white text-xl">💳</div>
              <div>
                <h3 class="font-bold text-lg">Payment Solutions Bot</h3>
                <p class="text-sm text-gray-600">Alternative Payments & Fintech</p>
              </div>
            </div>
            <p class="text-gray-600 mb-3">Expert help with alternative payment methods, crypto integration, and financial inclusion</p>
            <div class="flex items-center justify-between">
              <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">Online</span>
              <span class="text-sm text-gray-500">91% accuracy</span>
            </div>
          </div>

          <div id="bot-global-markets" class="bot-card bg-white border-2 border-gray-200 rounded-lg p-6 cursor-pointer hover:border-blue-500 hover:shadow-lg transition-all">
            <div class="flex items-center gap-4 mb-4">
              <div class="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center text-white text-xl">🌍</div>
              <div>
                <h3 class="font-bold text-lg">Global Markets Bot</h3>
                <p class="text-sm text-gray-600">Global Market Access</p>
              </div>
            </div>
            <p class="text-gray-600 mb-3">Specialized guidance for underbanked entrepreneurs across different regions and cultures</p>
            <div class="flex items-center justify-between">
              <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">Online</span>
              <span class="text-sm text-gray-500">89% accuracy</span>
            </div>
          </div>
        </div>

        <div id="chat-section" class="hidden">
          <div class="bg-white border rounded-lg p-6">
            <div id="chat-header" class="border-b pb-4 mb-4">
              <h3 class="font-bold text-lg">Chat with <span id="selected-bot-name">Bot</span></h3>
            </div>
            
            <div id="chat-messages" class="space-y-4 mb-6 h-64 overflow-y-auto">
              <div class="text-center text-gray-500 py-8">
                <p>Start a conversation with your selected bot!</p>
              </div>
            </div>
            
            <div class="flex gap-2">
              <input 
                id="message-input" 
                type="text" 
                placeholder="Type your message..." 
                class="flex-1 border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button 
                id="send-button" 
                class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Send
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Add click handlers directly
    const botCards = container.querySelectorAll('.bot-card');
    let selectedBotId = '';
    let selectedBotName = '';

    botCards.forEach(card => {
      card.addEventListener('click', function() {
        // Remove previous selection
        botCards.forEach(c => {
          c.classList.remove('border-blue-500', 'bg-blue-50');
          c.classList.add('border-gray-200');
        });
        
        // Add selection to clicked card
        this.classList.remove('border-gray-200');
        this.classList.add('border-blue-500', 'bg-blue-50');
        
        // Get bot info
        selectedBotId = this.id.replace('bot-', '');
        selectedBotName = this.querySelector('h3').textContent;
        
        // Show chat section
        const chatSection = container.querySelector('#chat-section');
        const botNameSpan = container.querySelector('#selected-bot-name');
        if (chatSection && botNameSpan) {
          chatSection.classList.remove('hidden');
          botNameSpan.textContent = selectedBotName;
        }
        
        // Clear previous messages
        const messagesDiv = container.querySelector('#chat-messages');
        if (messagesDiv) {
          messagesDiv.innerHTML = '<div class="text-center text-gray-500 py-8"><p>Start a conversation with ' + selectedBotName + '!</p></div>';
        }
        
        console.log('Bot selected:', selectedBotId, selectedBotName);
      });
    });

    // Add send message handler
    const sendButton = container.querySelector('#send-button');
    const messageInput = container.querySelector('#message-input');
    
    const sendMessage = async () => {
      const message = messageInput.value.trim();
      if (!message || !selectedBotId) return;
      
      const messagesDiv = container.querySelector('#chat-messages');
      if (!messagesDiv) return;
      
      // Add user message
      const userMessageDiv = document.createElement('div');
      userMessageDiv.className = 'flex justify-end';
      userMessageDiv.innerHTML = \`
        <div class="bg-blue-600 text-white rounded-lg px-4 py-2 max-w-xs">
          <p>\${message}</p>
          <div class="text-xs opacity-70 mt-1">\${new Date().toLocaleTimeString()}</div>
        </div>
      \`;
      messagesDiv.appendChild(userMessageDiv);
      messageInput.value = '';
      
      // Add thinking indicator
      const thinkingDiv = document.createElement('div');
      thinkingDiv.className = 'flex justify-start';
      thinkingDiv.innerHTML = \`
        <div class="bg-gray-100 text-gray-900 rounded-lg px-4 py-2">
          <p>Thinking...</p>
        </div>
      \`;
      messagesDiv.appendChild(thinkingDiv);
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
      
      try {
        const response = await fetch('/api/support-bots/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            botId: selectedBotId,
            message: message,
            sessionId: 'session-' + Date.now()
          })
        });
        
        const data = await response.json();
        
        // Remove thinking indicator
        messagesDiv.removeChild(thinkingDiv);
        
        // Add bot response
        const botMessageDiv = document.createElement('div');
        botMessageDiv.className = 'flex justify-start';
        botMessageDiv.innerHTML = \`
          <div class="bg-gray-100 text-gray-900 rounded-lg px-4 py-2 max-w-xs">
            <p>\${data.response}</p>
            <div class="text-xs opacity-70 mt-1">\${new Date().toLocaleTimeString()}</div>
          </div>
        \`;
        messagesDiv.appendChild(botMessageDiv);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
        
      } catch (error) {
        messagesDiv.removeChild(thinkingDiv);
        console.error('Error:', error);
      }
    };
    
    sendButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') sendMessage();
    });

  }, []);

  return (
    <div className="container mx-auto px-4 py-8">
      <SEOHead 
        title="Biz Botz - AI Customer Support | FindMyBizName"
        description="24/7 AI-powered customer support for entrepreneurs worldwide"
        keywords="AI customer support, business advice, entrepreneur support"
      />

      <div id="biz-botz-container" className="min-h-screen">
        <div className="text-center py-12">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Biz Botz...</p>
        </div>
      </div>

      <div className="mt-8 text-center">
        <Link href="/">
          <button className="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition-colors">
            ← Back to Home
          </button>
        </Link>
      </div>
    </div>
  );
}