import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DomainInfo {
  available: boolean;
  price?: number;
  premium?: boolean;
}

interface GeneratedName {
  id: number;
  name: string;
  description?: string;
  domains: Record<string, DomainInfo>;
  isFavorite: boolean;
  createdAt: string;
}

export default function SimpleTest() {
  const [description, setDescription] = useState('coffee shop');
  const [names, setNames] = useState<GeneratedName[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/generate-names', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description,
          checkDomains: true,
        })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await response.json();
      console.log('Generated names:', result);
      
      if (result && result.names && Array.isArray(result.names) && result.names.length > 0) {
        setNames(result.names);
      } else {
        console.warn('Invalid response format:', result);
        setError('No names generated - check server logs');
      }
    } catch (err: any) {
      console.error('Generation error:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>🧪 Simple Name Generator Test</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <label className="block text-sm font-medium mb-2">Business Description</label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g., coffee shop, restaurant, gym"
                />
              </div>
              <Button 
                onClick={handleGenerate} 
                disabled={isLoading || !description.trim()}
                className="min-w-32"
              >
                {isLoading ? 'Generating...' : 'Generate Names'}
              </Button>
            </div>
            
            {error && (
              <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
                Error: {error}
              </div>
            )}
          </CardContent>
        </Card>

        {names.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>✅ Generated Names ({names.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {names.slice(0, 6).map((name) => (
                  <div key={name.id} className="border border-gray-200 rounded-lg p-4">
                    <h3 className="text-xl font-bold text-blue-600 mb-3">{name.name}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                      {Object.entries(name.domains).map(([tld, info]) => (
                        <div key={tld} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                          <span className="text-sm font-medium">
                            {name.name.toLowerCase()}.{tld}
                          </span>
                          <span className={`text-sm font-medium ${
                            info.available ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {info.available ? `$${(info.price! / 1000000).toFixed(2)}/yr` : 'Taken'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}