import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Newspaper, 
  Search, 
  Clock, 
  ExternalLink, 
  Filter, 
  TrendingUp,
  Globe,
  MapPin,
  Tag,
  BookOpen
} from "lucide-react";
import { Link } from "wouter";

interface NewsArticle {
  id: string;
  title: string;
  summary: string;
  content: string;
  source: string;
  category: string;
  region: string;
  url: string;
  relevanceScore: number;
  tags: string[];
  readTime: number;
  publishedAt: string;
}

interface NewsCategory {
  id: string;
  name: string;
  description: string;
  color: string;
  count: number;
}

export default function BizNewz() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedRegion, setSelectedRegion] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: categories = [], isLoading: categoriesLoading, error: categoriesError } = useQuery<NewsCategory[]>({
    queryKey: ["/api/news/categories"],
    queryFn: async () => {
      const response = await fetch('/api/news/categories');
      if (!response.ok) throw new Error('Failed to load categories');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
    staleTime: 5 * 60 * 1000,
  });

  const { data: articles = [], isLoading: articlesLoading, error: articlesError } = useQuery<NewsArticle[]>({
    queryKey: ["/api/news/articles"],
    queryFn: async () => {
      const response = await fetch('/api/news/articles');
      if (!response.ok) throw new Error('Failed to load articles');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
    staleTime: 5 * 60 * 1000,
  });

  const { data: trendingTopics = [], isLoading: trendingLoading, error: trendingError } = useQuery<string[]>({
    queryKey: ["/api/news/trending"],
    queryFn: async () => {
      const response = await fetch('/api/news/trending');
      if (!response.ok) throw new Error('Failed to load trending topics');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
    staleTime: 5 * 60 * 1000,
  });

  const filteredArticles = articles.filter(article => {
    const matchesCategory = selectedCategory === "all" || article.category === selectedCategory;
    const matchesRegion = selectedRegion === "all" || article.region === selectedRegion;
    const matchesSearch = searchQuery === "" || 
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    return matchesCategory && matchesRegion && matchesSearch;
  });

  const getCategoryColor = (color: string) => {
    const colorMap: Record<string, string> = {
      green: "bg-green-100 text-green-800 border-green-200",
      blue: "bg-superman-blue/10 text-superman-blue border-superman-blue/20",
      purple: "bg-purple-100 text-purple-800 border-purple-200",
      orange: "bg-orange-100 text-orange-800 border-orange-200",
      red: "bg-superman-red/10 text-superman-red border-superman-red/20",
      teal: "bg-teal-100 text-teal-800 border-teal-200",
    };
    return colorMap[color] || "bg-gray-100 text-gray-800 border-gray-200";
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const published = new Date(timestamp);
    const diff = now.getTime() - published.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    return "Just now";
  };

  if (categoriesLoading || articlesLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="h-96 bg-gray-200 rounded-lg"></div>
            <div className="lg:col-span-3 space-y-4">
              <div className="h-32 bg-gray-200 rounded-lg"></div>
              <div className="h-32 bg-gray-200 rounded-lg"></div>
              <div className="h-32 bg-gray-200 rounded-lg"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
          <Newspaper className="h-8 w-8 text-superman-blue" />
          Biz Newz 📰
        </h1>
        <p className="text-gray-600">
          Stay updated with the latest business news, trends, and opportunities for entrepreneurs worldwide
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Search */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Search className="h-5 w-5" />
                Search News
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Input
                placeholder="Search articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
            </CardContent>
          </Card>

          {/* Categories */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Button
                  variant={selectedCategory === "all" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedCategory("all")}
                >
                  All Categories
                </Button>
                {categories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "ghost"}
                    className="w-full justify-between"
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <span>{category.name}</span>
                    <Badge variant="outline" className="ml-2">
                      {category.count}
                    </Badge>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Regions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Regions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Button
                  variant={selectedRegion === "all" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedRegion("all")}
                >
                  All Regions
                </Button>
                <Button
                  variant={selectedRegion === "global" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedRegion("global")}
                >
                  <Globe className="h-4 w-4 mr-2" />
                  Global
                </Button>
                <Button
                  variant={selectedRegion === "africa" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedRegion("africa")}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Africa
                </Button>
                <Button
                  variant={selectedRegion === "latinamerica" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedRegion("latinamerica")}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Latin America
                </Button>
                <Button
                  variant={selectedRegion === "asia" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedRegion("asia")}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Asia
                </Button>
                <Button
                  variant={selectedRegion === "philippines" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedRegion("philippines")}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Philippines
                </Button>
                <Button
                  variant={selectedRegion === "europe" ? "default" : "ghost"}
                  className="w-full justify-start"
                  onClick={() => setSelectedRegion("europe")}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Europe
                </Button>
                <Button
                  variant={selectedRegion === "caribbean" ? "default" : "ghost"}
                  className="w-full justify-start" 
                  onClick={() => setSelectedRegion("caribbean")}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Caribbean
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Trending Topics */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-superman-red" />
                Trending
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {trendingTopics.map((topic, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="w-full justify-start text-left h-auto py-2 px-3"
                    onClick={() => setSearchQuery(topic)}
                  >
                    <Tag className="h-3 w-3 mr-2 text-superman-yellow" />
                    {topic}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          {/* Results Header */}
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">
              {filteredArticles.length} {filteredArticles.length === 1 ? 'Article' : 'Articles'}
              {selectedCategory !== "all" && (
                <span className="text-gray-500"> in {categories.find(c => c.id === selectedCategory)?.name}</span>
              )}
            </h2>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <span className="text-sm text-gray-500">Latest first</span>
            </div>
          </div>

          {/* Articles */}
          <div className="space-y-4">
            {filteredArticles.length === 0 ? (
              <Card>
                <CardContent className="flex items-center justify-center py-12">
                  <div className="text-center">
                    <Newspaper className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      No articles found
                    </h3>
                    <p className="text-gray-600">
                      Try adjusting your filters or search terms to find relevant articles.
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              filteredArticles.map((article) => (
                <Card key={article.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className={getCategoryColor(categories.find(c => c.id === article.category)?.color || "gray")}>
                            {categories.find(c => c.id === article.category)?.name || article.category}
                          </Badge>
                          <Badge variant="outline">
                            {article.region === "global" ? (
                              <><Globe className="h-3 w-3 mr-1" /> Global</>
                            ) : (
                              <><MapPin className="h-3 w-3 mr-1" /> {article.region}</>
                            )}
                          </Badge>
                          <span className="text-sm text-gray-500 flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {formatTimeAgo(article.publishedAt)}
                          </span>
                        </div>
                        <CardTitle className="text-lg mb-2 hover:text-superman-blue cursor-pointer">
                          {article.title}
                        </CardTitle>
                        <CardDescription className="text-sm line-clamp-2">
                          {article.summary}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <BookOpen className="h-3 w-3" />
                          {article.readTime} min read
                        </span>
                        <span>by {article.source}</span>
                        <span className="text-superman-blue font-medium">
                          {article.relevanceScore}% relevance
                        </span>
                      </div>
                      <Button size="sm" variant="outline" className="flex items-center gap-1">
                        <ExternalLink className="h-3 w-3" />
                        Read More
                      </Button>
                    </div>
                    
                    {article.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-3">
                        {article.tags.slice(0, 4).map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {article.tags.length > 4 && (
                          <Badge variant="secondary" className="text-xs">
                            +{article.tags.length - 4} more
                          </Badge>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Back to Home */}
      <div className="mt-8 text-center">
        <Link href="/">
          <Button variant="outline">
            ← Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}