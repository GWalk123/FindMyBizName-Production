import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { MessageCircle, Users, Send, Globe, TrendingUp, Heart } from "lucide-react";
import Header from "@/components/header";
import { useQuery } from "@tanstack/react-query";
import { type UserProfile } from "@shared/schema";

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  userType: 'entrepreneur' | 'supporter' | 'premium';
}

interface ConnectedUser {
  id: string;
  username: string;
  userType: 'entrepreneur' | 'supporter' | 'premium';
  location?: string;
}

export default function Community() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [connectedUsers, setConnectedUsers] = useState<ConnectedUser[]>([]);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting');
  const [username, setUsername] = useState('');

  // Fetch user profile to get stored username
  const { data: userProfile } = useQuery<UserProfile>({
    queryKey: ['/api/profile'],
    retry: false,
  });

  useEffect(() => {
    const generateUsername = () => {
      const adjectives = ['Creative', 'Innovative', 'Ambitious', 'Visionary', 'Dynamic', 'Strategic', 'Bold', 'Rising'];
      const nouns = ['Entrepreneur', 'Founder', 'Innovator', 'Leader', 'Creator', 'Builder', 'Dreamer', 'Hustler'];
      return `${adjectives[Math.floor(Math.random() * adjectives.length)]}${nouns[Math.floor(Math.random() * nouns.length)]}${Math.floor(Math.random() * 1000)}`;
    };

    const connectWebSocket = () => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const websocket = new WebSocket(wsUrl);
      
      websocket.onopen = () => {
        setConnectionStatus('connected');
        setWs(websocket);
        
        // Use stored profile username or generate random one as fallback
        const userUsername = (userProfile as UserProfile)?.displayName || generateUsername();
        setUsername(userUsername);
        
        // Join community chat room
        websocket.send(JSON.stringify({
          type: 'join_community',
          username: userUsername,
          userType: 'entrepreneur',
          location: (userProfile as UserProfile)?.location || 'Caribbean'
        }));
      };

      websocket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
          case 'community_message':
            setMessages(prev => [...prev, {
              id: data.id,
              username: data.username,
              message: data.message,
              timestamp: new Date(data.timestamp),
              userType: data.userType
            }]);
            break;
            
          case 'user_joined':
            setConnectedUsers(prev => [...prev, data.user]);
            setMessages(prev => [...prev, {
              id: Date.now().toString(),
              username: 'System',
              message: `${data.user.username} joined the community`,
              timestamp: new Date(),
              userType: 'supporter'
            }]);
            break;
            
          case 'user_left':
            setConnectedUsers(prev => prev.filter(user => user.id !== data.userId));
            break;
            
          case 'users_update':
            setConnectedUsers(data.users);
            break;
        }
      };

      websocket.onclose = () => {
        setConnectionStatus('disconnected');
        setWs(null);
        // Attempt to reconnect after 5 seconds
        setTimeout(() => {
          setConnectionStatus('connecting');
          connectWebSocket();
        }, 5000);
      };

      websocket.onerror = () => {
        setConnectionStatus('disconnected');
      };
    };

    // Only connect after attempting to load user profile
    connectWebSocket();

    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, [userProfile]); // Depend on userProfile so connection happens after profile loads

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim() && ws && connectionStatus === 'connected') {
      ws.send(JSON.stringify({
        type: 'community_message',
        message: newMessage.trim()
      }));
      setNewMessage('');
    }
  };

  const getUserTypeColor = (userType: string) => {
    switch (userType) {
      case 'premium': return 'bg-purple-100 text-purple-800';
      case 'supporter': return 'bg-green-100 text-green-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getUserTypeIcon = (userType: string) => {
    switch (userType) {
      case 'premium': return '👑';
      case 'supporter': return '🤝';
      default: return '🚀';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header Section */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <MessageCircle className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Biz Buzz</h1>
          </div>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Connect with entrepreneurs worldwide. Share ideas, get feedback, and grow your business together.
          </p>
          
          <div className="flex items-center justify-center gap-6 mt-6">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-green-600" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {connectedUsers.length} Online
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-blue-600" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Global Community
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${
                connectionStatus === 'connected' ? 'bg-green-500' : 
                connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
              }`} />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {connectionStatus === 'connected' ? 'Connected' : 
                 connectionStatus === 'connecting' ? 'Connecting...' : 'Disconnected'}
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Online Users Sidebar */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                <Users className="h-4 w-4" />
                Online Now ({connectedUsers.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                <div className="space-y-2">
                  {connectedUsers.map((user) => (
                    <div key={user.id} className="flex items-center gap-2 p-2 rounded-lg bg-gray-50 dark:bg-gray-800">
                      <span className="text-sm">{getUserTypeIcon(user.userType)}</span>
                      <div className="flex-1">
                        <div className="text-sm font-medium">{user.username}</div>
                        {user.location && (
                          <div className="text-xs text-gray-500">{user.location}</div>
                        )}
                      </div>
                      <Badge variant="secondary" className={`text-xs ${getUserTypeColor(user.userType)}`}>
                        {user.userType}
                      </Badge>
                    </div>
                  ))}
                  {connectedUsers.length === 0 && (
                    <div className="text-center text-gray-500 py-4">
                      <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No one online yet</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Main Chat Area */}
          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                Community Chat
                {username && (
                  <Badge variant="outline" className="ml-2">
                    You're chatting as: {username}
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col h-96">
                {/* Messages Area */}
                <ScrollArea className="flex-1 mb-4 border rounded-lg p-4 bg-gray-50 dark:bg-gray-800">
                  <div className="space-y-4">
                    {messages.length === 0 ? (
                      <div className="text-center text-gray-500 py-8">
                        <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>No messages yet. Start the conversation!</p>
                      </div>
                    ) : (
                      messages.map((msg) => (
                        <div key={msg.id} className="flex items-start gap-3">
                          <div className="flex-shrink-0">
                            <span className="text-lg">{getUserTypeIcon(msg.userType)}</span>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-sm">{msg.username}</span>
                              <Badge variant="secondary" className={`text-xs ${getUserTypeColor(msg.userType)}`}>
                                {msg.userType}
                              </Badge>
                              <span className="text-xs text-gray-500">
                                {msg.timestamp.toLocaleTimeString()}
                              </span>
                            </div>
                            <p className="text-sm text-gray-700 dark:text-gray-300">{msg.message}</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>

                {/* Message Input */}
                <form onSubmit={sendMessage} className="flex gap-2">
                  <Input
                    placeholder={
                      connectionStatus === 'connected' 
                        ? "Type your message..." 
                        : connectionStatus === 'connecting' 
                        ? "Connecting..." 
                        : "Disconnected"
                    }
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    disabled={connectionStatus !== 'connected'}
                    className="flex-1"
                  />
                  <Button 
                    type="submit" 
                    disabled={!newMessage.trim() || connectionStatus !== 'connected'}
                    className="px-4"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </form>

                {connectionStatus === 'disconnected' && (
                  <div className="text-center text-red-500 text-sm mt-2">
                    Connection lost. Attempting to reconnect...
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Community Stats */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-100 rounded-full">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {connectedUsers.length}
                  </p>
                  <p className="text-sm text-gray-500">Active Entrepreneurs</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-green-100 rounded-full">
                  <MessageCircle className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {messages.length}
                  </p>
                  <p className="text-sm text-gray-500">Messages Today</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-purple-100 rounded-full">
                  <Heart className="h-6 w-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    Caribbean
                  </p>
                  <p className="text-sm text-gray-500">Community Focus</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}