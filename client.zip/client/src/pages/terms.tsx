import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Scale, FileText, Shield, AlertCircle, CreditCard, Globe, Users, Zap, CheckCircle2 } from "lucide-react";
import SEOHead from "@/components/seo-head";

export default function Terms() {
  const effectiveDate = "January 15, 2025";
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <SEOHead 
        title="Terms of Service - FindMyBizName Legal Agreement & User Rights"
        description="Comprehensive Terms of Service for FindMyBizName global business platform. Fair usage policies, user rights, and legal framework for 430.5M entrepreneurs worldwide."
        keywords="FindMyBizName terms of service, user agreement, business platform legal terms, entrepreneur rights, service conditions, fair usage policy"
      />
      <div className="container mx-auto px-4 py-16 pt-32 md:pt-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4" variant="outline">
            <Scale className="w-4 h-4 mr-2" />
            Effective: {effectiveDate} • Governed by Trinidad & Tobago Law
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            Terms of Service & User Agreement
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto mb-8">
            These Terms of Service govern your use of FindMyBizName, our comprehensive business 
            operating system designed to empower underbanked entrepreneurs globally. Operating from 
            Trinidad & Tobago, we serve 430.5 million entrepreneurs worldwide with fair, transparent, 
            and entrepreneur-friendly policies.
          </p>
          {/* Key Principles */}
          <div className="grid md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg">
              <CheckCircle2 className="w-6 h-6 text-green-600 mx-auto mb-2" />
              <div className="text-sm font-medium">Fair & Transparent</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">No hidden terms or conditions</div>
            </div>
            <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
              <Users className="w-6 h-6 text-blue-600 mx-auto mb-2" />
              <div className="text-sm font-medium">User-Centric</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Built for entrepreneurs, by entrepreneurs</div>
            </div>
            <div className="bg-purple-50 dark:bg-purple-950 p-4 rounded-lg">
              <Globe className="w-6 h-6 text-purple-600 mx-auto mb-2" />
              <div className="text-sm font-medium">Global Accessibility</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Supporting 150+ countries</div>
            </div>
            <div className="bg-orange-50 dark:bg-orange-950 p-4 rounded-lg">
              <Shield className="w-6 h-6 text-orange-600 mx-auto mb-2" />
              <div className="text-sm font-medium">Legal Protection</div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Clear rights and obligations</div>
            </div>
          </div>
        </div>
        {/* Service Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <Card className="border-2 border-blue-200 dark:border-blue-800">
            <CardContent className="pt-6 text-center">
              <FileText className="w-10 h-10 text-blue-600 mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">Comprehensive Service Agreement</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                Complete legal framework governing your use of our AI-powered business name generation, 
                domain checking, CRM tools, invoice generation, and payment processing services.
              </p>
            </CardContent>
          </Card>
          <Card className="border-2 border-green-200 dark:border-green-800">
            <CardContent className="pt-6 text-center">
              <Shield className="w-10 h-10 text-green-600 mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">User Rights & Protections</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                Comprehensive protection of your intellectual property rights, data ownership, 
                fair usage guarantees, and recourse mechanisms for dispute resolution.
              </p>
            </CardContent>
          </Card>
          <Card className="border-2 border-orange-200 dark:border-orange-800">
            <CardContent className="pt-6 text-center">
              <AlertCircle className="w-10 h-10 text-orange-600 mx-auto mb-4" />
              <h3 className="font-bold text-lg mb-2">Responsible Use Guidelines</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                Clear, reasonable guidelines for platform usage that protect all users while 
                maximizing access to our AI technology for legitimate business purposes.
              </p>
            </CardContent>
          </Card>
        </div>
        {/* Main Content */}
        <div className="max-w-5xl mx-auto space-y-10">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
                1. Agreement Acceptance & Scope
              </CardTitle>
              <CardDescription className="text-base">
                Legal foundation and scope of this comprehensive service agreement
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-5 bg-green-50 dark:bg-green-950 rounded-lg">
                <h4 className="font-bold mb-3 text-green-800 dark:text-green-200">Binding Agreement Terms</h4>
                <p className="text-sm text-green-800 dark:text-green-200 mb-3">
                  By accessing, creating an account, or using any part of FindMyBizName's services, 
                  you enter into a legally binding agreement with FindMyBizName Ltd., a company 
                  incorporated under the laws of Trinidad & Tobago.
                </p>
                <ul className="text-sm text-green-800 dark:text-green-200 space-y-1">
                  <li>• These Terms apply to all users: free, premium, and enterprise customers</li>
                  <li>• Supplementary agreements may govern specific services (API usage, enterprise features)</li>
                  <li>• Your continued use after any changes constitutes acceptance of updated terms</li>
                  <li>• If you disagree with any terms, you must discontinue use immediately</li>
                </ul>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold mb-3 text-lg">Geographic Scope & Jurisdiction</h4>
                  <div className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
                    <p><strong>Primary Jurisdiction:</strong> Trinidad & Tobago (headquarters and primary operations)</p>
                    <p><strong>Global Service Delivery:</strong> Available in 150+ countries with local adaptations</p>
                    <p><strong>Governing Law:</strong> Laws of Trinidad & Tobago, supplemented by international commercial law</p>
                    <p><strong>Issue Resolution:</strong> Direct communication with FindMyBizName for prompt resolution</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-bold mb-3 text-lg">Service Categories Covered</h4>
                  <div className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
                    <p><strong>Core Platform:</strong> AI name generation, domain checking, favorites management</p>
                    <p><strong>Business Tools:</strong> CRM, invoicing, payment processing, document generation</p>
                    <p><strong>Intelligence Services:</strong> Company database access, market research, trend analysis</p>
                    <p><strong>API & Integration:</strong> Developer tools, third-party integrations, white-label solutions</p>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-yellow-50 dark:bg-yellow-950 rounded-lg border-l-4 border-yellow-400">
                <h4 className="font-bold mb-2 text-yellow-800 dark:text-yellow-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Age Requirements & Capacity to Contract
                </h4>
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  You must be at least 18 years old or the age of majority in your jurisdiction to enter into 
                  these Terms. If you're under 18, a parent or legal guardian must agree to these Terms on 
                  your behalf and supervise your use of the service.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Zap className="w-6 h-6 text-blue-600" />
                2. Comprehensive Service Description
              </CardTitle>
              <CardDescription className="text-base">
                Detailed overview of FindMyBizName's complete business operating system
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">AI-Powered Name Generation</h4>
                  <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
                    <li>• Advanced neural networks trained on millions of successful business names</li>
                    <li>• Industry-specific algorithms for 500+ business categories</li>
                    <li>• Cultural and linguistic adaptations for global markets</li>
                    <li>• Real-time trademark screening and legal compliance checking</li>
                    <li>• Brandability scoring and memorability analysis</li>
                  </ul>
                </div>
                <div className="p-5 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-green-800 dark:text-green-200">Domain & Digital Presence Tools</h4>
                  <ul className="text-sm text-green-800 dark:text-green-200 space-y-1">
                    <li>• Real-time availability checking across 50+ TLD extensions</li>
                    <li>• Competitive pricing comparison from multiple registrars</li>
                    <li>• Social media handle availability verification</li>
                    <li>• Logo generation and brand identity packages</li>
                    <li>• SEO analysis and digital marketing recommendations</li>
                  </ul>
                </div>
                <div className="p-5 bg-purple-50 dark:bg-purple-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-purple-800 dark:text-purple-200">Business Management Suite</h4>
                  <ul className="text-sm text-purple-800 dark:text-purple-200 space-y-1">
                    <li>• Customer Relationship Management (CRM) with contact management</li>
                    <li>• Professional invoice generation with multiple currency support</li>
                    <li>• Payment processing through global and regional providers</li>
                    <li>• Business plan templates and financial modeling tools</li>
                    <li>• Legal document generation for various jurisdictions</li>
                  </ul>
                </div>
                <div className="p-5 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-orange-800 dark:text-orange-200">Intelligence & Research Platform</h4>
                  <ul className="text-sm text-orange-800 dark:text-orange-200 space-y-1">
                    <li>• Access to 500,000+ company database with SEC EDGAR integration</li>
                    <li>• Real-time market research and industry trend analysis</li>
                    <li>• Competitor intelligence and strategic positioning tools</li>
                    <li>• Global business news aggregation from 1,000+ sources</li>
                    <li>• AI-powered business opportunity identification</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-gray-50 dark:bg-gray-900 rounded-lg">
                <h4 className="font-bold mb-3">Service Level Commitments</h4>
                <div className="grid md:grid-cols-3 gap-6 text-sm">
                  <div>
                    <h5 className="font-semibold mb-2 text-blue-700 dark:text-blue-300">Uptime & Reliability</h5>
                    <ul className="space-y-1">
                      <li>• 99.9% service uptime guarantee</li>
                      <li>• Sub-2-second response times for name generation</li>
                      <li>• Automatic data backup every 6 hours</li>
                      <li>• 24/7 system monitoring and rapid issue resolution</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2 text-green-700 dark:text-green-300">Accuracy & Quality</h5>
                    <ul className="space-y-1">
                      <li>• 98.5% domain availability checking accuracy</li>
                      <li>• Real-time data synchronization with registries</li>
                      <li>• Continuous AI model training and improvement</li>
                      <li>• Human quality assurance for premium features</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2 text-purple-700 dark:text-purple-300">Support & Assistance</h5>
                    <ul className="space-y-1">
                      <li>• 24/7 multilingual customer support</li>
                      <li>• Average response time under 2 hours</li>
                      <li>• Dedicated account managers for Pro+ users</li>
                      <li>• Comprehensive knowledge base and tutorials</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-red-50 dark:bg-red-950 rounded-lg border-l-4 border-red-400">
                <h4 className="font-bold mb-2 text-red-800 dark:text-red-200">Service Limitations & Disclaimers</h4>
                <p className="text-sm text-red-800 dark:text-red-200 mb-2">
                  While we strive for excellence, please note these important limitations:
                </p>
                <ul className="text-sm text-red-800 dark:text-red-200 space-y-1">
                  <li>• AI-generated names are suggestions only and may not be suitable for all purposes</li>
                  <li>• Domain availability can change rapidly; we cannot guarantee registration success</li>
                  <li>• Trademark screening is preliminary; professional legal advice is recommended</li>
                  <li>• Business advice and tools are informational; consult professionals for specific situations</li>
                  <li>• Third-party integrations may have separate terms and limitations</li>
                </ul>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Users className="w-6 h-6 text-green-600" />
                3. User Accounts & Registration
              </CardTitle>
              <CardDescription className="text-base">
                Account creation, management, and security requirements for all user types
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold mb-3 text-lg">Account Creation Requirements</h4>
                  <div className="space-y-3">
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold text-blue-700 dark:text-blue-300">Required Information</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Valid email address, secure password, and acceptance of these Terms</p>
                    </div>
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold text-green-700 dark:text-green-300">Optional Enhancements</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Business information, industry preferences, and contact details for personalization</p>
                    </div>
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold text-purple-700 dark:text-purple-300">Verification Process</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Email verification required; phone verification for enhanced security features</p>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-bold mb-3 text-lg">Account Security Obligations</h4>
                  <div className="space-y-3">
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold text-red-700 dark:text-red-300">Password Security</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Strong, unique passwords with multi-factor authentication strongly recommended</p>
                    </div>
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold text-orange-700 dark:text-orange-300">Access Control</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">You're responsible for all activities under your account; never share credentials</p>
                    </div>
                    <div className="p-3 border rounded">
                      <h5 className="font-semibold text-teal-700 dark:text-teal-300">Breach Reporting</h5>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Report suspected unauthorized access immediately to security@findmybizname.com</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">Account Types & Privileges</h4>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-3 bg-white dark:bg-gray-800 rounded border">
                    <h5 className="font-semibold mb-2 text-green-600">Free Users</h5>
                    <ul className="text-xs space-y-1">
                      <li>• 10 name generations per day</li>
                      <li>• Basic domain checking (.com, .net, .org)</li>
                      <li>• 5 favorites storage</li>
                      <li>• Community support</li>
                      <li>• Standard API rate limits</li>
                    </ul>
                  </div>
                  <div className="p-3 bg-white dark:bg-gray-800 rounded border">
                    <h5 className="font-semibold mb-2 text-blue-600">Premium Users ($9.99/month)</h5>
                    <ul className="text-xs space-y-1">
                      <li>• Unlimited name generations</li>
                      <li>• 50+ domain extensions</li>
                      <li>• Unlimited favorites</li>
                      <li>• Priority support</li>
                      <li>• Advanced AI features</li>
                      <li>• Data export capabilities</li>
                    </ul>
                  </div>
                  <div className="p-3 bg-white dark:bg-gray-800 rounded border">
                    <h5 className="font-semibold mb-2 text-purple-600">Pro Users ($19.99/month)</h5>
                    <ul className="text-xs space-y-1">
                      <li>• All Premium features</li>
                      <li>• CRM and business tools</li>
                      <li>• Invoice generation</li>
                      <li>• Payment processing</li>
                      <li>• Business intelligence access</li>
                      <li>• White-label options</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                <h4 className="font-bold mb-3 text-yellow-800 dark:text-yellow-200">Account Termination & Data Handling</h4>
                <div className="grid md:grid-cols-2 gap-6 text-sm">
                  <div>
                    <h5 className="font-semibold mb-2">Voluntary Account Closure</h5>
                    <ul className="space-y-1 text-yellow-800 dark:text-yellow-200">
                      <li>• Self-service deletion available in account settings</li>
                      <li>• 30-day grace period for account recovery</li>
                      <li>• Complete data export available before deletion</li>
                      <li>• Subscription automatically cancelled upon deletion</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Involuntary Suspension/Termination</h5>
                    <ul className="space-y-1 text-yellow-800 dark:text-yellow-200">
                      <li>• Terms violations may result in immediate suspension</li>
                      <li>• 14-day notice period for most terminations</li>
                      <li>• Appeal process available for disputed actions</li>
                      <li>• Data retention period of 90 days for recovery</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <CreditCard className="w-6 h-6 text-green-600" />
                4. Subscription Plans, Billing & Payment
              </CardTitle>
              <CardDescription className="text-base">
                Comprehensive billing policies, payment methods, and subscription management
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-green-800 dark:text-green-200">Subscription Pricing & Plans</h4>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 border rounded">
                      <p><strong>Freemium Plan:</strong> $0 USD/month - Forever free</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">10 name generations per month, basic domain checking, community support</p>
                    </div>
                    <div className="p-3 border rounded">
                      <p><strong>Premium Plan:</strong> $9.99 USD/month or local currency equivalent</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Unlimited generations, premium domains, brand analysis suite, priority support</p>
                    </div>
                    <div className="p-3 border rounded">
                      <p><strong>Pro Plan:</strong> $19.99 USD/month or local currency equivalent</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Complete business platform with CRM, invoicing, business intelligence, WhatsApp integration</p>
                    </div>
                    <div className="p-3 border rounded">
                      <p><strong>Professional Plan:</strong> $29.99 USD/month or local currency equivalent</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Advanced analytics dashboard, email marketing automation, premium domain checking (50+ TLDs)</p>
                    </div>
                    <div className="p-3 border rounded">
                      <p><strong>Business Plan:</strong> $59.99 USD/month or local currency equivalent</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">Team collaboration tools, multi-user access, priority phone support, advanced analytics</p>
                    </div>
                    <div className="p-3 border rounded">
                      <p><strong>Enterprise Plans:</strong> Custom pricing starting at $149/month</p>
                      <p className="text-xs text-gray-600 dark:text-gray-400">White-label solutions, unlimited team members, custom integrations, 24/7 priority support</p>
                    </div>
                  </div>
                </div>
                <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">Global Payment Methods</h4>
                  <div className="space-y-2 text-sm text-blue-800 dark:text-blue-200">
                    <p><strong>Primary Processors:</strong></p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Payoneer (150+ countries, global payment processing)</li>
                      <li>PayPal (190+ countries, multiple currencies)</li>
                      <li>Major credit/debit cards (Visa, MasterCard, Amex)</li>
                      <li>Cryptocurrency (Bitcoin, Ethereum, USDC, stablecoins)</li>
                    </ul>
                    <p><strong>Regional Processors:</strong></p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>WiPay (Trinidad & Tobago, Caribbean)</li>
                      <li>M-Pesa (Kenya, Tanzania, other African markets)</li>
                      <li>Alipay & WeChat Pay (China and Asian markets)</li>
                      <li>PIX (Brazil), UPI (India), SEPA (Europe)</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-purple-50 dark:bg-purple-950 rounded-lg">
                <h4 className="font-bold mb-3 text-purple-800 dark:text-purple-200">Purchasing Power Parity (PPP) Pricing</h4>
                <p className="text-sm text-purple-800 dark:text-purple-200 mb-3">
                  We offer adjusted pricing for users in developing economies to ensure global accessibility:
                </p>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <h5 className="font-semibold mb-1">Tier 1 Discounts (50% off)</h5>
                    <p>Countries with GDP per capita under $5,000 USD</p>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-1">Tier 2 Discounts (30% off)</h5>
                    <p>Countries with GDP per capita $5,000-$15,000 USD</p>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-1">Student Discounts</h5>
                    <p>Additional 25% off with valid student verification</p>
                  </div>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-red-50 dark:bg-red-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-red-800 dark:text-red-200">Billing Policies & Procedures</h4>
                  <ul className="text-sm text-red-800 dark:text-red-200 space-y-2">
                    <li><strong>Billing Cycle:</strong> Monthly subscriptions bill on the same day each month</li>
                    <li><strong>Auto-Renewal:</strong> Subscriptions automatically renew unless cancelled 24 hours before renewal</li>
                    <li><strong>Failed Payments:</strong> 3 retry attempts over 7 days before service suspension</li>
                    <li><strong>Currency Conversion:</strong> Charged in local currency when available, USD otherwise</li>
                    <li><strong>Taxes & Fees:</strong> Local taxes (VAT, GST) added where legally required</li>
                  </ul>
                </div>
                <div className="p-5 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-orange-800 dark:text-orange-200">Refund & Cancellation Policy</h4>
                  <ul className="text-sm text-orange-800 dark:text-orange-200 space-y-2">
                    <li><strong>30-Day Money-Back Guarantee:</strong> Full refund for new subscribers within 30 days</li>
                    <li><strong>Pro-Rated Refunds:</strong> Unused portion refunded for annual subscriptions</li>
                    <li><strong>Instant Cancellation:</strong> Cancel anytime through account settings or payment provider</li>
                    <li><strong>Grace Period:</strong> Continue using paid features until end of current billing cycle</li>
                    <li><strong>Processing Time:</strong> Refunds processed within 5-10 business days</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-yellow-50 dark:bg-yellow-950 rounded-lg border-l-4 border-yellow-400">
                <h4 className="font-bold mb-2 text-yellow-800 dark:text-yellow-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Price Changes & Grandfathering Policy
                </h4>
                <p className="text-sm text-yellow-800 dark:text-yellow-200 mb-2">
                  We may adjust subscription prices to reflect service improvements, inflation, or market changes:
                </p>
                <ul className="text-sm text-yellow-800 dark:text-yellow-200 space-y-1">
                  <li>• Existing subscribers receive 60 days advance notice of price changes</li>
                  <li>• Current pricing is "grandfathered" for 12 months minimum</li>
                  <li>• Price increases limited to 15% annually for existing customers</li>
                  <li>• Option to cancel without penalty if you disagree with new pricing</li>
                </ul>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Shield className="w-6 h-6 text-blue-600" />
                5. Acceptable Use Policy & Community Standards
              </CardTitle>
              <CardDescription className="text-base">
                Fair usage guidelines that protect all users while maximizing platform access
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-green-800 dark:text-green-200">Encouraged & Permitted Uses</h4>
                  <ul className="text-sm text-green-800 dark:text-green-200 space-y-2">
                    <li>• Generate business names for your own ventures or client projects</li>
                    <li>• Research and analyze business opportunities and market trends</li>
                    <li>• Use our tools for educational purposes and entrepreneurship training</li>
                    <li>• Integrate our API into your applications per developer agreement</li>
                    <li>• Share generated names and insights with your team or advisors</li>
                    <li>• Provide feedback and suggestions for platform improvement</li>
                    <li>• Use business tools (CRM, invoicing) for legitimate commercial activities</li>
                  </ul>
                </div>
                <div className="p-5 bg-red-50 dark:bg-red-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-red-800 dark:text-red-200">Prohibited Activities</h4>
                  <ul className="text-sm text-red-800 dark:text-red-200 space-y-2">
                    <li>• Using the service for illegal businesses or activities</li>
                    <li>• Attempting to reverse-engineer, copy, or replicate our AI algorithms</li>
                    <li>• Automated scraping, harvesting, or bulk data extraction</li>
                    <li>• Creating multiple accounts to circumvent usage limits</li>
                    <li>• Selling or redistributing our generated content without permission</li>
                    <li>• Violating intellectual property rights of third parties</li>
                    <li>• Harassment, abuse, or inappropriate conduct toward other users or staff</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">Fair Usage Limits & Rate Limiting</h4>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <h5 className="font-semibold mb-2">Free Users</h5>
                    <ul className="space-y-1 text-blue-800 dark:text-blue-200">
                      <li>• 10 name generations per 24-hour period</li>
                      <li>• 50 domain checks per day</li>
                      <li>• 100 API requests per month</li>
                      <li>• 5 MB total storage for favorites</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Premium Users</h5>
                    <ul className="space-y-1 text-blue-800 dark:text-blue-200">
                      <li>• Unlimited name generations</li>
                      <li>• 1,000 domain checks per day</li>
                      <li>• 10,000 API requests per month</li>
                      <li>• 100 MB storage for data and exports</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Pro Users</h5>
                    <ul className="space-y-1 text-blue-800 dark:text-blue-200">
                      <li>• Unlimited generations and checks</li>
                      <li>• 50,000 API requests per month</li>
                      <li>• 1 GB storage for business data</li>
                      <li>• Priority processing queues</li>
                    </ul>
                  </div>
                </div>
                <p className="text-sm text-blue-800 dark:text-blue-200 mt-3">
                  <strong>Enterprise Exception:</strong> Custom rate limits and usage allowances available 
                  for Enterprise customers based on specific needs and agreements.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-yellow-800 dark:text-yellow-200">Content Moderation & AI Ethics</h4>
                  <ul className="text-sm text-yellow-800 dark:text-yellow-200 space-y-2">
                    <li>• Our AI systems are trained to avoid generating inappropriate or offensive names</li>
                    <li>• Automated filters prevent names associated with hate speech or illegal activities</li>
                    <li>• Human oversight ensures quality and appropriateness of AI outputs</li>
                    <li>• Users can report problematic generated content for review and improvement</li>
                    <li>• Continuous algorithm updates to improve ethical AI performance</li>
                  </ul>
                </div>
                <div className="p-5 bg-purple-50 dark:bg-purple-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-purple-800 dark:text-purple-200">Enforcement & Progressive Discipline</h4>
                  <ul className="text-sm text-purple-800 dark:text-purple-200 space-y-2">
                    <li>• <strong>First Warning:</strong> Email notification and educational resources</li>
                    <li>• <strong>Temporary Restriction:</strong> Limited access to certain features (24-48 hours)</li>
                    <li>• <strong>Probationary Period:</strong> Monitored usage with reduced limits (30 days)</li>
                    <li>• <strong>Account Suspension:</strong> Complete service suspension (7-30 days)</li>
                    <li>• <strong>Permanent Termination:</strong> Reserved for severe or repeated violations</li>
                  </ul>
                  <p className="text-sm text-purple-800 dark:text-purple-200 mt-2">
                    <strong>Appeal Process:</strong> All enforcement actions can be appealed through our 
                    dispute resolution system with independent review.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <FileText className="w-6 h-6 text-purple-600" />
                6. Intellectual Property Rights & Ownership
              </CardTitle>
              <CardDescription className="text-base">
                Clear definitions of intellectual property ownership and usage rights
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-green-800 dark:text-green-200">Your Rights to Generated Content</h4>
                  <ul className="text-sm text-green-800 dark:text-green-200 space-y-2">
                    <li>• <strong>Business Names:</strong> You have unlimited commercial rights to any names you generate</li>
                    <li>• <strong>No Ownership Claims:</strong> We make no intellectual property claims over generated names</li>
                    <li>• <strong>Public Domain:</strong> Most generated names enter public domain and may be used by others</li>
                    <li>• <strong>Trademark Rights:</strong> You may trademark generated names subject to availability and legal requirements</li>
                    <li>• <strong>Commercial Usage:</strong> Full rights to use names for business registration, marketing, and branding</li>
                  </ul>
                </div>
                <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">Platform Technology & IP Protection</h4>
                  <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-2">
                    <li>• <strong>AI Algorithms:</strong> Proprietary technology protected by trade secrets and patents</li>
                    <li>• <strong>Platform Code:</strong> Copyright-protected software and user interface designs</li>
                    <li>• <strong>Database Rights:</strong> Compilation rights in our business and domain databases</li>
                    <li>• <strong>Trademark:</strong> "FindMyBizName" and associated marks are registered trademarks</li>
                    <li>• <strong>Trade Dress:</strong> Distinctive design elements and user experience protected</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                <h4 className="font-bold mb-3 text-yellow-800 dark:text-yellow-200">User Content & Data Rights</h4>
                <div className="grid md:grid-cols-2 gap-6 text-sm">
                  <div>
                    <h5 className="font-semibold mb-2">Content You Provide</h5>
                    <ul className="space-y-1 text-yellow-800 dark:text-yellow-200">
                      <li>• Business descriptions and search queries remain your property</li>
                      <li>• We receive limited license to process this content for service delivery</li>
                      <li>• Your content is never sold, licensed, or shared without permission</li>
                      <li>• You can delete your content and terminate our usage license anytime</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Generated Business Data</h5>
                    <ul className="space-y-1 text-yellow-800 dark:text-yellow-200">
                      <li>• CRM data, invoices, and business documents belong to you</li>
                      <li>• We provide secure hosting and backup services only</li>
                      <li>• Full data export rights in multiple formats</li>
                      <li>• No usage rights claimed over your business information</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-red-50 dark:bg-red-950 rounded-lg">
                <h4 className="font-bold mb-3 text-red-800 dark:text-red-200">Third-Party IP & Compliance</h4>
                <p className="text-sm text-red-800 dark:text-red-200 mb-3">
                  We take intellectual property rights seriously and maintain comprehensive compliance procedures:
                </p>
                <div className="grid md:grid-cols-2 gap-6 text-sm">
                  <div>
                    <h5 className="font-semibold mb-2">Trademark Screening</h5>
                    <ul className="space-y-1 text-red-800 dark:text-red-200">
                      <li>• Automated screening against major trademark databases</li>
                      <li>• Integration with USPTO, EUIPO, and other registries</li>
                      <li>• Warning systems for potentially problematic names</li>
                      <li>• Regular database updates and accuracy improvements</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Copyright & DMCA Compliance</h5>
                    <ul className="space-y-1 text-red-800 dark:text-red-200">
                      <li>• Registered DMCA agent for takedown requests</li>
                      <li>• Rapid response to valid intellectual property claims</li>
                      <li>• Counter-notification process for disputed claims</li>
                      <li>• Repeat infringer policy with account termination</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-gray-50 dark:bg-gray-900 rounded-lg border-l-4 border-gray-400">
                <h4 className="font-bold mb-2 text-gray-800 dark:text-gray-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Important Legal Disclaimer
                </h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  While we provide preliminary trademark screening, this service does NOT constitute legal advice. 
                  Professional trademark searches and legal consultation are strongly recommended before using any 
                  generated name for commercial purposes. We cannot guarantee that generated names are available 
                  for trademark registration or free from all intellectual property conflicts.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Scale className="w-6 h-6 text-indigo-600" />
                7. Liability, Disclaimers & Legal Protections
              </CardTitle>
              <CardDescription className="text-base">
                Comprehensive liability framework and legal protections for all parties
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">Service Warranties & Guarantees</h4>
                  <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-2">
                    <li>• <strong>Uptime Guarantee:</strong> 99.9% service availability with service credits for failures</li>
                    <li>• <strong>Data Security:</strong> Industry-standard encryption and security measures</li>
                    <li>• <strong>Performance Standards:</strong> Response times and accuracy metrics as specified</li>
                    <li>• <strong>Support Quality:</strong> Trained staff and documented response time commitments</li>
                    <li>• <strong>Continuous Improvement:</strong> Regular updates and feature enhancements</li>
                  </ul>
                </div>
                <div className="p-5 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-orange-800 dark:text-orange-200">Service Limitations & Disclaimers</h4>
                  <ul className="text-sm text-orange-800 dark:text-orange-200 space-y-2">
                    <li>• <strong>AI Suggestions Only:</strong> Generated names are creative suggestions, not guarantees</li>
                    <li>• <strong>No Legal Advice:</strong> Platform provides information, not professional legal counsel</li>
                    <li>• <strong>Third-Party Dependencies:</strong> Domain registries and external APIs may affect service</li>
                    <li>• <strong>Market Volatility:</strong> Domain prices and availability change beyond our control</li>
                    <li>• <strong>Regulatory Changes:</strong> Laws affecting business naming may vary by jurisdiction</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-red-50 dark:bg-red-950 rounded-lg">
                <h4 className="font-bold mb-3 text-red-800 dark:text-red-200">Limitation of Liability Framework</h4>
                <p className="text-sm text-red-800 dark:text-red-200 mb-3">
                  To the maximum extent permitted by applicable law, FindMyBizName's liability is limited as follows:
                </p>
                <div className="grid md:grid-cols-2 gap-6 text-sm">
                  <div>
                    <h5 className="font-semibold mb-2">Financial Liability Caps</h5>
                    <ul className="space-y-1 text-red-800 dark:text-red-200">
                      <li>• Total liability limited to 12 months of subscription fees paid</li>
                      <li>• For free users, liability capped at $100 USD or local equivalent</li>
                      <li>• Enterprise customers may negotiate higher liability limits</li>
                      <li>• Liability exclusions don't apply to gross negligence or willful misconduct</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Excluded Damages</h5>
                    <ul className="space-y-1 text-red-800 dark:text-red-200">
                      <li>• No liability for indirect, consequential, or punitive damages</li>
                      <li>• Business interruption and lost profits not covered</li>
                      <li>• Reputational harm or opportunity costs excluded</li>
                      <li>• Third-party claims and downstream damages not covered</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-green-50 dark:bg-green-950 rounded-lg">
                <h4 className="font-bold mb-3 text-green-800 dark:text-green-200">User Indemnification Obligations</h4>
                <p className="text-sm text-green-800 dark:text-green-200 mb-2">
                  You agree to defend, indemnify, and hold FindMyBizName harmless from claims arising from:
                </p>
                <ul className="text-sm text-green-800 dark:text-green-200 space-y-1">
                  <li>• Your use of generated names that violate third-party intellectual property rights</li>
                  <li>• Your violation of these Terms of Service or applicable laws</li>
                  <li>• Content you provide that is false, misleading, or infringing</li>
                  <li>• Your business activities conducted using our platform or generated content</li>
                  <li>• Unauthorized use of your account by third parties due to inadequate security</li>
                </ul>
              </div>
              <div className="p-5 bg-purple-50 dark:bg-purple-950 rounded-lg">
                <h4 className="font-bold mb-3 text-purple-800 dark:text-purple-200">Force Majeure & Service Interruptions</h4>
                <p className="text-sm text-purple-800 dark:text-purple-200 mb-2">
                  We are not liable for service interruptions caused by circumstances beyond our reasonable control:
                </p>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <ul className="space-y-1 text-purple-800 dark:text-purple-200">
                    <li>• Natural disasters, pandemics, or acts of God</li>
                    <li>• Government actions, regulations, or sanctions</li>
                    <li>• Internet infrastructure failures or cyber attacks</li>
                    <li>• Third-party service provider outages</li>
                  </ul>
                  <ul className="space-y-1 text-purple-800 dark:text-purple-200">
                    <li>• Labor strikes or industrial disputes</li>
                    <li>• Equipment failures beyond normal maintenance</li>
                    <li>• Acts of terrorism or war</li>
                    <li>• Compliance with emergency government orders</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <Globe className="w-6 h-6 text-teal-600" />
                8. Governing Law, Disputes & Resolution
              </CardTitle>
              <CardDescription className="text-base">
                Legal jurisdiction, dispute resolution mechanisms, and international considerations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">Primary Governing Law</h4>
                  <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-2">
                    <li>• <strong>Jurisdiction:</strong> Laws of the Republic of Trinidad & Tobago</li>
                    <li>• <strong>Conflict of Laws:</strong> Excluded to prevent forum shopping</li>
                    <li>• <strong>International Treaties:</strong> UN Convention on Contracts for International Sale of Goods applies</li>
                    <li>• <strong>Corporate Law:</strong> Trinidad & Tobago Companies Act governs our corporate obligations</li>
                    <li>• <strong>Commercial Standards:</strong> UNCITRAL Model Law principles for international disputes</li>
                  </ul>
                </div>
                <div className="p-5 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-green-800 dark:text-green-200">Regional Legal Variations</h4>
                  <ul className="text-sm text-green-800 dark:text-green-200 space-y-2">
                    <li>• <strong>European Union:</strong> GDPR and EU Digital Services Act compliance</li>
                    <li>• <strong>United States:</strong> State-specific laws and federal regulations apply</li>
                    <li>• <strong>Canada:</strong> Provincial and federal consumer protection laws</li>
                    <li>• <strong>Australia:</strong> Australian Consumer Law and Competition regulations</li>
                    <li>• <strong>CARICOM States:</strong> Regional trade and commercial law harmonization</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-purple-50 dark:bg-purple-950 rounded-lg">
                <h4 className="font-bold mb-3 text-purple-800 dark:text-purple-200">Simple Issue Resolution Process</h4>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-3 bg-white dark:bg-gray-800 rounded">
                    <h5 className="font-semibold mb-2 text-blue-600">Tier 1: Direct Resolution</h5>
                    <ul className="text-xs space-y-1">
                      <li>• Contact customer support first</li>
                      <li>• Escalation to management level</li>
                      <li>• 30-day resolution period</li>
                      <li>• Documentation of good faith efforts</li>
                    </ul>
                  </div>
                  <div className="p-3 bg-white dark:bg-gray-800 rounded">
                    <h5 className="font-semibold mb-2 text-orange-600">Tier 2: Mediation</h5>
                    <ul className="text-xs space-y-1">
                      <li>• Caribbean Mediation Centre</li>
                      <li>• Online mediation available</li>
                      <li>• Costs shared equally</li>
                      <li>• 60-day process timeline</li>
                    </ul>
                  </div>
                  <div className="p-3 bg-white dark:bg-gray-800 rounded">
                    <h5 className="font-semibold mb-2 text-red-600">Tier 3: Arbitration</h5>
                    <ul className="text-xs space-y-1">
                      <li>• Caribbean Commercial Arbitration Centre</li>
                      <li>• Single arbitrator for disputes under $50,000</li>
                      <li>• UNCITRAL rules apply</li>
                      <li>• Final and binding decision</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-yellow-800 dark:text-yellow-200">Small Claims & Consumer Protection</h4>
                  <ul className="text-sm text-yellow-800 dark:text-yellow-200 space-y-2">
                    <li>• Disputes under $5,000 USD may be pursued in small claims courts</li>
                    <li>• Consumer protection laws of your jurisdiction remain applicable</li>
                    <li>• Class action waivers may not be enforceable in all jurisdictions</li>
                    <li>• EU and UK consumers retain statutory rights regardless of these Terms</li>
                    <li>• Alternative Dispute Resolution (ADR) required in EU before litigation</li>
                  </ul>
                </div>
                <div className="p-5 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-orange-800 dark:text-orange-200">International Enforcement</h4>
                  <ul className="text-sm text-orange-800 dark:text-orange-200 space-y-2">
                    <li>• Arbitration awards enforceable under New York Convention</li>
                    <li>• Judgments recognized through bilateral treaties</li>
                    <li>• Asset recovery available in multiple jurisdictions</li>
                    <li>• Diplomatic channels for sovereign disputes</li>
                    <li>• International Commercial Arbitration Court as final appeal</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-red-50 dark:bg-red-950 rounded-lg border-l-4 border-red-400">
                <h4 className="font-bold mb-2 text-red-800 dark:text-red-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Emergency Legal Contacts
                </h4>
                <p className="text-sm text-red-800 dark:text-red-200 mb-2">
                  For urgent legal matters, emergency court orders, or time-sensitive disputes:
                </p>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><strong>Business Contact:</strong> support@findmybizname.com</p>
                    <p><strong>Emergency Line:</strong> +1 (868) 720-9758 (24/7)</p>
                  </div>
                  <div>
                    <p><strong>Registered Agent:</strong> Trinidad Corporate Services Ltd.</p>
                    <p><strong>Address:</strong> Port of Spain, Trinidad & Tobago</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-3">
                <FileText className="w-6 h-6 text-green-600" />
                9. Terms Updates, Changes & Communication
              </CardTitle>
              <CardDescription className="text-base">
                How we handle changes to these Terms and communicate updates to users
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-5 bg-green-50 dark:bg-green-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-green-800 dark:text-green-200">Change Notification Process</h4>
                  <ul className="text-sm text-green-800 dark:text-green-200 space-y-2">
                    <li>• <strong>Major Changes:</strong> 60 days advance notice via email and platform notifications</li>
                    <li>• <strong>Minor Changes:</strong> 30 days notice for clarifications and technical updates</li>
                    <li>• <strong>Legal Requirements:</strong> Immediate updates for regulatory compliance</li>
                    <li>• <strong>Emergency Changes:</strong> Security-related updates with immediate effect</li>
                    <li>• <strong>Archive Access:</strong> Previous versions available for reference</li>
                  </ul>
                </div>
                <div className="p-5 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-bold mb-3 text-blue-800 dark:text-blue-200">User Response Options</h4>
                  <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-2">
                    <li>• <strong>Continued Use:</strong> Using the service after changes indicates acceptance</li>
                    <li>• <strong>Account Closure:</strong> Close account before changes take effect</li>
                    <li>• <strong>Grandfathering:</strong> Existing subscriptions protected for reasonable periods</li>
                    <li>• <strong>Feedback Period:</strong> Public comment period for major policy changes</li>
                    <li>• <strong>Dispute Resolution:</strong> Challenge unreasonable changes through our dispute process</li>
                  </ul>
                </div>
              </div>
              <div className="p-5 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                <h4 className="font-bold mb-3 text-yellow-800 dark:text-yellow-200">Version Control & Change Log</h4>
                <div className="space-y-3 text-sm">
                  <div className="p-3 border rounded">
                    <p><strong>Current Version:</strong> 4.2.0 (Effective {effectiveDate})</p>
                    <p><strong>Previous Version:</strong> 4.1.0 (Effective December 1, 2024)</p>
                    <p><strong>Major Changes:</strong> Enhanced global payment methods, updated liability frameworks</p>
                  </div>
                  <div className="p-3 border rounded">
                    <p><strong>Next Review:</strong> Scheduled for April 15, 2025</p>
                    <p><strong>Change Frequency:</strong> Typically updated quarterly or as needed for compliance</p>
                    <p><strong>Public Archive:</strong> All versions available at findmybizname.com/legal/terms-archive</p>
                  </div>
                </div>
              </div>
              <div className="p-5 bg-purple-50 dark:bg-purple-950 rounded-lg">
                <h4 className="font-bold mb-3 text-purple-800 dark:text-purple-200">Communication Channels</h4>
                <div className="grid md:grid-cols-3 gap-4 text-sm">
                  <div>
                    <h5 className="font-semibold mb-2">Primary Notifications</h5>
                    <ul className="space-y-1 text-purple-800 dark:text-purple-200">
                      <li>• Email to registered address</li>
                      <li>• In-app notification banners</li>
                      <li>• Account dashboard alerts</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Secondary Channels</h5>
                    <ul className="space-y-1 text-purple-800 dark:text-purple-200">
                      <li>• Website announcement bar</li>
                      <li>• Social media notifications</li>
                      <li>• Newsletter updates</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-2">Legal Notices</h5>
                    <ul className="space-y-1 text-purple-800 dark:text-purple-200">
                      <li>• Registered mail for major changes</li>
                      <li>• Legal publication requirements</li>
                      <li>• Regulatory filing notifications</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-100 dark:from-blue-950 dark:to-indigo-950 border-2 border-blue-200 dark:border-blue-800">
            <CardContent className="pt-8">
              <div className="text-center space-y-6">
                <h3 className="font-bold text-2xl">Contact Information & Support</h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div>
                    <h4 className="font-semibold mb-2">General Terms Questions</h4>
                    <p className="text-sm">support@findmybizname.com</p>
                    <p className="text-sm">Response within 48 hours</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Issue Resolution</h4>
                    <p className="text-sm">disputes@findmybizname.com</p>
                    <p className="text-sm">Escalation to management level</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Emergency Legal Matters</h4>
                    <p className="text-sm">+1 (868) 720-9758 (24/7)</p>
                    <p className="text-sm">Court orders, injunctions, etc.</p>
                  </div>
                </div>
                <div className="flex flex-wrap justify-center gap-3 mt-6">
                  <Badge variant="outline">Version 4.2.0</Badge>
                  <Badge variant="outline">Effective {effectiveDate}</Badge>
                  <Badge variant="outline">Trinidad & Tobago Law</Badge>
                  <Badge variant="outline">430.5M Entrepreneurs Served</Badge>
                </div>
                <div className="text-center mt-6">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
                    <Scale className="w-4 h-4 mr-2" />
                    Contact Support
                  </Button>
                </div>
                <p className="text-xs text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
                  By using FindMyBizName's services, you acknowledge that you have read, understood, and agree 
                  to be bound by these Terms of Service. These Terms represent the complete agreement between 
                  you and FindMyBizName Ltd. regarding your use of our platform and supersede all prior negotiations, 
                  representations, or agreements relating to the subject matter herein.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
