import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CryptoPaymentButton } from "@/components/crypto-payment-button";
import { Badge } from "@/components/ui/badge";
import { Bitcoin, TestTube, CheckCircle } from "lucide-react";
import SEOHead from "@/components/seo-head";

export default function TestCryptoPayment() {
  const [testData, setTestData] = useState({
    customerEmail: 'test@findmybizname.com',
    customerName: 'Test User',
    plan: 'pro',
  });

  const plans = [
    { value: 'starter', label: 'Starter Plan - $9.99', price: 9.99 },
    { value: 'growth', label: 'Growth Plan - $29.99', price: 29.99 },
    { value: 'professional', label: 'Professional Plan - $79.99', price: 79.99 },
    { value: 'enterprise', label: 'Enterprise Plan - $149.99', price: 149.99 },
  ];

  const selectedPlan = plans.find(p => p.value === testData.plan);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 dark:from-gray-900 dark:to-gray-800">
      <SEOHead 
        title="Test Crypto Payments - FindMyBizName"
        description="Test crypto payment integration for underbanked entrepreneurs"
      />
      
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-orange-100 text-orange-800">
              <TestTube className="w-4 h-4 mr-2" />
              Testing Environment
            </Badge>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Crypto Payment Integration Test
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Testing Coinbase Commerce integration for underbanked entrepreneurs
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Test Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TestTube className="w-5 h-5" />
                  Test Configuration
                </CardTitle>
                <CardDescription>
                  Configure test payment parameters
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="email">Customer Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={testData.customerEmail}
                    onChange={(e) => setTestData({...testData, customerEmail: e.target.value})}
                    placeholder="test@example.com"
                  />
                </div>

                <div>
                  <Label htmlFor="name">Customer Name</Label>
                  <Input
                    id="name"
                    value={testData.customerName}
                    onChange={(e) => setTestData({...testData, customerName: e.target.value})}
                    placeholder="Test User"
                  />
                </div>

                <div>
                  <Label htmlFor="plan">Subscription Plan</Label>
                  <Select value={testData.plan} onValueChange={(value) => setTestData({...testData, plan: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a plan" />
                    </SelectTrigger>
                    <SelectContent>
                      {plans.map((plan) => (
                        <SelectItem key={plan.value} value={plan.value}>
                          {plan.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Test Results Panel */}
                <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <h3 className="font-semibold text-green-800 mb-2 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Integration Status
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>API Key:</span>
                      <Badge variant="outline" className="bg-green-100 text-green-800">Configured</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Backend Service:</span>
                      <Badge variant="outline" className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Supported Currencies:</span>
                      <span className="text-green-700">BTC, ETH, USDC, DAI</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Transaction Fee:</span>
                      <span className="font-semibold text-green-700">1%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Crypto Payment Test */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bitcoin className="w-5 h-5 text-orange-600" />
                  Crypto Payment Test
                </CardTitle>
                <CardDescription>
                  Test the complete payment flow
                </CardDescription>
              </CardHeader>
              <CardContent>
                {selectedPlan && (
                  <CryptoPaymentButton
                    plan={testData.plan}
                    price={selectedPlan.price}
                    customerEmail={testData.customerEmail}
                    customerName={testData.customerName}
                  />
                )}

                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h3 className="font-semibold text-blue-800 mb-2">Test Instructions</h3>
                  <ol className="text-sm text-blue-700 space-y-1">
                    <li>1. Click "Pay with Crypto" button above</li>
                    <li>2. Coinbase Commerce checkout page will open</li>
                    <li>3. Select cryptocurrency (BTC, ETH, USDC, DAI)</li>
                    <li>4. Complete test payment (use Coinbase's test mode)</li>
                    <li>5. Verify webhook receives payment confirmation</li>
                  </ol>
                </div>

                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h3 className="font-semibold text-yellow-800 mb-2">STRIPEGATE Breaking News</h3>
                  <p className="text-sm text-yellow-700">
                    This crypto payment system serves the 430.5M underbanked entrepreneurs 
                    that Stripe systematically excluded from Caribbean, Africa, Latin America, 
                    and Asia markets.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Technical Details */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Technical Implementation Details</CardTitle>
              <CardDescription>
                Crypto payment integration for underbanked markets
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div>
                  <h3 className="font-semibold mb-2">Backend Integration</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Coinbase Commerce API service</li>
                    <li>• Charge creation endpoint</li>
                    <li>• Payment verification system</li>
                    <li>• Webhook handling for confirmations</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Frontend Components</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• React crypto payment button</li>
                    <li>• Real-time payment status</li>
                    <li>• Error handling & user feedback</li>
                    <li>• Responsive design for mobile</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Security Features</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• API key encryption</li>
                    <li>• Webhook signature verification</li>
                    <li>• HTTPS-only communication</li>
                    <li>• PCI DSS compliant infrastructure</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}