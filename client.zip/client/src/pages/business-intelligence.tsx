import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  Building2, 
  TrendingUp, 
  DollarSign, 
  Users, 
  MapPin, 
  ExternalLink,
  Database,
  BarChart3,
  Globe
} from "lucide-react";
import SEOHead from "@/components/seo-head";
import AnalyticsTracker from "@/components/analytics-tracker";

interface Company {
  cik: string;
  name: string;
  ticker?: string;
  industry?: string;
  address?: string;
  website?: string;
  description?: string;
  revenue?: number;
  employees?: number;
  source: string;
}

interface CompanySearchResponse {
  companies: Company[];
  total: number;
  query: string;
  source: string;
}

export default function BusinessIntelligence() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchSubmitted, setSearchSubmitted] = useState("");
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [activeTab, setActiveTab] = useState("trending");
  const { toast } = useToast();

  // Search companies
  const { data: searchResults, isLoading: isSearching, error: searchError } = useQuery<CompanySearchResponse>({
    queryKey: ['/api/companies/search', searchSubmitted],
    queryFn: async () => {
      if (!searchSubmitted) return null;
      const response = await fetch(`/api/companies/search?query=${encodeURIComponent(searchSubmitted)}&limit=20`);
      if (!response.ok) throw new Error('Search failed');
      return response.json();
    },
    enabled: !!searchSubmitted,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 3,
    refetchOnWindowFocus: false,
  });

  // Get trending companies
  const { data: trendingData, isLoading: isTrendingLoading, error: trendingError } = useQuery<CompanySearchResponse>({
    queryKey: ['/api/companies/trending'],
    queryFn: async () => {
      const response = await fetch('/api/companies/trending');
      if (!response.ok) throw new Error('Failed to load trending companies');
      return response.json();
    },
    staleTime: 10 * 60 * 1000, // 10 minutes
    retry: 3,
    refetchOnWindowFocus: false,
  });

  // Debug after hooks are defined
  console.log('Business Intelligence Debug:', {
    trendingData,
    isTrendingLoading,
    trendingError: trendingError?.message,
    searchResults,
    isSearching,
    searchError: searchError?.message
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSearchSubmitted(searchQuery.trim());
      // Auto-switch to search tab when searching
      setActiveTab("search");
    }
  };

  const formatRevenue = (revenue?: number) => {
    if (!revenue) return "N/A";
    if (revenue >= 1e9) return `$${(revenue / 1e9).toFixed(1)}B`;
    if (revenue >= 1e6) return `$${(revenue / 1e6).toFixed(1)}M`;
    if (revenue >= 1e3) return `$${(revenue / 1e3).toFixed(1)}K`;
    return `$${revenue}`;
  };

  const handleCompanyClick = (company: Company) => {
    setSelectedCompany(company);
    toast({
      title: "Company Selected",
      description: `Viewing details for ${company.name}`,
    });
    // Scroll to the company details section
    setTimeout(() => {
      const element = document.getElementById('company-details');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <SEOHead 
        title="Business Intelligence Database | FindMyBizName"
        description="Search 500,000+ companies from SEC EDGAR database. Get business intelligence, competitor analysis, and market research data for entrepreneurs."
        keywords="business intelligence, company database, SEC EDGAR, competitor analysis, market research"
      />
      <AnalyticsTracker />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Business Intelligence Database
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Research 500,000+ public companies from SEC EDGAR database. Get competitor insights, 
            market intelligence, and business data to validate your ideas.
          </p>
          
          {/* Debug Info */}
          {trendingError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4 mt-4">
              <p className="text-red-700">Trending Error: {trendingError.message}</p>
            </div>
          )}
          {searchError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4 mt-4">
              <p className="text-red-700">Search Error: {searchError.message}</p>
            </div>
          )}
          
          {/* Data Status */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4 mt-4 text-sm">
            <p className="text-blue-700">
              Trending Loading: {isTrendingLoading ? 'Yes' : 'No'} | 
              Companies Found: {trendingData?.companies?.length || 0} | 
              Search Loading: {isSearching ? 'Yes' : 'No'}
            </p>
          </div>
          <div className="flex items-center justify-center gap-4 mt-4">
            <Badge variant="secondary" className="flex items-center gap-1">
              <Database className="h-3 w-3" />
              SEC EDGAR Database
            </Badge>
            <Badge variant="secondary" className="flex items-center gap-1">
              <Globe className="h-3 w-3" />
              500K+ Companies
            </Badge>
            <Badge variant="secondary" className="flex items-center gap-1">
              <BarChart3 className="h-3 w-3" />
              Financial Data
            </Badge>
          </div>
        </div>



        {/* Search Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Company Search
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="flex gap-2">
              <Input
                type="text"
                placeholder="Search companies by name or ticker (e.g., Apple, AAPL, Tesla)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" disabled={isSearching}>
                {isSearching ? "Searching..." : "Search"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="trending" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Trending Companies
            </TabsTrigger>
            <TabsTrigger value="search" className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              Search Results
            </TabsTrigger>
          </TabsList>

          {/* Trending Companies Tab */}
          <TabsContent value="trending">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {isTrendingLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader>
                      <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="h-3 bg-gray-200 rounded"></div>
                        <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : trendingData?.companies?.map((company: Company) => (
                <Card 
                  key={company.cik} 
                  className="hover:shadow-lg hover:border-blue-300 dark:hover:border-blue-600 transition-all duration-200 cursor-pointer transform hover:scale-[1.02] border-2 border-transparent"
                  onClick={() => handleCompanyClick(company)}
                >
                  <CardHeader>
                    <CardTitle className="text-lg flex items-start justify-between">
                      <span className="flex-1">{company.name}</span>
                      {company.ticker && (
                        <Badge variant="outline">{company.ticker}</Badge>
                      )}
                    </CardTitle>
                    {company.industry && (
                      <p className="text-sm text-muted-foreground">{company.industry}</p>
                    )}
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {company.revenue && (
                        <div className="flex items-center gap-2 text-sm">
                          <DollarSign className="h-4 w-4 text-green-600" />
                          <span>Revenue: {formatRevenue(company.revenue)}</span>
                        </div>
                      )}
                      {company.address && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="h-4 w-4" />
                          <span className="truncate">{company.address}</span>
                        </div>
                      )}
                      {company.website && (
                        <div className="flex items-center gap-2 text-sm">
                          <ExternalLink className="h-4 w-4 text-blue-600" />
                          <a 
                            href={company.website.startsWith('http') ? company.website : `https://${company.website}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline truncate"
                            onClick={(e) => e.stopPropagation()}
                          >
                            {company.website}
                          </a>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Search Results Tab */}
          <TabsContent value="search">
            {searchError && (
              <Card className="border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20">
                <CardContent className="pt-6">
                  <p className="text-red-600 dark:text-red-400">
                    Failed to search companies. Please try again.
                  </p>
                </CardContent>
              </Card>
            )}

            {!searchSubmitted && !isSearching && (
              <Card>
                <CardContent className="pt-6 text-center py-12">
                  <Search className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    Search Companies
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    Enter a company name or ticker symbol to search the SEC EDGAR database
                  </p>
                </CardContent>
              </Card>
            )}

            {isSearching && searchSubmitted && (
              <Card>
                <CardContent className="pt-6 text-center py-12">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    Searching Companies...
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    Querying SEC EDGAR database
                  </p>
                </CardContent>
              </Card>
            )}

            {searchSubmitted && searchResults && !isSearching && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">
                    Search Results for "{searchResults.query}"
                  </h3>
                  <Badge variant="secondary">
                    {searchResults.total} results from {searchResults.source}
                  </Badge>
                </div>

                {searchResults.companies.length === 0 ? (
                  <Card className="border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-900/20">
                    <CardContent className="pt-6 text-center py-12">
                      <Search className="h-12 w-12 mx-auto text-amber-500 mb-4" />
                      <h3 className="text-lg font-medium text-amber-800 dark:text-amber-200 mb-2">
                        No Results Found
                      </h3>
                      <p className="text-amber-600 dark:text-amber-300 mb-4">
                        "{searchResults.query}" was not found in the SEC EDGAR database.
                      </p>
                      <div className="text-sm text-amber-600 dark:text-amber-400 space-y-1">
                        <p><strong>Search Tips:</strong></p>
                        <p>• Try the exact company name (e.g., "Apple Inc")</p>
                        <p>• Use the ticker symbol (e.g., "AAPL")</p>
                        <p>• Check spelling and try variations</p>
                        <p>• Only public companies are in the database</p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {searchResults.companies.map((company: Company) => (
                    <Card 
                      key={company.cik} 
                      className="hover:shadow-lg hover:border-blue-300 dark:hover:border-blue-600 transition-all duration-200 cursor-pointer transform hover:scale-[1.02] border-2 border-transparent"
                      onClick={() => handleCompanyClick(company)}
                    >
                      <CardHeader>
                        <CardTitle className="text-lg flex items-start justify-between">
                          <span className="flex-1">{company.name}</span>
                          {company.ticker && (
                            <Badge variant="outline">{company.ticker}</Badge>
                          )}
                        </CardTitle>
                        {company.industry && (
                          <p className="text-sm text-muted-foreground">{company.industry}</p>
                        )}
                      </CardHeader>
                      <CardContent>
                        <div className="text-xs text-blue-600 dark:text-blue-400 font-medium mb-2 flex items-center gap-1">
                          <span>👆 Click for details</span>
                        </div>
                        <div className="space-y-2">
                          {company.revenue && (
                            <div className="flex items-center gap-2 text-sm">
                              <DollarSign className="h-4 w-4 text-green-600" />
                              <span>Revenue: {formatRevenue(company.revenue)}</span>
                            </div>
                          )}
                          {company.address && (
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <MapPin className="h-4 w-4" />
                              <span className="truncate">{company.address}</span>
                            </div>
                          )}
                          {company.website && (
                            <div className="flex items-center gap-2 text-sm">
                              <ExternalLink className="h-4 w-4 text-blue-600" />
                              <a 
                                href={company.website.startsWith('http') ? company.website : `https://${company.website}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:underline truncate"
                                onClick={(e) => e.stopPropagation()}
                              >
                                {company.website}
                              </a>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  </div>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Company Detail Modal/Section */}
        {selectedCompany && (
          <Card id="company-details" className="mt-8 border-2 border-blue-200 dark:border-blue-800">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-2xl flex items-center gap-3">
                    <Building2 className="h-6 w-6" />
                    {selectedCompany.name}
                    {selectedCompany.ticker && (
                      <Badge variant="outline" className="text-lg px-3 py-1">
                        {selectedCompany.ticker}
                      </Badge>
                    )}
                  </CardTitle>
                  {selectedCompany.industry && (
                    <p className="text-lg text-muted-foreground mt-2">{selectedCompany.industry}</p>
                  )}
                </div>
                <Button 
                  variant="outline" 
                  onClick={() => setSelectedCompany(null)}
                >
                  Close
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {selectedCompany.description && (
                <div>
                  <h4 className="font-semibold mb-2">Business Description</h4>
                  <p className="text-muted-foreground leading-relaxed">
                    {selectedCompany.description}
                  </p>
                </div>
              )}

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Company Information</h4>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Database className="h-4 w-4 text-blue-600" />
                      <span className="text-sm">CIK: {selectedCompany.cik}</span>
                    </div>
                    {selectedCompany.revenue && (
                      <div className="flex items-center gap-3">
                        <DollarSign className="h-4 w-4 text-green-600" />
                        <span className="text-sm">Annual Revenue: {formatRevenue(selectedCompany.revenue)}</span>
                      </div>
                    )}
                    {selectedCompany.address && (
                      <div className="flex items-start gap-3">
                        <MapPin className="h-4 w-4 text-red-600 mt-0.5" />
                        <span className="text-sm">{selectedCompany.address}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold">External Links</h4>
                  <div className="space-y-3">
                    {selectedCompany.website && (
                      <a 
                        href={selectedCompany.website.startsWith('http') ? selectedCompany.website : `https://${selectedCompany.website}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 text-blue-600 hover:underline"
                      >
                        <ExternalLink className="h-4 w-4" />
                        <span className="text-sm">Company Website</span>
                      </a>
                    )}
                    <a 
                      href={`https://www.sec.gov/edgar/search/#/ciks=${selectedCompany.cik}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 text-blue-600 hover:underline"
                    >
                      <ExternalLink className="h-4 w-4" />
                      <span className="text-sm">SEC EDGAR Filings</span>
                    </a>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <p className="text-sm text-blue-800 dark:text-blue-200">
                  <strong>Business Intelligence:</strong> This data comes from the SEC EDGAR database, 
                  providing authentic, government-verified information about public companies. 
                  Use this intelligence to understand your competition, validate market opportunities, 
                  and research industry trends.
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}