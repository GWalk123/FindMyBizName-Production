import { useEffect } from 'react';
import { Link } from 'wouter';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, ArrowRight, Crown } from "lucide-react";
import SEOHead from "@/components/seo-head";
import { useAnalytics } from "@/components/analytics-tracker";

export default function SubscriptionSuccess() {
  const { trackPageView, trackConversion } = useAnalytics();

  useEffect(() => {
    trackPageView("subscription_success");
    trackConversion("subscription_completed", 1);
  }, []);

  // Get transaction details from URL params if available
  const urlParams = new URLSearchParams(window.location.search);
  const orderId = urlParams.get('order_id');
  const status = urlParams.get('status');
  const total = urlParams.get('total');
  const currency = urlParams.get('currency');

  const isSuccess = status === 'success';

  return (
    <>
      <SEOHead 
        title="Subscription Complete - BizNameForge"
        description="Your BizNameForge Premium subscription is now active. Start generating unlimited business names and checking premium domains."
      />
      
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-6">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            {isSuccess ? (
              <>
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <CardTitle className="text-2xl text-green-700">
                  🎉 Subscription Active!
                </CardTitle>
              </>
            ) : (
              <>
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">❌</span>
                </div>
                <CardTitle className="text-2xl text-red-700">
                  Payment Not Completed
                </CardTitle>
              </>
            )}
          </CardHeader>
          
          <CardContent className="text-center space-y-6">
            {isSuccess ? (
              <>
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <p className="text-green-800 font-medium mb-2">
                    Welcome to BizNameForge Premium! 🇹🇹
                  </p>
                  <p className="text-sm text-green-600">
                    Your subscription is now active. You have access to unlimited name generation, 
                    premium domains, and advanced business tools.
                  </p>
                </div>

                {orderId && (
                  <div className="text-sm text-gray-600">
                    <p><strong>Order ID:</strong> {orderId}</p>
                    {total && currency && (
                      <p><strong>Amount:</strong> {currency} ${total}</p>
                    )}
                  </div>
                )}

                <div className="space-y-3">
                  <h3 className="font-medium text-gray-900">What's Next?</h3>
                  <div className="text-sm text-gray-600 space-y-2">
                    <div className="flex items-center">
                      <Crown className="w-4 h-4 text-yellow-500 mr-2" />
                      <span>Generate unlimited business names</span>
                    </div>
                    <div className="flex items-center">
                      <Crown className="w-4 h-4 text-yellow-500 mr-2" />
                      <span>Check premium domain availability (.ai, .io, .co)</span>
                    </div>
                    <div className="flex items-center">
                      <Crown className="w-4 h-4 text-yellow-500 mr-2" />
                      <span>Export favorites as professional PDFs</span>
                    </div>
                  </div>
                </div>

                <Link href="/">
                  <Button className="w-full" size="lg">
                    Start Creating Names
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </>
            ) : (
              <>
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <p className="text-red-800 font-medium mb-2">
                    Payment was not completed
                  </p>
                  <p className="text-sm text-red-600">
                    Your subscription was not activated. You can try again or contact support for assistance.
                  </p>
                </div>

                <div className="space-y-3">
                  <Link href="/subscribe">
                    <Button className="w-full" size="lg">
                      Try Again
                    </Button>
                  </Link>
                  
                  <Link href="/alternative-payments">
                    <Button variant="outline" className="w-full">
                      Alternative Payment Methods
                    </Button>
                  </Link>
                </div>

                <div className="text-xs text-gray-500">
                  Need help? Contact us:
                  <br />
                  WhatsApp: +1 (868) 720-9758
                  <br />
                  Email: gregorywalker760@gmail.com
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}