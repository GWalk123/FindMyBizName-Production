import { useEffect } from 'react';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonical?: string;
}

export default function SEOHead({ 
  title = "FindMyBizName - The Shopify of Caribbean Business Tools", 
  description = "The leading business name generator for underbanked entrepreneurs. Pay with T&T debit cards, WiPay, or local methods. No credit card required. Generate names instantly.",
  keywords = "business name generator, Trinidad Tobago, underbanked entrepreneurs, debit card payments, WiPay, no credit card, local business tools, startup names",
  canonical = window.location.href
}: SEOHeadProps) {
  useEffect(() => {
    // Update document title
    document.title = title;

    // Update meta description
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', description);

    // Update meta keywords
    let metaKeywords = document.querySelector('meta[name="keywords"]');
    if (!metaKeywords) {
      metaKeywords = document.createElement('meta');
      metaKeywords.setAttribute('name', 'keywords');
      document.head.appendChild(metaKeywords);
    }
    metaKeywords.setAttribute('content', keywords);

    // Update canonical URL
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', canonical);

    // Open Graph tags
    const ogTags = [
      { property: 'og:title', content: title },
      { property: 'og:description', content: description },
      { property: 'og:type', content: 'website' },
      { property: 'og:url', content: canonical },
      { property: 'og:site_name', content: 'FindMyBizName' },
    ];

    ogTags.forEach(tag => {
      let ogTag = document.querySelector(`meta[property="${tag.property}"]`);
      if (!ogTag) {
        ogTag = document.createElement('meta');
        ogTag.setAttribute('property', tag.property);
        document.head.appendChild(ogTag);
      }
      ogTag.setAttribute('content', tag.content);
    });

    // Twitter Card tags
    const twitterTags = [
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: title },
      { name: 'twitter:description', content: description },
    ];

    twitterTags.forEach(tag => {
      let twitterTag = document.querySelector(`meta[name="${tag.name}"]`);
      if (!twitterTag) {
        twitterTag = document.createElement('meta');
        twitterTag.setAttribute('name', tag.name);
        document.head.appendChild(twitterTag);
      }
      twitterTag.setAttribute('content', tag.content);
    });

    // Add structured data for better SEO indexing
    let structuredData = document.querySelector('script[type="application/ld+json"]');
    if (structuredData) {
      structuredData.remove();
    }
    
    structuredData = document.createElement('script');
    (structuredData as HTMLScriptElement).type = 'application/ld+json';
    structuredData.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      "name": "FindMyBizName",
      "applicationCategory": "BusinessApplication",
      "operatingSystem": "Web Browser",
      "description": "AI-powered business name generator for underbanked entrepreneurs. Accepts T&T debit cards, WiPay, and local payment methods.",
      "url": "https://opportunity-hunter-gregorywalker76.replit.app",
      "provider": {
        "@type": "Organization",
        "name": "FindMyBizName",
        "description": "The Shopify of Caribbean Business Tools"
      },
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "USD",
        "description": "Free business name generation with premium upgrades available"
      },
      "featureList": [
        "AI business name generation",
        "Domain availability checking", 
        "T&T debit card payments",
        "WiPay integration",
        "Caribbean-focused tools"
      ],
      "audience": {
        "@type": "Audience",
        "audienceType": "Underbanked Entrepreneurs",
        "geographicArea": "Trinidad and Tobago"
      }
    });
    document.head.appendChild(structuredData);

  }, [title, description, keywords, canonical]);

  return null;
}