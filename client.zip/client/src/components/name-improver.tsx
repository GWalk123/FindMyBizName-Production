import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, Target, Zap, Star, Crown, Lock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import UpgradeModal from "./upgrade-modal";


interface NameSuggestion {
  name: string;
  improvement: string;
  score: number;
  reasons: string[];
}

export default function NameImprover() {
  const [currentName, setCurrentName] = useState("");
  const [suggestions, setSuggestions] = useState<NameSuggestion[]>([]);
  const [isImproving, setIsImproving] = useState(false);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      const response = await fetch('/api/user');
      if (!response.ok) throw new Error('Failed to fetch user data');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });


  const handleImprove = async () => {
    if (!currentName.trim() || !user) return;
    
    // Check usage limits for free users
    if (user.plan === 'free') {
      const usageLimit = 5; // Free users get 5 total improvements
      const remaining = usageLimit - (user.nameImprovementUsage || 0);
      
      if (remaining <= 0) {
        setShowUpgradeModal(true);
        return;
      }
      
      // Show upgrade prompt when close to limit
      if (remaining <= 1) {
        setShowUpgradeModal(true);
        return;
      }
    }
    
    setIsImproving(true);
    
    // Generate improved name suggestions
    const improvements = generateImprovedNames(currentName);
    setSuggestions(improvements);
    
    // Track usage (would normally call API to update user usage)
    
    setIsImproving(false);
  };

  const generateImprovedNames = (originalName: string): NameSuggestion[] => {
    const base = originalName.toLowerCase().replace(/[^a-z0-9]/g, '');
    const suggestions: NameSuggestion[] = [];

    // Power words for improvement
    const powerWords = ['Pro', 'Elite', 'Prime', 'Edge', 'Max', 'Plus', 'Hub', 'Labs', 'Works', 'Studio'];
    const modernSuffixes = ['AI', 'Tech', 'Digital', 'Smart', 'Cloud', 'Connect', 'Flow', 'Sphere'];
    const caribbeanFlair = ['Tropic', 'Island', 'Caribbean', 'Carib', 'Tropical', 'Paradise'];

    // Improvement 1: Add power word
    const powerVariant = originalName + powerWords[Math.floor(Math.random() * powerWords.length)];
    suggestions.push({
      name: powerVariant,
      improvement: "Added Authority",
      score: Math.floor(Math.random() * 15) + 75,
      reasons: ["More professional sound", "Increased memorability", "Authority positioning"]
    });

    // Improvement 2: Modern tech variant
    const techVariant = base.charAt(0).toUpperCase() + base.slice(1) + modernSuffixes[Math.floor(Math.random() * modernSuffixes.length)];
    suggestions.push({
      name: techVariant,
      improvement: "Tech Forward",
      score: Math.floor(Math.random() * 12) + 78,
      reasons: ["Modern appeal", "Digital positioning", "Future-ready branding"]
    });

    // Improvement 3: Caribbean localization
    const caribVariant = caribbeanFlair[Math.floor(Math.random() * caribbeanFlair.length)] + originalName.replace(/[^a-zA-Z]/g, '');
    suggestions.push({
      name: caribVariant,
      improvement: "Local Appeal",
      score: Math.floor(Math.random() * 10) + 80,
      reasons: ["Caribbean market appeal", "Cultural relevance", "Regional trust building"]
    });

    // Improvement 4: Simplified version
    const simplified = originalName.replace(/[^a-zA-Z]/g, '').slice(0, 8) + (originalName.length > 8 ? 'Co' : '');
    suggestions.push({
      name: simplified,
      improvement: "Simplified",
      score: Math.floor(Math.random() * 8) + 82,
      reasons: ["Easier to remember", "Shorter is better", "Clean professional look"]
    });

    return suggestions.sort((a, b) => b.score - a.score);
  };

  const getScoreColor = (score: number) => {
    if (score >= 85) return "text-green-600";
    if (score >= 75) return "text-yellow-600";
    return "text-red-600";
  };

  const getImprovementIcon = (improvement: string) => {
    switch (improvement) {
      case "Added Authority": return <Target className="h-4 w-4" />;
      case "Tech Forward": return <Zap className="h-4 w-4" />;
      case "Local Appeal": return <Star className="h-4 w-4" />;
      case "Simplified": return <TrendingUp className="h-4 w-4" />;
      default: return <Sparkles className="h-4 w-4" />;
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-600" />
          Name Improvement Engine
          <Badge variant="secondary" className="bg-purple-100 text-purple-700">
            Get Better Suggestions
          </Badge>
          {user?.plan === 'free' && (
            <Badge variant="outline" className="text-xs">
              {Math.max(0, 5 - (user.nameImprovementUsage || 0))}/5 Free
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Controls Row */}
          <div className="flex gap-4 justify-center items-center">
            <Button 
              onClick={handleImprove} 
              disabled={isImproving || currentName.trim().length < 1}
              className="px-8 bg-purple-600 hover:bg-purple-700"
            >
              {isImproving ? "Improving..." : "Get Better Suggestions"}
            </Button>
          </div>
          
          {/* Full-width Input Field */}
          <div>
            <input
              type="text"
              placeholder="Enter your current business name (e.g., MyBusiness, TechCorp, ServicePro)"
              value={currentName}
              onChange={(e) => setCurrentName(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleImprove()}
              style={{
                width: '100%',
                height: '50px',
                padding: '12px 16px',
                fontSize: '16px',
                color: '#000000',
                backgroundColor: '#ffffff',
                border: '2px solid #d1d5db',
                borderRadius: '8px',
                outline: 'none',
                fontFamily: 'system-ui, -apple-system, sans-serif'
              }}
              onFocus={(e) => {
                e.target.style.borderColor = '#7c3aed';
                e.target.style.boxShadow = '0 0 0 3px rgba(124, 58, 237, 0.1)';
              }}
              onBlur={(e) => {
                e.target.style.borderColor = '#d1d5db';
                e.target.style.boxShadow = 'none';
              }}
            />
          </div>

          {/* Results */}
          {suggestions.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-center">Better Name Suggestions:</h3>
              <div className="grid gap-3">
                {suggestions.map((suggestion, index) => (
                  <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {getImprovementIcon(suggestion.improvement)}
                        <span className="font-semibold text-lg">{suggestion.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {suggestion.improvement}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`font-bold ${getScoreColor(suggestion.score)}`}>
                          {suggestion.score}/100
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {suggestion.reasons.map((reason, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {reason}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="text-center pt-4 border-t">
                <p className="text-sm text-gray-600 mb-2">
                  Want comprehensive analysis for these names?
                </p>
                <Button variant="outline" className="text-purple-600 border-purple-600">
                  Analyze All Suggestions
                </Button>
              </div>
            </div>
          )}

          {currentName && suggestions.length === 0 && !isImproving && (
            <div className="text-center py-8 text-gray-500">
              Click "Get Better Suggestions" to see improved versions of "{currentName}"
            </div>
          )}
        </div>
      </CardContent>
      
      <UpgradeModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        feature="nameImprovement"
        usageRemaining={user?.plan === 'free' ? Math.max(0, 5 - (user.nameImprovementUsage || 0)) : -1}
      />
    </Card>
  );
}