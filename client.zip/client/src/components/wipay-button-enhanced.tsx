import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Copy, ExternalLink, Phone } from 'lucide-react';

interface WiPayButtonProps {
  amount: number;
  currency?: string;
  plan?: string;
  userEmail?: string;
  userName?: string;
  onSuccess?: (data: any) => void;
  onError?: (error: any) => void;
  className?: string;
  disabled?: boolean;
}

export default function WiPayButtonEnhanced({
  amount,
  currency = 'TTD',
  plan = 'Premium',
  userEmail = 'entrepreneur@example.com',
  userName = 'Caribbean Entrepreneur',
  onSuccess,
  onError,
  className,
  disabled = false
}: WiPayButtonProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [paymentInstructions, setPaymentInstructions] = useState<any>(null);
  const { toast } = useToast();

  const handlePayment = async () => {
    setIsLoading(true);

    try {
      const response = await apiRequest('POST', '/api/wipay/voucher', {
        amount,
        currency,
        description: `${plan} Plan - FindMyBizName Subscription`,
        customerEmail: userEmail,
        customerName: userName,
        plan
      });

      const data = await response.json();

      if (data.success) {
        setPaymentInstructions(data);
        toast({
          title: "Payment Instructions Generated",
          description: "Follow the WiPay transfer instructions below",
          variant: "default"
        });

        onSuccess?.(data);
      } else {
        throw new Error('Failed to generate payment instructions');
      }
    } catch (error) {
      console.error('WiPay payment error:', error);
      setIsLoading(false);
      
      toast({
        title: "Payment Error",
        description: error instanceof Error ? error.message : "Failed to process payment request",
        variant: "destructive"
      });
      
      onError?.(error);
    } finally {
      if (!paymentInstructions) {
        setIsLoading(false);
      }
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard`,
      variant: "default"
    });
  };

  const formatCurrency = (amount: number, currency: string) => {
    try {
      return new Intl.NumberFormat('en-TT', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 2
      }).format(amount);
    } catch {
      return `${currency} ${amount.toFixed(2)}`;
    }
  };

  const openWhatsApp = (phone: string, message: string) => {
    const whatsappUrl = `https://wa.me/${phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  if (paymentInstructions) {
    const instructions = paymentInstructions.paymentInstructions;
    const whatsappMessage = `Hi! I've completed WiPay transfer for FindMyBizName ${plan} plan.\n\nReference: ${instructions.reference}\nAmount: ${formatCurrency(amount, currency)}\nEmail: ${userEmail}\n\nPlease confirm receipt and upgrade my account. Thank you!`;

    return (
      <div className="space-y-6">
        <Card className="border-green-200 bg-green-50 dark:bg-green-900/20">
          <CardHeader>
            <CardTitle className="text-green-800 dark:text-green-200 flex items-center gap-2">
              🇹🇹 WiPay Payment Instructions
              <Badge variant="secondary">VERIFIED ACCOUNT</Badge>
            </CardTitle>
            <CardDescription>
              Complete your transfer to activate your {plan} plan
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Payment Summary */}
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border">
              <h4 className="font-semibold mb-2">Payment Summary</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <span className="text-muted-foreground">Amount:</span>
                <span className="font-medium">{formatCurrency(amount, currency)}</span>
                <span className="text-muted-foreground">Plan:</span>
                <span className="font-medium">{plan}</span>
                <span className="text-muted-foreground">Reference:</span>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-blue-600">{instructions.reference}</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(instructions.reference, 'Reference')}
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Transfer Instructions */}
            <div className="space-y-3">
              <h4 className="font-semibold">Transfer Instructions:</h4>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                  <span className="text-muted-foreground">Recipient:</span>
                  <span className="font-medium">FindMyBizName</span>
                  <span className="text-muted-foreground">Account:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-blue-600">6848049593</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard('6848049593', 'Account Number')}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                
                <ol className="text-sm space-y-1">
                  {instructions.instructions.map((instruction: string, index: number) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="bg-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium flex-shrink-0 mt-0.5">
                        {index + 1}
                      </span>
                      <span>{instruction}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                onClick={() => openWhatsApp(instructions.contact, whatsappMessage)}
                className="flex-1"
                variant="default"
              >
                <Phone className="h-4 w-4 mr-2" />
                Confirm via WhatsApp
              </Button>
              <Button
                onClick={() => window.open('https://wipayfinancial.com', '_blank')}
                variant="outline"
                className="flex-1"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                Open WiPay
              </Button>
            </div>

            {/* Processing Time */}
            <div className="text-center text-sm text-muted-foreground">
              <p>
                <strong>Processing Time:</strong> {paymentInstructions.estimatedProcessingTime}
              </p>
              <p>Support: {instructions.contact} | Monday-Saturday 8AM-8PM AST</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <Button
        onClick={handlePayment}
        disabled={disabled || isLoading}
        className={`w-full ${className}`}
        size="lg"
      >
        {isLoading ? (
          <div className="flex items-center space-x-2">
            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            <span>Generating Instructions...</span>
          </div>
        ) : (
          <div className="flex items-center space-x-2">
            <span>Pay {formatCurrency(amount, currency)} with WiPay</span>
          </div>
        )}
      </Button>
      
      <div className="flex flex-wrap gap-2 justify-center">
        <Badge variant="secondary" className="text-xs">
          🇹🇹 Trinidad & Tobago
        </Badge>
        <Badge variant="secondary" className="text-xs">
          ✅ Verified Account
        </Badge>
        <Badge variant="secondary" className="text-xs">
          📱 Mobile First
        </Badge>
        <Badge variant="secondary" className="text-xs">
          💬 WhatsApp Support
        </Badge>
      </div>
      
      <div className="text-center text-sm text-muted-foreground">
        <p>
          Secure local payment processing • Account: 6848049593 • 
          <br />
          Powered by WiPay T&T • 2.5% fees • Instant notifications
        </p>
      </div>
    </div>
  );
}