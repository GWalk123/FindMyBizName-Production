import { useEffect, useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, CheckCircle } from "lucide-react";

interface LoadingProgressProps {
  progress: number;
  loadingState: Record<string, boolean>;
}

export function LoadingProgress({ progress, loadingState }: LoadingProgressProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    if (progress === 100) {
      const timer = setTimeout(() => setIsVisible(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [progress]);

  if (!isVisible || progress === 100) return null;

  const componentLabels: Record<string, string> = {
    'core-ui': 'Core Interface',
    'name-generator': 'Business Name Generator',
    'domain-checker': 'Domain Availability Checker', 
    'analytics': 'Launch Analytics Dashboard',
    'performance-monitor': 'System Performance Monitor'
  };

  return (
    <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 w-96">
      <Card className="bg-white shadow-lg border-2 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-center gap-3 mb-3">
            <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
            <h3 className="font-semibold text-gray-900">Loading Business Platform</h3>
          </div>
          
          <Progress value={progress} className="mb-4" />
          
          <div className="space-y-2 text-sm">
            {Object.entries(componentLabels).map(([key, label]) => (
              <div key={key} className="flex items-center justify-between">
                <span className={loadingState[key] ? 'text-green-700' : 'text-gray-500'}>
                  {label}
                </span>
                {loadingState[key] && (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                )}
              </div>
            ))}
          </div>
          
          <p className="text-xs text-gray-500 mt-3 text-center">
            Initializing features sequentially for optimal performance
          </p>
        </CardContent>
      </Card>
    </div>
  );
}