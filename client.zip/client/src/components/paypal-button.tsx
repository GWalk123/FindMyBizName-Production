import React, { useEffect } from "react";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "paypal-button": React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement>,
        HTMLElement
      >;
    }
  }
}

interface PayPalButtonProps {
  amount: string;
  currency: string;
  intent: string;
  planName?: string;
}

export default function PayPalButton({
  amount,
  currency,
  intent,
  planName = "FindMyBizName Plan",
}: PayPalButtonProps) {
  const createOrder = async () => {
    const orderPayload = {
      amount: amount,
      currency: currency,
      intent: intent,
    };
    const response = await fetch("/paypal/order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(orderPayload),
    });
    const output = await response.json();
    return { orderId: output.id };
  };

  const captureOrder = async (orderId: string) => {
    const response = await fetch(`/paypal/order/${orderId}/capture`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });
    const data = await response.json();
    return data;
  };

  const onApprove = async (data: any) => {
    console.log("Payment approved:", data);
    const orderData = await captureOrder(data.orderId);
    console.log("Payment captured:", orderData);
    
    // Show success message
    alert(`Payment successful! Welcome to ${planName}. Check your email for details.`);
  };

  const onCancel = async (data: any) => {
    console.log("Payment cancelled:", data);
    alert("Payment was cancelled. You can try again anytime.");
  };

  const onError = async (data: any) => {
    console.log("Payment error:", data);
    alert("Payment error occurred. Please try again or contact support.");
  };

  useEffect(() => {
    const loadPayPalSDK = async () => {
      try {
        if (!(window as any).paypal) {
          const script = document.createElement("script");
          script.src = (import.meta as any).env?.PROD
            ? "https://www.paypal.com/web-sdk/v6/core"
            : "https://www.sandbox.paypal.com/web-sdk/v6/core";
          script.async = true;
          script.onload = () => initPayPal();
          document.body.appendChild(script);
        } else {
          await initPayPal();
        }
      } catch (e) {
        console.warn("PayPal SDK load failed, using fallback", e?.message || e);
        // Gracefully handle SDK loading failure
      }
    };

    loadPayPalSDK();
  }, []);

  const initPayPal = async () => {
    try {
      const clientToken: string = await fetch("/paypal/setup")
        .then((res) => res.json())
        .then((data) => {
          return data.clientToken;
        });
      
      const sdkInstance = await (window as any).paypal.createInstance({
        clientToken,
        components: ["paypal-payments"],
      });

      const paypalCheckout = sdkInstance.createPayPalOneTimePaymentSession({
        onApprove,
        onCancel,
        onError,
      });

      const onClick = async () => {
        try {
          const checkoutOptionsPromise = createOrder();
          await paypalCheckout.start(
            { paymentFlow: "auto" },
            checkoutOptionsPromise,
          );
        } catch (e) {
          console.warn("PayPal checkout error handled:", e?.message || e);
        }
      };

      const paypalButton = document.getElementById("paypal-button");
      if (paypalButton) {
        paypalButton.addEventListener("click", onClick);
      }

      return () => {
        if (paypalButton) {
          paypalButton.removeEventListener("click", onClick);
        }
      };
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="w-full">
      <paypal-button 
        id="paypal-button"
        className="w-full bg-[#0070ba] hover:bg-[#005ea6] text-white font-semibold py-3 px-6 rounded-lg cursor-pointer transition-colors duration-200 text-center block"
        style={{
          background: '#0070ba',
          color: 'white',
          border: 'none',
          borderRadius: '8px',
          padding: '12px 24px',
          fontSize: '16px',
          fontWeight: '600',
          cursor: 'pointer',
          width: '100%',
          textAlign: 'center' as const,
        }}
      >
        💳 Pay with PayPal - ${amount}
      </paypal-button>
    </div>
  );
}