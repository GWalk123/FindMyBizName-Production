import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Crown, Zap, TrendingUp, CheckCircle } from "lucide-react";
import { Link } from "wouter";
import { useAnalytics } from "@/components/analytics-tracker";

interface LimitReachedBannerProps {
  remainingUsage: number;
  onUpgradeClick?: () => void;
}

export function LimitReachedBanner({ remainingUsage, onUpgradeClick }: LimitReachedBannerProps) {
  const { trackUpgradeClick } = useAnalytics();
  
  if (remainingUsage > 0) return null;

  const handleUpgradeClick = () => {
    trackUpgradeClick('limit_reached_banner');
    onUpgradeClick?.();
  };

  return (
    <Card className="border-red-600 bg-red-500 mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-red-700 rounded-full flex items-center justify-center">
              <Crown className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Monthly Limit Reached!</h3>
              <p className="text-sm text-white">
                You've used all your free generations this month. Upgrade for unlimited access + advanced features!
              </p>
            </div>
          </div>
          <Link href="/subscribe?plan=premium">
            <Button onClick={handleUpgradeClick} className="bg-red-600 hover:bg-red-700">
              Upgrade Now
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

interface SocialProofProps {
  className?: string;
}

export function SocialProof({ className = "" }: SocialProofProps) {
  const [stats, setStats] = useState({
    totalNames: 0,
    activeUsers: 0,
    domainsChecked: 0
  });

  useEffect(() => {
    // Simulate growing numbers for social proof
    const interval = setInterval(() => {
      setStats(prev => ({
        totalNames: Math.min(prev.totalNames + Math.floor(Math.random() * 3) + 1, 50000),
        activeUsers: Math.min(prev.activeUsers + Math.floor(Math.random() * 2), 1200),
        domainsChecked: Math.min(prev.domainsChecked + Math.floor(Math.random() * 5) + 2, 100000)
      }));
    }, 3000);

    // Initialize with base numbers
    setStats({
      totalNames: 47834 + Math.floor(Math.random() * 100),
      activeUsers: 580 + Math.floor(Math.random() * 20), // Pre-launch visitor count climaxed at 580
      domainsChecked: 98432 + Math.floor(Math.random() * 200)
    });

    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`grid grid-cols-3 gap-4 text-center ${className}`}>
      <div className="bg-white rounded-lg p-4 shadow-sm">
        <div className="text-2xl font-bold text-blue-600">{stats.totalNames.toLocaleString()}</div>
        <div className="text-sm text-gray-600">Names Generated</div>
      </div>
      <div className="bg-white rounded-lg p-4 shadow-sm">
        <div className="text-2xl font-bold text-green-600">{stats.activeUsers.toLocaleString()}</div>
        <div className="text-sm text-gray-600">Pre-Launch Visitors</div>
      </div>
      <div className="bg-white rounded-lg p-4 shadow-sm">
        <div className="text-2xl font-bold text-purple-600">{stats.domainsChecked.toLocaleString()}</div>
        <div className="text-sm text-gray-600">Domains Checked</div>
      </div>
    </div>
  );
}

interface UpgradePromptProps {
  trigger: 'generation_3' | 'generation_7' | 'domain_check' | 'export_attempt';
  onClose: () => void;
}

export function UpgradePrompt({ trigger, onClose }: UpgradePromptProps) {
  const { trackUpgradeClick } = useAnalytics();
  
  const messages = {
    generation_3: {
      title: "🔥 You're on fire!",
      description: "3 generations already? Upgrade for unlimited business names and premium domains!",
      cta: "Unlock Unlimited"
    },
    generation_7: {
      title: "⚡ Almost at your limit!",
      description: "You have 3 generations left today. Upgrade now to keep the momentum going!",
      cta: "Upgrade to Premium"
    },
    domain_check: {
      title: "💎 Want premium domains?",
      description: "Upgrade to check .ai, .co, .app domains and get priority access to premium names!",
      cta: "Get Premium Domains"
    },
    export_attempt: {
      title: "📤 Export your favorites!",
      description: "Save your best names to CSV/JSON. Available for Premium users only.",
      cta: "Upgrade to Export"
    }
  };

  const message = messages[trigger];

  const handleUpgrade = () => {
    trackUpgradeClick(`prompt_${trigger}`);
    // Navigate to upgrade page
  };

  return (
    <Card className="fixed bottom-4 right-4 w-80 z-50 shadow-lg border-blue-200 bg-gradient-to-br from-blue-50 to-purple-50">
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-gray-800">{message.title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">×</button>
        </div>
        <p className="text-sm text-gray-600 mb-3">{message.description}</p>
        <div className="flex space-x-2">
          <Link href="/subscribe?plan=premium" className="flex-1">
            <Button onClick={handleUpgrade} size="sm" className="w-full">
              {message.cta}
            </Button>
          </Link>
          <Button onClick={onClose} variant="outline" size="sm">
            Later
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export function TestimonialBanner() {
  const testimonials = [
    {
      text: "Found the perfect name for my tech startup in minutes!",
      author: "Sarah M., Port of Spain",
      business: "TechFlow Solutions"
    },
    {
      text: "The domain checker saved me hours of research. Highly recommended!",
      author: "Marcus T., San Fernando", 
      business: "Local Foods Ltd"
    },
    {
      text: "Upgraded to Premium and launched 3 businesses this year!",
      author: "Lisa R., Chaguanas",
      business: "Creative Studios"
    }
  ];

  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const testimonial = testimonials[currentTestimonial];

  return (
    <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white mb-8">
      <CardContent className="p-6 text-center">
        <div className="flex items-center justify-center mb-4">
          <CheckCircle className="w-6 h-6 text-green-300 mr-2" />
          <span className="text-sm font-medium">SUCCESS STORY</span>
        </div>
        <blockquote className="text-lg italic mb-2">"{testimonial.text}"</blockquote>
        <div className="text-sm opacity-90">
          <strong>{testimonial.author}</strong> - {testimonial.business}
        </div>
        <div className="flex justify-center mt-4 space-x-2">
          {testimonials.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full ${
                index === currentTestimonial ? 'bg-white' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}