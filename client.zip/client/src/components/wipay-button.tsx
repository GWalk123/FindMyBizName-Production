import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CreditCard, DollarSign } from "lucide-react";

interface WiPayButtonProps {
  amount: number;
  description?: string;
  onSuccess?: (transactionId: string) => void;
  onError?: (error: string) => void;
}

export function WiPayButton({ amount, description, onSuccess, onError }: WiPayButtonProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [voucherNumber, setVoucherNumber] = useState("");
  const [currency, setCurrency] = useState("TTD");
  const [showForm, setShowForm] = useState(false);
  const { toast } = useToast();

  const handlePayment = async () => {
    if (!voucherNumber.trim()) {
      toast({
        title: "Error",
        description: "Please enter a valid voucher number",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    try {
      const response = await apiRequest("POST", "/api/wipay/voucher", {
        voucher_number: voucherNumber.trim(),
        amount: amount,
        currency: currency,
        description: description || "FindMyBizName Payment",
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Payment Successful",
          description: `Payment of ${currency} ${amount} processed successfully`,
        });
        
        onSuccess?.(data.transaction_id);
        setShowForm(false);
        setVoucherNumber("");
      } else {
        throw new Error(data.message || "Payment failed");
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Payment processing failed";
      toast({
        title: "Payment Failed",
        description: errorMessage,
        variant: "destructive",
      });
      onError?.(errorMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!showForm) {
    return (
      <Button
        onClick={() => setShowForm(true)}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
        size="lg"
      >
        <CreditCard className="w-4 h-4 mr-2" />
        Pay with WiPay
      </Button>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-blue-600" />
          WiPay Payment
        </CardTitle>
        <CardDescription>
          Enter your WiPay voucher details to complete payment
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
          <DollarSign className="w-4 h-4 text-blue-600" />
          <span className="font-medium">Amount: {currency} {amount.toFixed(2)}</span>
        </div>

        <div className="space-y-2">
          <Label htmlFor="voucher">WiPay Voucher Number</Label>
          <Input
            id="voucher"
            type="text"
            placeholder="Enter voucher number"
            value={voucherNumber}
            onChange={(e) => setVoucherNumber(e.target.value)}
            className="font-mono"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="currency">Currency</Label>
          <Select value={currency} onValueChange={setCurrency}>
            <SelectTrigger>
              <SelectValue placeholder="Select currency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="TTD">TTD - Trinidad & Tobago Dollar</SelectItem>
              <SelectItem value="USD">USD - US Dollar</SelectItem>
              <SelectItem value="CAD">CAD - Canadian Dollar</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2 pt-4">
          <Button
            variant="outline"
            onClick={() => setShowForm(false)}
            className="flex-1"
            disabled={isProcessing}
          >
            Cancel
          </Button>
          <Button
            onClick={handlePayment}
            disabled={isProcessing || !voucherNumber.trim()}
            className="flex-1 bg-blue-600 hover:bg-blue-700"
          >
            {isProcessing ? "Processing..." : "Pay Now"}
          </Button>
        </div>

        <div className="text-xs text-gray-500 text-center pt-2">
          WiPay is the leading Caribbean payment processor.<br />
          Your voucher will be validated securely.
        </div>
      </CardContent>
    </Card>
  );
}

// Hook for checking WiPay status
export function useWiPayStatus() {
  const [status, setStatus] = useState<{
    configured: boolean;
    environment: string;
    supported_currencies: string[];
    description: string;
  } | null>(null);

  const checkStatus = async () => {
    try {
      const response = await apiRequest("GET", "/api/wipay/status");
      const data = await response.json();
      setStatus(data);
    } catch (error) {
      console.error("Failed to check WiPay status:", error);
    }
  };

  return { status, checkStatus };
}