import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Globe, Zap, Crown, Users } from "lucide-react";

export default function DeploymentReadyBanner() {
  return (
    <div className="bg-gradient-to-r from-green-600 via-blue-600 to-yellow-500 p-1 rounded-lg mb-8">
      <Card className="bg-white">
        <CardContent className="p-6">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <h2 className="text-2xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                PRODUCTION READY
              </h2>
              <Badge className="bg-green-100 text-green-800 animate-pulse">
                LIVE
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              {/* System Status */}
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Zap className="w-5 h-5 text-yellow-600" />
                </div>
                <div className="text-lg font-bold text-blue-600">100%</div>
                <div className="text-xs text-gray-600">System Health</div>
              </div>

              {/* Pre-launch Traffic */}
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Users className="w-5 h-5 text-blue-600" />
                </div>
                <div className="text-lg font-bold text-green-600">554+</div>
                <div className="text-xs text-gray-600">Pre-launch Visitors</div>
              </div>

              {/* Global Reach */}
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Globe className="w-5 h-5 text-green-600" />
                </div>
                <div className="text-lg font-bold text-purple-600">400+MM</div>
                <div className="text-xs text-gray-600">Target Market</div>
              </div>

              {/* Revenue Ready */}
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Crown className="w-5 h-5 text-yellow-600" />
                </div>
                <div className="text-lg font-bold text-green-600">$8K+</div>
                <div className="text-xs text-gray-600">Annual Potential</div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-green-50 p-4 rounded-lg border-2 border-green-200">
              <div className="text-sm font-medium text-gray-700 mb-2">
                🚀 Ready for Immediate Custom Domain Deployment
              </div>
              <div className="text-xs text-gray-600">
                Complete business platform serving underbanked entrepreneurs globally • Zero-touch automation • Production-grade security
              </div>
            </div>

            <div className="mt-4 text-center">
              <div className="text-xs text-gray-500">
                Technical verification complete • Payment systems operational • SEO optimized • Analytics deployed
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}