import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { CreditCard, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface WiPayButtonProps {
  plan: string;
  amount: string;
  currency?: string;
  customerEmail?: string;
  customerName?: string;
  className?: string;
}

export default function WiPayButton({ 
  plan, 
  amount, 
  currency = "TTD", 
  customerEmail = "demo@example.com",
  customerName = "Demo User",
  className = ""
}: WiPayButtonProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleWiPayCheckout = async () => {
    setIsLoading(true);
    
    try {
      const response = await fetch("/api/wipay/subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          plan,
          amount,
          currency,
          customer_email: customerEmail,
          customer_name: customerName
        })
      });

      const data = await response.json();

      if (data.success) {
        // Create WiPay checkout form and submit
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = data.checkout_url;
        form.target = '_blank'; // Open in new tab for better UX

        // Add all form fields
        Object.entries(data.form_data).forEach(([key, value]) => {
          const input = document.createElement('input');
          input.type = 'hidden';
          input.name = key;
          input.value = value as string;
          form.appendChild(input);
        });

        document.body.appendChild(form);
        form.submit();
        document.body.removeChild(form);

        toast({
          title: "Redirecting to WiPay",
          description: "You'll be redirected to complete your payment securely with WiPay.",
        });
      } else {
        throw new Error(data.error || "Failed to initialize WiPay checkout");
      }
    } catch (error: any) {
      console.error("WiPay checkout error:", error);
      
      if (error.message.includes("not configured")) {
        toast({
          title: "Payment Setup Required",
          description: "WiPay is not yet configured. Please contact support for manual payment processing.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Payment Error",
          description: "Unable to process payment. Please try again or contact support.",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Button 
      onClick={handleWiPayCheckout}
      disabled={isLoading}
      className={`w-full bg-[#00a651] hover:bg-[#008f45] text-white ${className}`}
      size="lg"
    >
      {isLoading ? (
        <>
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
          Processing...
        </>
      ) : (
        <>
          <CreditCard className="w-5 h-5 mr-2" />
          Pay with WiPay - {currency} ${amount}
          <ExternalLink className="w-4 h-4 ml-2" />
        </>
      )}
    </Button>
  );
}