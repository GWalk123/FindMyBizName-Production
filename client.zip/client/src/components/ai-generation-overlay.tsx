import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, Brain, Search, CheckCircle } from "lucide-react";

interface AIGenerationOverlayProps {
  isVisible: boolean;
  onComplete: () => void;
}

const generationSteps = [
  { 
    icon: Brain, 
    text: "AI analyzing your business description", 
    duration: 1500,
    status: "processing"
  },
  { 
    icon: Zap, 
    text: "Generating creative name combinations", 
    duration: 2000,
    status: "processing"
  },
  { 
    icon: Search, 
    text: "Checking domain availability across multiple TLDs", 
    duration: 1800,
    status: "processing"
  },
  { 
    icon: CheckCircle, 
    text: "Finalizing results with pricing data", 
    duration: 1200,
    status: "processing"
  }
];

export default function AIGenerationOverlay({ isVisible, onComplete }: AIGenerationOverlayProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  useEffect(() => {
    if (!isVisible) {
      setCurrentStep(0);
      setCompletedSteps([]);
      return;
    }

    let timeouts: NodeJS.Timeout[] = [];
    let totalDelay = 0;

    generationSteps.forEach((step, index) => {
      const timeout = setTimeout(() => {
        setCurrentStep(index);
        
        // Mark previous steps as completed
        if (index > 0) {
          setCompletedSteps(prev => [...prev, index - 1]);
        }
        
        // Complete the last step and call onComplete
        if (index === generationSteps.length - 1) {
          setTimeout(() => {
            setCompletedSteps(prev => [...prev, index]);
            setTimeout(onComplete, 500);
          }, step.duration);
        }
      }, totalDelay);
      
      timeouts.push(timeout);
      totalDelay += step.duration;
    });

    return () => {
      timeouts.forEach(timeout => clearTimeout(timeout));
    };
  }, [isVisible, onComplete]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md mx-4">
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">AI Name Generation</h3>
            <p className="text-gray-600">Creating unique business names tailored for you</p>
          </div>
          
          <div className="space-y-4">
            {generationSteps.map((step, index) => {
              const isCompleted = completedSteps.includes(index);
              const isCurrent = currentStep === index;
              const isPending = index > currentStep;
              
              return (
                <div 
                  key={index}
                  className={`flex items-center space-x-3 p-3 rounded-lg transition-all duration-500 ${
                    isCompleted 
                      ? 'bg-green-50 border border-green-200' 
                      : isCurrent 
                        ? 'bg-blue-50 border border-blue-200' 
                        : 'bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                    isCompleted 
                      ? 'bg-green-500 text-white' 
                      : isCurrent 
                        ? 'bg-blue-500 text-white' 
                        : 'bg-gray-300 text-gray-500'
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      <step.icon className={`w-5 h-5 ${isCurrent ? 'animate-pulse' : ''}`} />
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <span className={`text-sm font-medium ${
                      isCompleted 
                        ? 'text-green-800' 
                        : isCurrent 
                          ? 'text-blue-800' 
                          : 'text-gray-600'
                    }`}>
                      {step.text}
                    </span>
                  </div>
                  
                  {isCurrent && (
                    <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                  )}
                  
                  {isCompleted && (
                    <Badge className="bg-green-100 text-green-800 text-xs">
                      Complete
                    </Badge>
                  )}
                </div>
              );
            })}
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-xs text-gray-500">
              Powered by OpenAI GPT-4o • Real-time domain checking
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}