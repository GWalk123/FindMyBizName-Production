import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Search, 
  Globe, 
  Users, 
  TrendingUp, 
  Volume2, 
  Star,
  Instagram,
  Twitter,
  Facebook,
  Linkedin,
  Youtube,
  MessageCircle,
  Lock,
  Crown,
  CheckCircle,
  XCircle
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { type User } from "@shared/schema";
import UpgradeModal from "./upgrade-modal";

interface BrandAnalysisProps {
  businessName?: string;
  industry?: string;
}

interface SocialMediaStatus {
  available: boolean;
  url?: string;
  note?: string;
}

interface SocialMediaAvailability {
  instagram: SocialMediaStatus;
  twitter: SocialMediaStatus;
  facebook: SocialMediaStatus;
  linkedin: SocialMediaStatus;
  youtube: SocialMediaStatus;
  tiktok: SocialMediaStatus;
}

interface BrandAnalysisData {
  name: string;
  domains: Record<string, any>;
  socialMedia: SocialMediaAvailability;
  brandAnalysis: {
    sentiment: {
      overall: 'positive' | 'neutral' | 'negative';
      confidence: number;
      emotions: string[];
      culturalNotes: string[];
    };
    pronunciation: {
      difficulty: 'easy' | 'medium' | 'hard';
      score: number;
      syllables: number;
      phoneticSpelling: string;
      notes: string[];
    };
    seo: {
      score: number;
      searchability: 'excellent' | 'good' | 'fair' | 'poor';
      keywordStrength: number;
      brandability: number;
      notes: string[];
    };
    competitor: {
      uniqueness: number;
      marketFit: 'excellent' | 'good' | 'fair' | 'poor';
      similarNames: string[];
      recommendations: string[];
    };
    overallScore: number;
  };
}

export default function BrandAnalysis({ businessName, industry }: BrandAnalysisProps) {
  const [searchName, setSearchName] = useState(businessName || "");
  const [searchIndustry, setSearchIndustry] = useState(industry || "");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisData, setAnalysisData] = useState<BrandAnalysisData | null>(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  // Get user data for premium feature gating
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      const response = await fetch('/api/user');
      if (!response.ok) throw new Error('Failed to fetch user data');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });

  const handleAnalyze = async () => {
    if (!searchName.trim() || searchName.trim().length < 1 || !user) {
      return;
    }

    // Check usage limits for free users
    if (user.plan === 'free') {
      const usageLimit = 3; // Free users get 3 total brand analyses
      const remaining = usageLimit - (user.brandAnalysisUsage || 0);
      
      if (remaining <= 0) {
        setShowUpgradeModal(true);
        return;
      }
      
      // Show upgrade prompt when close to limit
      if (remaining <= 1) {
        setShowUpgradeModal(true);
        return;
      }
    }

    setIsAnalyzing(true);
    
    try {
      const response = await fetch("/api/analyze-name-complete", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          businessName: searchName,
          industry: searchIndustry || 'other',
          userPlan: user?.plan || 'free'
        }),
      });

      if (response.ok) {
        const data = await response.json();
        setAnalysisData(data);
      } else {
        console.error("Analysis failed with status:", response.status);
      }
    } catch (error) {
      console.error("Error during analysis:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getSocialIcon = (platform: string) => {
    switch (platform) {
      case 'instagram': return <Instagram className="w-4 h-4" />;
      case 'twitter': return <Twitter className="w-4 h-4" />;
      case 'facebook': return <Facebook className="w-4 h-4" />;
      case 'linkedin': return <Linkedin className="w-4 h-4" />;
      case 'youtube': return <Youtube className="w-4 h-4" />;
      case 'tiktok': return <MessageCircle className="w-4 h-4" />;
      default: return <Users className="w-4 h-4" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return "bg-green-100 text-green-800";
      case 'medium': return "bg-yellow-100 text-yellow-800";
      case 'hard': return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return "bg-green-100 text-green-800";
      case 'neutral': return "bg-gray-100 text-gray-800";
      case 'negative': return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Interface */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Brand Analysis Suite
            <Badge variant="outline" className="ml-2">
              <Crown className="w-3 h-3 mr-1" />
              Premium Feature
            </Badge>
            {user?.plan === 'free' && (
              <Badge variant="outline" className="text-xs">
                {Math.max(0, 3 - (user.brandAnalysisUsage || 0))}/3 Free
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Controls Row */}
            <div className="flex gap-4 justify-center items-center">
              <div className="w-48">
                <Select value={searchIndustry} onValueChange={setSearchIndustry}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select industry" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="technology">Technology</SelectItem>
                    <SelectItem value="healthcare">Healthcare</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                    <SelectItem value="retail">Retail</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="food">Food & Beverage</SelectItem>
                    <SelectItem value="consulting">Consulting</SelectItem>
                    <SelectItem value="construction">Construction</SelectItem>
                    <SelectItem value="automotive">Automotive</SelectItem>
                    <SelectItem value="tourism">Tourism</SelectItem>
                    <SelectItem value="agriculture">Agriculture</SelectItem>
                    <SelectItem value="manufacturing">Manufacturing</SelectItem>
                    <SelectItem value="real-estate">Real Estate</SelectItem>
                    <SelectItem value="entertainment">Entertainment</SelectItem>
                    <SelectItem value="fitness">Fitness</SelectItem>
                    <SelectItem value="beauty">Beauty</SelectItem>
                    <SelectItem value="legal">Legal</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleAnalyze} 
                disabled={isAnalyzing || searchName.trim().length < 1}
                className="px-8"
              >
                {isAnalyzing ? "Analyzing..." : "Analyze"}
              </Button>
            </div>
            
            {/* Full-width Input Field */}
            <div>
              <input
                type="text"
                placeholder="Enter business name to analyze (e.g., CaribbeanTech, TropicalEats, IslandFinance)"
                value={searchName}
                onChange={(e) => setSearchName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAnalyze()}
                style={{
                  width: '100%',
                  height: '50px',
                  padding: '12px 16px',
                  fontSize: '16px',
                  color: '#000000',
                  backgroundColor: '#ffffff',
                  border: '2px solid #d1d5db',
                  borderRadius: '8px',
                  outline: 'none',
                  fontFamily: 'system-ui, -apple-system, sans-serif'
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = '#3b82f6';
                  e.target.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.1)';
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = '#d1d5db';
                  e.target.style.boxShadow = 'none';
                }}
              />
            </div>
          </div>
          
          {user?.plan === 'free' && (
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                <Crown className="w-4 h-4 inline mr-1" />
                Upgrade to Premium or Pro for unlimited brand analysis with social media checking and advanced scoring.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Analysis Results */}
      {analysisData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Analysis Results: {analysisData.name}</span>
              <Badge variant="outline" className={`${getScoreColor(analysisData.brandAnalysis.overallScore)} text-lg px-3 py-1`}>
                {analysisData.brandAnalysis.overallScore}/100
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 gap-1">
                <TabsTrigger value="overview" className="text-xs md:text-sm">Overview</TabsTrigger>
                <TabsTrigger value="social" className="text-xs md:text-sm">Social</TabsTrigger>
                <TabsTrigger value="domains" className="text-xs md:text-sm">Domains</TabsTrigger>
                <TabsTrigger value="seo" className="text-xs md:text-sm">SEO</TabsTrigger>
                <TabsTrigger value="competitor" className="text-xs md:text-sm">Competition</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span className="font-semibold">Sentiment</span>
                      </div>
                      <Badge className={getSentimentColor(analysisData.brandAnalysis.sentiment.overall)}>
                        {analysisData.brandAnalysis.sentiment.overall}
                      </Badge>
                      <p className="text-sm text-gray-600 mt-1">
                        {Math.round(analysisData.brandAnalysis.sentiment.confidence * 100)}% confidence
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Volume2 className="w-4 h-4 text-blue-500" />
                        <span className="font-semibold">Pronunciation</span>
                      </div>
                      <Badge className={getDifficultyColor(analysisData.brandAnalysis.pronunciation.difficulty)}>
                        {analysisData.brandAnalysis.pronunciation.difficulty}
                      </Badge>
                      <p className="text-sm text-gray-600 mt-1">
                        {analysisData.brandAnalysis.pronunciation.syllables} syllables
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="w-4 h-4 text-green-500" />
                        <span className="font-semibold">SEO Score</span>
                      </div>
                      <div className={`text-2xl font-bold ${getScoreColor(analysisData.brandAnalysis.seo.score)}`}>
                        {analysisData.brandAnalysis.seo.score}
                      </div>
                      <p className="text-sm text-gray-600 mt-1">
                        {analysisData.brandAnalysis.seo.searchability}
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Globe className="w-4 h-4 text-purple-500" />
                        <span className="font-semibold">Uniqueness</span>
                      </div>
                      <div className={`text-2xl font-bold ${getScoreColor(analysisData.brandAnalysis.competitor.uniqueness)}`}>
                        {analysisData.brandAnalysis.competitor.uniqueness}
                      </div>
                      <p className="text-sm text-gray-600 mt-1">
                        {analysisData.brandAnalysis.competitor.marketFit}
                      </p>
                    </CardContent>
                  </Card>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold">Cultural Notes</h4>
                  <div className="space-y-2">
                    {analysisData.brandAnalysis.sentiment.culturalNotes.map((note, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{note}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="social" className="space-y-4">
                <h4 className="font-semibold">Social Media Handle Availability</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {analysisData.socialMedia && Object.entries(analysisData.socialMedia).length > 0 ? (
                    Object.entries(analysisData.socialMedia).map(([platform, status]) => (
                      <Card key={platform}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getSocialIcon(platform)}
                              <span className="font-semibold capitalize">{platform}</span>
                            </div>
                            {(status as SocialMediaStatus).available ? (
                              <CheckCircle className="w-5 h-5 text-green-500" />
                            ) : (
                              <XCircle className="w-5 h-5 text-red-500" />
                            )}
                          </div>
                          <Badge variant={(status as SocialMediaStatus).available ? "default" : "destructive"}>
                            {(status as SocialMediaStatus).available ? "Available" : "Taken"}
                          </Badge>
                          <p className="text-sm text-gray-600 mt-2">{(status as SocialMediaStatus).note}</p>
                          {(status as SocialMediaStatus).url && (
                            <Button variant="outline" size="sm" className="mt-2 w-full">
                              Visit Platform
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500">Social media data not available</p>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="domains" className="space-y-4">
                <h4 className="font-semibold">Domain Availability</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(analysisData.domains).map(([tld, domain]: [string, any]) => (
                    <Card key={tld}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-semibold">.{tld}</span>
                          {domain.available ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : (
                            <XCircle className="w-5 h-5 text-red-500" />
                          )}
                        </div>
                        <Badge variant={domain.available ? "default" : "destructive"}>
                          {domain.available ? "Available" : "Taken"}
                        </Badge>
                        {domain.price && (
                          <p className="text-sm text-gray-600 mt-1">
                            ${domain.price}/year
                          </p>
                        )}
                        {domain.premium && (
                          <Badge variant="outline" className="mt-2">
                            Premium
                          </Badge>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="seo" className="space-y-4">
                <h4 className="font-semibold">SEO Analysis</h4>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <div className={`text-3xl font-bold ${getScoreColor(analysisData.brandAnalysis.seo.score)}`}>
                            {analysisData.brandAnalysis.seo.score}
                          </div>
                          <p className="text-sm text-gray-600">Overall SEO Score</p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <div className={`text-3xl font-bold ${getScoreColor(analysisData.brandAnalysis.seo.keywordStrength)}`}>
                            {analysisData.brandAnalysis.seo.keywordStrength}
                          </div>
                          <p className="text-sm text-gray-600">Keyword Strength</p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <div className={`text-3xl font-bold ${getScoreColor(analysisData.brandAnalysis.seo.brandability)}`}>
                            {analysisData.brandAnalysis.seo.brandability}
                          </div>
                          <p className="text-sm text-gray-600">Brandability</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="space-y-3">
                    <h5 className="font-semibold">SEO Insights</h5>
                    <div className="space-y-2">
                      {analysisData.brandAnalysis.seo.notes.map((note, index) => (
                        <div key={index} className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{note}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="competitor" className="space-y-4">
                <h4 className="font-semibold">Competitor Analysis</h4>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <div className={`text-3xl font-bold ${getScoreColor(analysisData.brandAnalysis.competitor.uniqueness)}`}>
                            {analysisData.brandAnalysis.competitor.uniqueness}
                          </div>
                          <p className="text-sm text-gray-600">Uniqueness Score</p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <Badge className={getSentimentColor(analysisData.brandAnalysis.competitor.marketFit)}>
                            {analysisData.brandAnalysis.competitor.marketFit}
                          </Badge>
                          <p className="text-sm text-gray-600 mt-2">Market Fit</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {analysisData.brandAnalysis.competitor.similarNames.length > 0 && (
                    <div className="space-y-3">
                      <h5 className="font-semibold">Similar Names Found</h5>
                      <div className="flex flex-wrap gap-2">
                        {analysisData.brandAnalysis.competitor.similarNames.map((name, index) => (
                          <Badge key={index} variant="outline">{name}</Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="space-y-3">
                    <h5 className="font-semibold">Recommendations</h5>
                    <div className="space-y-2">
                      {analysisData.brandAnalysis.competitor.recommendations.map((rec, index) => (
                        <div key={index} className="flex items-start gap-2">
                          <TrendingUp className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{rec}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}

      <UpgradeModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        feature="brandAnalysis"
        usageRemaining={user?.plan === 'free' ? Math.max(0, 3 - (user.brandAnalysisUsage || 0)) : -1}
      />
    </div>
  );
}