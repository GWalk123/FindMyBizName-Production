import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, Crown, Lock } from "lucide-react";
import { useBusinessNames } from "@/hooks/use-business-names";
import { useQuery } from "@tanstack/react-query";
import { type GeneratedNameWithDomains, type User } from "@shared/schema";

interface NameGeneratorProps {
  onNamesGenerated: (names: GeneratedNameWithDomains[]) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  onGenerationStart?: () => void;
}

export default function NameGenerator({ onNamesGenerated, isLoading, setIsLoading, onGenerationStart }: NameGeneratorProps) {
  const [description, setDescription] = useState("");
  const [specificName, setSpecificName] = useState("");
  const [industry, setIndustry] = useState("");
  const [style, setStyle] = useState("");
  const [checkDomains, setCheckDomains] = useState(true);
  const [checkPremiumDomains, setCheckPremiumDomains] = useState(false);
  const [includeSynonyms, setIncludeSynonyms] = useState(false);

  const { generateNames, isGenerating } = useBusinessNames();
  
  // Get user data for usage tracking
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      const response = await fetch('/api/user');
      if (!response.ok) throw new Error('Failed to fetch user data');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });
  
  // Calculate usage status for conversion messaging
  const remainingGenerations = user ? Math.max(0, 10 - user.dailyUsage) : 10;
  const usagePercentage = user ? (user.dailyUsage / 10) * 100 : 0;
  const isNearLimit = remainingGenerations <= 3;
  const isAtLimit = remainingGenerations === 0;

  const handleGenerate = async () => {
    if (!description.trim() && !specificName.trim()) return;
    
    try {
      onGenerationStart?.(); // Show AI overlay
      setIsLoading(true);
      
      const result = await generateNames({
        description,
        specificName,
        industry,
        style,
        checkDomains: true, // Always check domains for proper display
        checkPremiumDomains: false, // Keep false for free users
        includeSynonyms,
      });
      
      console.log('✅ Name generation SUCCESS:', result);
      console.log('✅ Names received:', result?.names?.length || 0);
      
      if (result && result.names && Array.isArray(result.names) && result.names.length > 0) {
        console.log('✅ Passing names to display component:', result.names);
        onNamesGenerated(result.names);
      } else {
        console.error('❌ Invalid result structure:', result);
        // Show error toast
        alert('Names generated but display failed. Check console for details.');
      }
    } catch (error) {
      console.error("Failed to generate names:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold text-gray-900">Generate Business Names</h2>
          {user?.plan === "free" && (
            <div className="flex items-center gap-2">
              {isNearLimit && !isAtLimit && (
                <Badge variant="outline" className="text-amber-600 border-amber-300">
                  {remainingGenerations} left (5 total)
                </Badge>
              )}
              {isAtLimit && (
                <Badge variant="destructive">
                  Free limit reached (5 total)
                </Badge>
              )}
            </div>
          )}
        </div>
        
        {/* Smart conversion messaging */}
        {user?.plan === "free" && isNearLimit && (
          <div className="mb-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Crown className="w-5 h-5 text-blue-600" />
              <span className="font-medium text-blue-900">
                {isAtLimit ? "Upgrade for unlimited generations + trademark screening" : `${remainingGenerations} generations left (5 total)`}
              </span>
            </div>
            <p className="text-sm text-blue-700 mb-3">
              {isAtLimit 
                ? "Join 200+ T&T entrepreneurs with unlimited access to premium features."
                : "Upgrade to Premium for unlimited name generation and premium domain checking."
              }
            </p>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
              <Crown className="w-4 h-4 mr-1" />
              Upgrade to Premium
            </Button>
          </div>
        )}
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Describe your business or enter keywords
            </label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g., AI-powered fitness app for busy professionals"
              rows={3}
              className="resize-none"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Check a specific name (optional)
            </label>
            <input
              type="text"
              value={specificName}
              onChange={(e) => setSpecificName(e.target.value)}
              placeholder="e.g., FIT2FAB - Check domain availability for this exact name"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <p className="text-xs text-gray-500 mt-1">
              Enter a business name you're considering to check domain availability
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Industry</label>
              <select 
                value={industry || ""} 
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
              >
                <option value="">Select an industry</option>
                <option value="Technology">Technology</option>
                <option value="Healthcare">Healthcare</option>
                <option value="Finance">Finance</option>
                <option value="Retail">Retail</option>
                <option value="Food & Beverage">Food & Beverage</option>
                <option value="Real Estate">Real Estate</option>
                <option value="Consulting">Consulting</option>
                <option value="Education">Education</option>
                <option value="Travel & Tourism">Travel & Tourism</option>
                <option value="Agriculture">Agriculture</option>
                <option value="Manufacturing">Manufacturing</option>
                <option value="Construction">Construction</option>
                <option value="Marketing & Advertising">Marketing & Advertising</option>
                <option value="Entertainment">Entertainment</option>
                <option value="Automotive">Automotive</option>
                <option value="Beauty & Wellness">Beauty & Wellness</option>
                <option value="Sports & Fitness">Sports & Fitness</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Name Style</label>
              <select 
                value={style || ""} 
                onChange={(e) => setStyle(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
              >
                <option value="">Choose a name style</option>
                <option value="Modern & Tech">Modern & Tech</option>
                <option value="Classic & Professional">Classic & Professional</option>
                <option value="Creative & Unique">Creative & Unique</option>
                <option value="Short & Punchy">Short & Punchy</option>
                <option value="Brandable & Memorable">Brandable & Memorable</option>
                <option value="Abstract & Invented">Abstract & Invented</option>
                <option value="Descriptive & Clear">Descriptive & Clear</option>
                <option value="Luxury & Premium">Luxury & Premium</option>
                <option value="Fun & Playful">Fun & Playful</option>
                <option value="International & Global">International & Global</option>
              </select>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <label className="flex items-center space-x-2">
                <Checkbox 
                  checked={checkDomains}
                  onCheckedChange={(checked) => setCheckDomains(checked as boolean)}
                />
                <span className="text-sm text-gray-600">Check .com domain availability</span>
              </label>
              
              <label className="flex items-center space-x-2">
                <Checkbox 
                  checked={checkPremiumDomains}
                  onCheckedChange={(checked) => setCheckPremiumDomains(checked as boolean)}
                />
                <span className="text-sm text-gray-600">Check .ai, .co, .io domains</span>
              </label>
              
              {/* Synonyms Feature - Premium Required */}
              {user?.plan === "premium" || user?.plan === "pro" ? (
                <label className="flex items-center space-x-2">
                  <Checkbox 
                    checked={includeSynonyms}
                    onCheckedChange={(checked) => setIncludeSynonyms(checked as boolean)}
                  />
                  <span className="text-sm text-gray-600">Include synonyms</span>
                </label>
              ) : (
                <div className="flex items-center space-x-2 opacity-60">
                  <Checkbox disabled />
                  <span className="text-sm text-gray-500">Include synonyms</span>
                  <Lock className="w-3 h-3 text-gray-400" />
                  <Badge variant="secondary" className="text-xs">Premium</Badge>
                </div>
              )}
              
              {/* Advanced Algorithm Preview - Pro Required */}
              {user?.plan === "pro" ? (
                <label className="flex items-center space-x-2">
                  <Checkbox 
                    checked={true}
                    disabled
                  />
                  <span className="text-sm text-gray-600">Advanced industry algorithms</span>
                  <Badge variant="default" className="text-xs bg-purple-600">Active</Badge>
                </label>
              ) : (
                <div className="flex items-center space-x-2 opacity-60">
                  <Checkbox disabled />
                  <span className="text-sm text-gray-500">Advanced industry algorithms</span>
                  <Lock className="w-3 h-3 text-gray-400" />
                  <Badge variant="secondary" className="text-xs">Pro</Badge>
                </div>
              )}
            </div>
          </div>
          
          <Button 
            onClick={handleGenerate}
            disabled={isLoading || !description.trim()}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg"
            size="lg"
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent mr-3" />
                <span className="animate-pulse">AI Generating Creative Names...</span>
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 mr-2" />
                Generate AI-Powered Names
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
