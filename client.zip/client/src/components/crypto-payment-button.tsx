import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Bitcoin, Shield, Globe } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface CryptoPaymentButtonProps {
  plan: string;
  price: number;
  customerEmail?: string;
  customerName?: string;
}

export function CryptoPaymentButton({ 
  plan, 
  price, 
  customerEmail = '', 
  customerName = '' 
}: CryptoPaymentButtonProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [paymentUrl, setPaymentUrl] = useState<string | null>(null);
  const { toast } = useToast();

  const handleCryptoPayment = async () => {
    if (!customerEmail) {
      toast({
        title: "Email Required",
        description: "Please provide your email address for crypto payment.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      const responseData = await apiRequest('POST', '/api/payments/crypto/create', {
        plan,
        customerEmail,
        customerName,
      });

      if (responseData.success) {
        // Open Coinbase Commerce payment page
        window.open(responseData.hosted_url, '_blank');
        setPaymentUrl(responseData.hosted_url);
        
        toast({
          title: "Crypto Payment Initiated",
          description: "Complete your payment in the new tab. Accepts Bitcoin, Ethereum, USDC, and DAI.",
        });
      }
    } catch (error: any) {
      console.error('Crypto payment error:', error);
      toast({
        title: "Payment Error",
        description: error.message || "Failed to create crypto payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <Card className="border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-yellow-50">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Bitcoin className="w-5 h-5 text-orange-600" />
            Crypto Payment
            <Badge variant="secondary" className="bg-orange-100 text-orange-800">
              1% Fee Only
            </Badge>
          </CardTitle>
          <CardDescription className="text-sm">
            Pay with Bitcoin, Ethereum, USDC, or DAI. Perfect for underbanked entrepreneurs worldwide.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
            <div>
              <div className="font-semibold">{plan.charAt(0).toUpperCase() + plan.slice(1)} Plan</div>
              <div className="text-sm text-gray-600">${price}/month</div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-orange-600">${price} USD</div>
              <div className="text-xs text-gray-500">+ 1% processing fee</div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-green-600" />
              <span>Secure & Decentralized</span>
            </div>
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-600" />
              <span>Global Access</span>
            </div>
            <div className="flex items-center gap-2">
              <Bitcoin className="w-4 h-4 text-orange-600" />
              <span>Multiple Cryptocurrencies</span>
            </div>
            <div className="flex items-center gap-2">
              <Loader2 className="w-4 h-4 text-purple-600" />
              <span>No Bank Account Needed</span>
            </div>
          </div>

          <Button 
            onClick={handleCryptoPayment}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-orange-600 to-yellow-600 hover:from-orange-700 hover:to-yellow-700 text-white"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Creating Payment...
              </>
            ) : (
              <>
                <Bitcoin className="w-4 h-4 mr-2" />
                Pay with Crypto
              </>
            )}
          </Button>

          {paymentUrl && (
            <div className="text-center text-sm text-gray-600">
              <p>Payment window opened in new tab.</p>
              <Button 
                variant="link" 
                onClick={() => window.open(paymentUrl, '_blank')}
                className="text-orange-600 hover:text-orange-700"
              >
                Reopen Payment Page
              </Button>
            </div>
          )}

          <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded">
            <strong>Supported Cryptocurrencies:</strong> Bitcoin (BTC), Ethereum (ETH), USD Coin (USDC), DAI. 
            Payment processed by Coinbase Commerce with enterprise-grade security.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}