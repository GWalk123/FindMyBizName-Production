import { useEffect } from 'react';

interface AnalyticsEvent {
  action: string;
  category: string;
  label?: string;
  value?: number;
}

class Analytics {
  private static events: AnalyticsEvent[] = [];
  
  static track(event: AnalyticsEvent) {
    // Store events locally for now, ready for Google Analytics integration
    this.events.push({
      ...event,
      timestamp: Date.now()
    } as any);
    
    // In production, you would send to Google Analytics:
    // gtag('event', event.action, {
    //   event_category: event.category,
    //   event_label: event.label,
    //   value: event.value
    // });
    
    // console.log('Analytics Event:', event); // Disabled to reduce console noise
  }
  
  static getEvents() {
    return this.events;
  }
}

export function useAnalytics() {
  const trackEvent = (event: AnalyticsEvent) => {
    Analytics.track(event);
  };

  const trackPageView = (page: string) => {
    Analytics.track({
      action: 'page_view',
      category: 'navigation',
      label: page
    });
  };

  const trackConversion = (plan: string, amount: number) => {
    Analytics.track({
      action: 'subscription',
      category: 'conversion',
      label: plan,
      value: amount
    });
  };

  const trackNameGeneration = (industry: string, style: string) => {
    Analytics.track({
      action: 'generate_names',
      category: 'engagement',
      label: `${industry}_${style}`
    });
  };

  const trackUpgradeClick = (source: string) => {
    Analytics.track({
      action: 'upgrade_click',
      category: 'conversion_funnel',
      label: source
    });
  };

  return {
    trackEvent,
    trackPageView,
    trackConversion,
    trackNameGeneration,
    trackUpgradeClick
  };
}

export default function AnalyticsTracker() {
  useEffect(() => {
    // Track initial page load
    Analytics.track({
      action: 'page_load',
      category: 'navigation',
      label: window.location.pathname
    });
  }, []);

  return null;
}