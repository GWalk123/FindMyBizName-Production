import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { GitCompare, Download, Heart, Globe, Star } from "lucide-react";
import type { GeneratedNameWithDomains } from "@shared/schema";

interface NameComparisonProps {
  names: GeneratedNameWithDomains[];
  onFavorite: (name: GeneratedNameWithDomains) => void;
}

export default function NameComparison({ names, onFavorite }: NameComparisonProps) {
  const [selectedNames, setSelectedNames] = useState<number[]>([]);
  const [comparisonCriteria, setComparisonCriteria] = useState({
    domainAvailability: true,
    memorability: true,
    brandability: true,
    length: true,
    pronunciation: true
  });

  const toggleNameSelection = (nameId: number) => {
    setSelectedNames(prev => 
      prev.includes(nameId) 
        ? prev.filter(id => id !== nameId)
        : [...prev, nameId]
    );
  };

  const getComparisonData = () => {
    const selectedNameData = names.filter(name => selectedNames.includes(name.id));
    
    return selectedNameData.map(name => ({
      ...name,
      scores: {
        domainAvailability: Object.values(name.domains).filter(d => d.available).length,
        memorability: calculateMemorabilityScore(name.name),
        brandability: calculateBrandabilityScore(name.name),
        length: name.name.length <= 12 ? 5 : name.name.length <= 16 ? 3 : 1,
        pronunciation: calculatePronunciationScore(name.name)
      }
    }));
  };

  const calculateMemorabilityScore = (name: string): number => {
    // Simple scoring: shorter names, fewer syllables = more memorable
    const length = name.length;
    const syllables = estimateSyllables(name);
    
    if (length <= 6 && syllables <= 2) return 5;
    if (length <= 10 && syllables <= 3) return 4;
    if (length <= 14 && syllables <= 4) return 3;
    return 2;
  };

  const calculateBrandabilityScore = (name: string): number => {
    // Check for brandable characteristics
    let score = 3;
    
    // Unique spelling or made-up words score higher
    if (name.includes('x') || name.includes('z') || name.includes('q')) score += 1;
    
    // Avoid common words
    const commonWords = ['the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'had', 'her', 'was', 'one', 'our', 'out', 'day', 'get', 'has', 'him', 'his', 'how', 'man', 'new', 'now', 'old', 'see', 'two', 'who', 'boy', 'did', 'its', 'let', 'put', 'say', 'she', 'too', 'use'];
    if (!commonWords.some(word => name.toLowerCase().includes(word))) score += 1;
    
    // Shorter names are more brandable
    if (name.length <= 8) score += 1;
    
    return Math.min(score, 5);
  };

  const calculatePronunciationScore = (name: string): number => {
    // Simple pronunciation difficulty assessment
    const difficultCombinations = ['sch', 'tch', 'dge', 'ght', 'pht'];
    const vowels = 'aeiou';
    
    let score = 5;
    
    // Penalize difficult combinations
    difficultCombinations.forEach(combo => {
      if (name.toLowerCase().includes(combo)) score -= 1;
    });
    
    // Penalize consonant clusters
    const consonantClusters = name.toLowerCase().match(/[bcdfghjklmnpqrstvwxyz]{3,}/g);
    if (consonantClusters && consonantClusters.length > 0) score -= 1;
    
    return Math.max(score, 1);
  };

  const estimateSyllables = (name: string): number => {
    return name.toLowerCase().replace(/[^aeiou]/g, '').length || 1;
  };

  const comparisonData = getComparisonData();

  if (selectedNames.length < 2) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <GitCompare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Compare Names</h3>
          <p className="text-gray-500 mb-4">Select 2 or more names to compare them side by side</p>
          <div className="text-sm text-gray-600">
            <p>Compare names based on:</p>
            <div className="flex flex-wrap justify-center gap-2 mt-2">
              <Badge variant="outline">Domain Availability</Badge>
              <Badge variant="outline">Memorability</Badge>
              <Badge variant="outline">Brandability</Badge>
              <Badge variant="outline">Length</Badge>
              <Badge variant="outline">Pronunciation</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <GitCompare className="w-5 h-5" />
          <span>Name Comparison</span>
          <Badge variant="secondary">{selectedNames.length} selected</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b">
                <th className="text-left p-3 font-medium">Criteria</th>
                {comparisonData.map(name => (
                  <th key={name.id} className="text-center p-3 font-medium min-w-[120px]">
                    <div className="space-y-1">
                      <div className="font-semibold">{name.name}</div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onFavorite(name)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Heart className={`w-4 h-4 ${name.isFavorite ? 'fill-current' : ''}`} />
                      </Button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-b">
                <td className="p-3 font-medium">Domain Availability</td>
                {comparisonData.map(name => (
                  <td key={name.id} className="text-center p-3">
                    <div className="space-y-1">
                      <Badge variant={name.scores.domainAvailability >= 2 ? "default" : "secondary"}>
                        {name.scores.domainAvailability}/4 available
                      </Badge>
                      <div className="text-xs text-gray-500">
                        {Object.entries(name.domains)
                          .filter(([_, domain]) => domain.available)
                          .map(([tld]) => `.${tld}`)
                          .join(', ')
                        }
                      </div>
                    </div>
                  </td>
                ))}
              </tr>
              
              <tr className="border-b">
                <td className="p-3 font-medium">Memorability</td>
                {comparisonData.map(name => (
                  <td key={name.id} className="text-center p-3">
                    <div className="flex justify-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < name.scores.memorability 
                              ? 'text-yellow-400 fill-current' 
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {name.name.length} chars, {estimateSyllables(name.name)} syllables
                    </div>
                  </td>
                ))}
              </tr>
              
              <tr className="border-b">
                <td className="p-3 font-medium">Brandability</td>
                {comparisonData.map(name => (
                  <td key={name.id} className="text-center p-3">
                    <div className="flex justify-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < name.scores.brandability 
                              ? 'text-blue-400 fill-current' 
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                  </td>
                ))}
              </tr>
              
              <tr className="border-b">
                <td className="p-3 font-medium">Length Score</td>
                {comparisonData.map(name => (
                  <td key={name.id} className="text-center p-3">
                    <div className="flex justify-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < name.scores.length 
                              ? 'text-green-400 fill-current' 
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {name.name.length <= 12 ? 'Perfect' : name.name.length <= 16 ? 'Good' : 'Long'}
                    </div>
                  </td>
                ))}
              </tr>
              
              <tr className="border-b">
                <td className="p-3 font-medium">Pronunciation</td>
                {comparisonData.map(name => (
                  <td key={name.id} className="text-center p-3">
                    <div className="flex justify-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < name.scores.pronunciation 
                              ? 'text-purple-400 fill-current' 
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {name.scores.pronunciation >= 4 ? 'Easy' : name.scores.pronunciation >= 3 ? 'Moderate' : 'Difficult'}
                    </div>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
        
        <div className="mt-6 flex justify-between items-center">
          <Button
            variant="outline"
            onClick={() => setSelectedNames([])}
          >
            Clear Selection
          </Button>
          
          <div className="text-sm text-gray-500">
            Tip: Higher star ratings indicate better scores for each criteria
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export { NameComparison };