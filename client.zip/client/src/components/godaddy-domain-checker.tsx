import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Loader2, CheckCircle, XCircle, ExternalLink, TestTube } from 'lucide-react';

interface DomainCheckResult {
  domain: string;
  available: boolean;
  definitive: boolean;
  price?: number;
  currency?: string;
  period?: number;
}

interface GoDaddyStatus {
  configured: boolean;
  environment: string;
  api_url: string;
  description: string;
  features: string[];
}

interface TestResult {
  success: boolean;
  message: string;
  environment: string;
  api_configured: boolean;
  base_url: string;
}

export function GoDaddyDomainChecker({ businessName }: { businessName?: string }) {
  const [searchName, setSearchName] = useState(businessName || '');
  const [results, setResults] = useState<DomainCheckResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<GoDaddyStatus | null>(null);
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [testing, setTesting] = useState(false);
  const { toast } = useToast();

  const defaultTlds = ['.com', '.net', '.org', '.io', '.co', '.biz'];

  useEffect(() => {
    if (businessName) {
      setSearchName(businessName);
    }
  }, [businessName]);

  useEffect(() => {
    fetchStatus();
  }, []);

  const fetchStatus = async () => {
    try {
      const response = await fetch('/api/godaddy/status');
      const data = await response.json();
      setStatus(data);
    } catch (error) {
      console.error('Failed to fetch GoDaddy status:', error);
    }
  };

  const testConnection = async () => {
    setTesting(true);
    try {
      const response = await fetch('/api/godaddy/test');
      const data = await response.json();
      setTestResult(data);
      
      if (data.success) {
        toast({
          title: "Connection Successful",
          description: data.message,
        });
      } else {
        toast({
          title: "Connection Failed",
          description: data.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Test connection failed:', error);
      toast({
        title: "Test Failed",
        description: "Unable to test GoDaddy connection",
        variant: "destructive",
      });
    } finally {
      setTesting(false);
    }
  };

  const checkDomains = async () => {
    if (!searchName.trim()) {
      toast({
        title: "Business Name Required",
        description: "Please enter a business name to check domains",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setResults([]);
    
    try {
      const response = await fetch('/api/godaddy/check-domains', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: searchName,
          tlds: defaultTlds
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        setResults(data.results);
        toast({
          title: "Domain Check Complete",
          description: `Checked ${data.checked_domains} domains`,
        });
      } else {
        toast({
          title: "Domain Check Failed",
          description: data.message || "Failed to check domains",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Domain check failed:', error);
      toast({
        title: "Error",
        description: "Unable to check domain availability",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = (domain: string) => {
    // For OTE environment, show info instead of actual purchase
    if (status?.environment === 'ote') {
      toast({
        title: "Test Environment",
        description: `Domain ${domain} would be purchased in production environment`,
      });
    } else {
      // In production, redirect to GoDaddy or handle purchase
      window.open(`https://www.godaddy.com/domains/searchresults.aspx?checkAvail=1&domainToCheck=${domain}`, '_blank');
    }
  };

  if (!status) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-6">
          <Loader2 className="w-4 h-4 animate-spin mr-2" />
          Loading GoDaddy integration...
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status and Test Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>GoDaddy API Integration</span>
            <Badge variant={status.configured ? "default" : "destructive"}>
              {status.configured ? "Configured" : "Not Configured"}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Environment:</span> {status.environment.toUpperCase()}
            </div>
            <div>
              <span className="font-medium">API URL:</span> {status.api_url}
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button
              onClick={testConnection}
              disabled={testing || !status.configured}
              variant="outline"
              size="sm"
            >
              {testing ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <TestTube className="w-4 h-4 mr-2" />
              )}
              Test Connection
            </Button>
            
            {status.environment === 'ote' && (
              <Badge variant="secondary" className="ml-2">
                Test Environment - No Real Purchases
              </Badge>
            )}
          </div>

          {testResult && (
            <div className={`p-3 rounded-lg border ${testResult.success ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
              <div className="flex items-start gap-2">
                {testResult.success ? (
                  <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                )}
                <div className="text-sm">
                  <div className="font-medium">{testResult.success ? 'Connection Successful' : 'Connection Failed'}</div>
                  <div className="text-gray-600">{testResult.message}</div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Domain Search Section */}
      <Card>
        <CardHeader>
          <CardTitle>Domain Availability Checker</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter business name (e.g., MyAwesomeBiz)"
              value={searchName}
              onChange={(e) => setSearchName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && checkDomains()}
              className="flex-1"
            />
            <Button 
              onClick={checkDomains}
              disabled={loading || !status.configured}
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : null}
              Check Domains
            </Button>
          </div>

          {loading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin mr-2" />
              <span>Checking domain availability...</span>
            </div>
          )}

          {results.length > 0 && (
            <div className="space-y-2">
              <h4 className="font-medium">Domain Results:</h4>
              {results.map((result) => (
                <div key={result.domain} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <span className="font-medium text-lg">{result.domain}</span>
                    <Badge variant={result.available ? "default" : "secondary"}>
                      {result.available ? "Available" : "Taken"}
                    </Badge>
                    {!result.definitive && (
                      <Badge variant="outline" className="text-xs">
                        Preliminary
                      </Badge>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    {result.available && result.price && (
                      <span className="text-sm text-gray-600">
                        ${(result.price / 1000000).toFixed(2)}/{result.period}yr
                      </span>
                    )}
                    
                    {result.available && (
                      <Button 
                        size="sm" 
                        onClick={() => handlePurchase(result.domain)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {status.environment === 'ote' ? 'Test Buy' : 'Buy Now'}
                        <ExternalLink className="w-3 h-3 ml-1" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {!status.configured && (
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <h4 className="font-medium text-yellow-800 mb-2">Setup Required</h4>
              <p className="text-sm text-yellow-700 mb-3">
                Add your GoDaddy API credentials to environment variables:
              </p>
              <ul className="text-sm text-yellow-700 space-y-1">
                <li>• <code>GODADDY_API_KEY</code> - Your API key</li>
                <li>• <code>GODADDY_API_SECRET</code> - Your API secret</li>
                <li>• <code>GODADDY_ENVIRONMENT=ote</code> - Test environment</li>
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}