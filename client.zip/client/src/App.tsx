import { Switch, Route, Link } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
// import { Toaster } from "@/components/ui/toaster";
import { queryClient } from "@/lib/queryClient";
import { ErrorBoundary } from "@/components/error-boundary";
import Home from "@/pages/home";
import Features from "@/pages/features";
import Pricing from "@/pages/pricing";
import BusinessIntelligence from "@/pages/business-intelligence";
import BizNewz from "@/pages/biz-newz";
import BizBotz from "@/pages/biz-botz-working";
import BizBuzz from "@/pages/biz-buzz";
import AITemplates from "@/pages/ai-templates";
import Referrals from "@/pages/referrals";
import DigitalProducts from "@/pages/digital-products";
import AlternativePayments from "@/pages/alternative-payments";
import TestCryptoPayment from "@/pages/test-crypto-payment";
import GoDaddyTest from "@/pages/godaddy-test";
import TestNameGeneration from "@/pages/test-name-generation";
import SimpleTest from "@/pages/simple-test";
import StableTest from "@/pages/stable-test";
import AdminPanel from "@/pages/admin";
import Help from "@/pages/help";
import Contact from "@/pages/contact";
import Privacy from "@/pages/privacy";
import Terms from "@/pages/terms";
import Profile from "@/pages/profile";
import Wallet from "@/pages/wallet";
import NotFound from "@/pages/not-found";

function Navigation() {
  return (
    <nav className="bg-gradient-to-r from-red-600 to-blue-600 text-white p-4">
      <div className="container mx-auto flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold text-yellow-300">
          FindMyBizName
        </Link>
        <div className="flex space-x-6">
          <Link href="/" className="hover:text-yellow-300 transition-colors">Home</Link>
          <Link href="/features" className="hover:text-yellow-300 transition-colors">Features</Link>
          <Link href="/pricing" className="hover:text-yellow-300 transition-colors">Pricing</Link>
          <Link href="/business-intelligence" className="hover:text-yellow-300 transition-colors">Biz Intel</Link>
          <Link href="/biz-newz" className="hover:text-yellow-300 transition-colors">Biz Newz</Link>
          <Link href="/biz-botz" className="hover:text-yellow-300 transition-colors">Biz Botz</Link>
          <Link href="/biz-buzz" className="hover:text-yellow-300 transition-colors">Biz Buzz</Link>
          <Link href="/ai-templates" className="hover:text-yellow-300 transition-colors">AI Templates</Link>
          <Link href="/referrals" className="hover:text-yellow-300 transition-colors">Referrals</Link>
          <Link href="/wallet" className="hover:text-yellow-300 transition-colors">Wallet</Link>
          <Link href="/digital-products" className="hover:text-yellow-300 transition-colors">Products</Link>
          <Link href="/admin" className="hover:text-yellow-300 transition-colors text-xs bg-red-600 px-2 py-1 rounded">🔧 ADMIN</Link>
          <Link href="/test-crypto" className="hover:text-yellow-300 transition-colors text-xs">🧪 Test</Link>
          <Link href="/godaddy-test" className="hover:text-yellow-300 transition-colors text-xs">🌐 GoDaddy</Link>
          <Link href="/test-names" className="hover:text-yellow-300 transition-colors text-xs">⚡ Names</Link>
          <Link href="/simple-test" className="hover:text-yellow-300 transition-colors text-xs">🧪 Simple</Link>
          <Link href="/stable-test" className="hover:text-yellow-300 transition-colors text-xs">✅ Stable</Link>
        </div>
      </div>
    </nav>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <div className="min-h-screen bg-gray-50">
          {/* Force cache refresh - v2.0 */}
          <Navigation />
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/features" component={Features} />
            <Route path="/pricing" component={Pricing} />
            <Route path="/business-intelligence" component={BusinessIntelligence} />
            <Route path="/biz-newz" component={BizNewz} />
            <Route path="/biz-botz" component={BizBotz} />
            <Route path="/biz-buzz" component={BizBuzz} />
            <Route path="/ai-templates" component={AITemplates} />
            <Route path="/referrals" component={Referrals} />
            <Route path="/digital-products" component={DigitalProducts} />
            <Route path="/alternative-payments" component={AlternativePayments} />
            <Route path="/test-crypto" component={TestCryptoPayment} />
            <Route path="/crypto-payment" component={TestCryptoPayment} />
            <Route path="/godaddy-test" component={GoDaddyTest} />
            <Route path="/test-names" component={TestNameGeneration} />
            <Route path="/simple-test" component={SimpleTest} />
            <Route path="/stable-test" component={StableTest} />
            <Route path="/admin" component={AdminPanel} />
            <Route path="/help" component={Help} />
            <Route path="/contact" component={Contact} />
            <Route path="/privacy" component={Privacy} />
            <Route path="/terms" component={Terms} />
            <Route path="/profile" component={Profile} />
            <Route path="/wallet" component={Wallet} />
            <Route component={NotFound} />
          </Switch>
          {/* <Toaster /> */}
        </div>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}