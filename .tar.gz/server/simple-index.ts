import express from "express";
import { setupVite } from "./vite";
import { createServer } from "http";

const app = express();

app.get('/test', (req, res) => {
  res.send('Simple server is working!');
});

async function start() {
  try {
    const server = createServer(app);
    
    // Setup Vite for React serving
    await setupVite(app, server);
    
    const port = 5000;
    server.listen({
      port,
      host: "0.0.0.0",
    }, () => {
      console.log(`Simple server running on port ${port}`);
    });
    
  } catch (error) {
    console.error('Server failed:', error);
    process.exit(1);
  }
}

start();