import express from "express";
import { setupVite, serveStatic, log } from "./vite";

const app = express();

// Simple health check for Railway
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Basic middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Setup Vite for development or serve static for production
const isProduction = process.env.NODE_ENV === "production";
if (isProduction) {
  serveStatic(app);
} else {
  await setupVite(app);
}

// Basic route for platform
app.get('/', (req, res) => {
  if (isProduction) {
    res.sendFile('index.html', { root: 'dist/client' });
  } else {
    // Vite will handle this in development
    res.send(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>FindMyBizName - Global Business Operating System</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
        <body>
          <div id="root">
            <div style="display: flex; justify-content: center; align-items: center; height: 100vh; font-family: Arial;">
              <div style="text-align: center;">
                <h1 style="color: #FF2D2D;">FindMyBizName</h1>
                <p>Global Business Operating System for Underbanked Entrepreneurs</p>
                <p>Platform Status: <strong style="color: green;">ACTIVE</strong></p>
              </div>
            </div>
          </div>
        </body>
      </html>
    `);
  }
});

// Railway requires binding to assigned port
const port = process.env.PORT || 5000;
const host = process.env.NODE_ENV === "production" ? "0.0.0.0" : "localhost";

app.listen(port, host, () => {
  log(`🚀 FindMyBizName server running on ${host}:${port}`);
  log(`🌍 Railway URL: https://findmybizname-production.up.railway.app`);
  log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
});