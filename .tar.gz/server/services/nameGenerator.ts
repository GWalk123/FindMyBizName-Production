import { type NameGenerationRequest } from "@shared/schema";

interface NameGenerationAlgorithm {
  generate(request: NameGenerationRequest): string[];
}

class KeywordCombinationAlgorithm implements NameGenerationAlgorithm {
  private industryKeywords: Record<string, string[]> = {
    "Technology": ["nexus", "vertex", "quantum", "spark", "forge", "vault", "flux", "pulse", "vibe", "zero"],
    "Healthcare": ["vital", "zenith", "apex", "nova", "pure", "prime", "glow", "sage", "bloom", "thrive"],
    "Finance": ["mint", "vault", "peak", "sterling", "crown", "atlas", "beacon", "summit", "forge", "prism"],
    "Retail": ["bloom", "vibe", "spark", "grove", "wave", "pulse", "dash", "flux", "zen", "epic"],
    "Food & Beverage": ["savvy", "bliss", "zest", "grove", "spark", "bloom", "dash", "vibe", "zen", "mint"],
    "Other": ["apex", "zenith", "vertex", "prime", "epic", "nova", "spark", "vibe", "pulse", "flux"]
  };

  private creativePrefixes: string[] = ["neo", "nova", "zen", "epic", "pure", "prime", "sage", "mint", "vibe", "flux"];
  private modernSuffixes: string[] = ["ify", "ize", "ly", "co", "io", "ai", "go", "hub", "lab", "sync"];

  private styleSuffixes: Record<string, string[]> = {
    "Modern & Tech": ["ly", "fy", "io", "ai", "hub", "lab", "core", "sync", "flow", "wave"],
    "Classic & Professional": ["group", "corp", "inc", "solutions", "services", "partners", "associates", "enterprises"],
    "Creative & Unique": ["studio", "forge", "craft", "works", "lab", "space", "house", "vault", "grove", "bloom"],
    "Short & Punchy": ["co", "go", "io", "ly", "ai", "up", "pro", "ace", "max", "zen"]
  };

  generate(request: NameGenerationRequest): string[] {
    const names: string[] = [];
    const keywords = this.extractKeywords(request.description);
    const industryWords = this.industryKeywords[request.industry] || this.industryKeywords["Other"];
    const suffixes = this.styleSuffixes[request.style] || this.styleSuffixes["Modern & Tech"];

    // Creative prefix + keyword combinations
    for (const keyword of keywords.slice(0, 2)) {
      for (const prefix of this.creativePrefixes.slice(0, 3)) {
        names.push(prefix + this.capitalize(keyword));
        names.push(this.capitalize(keyword) + this.capitalize(prefix));
      }
    }

    // Keyword + industry word blends
    for (const keyword of keywords.slice(0, 2)) {
      for (const industryWord of industryWords.slice(0, 3)) {
        // Create meaningful blends
        names.push(keyword.slice(0, 3) + industryWord.slice(2));
        names.push(industryWord.slice(0, 3) + keyword.slice(2));
        names.push(this.capitalize(keyword) + this.capitalize(industryWord));
      }
    }

    // Modern suffix patterns
    for (const keyword of keywords.slice(0, 2)) {
      for (const suffix of this.modernSuffixes.slice(0, 4)) {
        names.push(keyword + suffix);
        names.push(this.capitalize(keyword) + suffix);
      }
    }

    // Industry + style combinations
    for (const industryWord of industryWords.slice(0, 3)) {
      for (const suffix of suffixes.slice(0, 3)) {
        names.push(this.capitalize(industryWord) + this.capitalize(suffix));
      }
    }

    // Creative standalone names
    for (const industryWord of industryWords.slice(0, 5)) {
      names.push(this.capitalize(industryWord));
    }

    return this.removeDuplicates(names).slice(0, 20);
  }

  private extractKeywords(description: string): string[] {
    const words = description.toLowerCase()
      .replace(/[^a-z\s]/g, '')
      .split(/\s+/)
      .filter(word => word.length > 2 && !this.isStopWord(word));
    
    return words.slice(0, 5);
  }

  private isStopWord(word: string): boolean {
    const stopWords = ["the", "and", "for", "are", "but", "not", "you", "all", "can", "had", "her", "was", "one", "our", "out", "day", "get", "has", "him", "his", "how", "its", "may", "new", "now", "old", "see", "two", "who", "boy", "did", "man", "men", "run", "say", "she", "too", "use"];
    return stopWords.includes(word);
  }

  private capitalize(word: string): string {
    return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
  }

  private removeDuplicates(names: string[]): string[] {
    return Array.from(new Set(names));
  }
}

class SynonymAlgorithm implements NameGenerationAlgorithm {
  private synonyms: Record<string, string[]> = {
    "ai": ["intelligence", "smart", "brain", "mind", "genius", "wise"],
    "fitness": ["health", "strength", "power", "energy", "vitality", "wellness"],
    "app": ["platform", "hub", "center", "space", "zone", "portal"],
    "business": ["venture", "enterprise", "company", "firm", "corp", "group"],
    "professional": ["expert", "pro", "elite", "master", "ace", "prime"],
    "busy": ["active", "dynamic", "fast", "quick", "swift", "rapid"],
    "tech": ["digital", "cyber", "virtual", "electronic", "modern", "advanced"],
    "food": ["cuisine", "dining", "meal", "feast", "dish", "flavor"],
    "delivery": ["express", "rapid", "swift", "quick", "fast", "instant"]
  };

  generate(request: NameGenerationRequest): string[] {
    if (!request.includeSynonyms) return [];

    const names: string[] = [];
    const words = request.description.toLowerCase().split(/\s+/);

    for (const word of words) {
      const syns = this.synonyms[word];
      if (syns) {
        for (const synonym of syns.slice(0, 3)) {
          names.push(this.capitalize(synonym) + "Core");
          names.push(this.capitalize(synonym) + "Hub");
          names.push(this.capitalize(synonym) + "Flow");
          names.push("Smart" + this.capitalize(synonym));
        }
      }
    }

    return this.removeDuplicates(names).slice(0, 10);
  }

  private capitalize(word: string): string {
    return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
  }

  private removeDuplicates(names: string[]): string[] {
    return Array.from(new Set(names));
  }
}

export class NameGeneratorService {
  private algorithms: NameGenerationAlgorithm[];

  constructor() {
    this.algorithms = [
      new KeywordCombinationAlgorithm(),
      new SynonymAlgorithm()
    ];
  }

  async generateNames(request: NameGenerationRequest): Promise<string[]> {
    const allNames: string[] = [];

    for (const algorithm of this.algorithms) {
      const names = algorithm.generate(request);
      allNames.push(...names);
    }

    // Remove duplicates and limit results
    const uniqueNames = Array.from(new Set(allNames));
    return this.shuffleArray(uniqueNames).slice(0, 20);
  }

  private shuffleArray<T>(array: T[]): T[] {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }
}
