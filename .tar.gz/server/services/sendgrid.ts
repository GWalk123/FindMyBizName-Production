import { MailerSend, EmailParams, Sender, Recipient } from 'mailersend';

export interface EmailTemplate {
  to: string;
  from: string;
  subject: string;
  html: string;
  text?: string;
}

export class EmailService {
  private isConfigured: boolean = false;
  private mailerSend: MailerSend;
  private trialDomain: string = 'test-zxk54v8jmqplj6v.mlsender.net';
  private registeredEmail: string = 'gregorywalker760@gmail.com';
  
  constructor() {
    if (process.env.MAILERSEND_API_KEY) {
      this.mailerSend = new MailerSend({
        apiKey: process.env.MAILERSEND_API_KEY,
      });
      this.isConfigured = true;
      console.log('📧 MailerSend Email Service initialized');
      console.log(`📧 Using trial domain: ${this.trialDomain}`);
      console.log(`📧 Trial emails will be sent to: ${this.registeredEmail}`);
    } else {
      console.log('⚠️ MailerSend API key not found - Email service will be available once key is added');
      console.log('💡 To configure MailerSend: Add MAILERSEND_API_KEY to your environment variables');
      // Initialize with empty config to prevent errors
      this.mailerSend = new MailerSend({ apiKey: '' });
    }
  }

  async sendWelcomeEmail(userEmail: string, userName: string): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('MailerSend service not configured - skipping welcome email');
      return false;
    }

    // For trial mode, only send to registered email
    const recipientEmail = userEmail === this.registeredEmail ? userEmail : this.registeredEmail;
    
    // Use the exact verified trial domain from MailerSend dashboard
    const fromEmail = `welcome@${this.trialDomain}`;
    console.log(`📧 Attempting to send from: ${fromEmail}`);
    
    const emailData: EmailTemplate = {
      to: recipientEmail,
      from: fromEmail,
      subject: 'Welcome to FindMyBizName - Your Business Journey Starts Here!',
      html: this.getWelcomeEmailTemplate(userName),
      text: `Welcome to FindMyBizName, ${userName}! Your complete business operating system is ready. Start generating business names, check domains, and build your entrepreneur network today.`
    };

    if (userEmail !== this.registeredEmail) {
      console.log(`📧 Trial mode: Email redirected from ${userEmail} to ${this.registeredEmail}`);
    }

    return await this.sendEmail(emailData);
  }

  async sendSubscriptionConfirmation(userEmail: string, planName: string, amount: string): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('MailerSend service not configured - skipping subscription email');
      return false;
    }

    const emailData: EmailTemplate = {
      to: userEmail,
      from: `billing@${this.trialDomain}`,
      subject: `Subscription Confirmed - ${planName} Plan Activated`,
      html: this.getSubscriptionEmailTemplate(planName, amount),
      text: `Your ${planName} subscription has been activated for $${amount}. You now have access to all premium features!`
    };

    return await this.sendEmail(emailData);
  }

  async sendReferralNotification(userEmail: string, referralCode: string, commission: string): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('MailerSend service not configured - skipping referral email');
      return false;
    }

    const emailData: EmailTemplate = {
      to: userEmail,
      from: `referrals@${this.trialDomain}`,
      subject: `🎉 Referral Commission Earned - $${commission}`,
      html: this.getReferralEmailTemplate(referralCode, commission),
      text: `Congratulations! You've earned $${commission} in referral commissions. Your referral code ${referralCode} is working great!`
    };

    return await this.sendEmail(emailData);
  }

  async sendBusinessNewsDigest(userEmail: string, headlines: string[]): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('MailerSend service not configured - skipping news digest');
      return false;
    }

    const emailData: EmailTemplate = {
      to: userEmail,
      from: `news@${this.trialDomain}`,
      subject: 'Your Daily Biz Newz Digest',
      html: this.getNewsDigestTemplate(headlines),
      text: `Daily Business News: ${headlines.join(' | ')}`
    };

    return await this.sendEmail(emailData);
  }

  private async sendEmail(emailData: EmailTemplate): Promise<boolean> {
    try {
      const sentFrom = new Sender(emailData.from, 'FindMyBizName');
      const recipients = [new Recipient(emailData.to)];

      const emailParams = new EmailParams()
        .setFrom(sentFrom)
        .setTo(recipients)
        .setSubject(emailData.subject)
        .setHtml(emailData.html);

      if (emailData.text) {
        emailParams.setText(emailData.text);
      }

      await this.mailerSend.email.send(emailParams);
      console.log(`Email sent successfully to ${emailData.to} via MailerSend`);
      return true;
    } catch (error) {
      console.error('MailerSend email sending failed:', error);
      return false;
    }
  }

  private getWelcomeEmailTemplate(userName: string): string {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; }
        .header { background: linear-gradient(135deg, #0040FF, #FF2D2D); color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .cta-button { background: #FF2D2D; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 20px 0; }
        .features { background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>Welcome to FindMyBizName!</h1>
        <p>The First Complete Global Business Operating System for Underbanked Entrepreneurs</p>
      </div>
      <div class="content">
        <h2>Hi ${userName},</h2>
        <p>Welcome to the revolution! You've joined over 430.5M underbanked entrepreneurs building their dreams with tools that actually work.</p>
        
        <div class="features">
          <h3>🚀 Your Platform is Ready:</h3>
          <ul>
            <li>✅ AI Business Name Generation</li>
            <li>✅ Real-time Domain Checking</li>
            <li>✅ Biz Newz - Live Business News</li>
            <li>✅ Biz Buzz - Community Chat Forum</li>
            <li>✅ CRM & Invoicing Tools</li>
            <li>✅ Global Payment Options (Crypto, PayPal, Payoneer)</li>
          </ul>
        </div>
        
        <a href="https://findmybizname.com" class="cta-button">Start Building Your Business</a>
        
        <p><strong>Why you made the right choice:</strong></p>
        <ul>
          <li>💰 Save $30,456+ annually vs traditional business tools</li>
          <li>🌍 Built for underbanked entrepreneurs worldwide</li>
          <li>🔥 1% crypto payment fees (vs 3-6% traditional)</li>
        </ul>
        
        <p>Questions? Reply to this email - we're here to help!</p>
        <p>Welcome to your business evolution,<br>The FindMyBizName Team</p>
      </div>
    </body>
    </html>`;
  }

  private getSubscriptionEmailTemplate(planName: string, amount: string): string {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; }
        .header { background: #0040FF; color: white; padding: 20px; text-align: center; }
        .success { background: #28a745; color: white; padding: 15px; text-align: center; border-radius: 8px; margin: 20px; }
        .content { padding: 20px; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>Subscription Activated!</h1>
      </div>
      <div class="success">
        <h2>✅ ${planName} Plan - $${amount}</h2>
        <p>All premium features are now active</p>
      </div>
      <div class="content">
        <p>Your subscription is confirmed and active. You now have access to all ${planName} features including enhanced AI support, priority customer service, and advanced business tools.</p>
        <p>Start exploring your new capabilities at <a href="https://findmybizname.com">FindMyBizName.com</a></p>
      </div>
    </body>
    </html>`;
  }

  private getReferralEmailTemplate(referralCode: string, commission: string): string {
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; }
        .header { background: #FFDD00; color: #333; padding: 20px; text-align: center; }
        .commission { background: #28a745; color: white; padding: 20px; text-align: center; font-size: 24px; margin: 20px 0; border-radius: 8px; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>🎉 Commission Earned!</h1>
      </div>
      <div class="commission">
        $${commission} USD
      </div>
      <div style="padding: 20px;">
        <p>Congratulations! Your referral code <strong>${referralCode}</strong> generated another commission.</p>
        <p>Keep sharing FindMyBizName and earn 30% recurring commissions on every subscription!</p>
        <p>Your entrepreneurial network is growing the movement.</p>
      </div>
    </body>
    </html>`;
  }

  private getNewsDigestTemplate(headlines: string[]): string {
    const headlinesList = headlines.map(headline => `<li>${headline}</li>`).join('');
    return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; }
        .header { background: #333; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .headlines { background: #f8f9fa; padding: 15px; border-radius: 8px; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>📰 Daily Biz Newz</h1>
        <p>Stay informed, stay ahead</p>
      </div>
      <div class="content">
        <div class="headlines">
          <h3>Today's Top Business Headlines:</h3>
          <ul>${headlinesList}</ul>
        </div>
        <p>Read full articles and join discussions at <a href="https://findmybizname.com/biz-newz">Biz Newz</a></p>
      </div>
    </body>
    </html>`;
  }

  getConfigurationStatus(): boolean {
    return this.isConfigured;
  }

  getDomainStatus(): { needsVerification: boolean; message: string; spfStatus: string; trialDomain: string } {
    return {
      needsVerification: true,
      message: 'Domain verification in progress: SPF record detected, DKIM and Return-Path records needed',
      spfStatus: 'SPF record already configured with MailerSend in Cloudflare DNS',
      trialDomain: `Currently using trial domain: ${this.trialDomain}`
    };
  }
}

export const emailService = new EmailService();