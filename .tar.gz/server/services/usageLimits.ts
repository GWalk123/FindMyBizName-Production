import { User } from "@shared/schema";

export interface FeatureLimits {
  brandAnalysis: number;
  nameImprovement: number;
  dailyGeneration: number;
  premiumDomains: boolean;
  pdfExport: boolean;
  socialMediaCheck: boolean;
}

export const PLAN_LIMITS: Record<string, FeatureLimits> = {
  free: {
    brandAnalysis: 3, // 3 brand analyses total (creates buzz but limits usage)
    nameImprovement: 5, // 5 name improvements total
    dailyGeneration: 10, // 10 name generations per day
    premiumDomains: false,
    pdfExport: false,
    socialMediaCheck: false,
  },
  premium: {
    brandAnalysis: 50, // 50 brand analyses per month
    nameImprovement: 100, // 100 name improvements per month
    dailyGeneration: 200, // 200 name generations per day
    premiumDomains: true,
    pdfExport: true,
    socialMediaCheck: true,
  },
  pro: {
    brandAnalysis: -1, // Unlimited
    nameImprovement: -1, // Unlimited
    dailyGeneration: -1, // Unlimited
    premiumDomains: true,
    pdfExport: true,
    socialMediaCheck: true,
  },
};

export function canUseFeature(user: User, feature: 'brandAnalysis' | 'nameImprovement'): boolean {
  const limits = PLAN_LIMITS[user.plan] || PLAN_LIMITS.free;
  const featureLimit = limits[feature];
  
  // Unlimited access for Pro users
  if (featureLimit === -1) return true;
  
  // Check usage against limit
  const currentUsage = feature === 'brandAnalysis' ? user.brandAnalysisUsage : user.nameImprovementUsage;
  return currentUsage < featureLimit;
}

export function getRemainingUsage(user: User, feature: 'brandAnalysis' | 'nameImprovement'): number {
  const limits = PLAN_LIMITS[user.plan] || PLAN_LIMITS.free;
  const featureLimit = limits[feature];
  
  // Unlimited access
  if (featureLimit === -1) return -1;
  
  const currentUsage = feature === 'brandAnalysis' ? user.brandAnalysisUsage : user.nameImprovementUsage;
  return Math.max(0, featureLimit - currentUsage);
}

export function getUpgradeMessage(feature: 'brandAnalysis' | 'nameImprovement'): string {
  const messages = {
    brandAnalysis: "Upgrade to Premium for 50 monthly brand analyses or Pro for unlimited access!",
    nameImprovement: "Upgrade to Premium for 100 monthly improvements or Pro for unlimited suggestions!"
  };
  return messages[feature];
}

export function getFeatureDescription(plan: string, feature: 'brandAnalysis' | 'nameImprovement'): string {
  const limits = PLAN_LIMITS[plan] || PLAN_LIMITS.free;
  const limit = limits[feature];
  
  if (limit === -1) return "Unlimited";
  if (plan === 'free') return `${limit} total`;
  return `${limit}/month`;
}