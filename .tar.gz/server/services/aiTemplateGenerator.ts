import { 
  templateCategories, 
  aiTemplates, 
  generatedTemplates, 
  templateGenerationQueue,
  type AiTemplate,
  type GeneratedTemplate,
  type InsertGeneratedTemplate
} from "@shared/schema";
import { db } from "../db";
import { eq, and, sql } from "drizzle-orm";
import crypto from "crypto";

// AI SDK integration for multiple providers
interface AIProvider {
  name: string;
  model: string;
  apiKey?: string;
  endpoint?: string;
}

const AI_PROVIDERS: Record<string, AIProvider> = {
  'openai-gpt-4': { name: 'openai', model: 'gpt-4' },
  'openai-gpt-3.5': { name: 'openai', model: 'gpt-3.5-turbo' },
  'groq-llama': { name: 'groq', model: 'llama-3.1-70b-versatile' },
  'xai-grok': { name: 'xai', model: 'grok-beta' },
};

export class AITemplateGenerator {
  private static instance: AITemplateGenerator;
  private generationQueue: Map<string, boolean> = new Map();

  static getInstance(): AITemplateGenerator {
    if (!AITemplateGenerator.instance) {
      AITemplateGenerator.instance = new AITemplateGenerator();
    }
    return AITemplateGenerator.instance;
  }

  /**
   * Initialize template categories - run this once on startup
   */
  async initializeCategories(): Promise<void> {
    const categories = [
      // Business Documents
      { name: 'Business Plans', description: 'Comprehensive business planning documents', icon: 'briefcase', sortOrder: 1 },
      { name: 'Legal Templates', description: 'Legal contracts and agreements', icon: 'gavel', sortOrder: 2 },
      { name: 'Financial Documents', description: 'Financial planning and tracking tools', icon: 'dollar-sign', sortOrder: 3 },
      { name: 'Marketing Materials', description: 'Marketing campaigns and content', icon: 'megaphone', sortOrder: 4 },
      { name: 'HR Documents', description: 'Human resources policies and forms', icon: 'users', sortOrder: 5 },
      { name: 'Operations', description: 'Standard operating procedures', icon: 'settings', sortOrder: 6 },
      { name: 'Sales Tools', description: 'Sales processes and materials', icon: 'trending-up', sortOrder: 7 },
      { name: 'Project Management', description: 'Project planning and tracking', icon: 'clipboard', sortOrder: 8 },
    ];

    for (const category of categories) {
      await db.insert(templateCategories)
        .values(category)
        .onConflictDoNothing();
    }
  }

  /**
   * Initialize AI templates with smart prompts
   */
  async initializeTemplates(): Promise<void> {
    const templates = [
      // Business Plans
      {
        title: 'Startup Business Plan',
        categoryName: 'Business Plans',
        description: 'Complete business plan for startups seeking funding',
        templateType: 'document',
        aiPrompt: `Create a comprehensive business plan for a startup in the {{industry}} industry. 
        Business Name: {{businessName}}
        Business Description: {{businessDescription}}
        Target Market: {{targetMarket}}
        Funding Needed: {{fundingAmount}}
        
        Include: Executive Summary, Market Analysis, Marketing Strategy, Financial Projections (3-year), Operations Plan, Management Team, Risk Analysis, and Appendices.
        
        Make it professional, investor-ready, and tailored to {{industry}} with Caribbean/underbanked market considerations where relevant.`,
        requiredInputs: ['businessName', 'businessDescription', 'industry', 'targetMarket', 'fundingAmount'],
        optionalInputs: ['teamSize', 'currentRevenue', 'competitorAnalysis'],
        pricing: 0, // Free
        aiModel: 'openai-gpt-4',
        estimatedTokens: 4000
      },
      
      // Legal Templates  
      {
        title: 'Service Agreement Contract',
        categoryName: 'Legal Templates',
        description: 'Professional service agreement between service provider and client',
        templateType: 'contract',
        aiPrompt: `Generate a professional service agreement contract between {{providerName}} and {{clientName}} for {{serviceType}} services.
        
        Service Details: {{serviceDescription}}
        Duration: {{contractDuration}}
        Payment Terms: {{paymentTerms}}
        Jurisdiction: {{jurisdiction}}
        
        Include: Scope of Work, Payment Terms, Intellectual Property Rights, Confidentiality, Termination Clauses, Liability Limitations, and Dispute Resolution.
        
        Ensure compliance with {{jurisdiction}} laws and include standard protective clauses for service providers.`,
        requiredInputs: ['providerName', 'clientName', 'serviceType', 'serviceDescription', 'paymentTerms', 'jurisdiction'],
        optionalInputs: ['contractDuration', 'deliverables', 'penaltyClauses'],
        pricing: 500, // $5.00
        aiModel: 'openai-gpt-4',
        estimatedTokens: 3000
      },

      // Marketing Materials
      {
        title: 'Social Media Marketing Strategy',
        categoryName: 'Marketing Materials', 
        description: 'Complete social media marketing strategy and content calendar',
        templateType: 'plan',
        aiPrompt: `Create a comprehensive social media marketing strategy for {{businessName}} in the {{industry}} sector.
        
        Target Audience: {{targetAudience}}
        Budget: {{marketingBudget}}
        Goals: {{marketingGoals}}
        Platforms: {{socialPlatforms}}
        
        Include: Platform Strategy, Content Calendar (30 days), Engagement Tactics, Hashtag Research, Competitor Analysis, Performance Metrics, and Growth Strategies.
        
        Focus on cost-effective strategies suitable for underbanked entrepreneurs and emerging markets.`,
        requiredInputs: ['businessName', 'industry', 'targetAudience', 'marketingGoals', 'socialPlatforms'],
        optionalInputs: ['marketingBudget', 'currentFollowers', 'competitorHandles'],
        pricing: 0, // Free
        aiModel: 'groq-llama',
        estimatedTokens: 3500
      },

      // Financial Documents
      {
        title: 'Financial Forecast & Budget',
        categoryName: 'Financial Documents',
        description: 'Comprehensive financial forecasting and budgeting template',
        templateType: 'document',
        aiPrompt: `Generate a detailed financial forecast and budget for {{businessName}} in {{industry}}.
        
        Current Revenue: {{currentRevenue}}
        Growth Target: {{growthTarget}}
        Time Period: {{forecastPeriod}}
        Business Model: {{businessModel}}
        
        Include: Revenue Projections, Expense Categories, Cash Flow Analysis, Break-even Analysis, Seasonal Adjustments, Scenario Planning (Best/Worst/Realistic), and Key Financial Ratios.
        
        Optimize for businesses in emerging markets with limited access to traditional banking.`,
        requiredInputs: ['businessName', 'industry', 'currentRevenue', 'growthTarget', 'businessModel'],
        optionalInputs: ['forecastPeriod', 'fixedCosts', 'variableCosts', 'seasonality'],
        pricing: 1000, // $10.00
        aiModel: 'openai-gpt-4',
        estimatedTokens: 3500
      }
    ];

    for (const template of templates) {
      // Get category ID
      const [category] = await db.select()
        .from(templateCategories)
        .where(eq(templateCategories.name, template.categoryName))
        .limit(1);

      if (category) {
        await db.insert(aiTemplates)
          .values({
            categoryId: category.id,
            title: template.title,
            description: template.description,
            templateType: template.templateType,
            aiPrompt: template.aiPrompt,
            outputFormat: 'markdown',
            requiredInputs: template.requiredInputs,
            optionalInputs: template.optionalInputs,
            pricing: template.pricing,
            aiModel: template.aiModel,
            estimatedTokens: template.estimatedTokens,
          })
          .onConflictDoNothing();
      }
    }
  }

  /**
   * Generate template content using AI
   */
  async generateTemplate(
    templateId: number, 
    userId: number, 
    userInputs: Record<string, any>
  ): Promise<GeneratedTemplate> {
    const startTime = Date.now();
    
    // Get template configuration
    const [template] = await db.select()
      .from(aiTemplates)
      .where(eq(aiTemplates.id, templateId))
      .limit(1);

    if (!template) {
      throw new Error('Template not found');
    }

    // Check for existing generated content (deduplication)
    const contentHash = this.generateContentHash(templateId, userInputs);
    const [existing] = await db.select()
      .from(generatedTemplates)
      .where(and(
        eq(generatedTemplates.templateId, templateId),
        eq(generatedTemplates.contentHash, contentHash)
      ))
      .limit(1);

    if (existing) {
      // Return existing content, increment download count
      await db.update(generatedTemplates)
        .set({ downloadCount: sql`${generatedTemplates.downloadCount} + 1` })
        .where(eq(generatedTemplates.id, existing.id));
      
      return existing;
    }

    // Generate new content
    const processedPrompt = this.processPrompt(template.aiPrompt, userInputs);
    const generatedContent = await this.callAIProvider(template.aiModel || 'openai-gpt-4', processedPrompt);
    
    const generationTime = Date.now() - startTime;
    
    // Save generated content
    const [generated] = await db.insert(generatedTemplates)
      .values({
        templateId,
        userId,
        userInputs,
        generatedContent,
        contentHash,
        tokensUsed: template.estimatedTokens, // Approximate for now
        generationTime,
      })
      .returning();

    // Update template generation count
    await db.update(aiTemplates)
      .set({ generationCount: sql`${aiTemplates.generationCount} + 1` })
      .where(eq(aiTemplates.id, templateId));

    return generated;
  }

  /**
   * Get available templates by category
   */
  async getTemplatesByCategory(categoryId?: number): Promise<AiTemplate[]> {
    if (categoryId) {
      return await db.select()
        .from(aiTemplates)
        .where(and(
          eq(aiTemplates.status, 'active'),
          eq(aiTemplates.categoryId, categoryId)
        ))
        .orderBy(aiTemplates.title);
    }
    
    return await db.select()
      .from(aiTemplates)
      .where(eq(aiTemplates.status, 'active'))
      .orderBy(aiTemplates.title);
  }

  /**
   * Get all template categories
   */
  async getCategories() {
    return await db.select()
      .from(templateCategories)
      .where(eq(templateCategories.isActive, true))
      .orderBy(templateCategories.sortOrder, templateCategories.name);
  }

  /**
   * Get user's generated templates
   */
  async getUserTemplates(userId: number, limit = 50): Promise<GeneratedTemplate[]> {
    return await db.select()
      .from(generatedTemplates)
      .where(eq(generatedTemplates.userId, userId))
      .orderBy(sql`${generatedTemplates.createdAt} DESC`)
      .limit(limit);
  }

  /**
   * Process template prompt with user inputs
   */
  private processPrompt(prompt: string, inputs: Record<string, any>): string {
    let processedPrompt = prompt;
    
    // Replace {{variable}} placeholders with user inputs
    for (const [key, value] of Object.entries(inputs)) {
      const regex = new RegExp(`{{${key}}}`, 'g');
      processedPrompt = processedPrompt.replace(regex, String(value || ''));
    }
    
    return processedPrompt;
  }

  /**
   * Generate content hash for deduplication
   */
  private generateContentHash(templateId: number, inputs: Record<string, any>): string {
    const hashInput = JSON.stringify({ templateId, inputs });
    return crypto.createHash('sha256').update(hashInput).digest('hex');
  }

  /**
   * Call AI provider (placeholder - implement with actual AI SDK)
   */
  private async callAIProvider(aiModel: string, prompt: string): Promise<string> {
    // TODO: Implement actual AI provider calls using AI SDK
    // For now, return structured placeholder that shows the system works
    
    const provider = AI_PROVIDERS[aiModel];
    if (!provider) {
      throw new Error(`Unsupported AI model: ${aiModel}`);
    }

    // Placeholder implementation - replace with actual AI SDK calls
    return `# AI-Generated Template Content

**Generated using ${provider.name} (${provider.model})**

${prompt}

---

*This is a placeholder response. The actual implementation will use the AI SDK to call OpenAI, Groq, xAI, or other providers based on your configuration.*

**Key Features to Implement:**
1. Real-time AI generation using your preferred models
2. Cost optimization through model selection
3. Content caching and deduplication
4. Queue-based processing for high volume
5. Admin review workflow (optional)
6. Usage-based pricing tracking

**Next Steps:**
1. Configure AI provider API keys
2. Implement AI SDK integration
3. Set up content review workflow
4. Configure pricing and billing integration
`;
  }

  /**
   * Rate a generated template
   */
  async rateTemplate(generatedId: number, userId: number, rating: number, feedback?: string): Promise<void> {
    // Update the generated template rating
    await db.update(generatedTemplates)
      .set({ rating, feedback })
      .where(and(
        eq(generatedTemplates.id, generatedId),
        eq(generatedTemplates.userId, userId)
      ));

    // Update template average rating
    const ratings = await db.select()
      .from(generatedTemplates)
      .where(eq(generatedTemplates.templateId, 
        sql`(SELECT template_id FROM generated_templates WHERE id = ${generatedId})`
      ));

    if (ratings.length > 0) {
      const avgRating = ratings
        .filter(r => r.rating !== null)
        .reduce((sum, r) => sum + (r.rating || 0), 0) / ratings.filter(r => r.rating !== null).length;

      await db.update(aiTemplates)
        .set({ averageRating: avgRating.toString() })
        .where(eq(aiTemplates.id, 
          sql`(SELECT template_id FROM generated_templates WHERE id = ${generatedId})`
        ));
    }
  }
}

export const aiTemplateGenerator = AITemplateGenerator.getInstance();