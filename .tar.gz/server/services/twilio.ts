import twilio from 'twilio';

export class SMSService {
  private client: any = null;
  private isConfigured: boolean = false;
  private fromNumber: string = '';
  
  constructor() {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const twilioNumber = process.env.TWILIO_PHONE_NUMBER;
    
    if (accountSid && authToken && twilioNumber) {
      this.client = twilio(accountSid, authToken);
      this.fromNumber = twilioNumber;
      this.isConfigured = true;
      console.log('📱 Twilio SMS Service initialized');
    } else {
      console.log('⚠️ Twilio credentials not found - SMS service will be available once credentials are added');
    }
  }

  async sendWelcomeSMS(phoneNumber: string, userName: string): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('SMS service not configured - skipping welcome SMS');
      return false;
    }

    const message = `Welcome to FindMyBizName, ${userName}! 🚀 Your complete business operating system is ready. Start building your entrepreneur empire at findmybizname.com`;

    return await this.sendSMS(phoneNumber, message);
  }

  async sendPaymentConfirmation(phoneNumber: string, amount: string, method: string): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('SMS service not configured - skipping payment SMS');
      return false;
    }

    const message = `✅ Payment confirmed: $${amount} via ${method}. Your FindMyBizName subscription is now active! Access all features at findmybizname.com`;

    return await this.sendSMS(phoneNumber, message);
  }

  async sendReferralAlert(phoneNumber: string, commission: string): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('SMS service not configured - skipping referral SMS');
      return false;
    }

    const message = `🎉 New referral commission: $${commission}! Your network is growing the FindMyBizName movement. Keep sharing and earn 30% recurring commissions!`;

    return await this.sendSMS(phoneNumber, message);
  }

  async sendDomainAlert(phoneNumber: string, domainName: string): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('SMS service not configured - skipping domain SMS');
      return false;
    }

    const message = `🔥 DOMAIN ALERT: ${domainName} you were watching is now AVAILABLE! Secure it now at findmybizname.com before someone else claims it.`;

    return await this.sendSMS(phoneNumber, message);
  }

  async sendBusinessNewsAlert(phoneNumber: string, headline: string): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('SMS service not configured - skipping news SMS');
      return false;
    }

    const message = `📰 BIZ NEWZ: ${headline}. Read full story and join discussion at findmybizname.com/biz-newz`;

    return await this.sendSMS(phoneNumber, message);
  }

  async sendVerificationCode(phoneNumber: string, code: string): Promise<boolean> {
    if (!this.isConfigured) {
      console.log('SMS service not configured - skipping verification SMS');
      return false;
    }

    const message = `Your FindMyBizName verification code: ${code}. Enter this code to confirm your phone number. Code expires in 10 minutes.`;

    return await this.sendSMS(phoneNumber, message);
  }

  private async sendSMS(to: string, message: string): Promise<boolean> {
    try {
      // Ensure phone number has country code
      const formattedNumber = to.startsWith('+') ? to : `+1${to.replace(/\D/g, '')}`;
      
      await this.client.messages.create({
        body: message,
        from: this.fromNumber,
        to: formattedNumber
      });
      
      console.log(`SMS sent successfully to ${formattedNumber}`);
      return true;
    } catch (error) {
      console.error('SMS sending failed:', error);
      return false;
    }
  }

  async generateVerificationCode(): Promise<string> {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  getConfigurationStatus(): boolean {
    return this.isConfigured;
  }
}

export const smsService = new SMSService();