import OpenAI from "openai";

// Biz Botz AI Customer Support Service
export class BizBotzService {
  private openai: OpenAI | null = null;
  
  constructor() {
    if (process.env.OPENAI_API_KEY) {
      this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
      console.log('🤖 Biz Botz AI Customer Support initialized');
    } else {
      console.log('⚠️ OpenAI API key not found - Biz Botz will be available once key is added');
    }
  }

  async generateBusinessName(keywords: string[], industry?: string): Promise<string[]> {
    if (!this.openai) {
      throw new Error('OpenAI API key required for enhanced name generation');
    }

    const prompt = `Generate 10 creative, memorable business names for ${industry || 'general business'} using these keywords: ${keywords.join(', ')}. 
    
    Consider:
    - Global appeal for underbanked entrepreneurs
    - Easy pronunciation across cultures  
    - Professional yet approachable
    - Brandable and memorable
    - Domain-friendly (avoid hyphens/numbers)
    
    Return only the names, one per line.`;

    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        max_tokens: 500,
        temperature: 0.8
      });

      const names = response.choices[0].message.content
        ?.split('\n')
        .filter(name => name.trim())
        .map(name => name.replace(/^\d+\.\s*/, '').trim())
        || [];

      return names;
    } catch (error) {
      console.error('OpenAI name generation error:', error);
      throw error;
    }
  }

  async provideBizBotzSupport(userMessage: string, context?: string): Promise<string> {
    if (!this.openai) {
      return "Biz Botz AI support is currently offline. Please provide your OpenAI API key to activate this feature.";
    }

    const systemPrompt = `You are Biz Botz, an AI customer support specialist for FindMyBizName - The First Complete Global Business Operating System for Underbanked Entrepreneurs.

    PLATFORM OVERVIEW:
    - Serves 430.5M underbanked entrepreneurs globally excluded by traditional tools
    - Offers complete business suite: naming, domains, CRM, invoicing, payments
    - Alternative payment methods: crypto (1% fees), Payoneer, PayPal
    - Features: Biz Newz (business news), Biz Buzz (community chat), referral program
    - Subscription tiers: Free, Starter ($9.99), Professional ($29.99), Enterprise ($149)

    SUPPORT GUIDELINES:
    - Be helpful, professional, and empathetic
    - Focus on empowering entrepreneurs
    - Explain features clearly in simple language
    - Offer practical business advice when relevant
    - Always maintain positive, encouraging tone
    - If technical issues, direct to platform support

    Current context: ${context || 'General support inquiry'}
    
    Respond helpfully to the user's question.`;

    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userMessage }
        ],
        max_tokens: 500,
        temperature: 0.7
      });

      return response.choices[0].message.content || "I'm having trouble processing your request. Please try again.";
    } catch (error) {
      console.error('Biz Botz support error:', error);
      return "I'm currently experiencing technical difficulties. Please contact our support team for assistance.";
    }
  }

  async analyzeBusinessName(name: string): Promise<{
    memorability: number;
    brandability: number;
    pronunciation: number;
    suggestions: string[];
  }> {
    if (!this.openai) {
      throw new Error('OpenAI API key required for name analysis');
    }

    const prompt = `Analyze the business name "${name}" and provide scoring (1-10) and suggestions. Return JSON format:

    {
      "memorability": [1-10 score],
      "brandability": [1-10 score], 
      "pronunciation": [1-10 score],
      "suggestions": ["suggestion1", "suggestion2", "suggestion3"]
    }

    Consider global appeal, cultural sensitivity, and ease of pronunciation across different languages.`;

    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        max_tokens: 300
      });

      const analysis = JSON.parse(response.choices[0].message.content || '{}');
      return {
        memorability: Math.max(1, Math.min(10, analysis.memorability || 5)),
        brandability: Math.max(1, Math.min(10, analysis.brandability || 5)),
        pronunciation: Math.max(1, Math.min(10, analysis.pronunciation || 5)),
        suggestions: Array.isArray(analysis.suggestions) ? analysis.suggestions : []
      };
    } catch (error) {
      console.error('Name analysis error:', error);
      throw error;
    }
  }

  isActive(): boolean {
    return this.openai !== null;
  }
}

export const bizBotzService = new BizBotzService();