import { Request, Response } from 'express';

interface CoinbaseChargeData {
  name: string;
  description: string;
  pricing_type: 'fixed_price';
  local_price: {
    amount: string;
    currency: string;
  };
  metadata: {
    customer_id?: string;
    customer_name?: string;
    customer_email?: string;
    order_id?: string;
    plan?: string;
    product?: string;
    payment_method?: string;
  };
}

export class CoinbaseCommerceService {
  private apiKey: string;
  private baseUrl = 'https://api.commerce.coinbase.com';

  constructor() {
    this.apiKey = process.env.COINBASE_COMMERCE_API_KEY || '';
  }

  async createCharge(chargeData: CoinbaseChargeData) {
    if (!this.apiKey) {
      // Return mock data for testing when API key is not configured
      console.log('DEMO MODE: Coinbase Commerce API key not configured, returning mock data');
      return {
        data: {
          id: `demo_charge_${Date.now()}`,
          hosted_url: `https://commerce.coinbase.com/demo/charges/demo_charge_${Date.now()}`,
          code: `DEMO${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
          name: chargeData.name,
          description: chargeData.description,
          pricing: {
            local: chargeData.local_price,
          },
          metadata: chargeData.metadata,
          timeline: [
            {
              time: new Date().toISOString(),
              status: 'NEW'
            }
          ]
        }
      };
    }

    const response = await fetch(`${this.baseUrl}/charges`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CC-Api-Key': this.apiKey,
        'X-CC-Version': '2018-03-22',
      },
      body: JSON.stringify(chargeData),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Coinbase Commerce API error: ${error}`);
    }

    return response.json();
  }

  async getCharge(chargeId: string) {
    if (!this.apiKey) {
      throw new Error('Coinbase Commerce API key not configured');
    }

    const response = await fetch(`${this.baseUrl}/charges/${chargeId}`, {
      headers: {
        'X-CC-Api-Key': this.apiKey,
        'X-CC-Version': '2018-03-22',
      },
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Coinbase Commerce API error: ${error}`);
    }

    return response.json();
  }

  generateChargeForSubscription(plan: string, customerEmail: string) {
    const planPrices: Record<string, number> = {
      starter: 9.99,
      growth: 29.99,
      professional: 79.99,
      enterprise: 149.99,
    };

    const price = planPrices[plan.toLowerCase()] || 9.99;

    return {
      name: `FindMyBizName ${plan.charAt(0).toUpperCase() + plan.slice(1)} Plan`,
      description: `Monthly subscription to FindMyBizName ${plan} plan - Global Business Operating System for Underbanked Entrepreneurs`,
      pricing_type: 'fixed_price' as const,
      local_price: {
        amount: price.toString(),
        currency: 'USD',
      },
      metadata: {
        customer_email: customerEmail,
        plan: plan,
        product: 'findmybizname_subscription',
        payment_method: 'crypto',
      },
    };
  }
}

export const coinbaseService = new CoinbaseCommerceService();

// Route handlers
export async function createCryptoPayment(req: Request, res: Response) {
  try {
    const { plan, customerEmail, customerName } = req.body;

    if (!plan || !customerEmail) {
      return res.status(400).json({
        error: 'Missing required fields: plan and customerEmail',
      });
    }

    const chargeData = coinbaseService.generateChargeForSubscription(plan, customerEmail);
    
    if (customerName) {
      chargeData.metadata.customer_name = customerName;
    }

    const charge = await coinbaseService.createCharge(chargeData);

    res.json({
      success: true,
      charge: charge.data,
      hosted_url: charge.data.hosted_url,
      payment_methods: ['Bitcoin', 'Ethereum', 'USDC', 'DAI'],
    });
  } catch (error: any) {
    console.error('Coinbase Commerce error:', error);
    res.status(500).json({
      error: 'Failed to create crypto payment',
      message: error.message,
    });
  }
}

export async function verifyCryptoPayment(req: Request, res: Response) {
  try {
    const { chargeId } = req.params;

    if (!chargeId) {
      return res.status(400).json({
        error: 'Missing charge ID',
      });
    }

    const charge = await coinbaseService.getCharge(chargeId);

    res.json({
      success: true,
      charge: charge.data,
      status: charge.data.timeline[charge.data.timeline.length - 1]?.status || 'pending',
    });
  } catch (error: any) {
    console.error('Coinbase Commerce verification error:', error);
    res.status(500).json({
      error: 'Failed to verify crypto payment',
      message: error.message,
    });
  }
}

export async function handleCoinbaseWebhook(req: Request, res: Response) {
  try {
    const event = req.body;
    
    // Verify webhook signature here if needed
    console.log('Coinbase webhook received:', event.type);

    switch (event.type) {
      case 'charge:confirmed':
        // Payment confirmed - activate subscription
        console.log('Payment confirmed for charge:', event.data.id);
        // TODO: Activate user subscription in database
        break;
      
      case 'charge:failed':
        // Payment failed
        console.log('Payment failed for charge:', event.data.id);
        break;
        
      case 'charge:delayed':
        // Payment pending
        console.log('Payment delayed for charge:', event.data.id);
        break;
    }

    res.status(200).json({ received: true });
  } catch (error: any) {
    console.error('Coinbase webhook error:', error);
    res.status(500).json({
      error: 'Webhook processing failed',
      message: error.message,
    });
  }
}