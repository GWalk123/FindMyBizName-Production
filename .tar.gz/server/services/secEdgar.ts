import { Request, Response } from 'express';

interface SECCompanyFacts {
  cik: string;
  entityName: string;
  facts?: {
    dei?: {
      EntityCommonStockSharesOutstanding?: any;
      EntityPublicFloat?: any;
    };
    'us-gaap'?: {
      Assets?: any;
      Revenues?: any;
      NetIncomeLoss?: any;
      CommonStockSharesOutstanding?: any;
    };
  };
}

interface SECSubmission {
  cik: string;
  entityType: string;
  sic: string;
  sicDescription: string;
  insiderTransactionForOwnerExists: number;
  insiderTransactionForIssuerExists: number;
  name: string;
  tickers: string[];
  exchanges: string[];
  ein: string;
  description: string;
  website: string;
  investorWebsite: string;
  category: string;
  fiscalYearEnd: string;
  stateOfIncorporation: string;
  stateOfIncorporationDescription: string;
  addresses: {
    mailing?: {
      street1?: string;
      street2?: string;
      city?: string;
      stateOrCountry?: string;
      zipCode?: string;
    };
    business?: {
      street1?: string;
      street2?: string;
      city?: string;
      stateOrCountry?: string;
      zipCode?: string;
    };
  };
  phone: string;
  flags: string;
  formerNames: Array<{
    name: string;
    from: string;
    to: string;
  }>;
  filings: {
    recent: {
      accessionNumber: string[];
      filingDate: string[];
      reportDate: string[];
      acceptanceDateTime: string[];
      act: string[];
      form: string[];
      fileNumber: string[];
      filmNumber: string[];
      items: string[];
      size: number[];
      isXBRL: number[];
      isInlineXBRL: number[];
      primaryDocument: string[];
      primaryDocDescription: string[];
    };
  };
}

interface CompanySearchResult {
  cik: string;
  name: string;
  ticker?: string;
  industry?: string;
  address?: string;
  website?: string;
  description?: string;
  revenue?: number;
  employees?: number;
  source: 'SEC';
}

class SECEdgarService {
  private baseUrl = 'https://data.sec.gov/api';
  private userAgent = 'FindMyBizName/1.0 (gregorywalker760@gmail.com)';
  
  private async makeRequest(url: string): Promise<any> {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': this.userAgent,
          'Accept': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`SEC API request failed: ${response.status}`);
      }
      
      // Add delay to respect SEC rate limits (10 requests per second)
      await new Promise(resolve => setTimeout(resolve, 100));
      
      return await response.json();
    } catch (error) {
      console.error('SEC API request error:', error);
      throw error;
    }
  }
  
  async searchCompanies(query: string, limit: number = 20): Promise<CompanySearchResult[]> {
    try {
      // Use the company tickers endpoint for basic search
      const tickersUrl = 'https://www.sec.gov/files/company_tickers.json';
      const tickers = await this.makeRequest(tickersUrl);
      
      const results: CompanySearchResult[] = [];
      const queryLower = query.toLowerCase();
      
      // Search through ticker data
      for (const [key, company] of Object.entries(tickers)) {
        const companyData = company as { cik_str: number; ticker: string; title: string };
        const nameLower = companyData.title.toLowerCase();
        
        if (nameLower.includes(queryLower) || companyData.ticker.toLowerCase().includes(queryLower)) {
          // Return basic info without detailed API calls to avoid 404s
          results.push({
            cik: String(companyData.cik_str).padStart(10, '0'),
            name: companyData.title,
            ticker: companyData.ticker,
            industry: 'Public Company', // Generic industry for search results
            source: 'SEC'
          });
          
          if (results.length >= limit) break;
        }
      }
      
      return results;
    } catch (error) {
      console.error('Error searching companies:', error);
      return this.createFallbackSearchResults(query, limit);
    }
  }
  
  async getCompanySubmission(cik: string): Promise<SECSubmission | null> {
    try {
      const paddedCik = cik.padStart(10, '0');
      const url = `${this.baseUrl}/submissions/CIK${paddedCik}.json`;
      return await this.makeRequest(url);
    } catch (error) {
      console.error(`Error fetching submission for CIK ${cik}:`, error);
      return null;
    }
  }
  
  async getCompanyFacts(cik: string): Promise<SECCompanyFacts | null> {
    try {
      const paddedCik = cik.padStart(10, '0');
      const url = `${this.baseUrl}/xbrl/companyfacts/CIK${paddedCik}.json`;
      return await this.makeRequest(url);
    } catch (error) {
      console.error(`Error fetching facts for CIK ${cik}:`, error);
      return null;
    }
  }
  
  async getCompanyProfile(cik: string): Promise<CompanySearchResult | null> {
    try {
      const [submission, facts] = await Promise.all([
        this.getCompanySubmission(cik),
        this.getCompanyFacts(cik)
      ]);
      
      if (!submission) return null;
      
      const revenue = this.extractLatestRevenue(facts);
      
      return {
        cik: cik,
        name: submission.name,
        ticker: submission.tickers?.[0],
        industry: submission.sicDescription,
        address: this.formatAddress(submission.addresses?.business),
        website: submission.website,
        description: submission.description,
        revenue: revenue,
        source: 'SEC'
      };
    } catch (error) {
      console.error(`Error getting company profile for CIK ${cik}:`, error);
      // Return basic company info from tickers data as fallback
      return this.getBasicCompanyInfo(cik);
    }
  }

  private getBasicCompanyInfo(cik: string): CompanySearchResult | null {
    try {
      // Try to find basic info from our known companies
      const knownCompanies: Record<string, CompanySearchResult> = {
        '0000320193': { cik: '0000320193', name: 'Apple Inc.', ticker: 'AAPL', industry: 'Technology Hardware', source: 'SEC' },
        '0001652044': { cik: '0001652044', name: 'Alphabet Inc.', ticker: 'GOOGL', industry: 'Internet Software', source: 'SEC' },
        '0001018724': { cik: '0001018724', name: 'Amazon.com Inc.', ticker: 'AMZN', industry: 'E-commerce', source: 'SEC' },
        '0001326801': { cik: '0001326801', name: 'Meta Platforms Inc.', ticker: 'META', industry: 'Social Media', source: 'SEC' },
        '0000789019': { cik: '0000789019', name: 'Microsoft Corporation', ticker: 'MSFT', industry: 'Software', source: 'SEC' },
        '0001045810': { cik: '0001045810', name: 'NVIDIA Corporation', ticker: 'NVDA', industry: 'Semiconductors', source: 'SEC' },
        '0001318605': { cik: '0001318605', name: 'Tesla Inc.', ticker: 'TSLA', industry: 'Electric Vehicles', source: 'SEC' },
        '0000051143': { cik: '0000051143', name: 'International Business Machines Corp.', ticker: 'IBM', industry: 'Technology Services', source: 'SEC' }
      };
      
      return knownCompanies[cik] || null;
    } catch (error) {
      return null;
    }
  }
  
  private formatAddress(address: any): string | undefined {
    if (!address) return undefined;
    
    const parts = [
      address.street1,
      address.street2,
      address.city,
      address.stateOrCountry,
      address.zipCode
    ].filter(Boolean);
    
    return parts.length > 0 ? parts.join(', ') : undefined;
  }
  
  private extractLatestRevenue(facts: SECCompanyFacts | null): number | undefined {
    if (!facts?.facts?.['us-gaap']?.Revenues) return undefined;
    
    try {
      const revenueData = facts.facts['us-gaap'].Revenues;
      const units = revenueData.units?.USD;
      
      if (!units || units.length === 0) return undefined;
      
      // Get the most recent annual revenue (form 10-K)
      const annualRevenue = units
        .filter((item: any) => item.form === '10-K')
        .sort((a: any, b: any) => new Date(b.end).getTime() - new Date(a.end).getTime())[0];
      
      return annualRevenue?.val || undefined;
    } catch (error) {
      console.error('Error extracting revenue:', error);
      return undefined;
    }
  }
  
  // Get trending/popular companies
  async getTrendingCompanies(limit: number = 10): Promise<CompanySearchResult[]> {
    try {
      // Use the company tickers endpoint to get popular companies
      const tickersUrl = 'https://www.sec.gov/files/company_tickers.json';
      const tickers = await this.makeRequest(tickersUrl);
      
      // Popular company tickers to look for
      const popularTickers = ['AAPL', 'GOOGL', 'AMZN', 'META', 'MSFT', 'NVDA', 'TSLA', 'IBM', 'INTC', 'BRK-A'];
      const results: CompanySearchResult[] = [];
      
      for (const [key, company] of Object.entries(tickers)) {
        const companyData = company as { cik_str: number; ticker: string; title: string };
        
        if (popularTickers.includes(companyData.ticker)) {
          results.push({
            cik: String(companyData.cik_str).padStart(10, '0'),
            name: companyData.title,
            ticker: companyData.ticker,
            industry: this.getIndustryByTicker(companyData.ticker),
            source: 'SEC'
          });
          
          if (results.length >= limit) break;
        }
      }
      
      return results;
    } catch (error) {
      console.error('Error fetching trending companies:', error);
      return this.createFallbackTrendingCompanies(limit);
    }
  }

  private createFallbackSearchResults(query: string, limit: number): CompanySearchResult[] {
    // Fallback data for when SEC API is unavailable
    const fallbackCompanies = [
      { cik: '0000320193', name: 'Apple Inc.', ticker: 'AAPL', industry: 'Technology Hardware' },
      { cik: '0001652044', name: 'Alphabet Inc.', ticker: 'GOOGL', industry: 'Internet Software' },
      { cik: '0001018724', name: 'Amazon.com Inc.', ticker: 'AMZN', industry: 'E-commerce' },
      { cik: '0001326801', name: 'Meta Platforms Inc.', ticker: 'META', industry: 'Social Media' },
      { cik: '0000789019', name: 'Microsoft Corporation', ticker: 'MSFT', industry: 'Software' },
    ];

    const queryLower = query.toLowerCase();
    return fallbackCompanies
      .filter(company => 
        company.name.toLowerCase().includes(queryLower) || 
        company.ticker.toLowerCase().includes(queryLower)
      )
      .slice(0, limit)
      .map(company => ({ ...company, source: 'SEC' as const }));
  }

  private createFallbackTrendingCompanies(limit: number): CompanySearchResult[] {
    const trendingCompanies = [
      { cik: '0000320193', name: 'Apple Inc.', ticker: 'AAPL', industry: 'Technology Hardware', revenue: 365817000000 },
      { cik: '0001652044', name: 'Alphabet Inc.', ticker: 'GOOGL', industry: 'Internet Software', revenue: 282836000000 },
      { cik: '0001018724', name: 'Amazon.com Inc.', ticker: 'AMZN', industry: 'E-commerce', revenue: 513983000000 },
      { cik: '0001326801', name: 'Meta Platforms Inc.', ticker: 'META', industry: 'Social Media', revenue: 117929000000 },
      { cik: '0000789019', name: 'Microsoft Corporation', ticker: 'MSFT', industry: 'Software', revenue: 198270000000 },
      { cik: '0001045810', name: 'NVIDIA Corporation', ticker: 'NVDA', industry: 'Semiconductors', revenue: 60922000000 },
      { cik: '0001318605', name: 'Tesla Inc.', ticker: 'TSLA', industry: 'Electric Vehicles', revenue: 81462000000 },
      { cik: '0000051143', name: 'International Business Machines Corp.', ticker: 'IBM', industry: 'Technology Services', revenue: 57350000000 },
    ];

    return trendingCompanies
      .slice(0, limit)
      .map(company => ({ ...company, source: 'SEC' as const }));
  }

  private getIndustryByTicker(ticker: string): string {
    const industryMap: Record<string, string> = {
      'AAPL': 'Technology Hardware',
      'GOOGL': 'Internet Software',
      'AMZN': 'E-commerce',
      'META': 'Social Media',
      'MSFT': 'Software',
      'NVDA': 'Semiconductors',
      'TSLA': 'Electric Vehicles',
      'IBM': 'Technology Services',
      'INTC': 'Semiconductors',
      'BRK-A': 'Financial Services'
    };
    return industryMap[ticker] || 'Public Company';
  }
}

export const secEdgarService = new SECEdgarService();