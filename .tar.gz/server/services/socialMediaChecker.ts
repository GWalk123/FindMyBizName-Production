import { type DomainStatus } from "@shared/schema";

interface SocialMediaStatus {
  available: boolean;
  url?: string;
  note?: string;
}

interface SocialMediaAvailability {
  instagram: SocialMediaStatus;
  twitter: SocialMediaStatus;
  facebook: SocialMediaStatus;
  linkedin: SocialMediaStatus;
  youtube: SocialMediaStatus;
  tiktok: SocialMediaStatus;
}

export class SocialMediaCheckerService {
  async checkSocialMediaAvailability(businessName: string): Promise<SocialMediaAvailability> {
    const sanitizedName = this.sanitizeUsername(businessName);
    
    // For now, simulate checks with realistic availability patterns
    // In production, this would connect to social media APIs
    return {
      instagram: await this.checkInstagram(sanitizedName),
      twitter: await this.checkTwitter(sanitizedName),
      facebook: await this.checkFacebook(sanitizedName),
      linkedin: await this.checkLinkedIn(sanitizedName),
      youtube: await this.checkYouTube(sanitizedName),
      tiktok: await this.checkTikTok(sanitizedName)
    };
  }

  private async checkInstagram(username: string): Promise<SocialMediaStatus> {
    // Simulate Instagram availability check
    const availabilityChance = this.getAvailabilityChance(username, 'instagram');
    const isAvailable = this.calculateAvailability(username, 'instagram', availabilityChance);
    
    return {
      available: isAvailable,
      url: `https://instagram.com/${username}`,
      note: isAvailable ? 'Available for registration' : 'Username already taken'
    };
  }

  private async checkTwitter(username: string): Promise<SocialMediaStatus> {
    const availabilityChance = this.getAvailabilityChance(username, 'twitter');
    const isAvailable = this.calculateAvailability(username, 'twitter', availabilityChance);
    
    return {
      available: isAvailable,
      url: `https://twitter.com/${username}`,
      note: isAvailable ? 'Available for registration' : 'Handle already taken'
    };
  }

  private async checkFacebook(username: string): Promise<SocialMediaStatus> {
    const availabilityChance = this.getAvailabilityChance(username, 'facebook');
    const isAvailable = this.calculateAvailability(username, 'facebook', availabilityChance);
    
    return {
      available: isAvailable,
      url: `https://facebook.com/${username}`,
      note: isAvailable ? 'Available for page creation' : 'Page name unavailable'
    };
  }

  private async checkLinkedIn(username: string): Promise<SocialMediaStatus> {
    const availabilityChance = this.getAvailabilityChance(username, 'linkedin');
    const isAvailable = this.calculateAvailability(username, 'linkedin', availabilityChance);
    
    return {
      available: isAvailable,
      url: `https://linkedin.com/company/${username}`,
      note: isAvailable ? 'Available for company page' : 'Company name taken'
    };
  }

  private async checkYouTube(username: string): Promise<SocialMediaStatus> {
    const availabilityChance = this.getAvailabilityChance(username, 'youtube');
    const isAvailable = this.calculateAvailability(username, 'youtube', availabilityChance);
    
    return {
      available: isAvailable,
      url: `https://youtube.com/@${username}`,
      note: isAvailable ? 'Available for channel' : 'Channel handle taken'
    };
  }

  private async checkTikTok(username: string): Promise<SocialMediaStatus> {
    const availabilityChance = this.getAvailabilityChance(username, 'tiktok');
    const isAvailable = this.calculateAvailability(username, 'tiktok', availabilityChance);
    
    return {
      available: isAvailable,
      url: `https://tiktok.com/@${username}`,
      note: isAvailable ? 'Available for profile' : 'Username already taken'
    };
  }

  private getAvailabilityChance(username: string, platform: string): number {
    // Different platforms have different availability rates
    const baseRates: Record<string, number> = {
      'instagram': 0.40, // 40% available (highly competitive)
      'twitter': 0.35,   // 35% available (very competitive)
      'facebook': 0.55,  // 55% available (pages more flexible)
      'linkedin': 0.60,  // 60% available (business focus)
      'youtube': 0.50,   // 50% available (moderate competition)
      'tiktok': 0.45     // 45% available (growing platform)
    };

    let chance = baseRates[platform] || 0.50;
    
    // Shorter names are less likely to be available
    if (username.length <= 5) chance *= 0.3;
    else if (username.length <= 8) chance *= 0.6;
    else if (username.length <= 12) chance *= 0.8;
    
    // Common words are less likely to be available
    const commonWords = ['shop', 'store', 'business', 'company', 'services', 'solutions', 'group', 'inc', 'llc'];
    if (commonWords.some(word => username.toLowerCase().includes(word))) {
      chance *= 0.7;
    }
    
    return Math.min(chance, 0.95); // Cap at 95%
  }

  private calculateAvailability(username: string, platform: string, chance: number): boolean {
    // Use deterministic hashing for consistent results
    const hash = (username + platform).split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
    }, 0);
    const normalizedHash = Math.abs(hash) / 2147483648;
    
    return normalizedHash < chance;
  }

  private sanitizeUsername(businessName: string): string {
    return businessName
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '') // Remove special characters
      .replace(/\s+/g, '') // Remove spaces
      .slice(0, 30); // Social media username length limit
  }

  // Bulk check for multiple names
  async bulkCheckSocialMedia(businessNames: string[]): Promise<Record<string, SocialMediaAvailability>> {
    const results: Record<string, SocialMediaAvailability> = {};

    for (const name of businessNames) {
      results[name] = await this.checkSocialMediaAvailability(name);
    }

    return results;
  }
}