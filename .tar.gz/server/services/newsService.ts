import Parser from 'rss-parser';

// News Service using FREE RSS feeds and APIs - $0/month vs $449/month News API
export class NewsService {
  private rssParser: Parser;
  
  constructor() {
    this.rssParser = new Parser();
  }

  // FREE RSS FEEDS - Global & Regional Sources (ZERO COST vs $449/month News API)
  private readonly rssSources = {
    business: [
      {
        name: "Reuters Business",
        url: "https://feeds.reuters.com/reuters/businessNews",
        category: "markets",
        region: "global"
      },
      {
        name: "NY Times Business", 
        url: "https://rss.nytimes.com/services/xml/rss/nyt/Business.xml",
        category: "markets",
        region: "global"
      },
      {
        name: "Reddit Business",
        url: "https://www.reddit.com/r/business/.rss",
        category: "entrepreneurship", 
        region: "global"
      },
      {
        name: "Reddit Finance",
        url: "https://www.reddit.com/r/finance/.rss",
        category: "funding",
        region: "global"
      },
      {
        name: "Reddit Startups",
        url: "https://www.reddit.com/r/startups/.rss", 
        category: "entrepreneurship",
        region: "global"
      },
      {
        name: "Reddit Investing",
        url: "https://www.reddit.com/r/investing/.rss",
        category: "funding",
        region: "global"
      }
    ],
    // AFRICA - Business news for African entrepreneurs
    africa: [
      {
        name: "AllAfrica Business",
        url: "https://allafrica.com/business/",
        category: "africa",
        region: "africa"
      },
      {
        name: "African Business Magazine",
        url: "https://african.business/feed",
        category: "africa",
        region: "africa"
      },
      {
        name: "Africanews Business",
        url: "https://www.africanews.com/feed/?theme=business",
        category: "africa",
        region: "africa"
      },
      {
        name: "How We Made It In Africa",
        url: "https://www.howwemadeitinafrica.com/feed/",
        category: "entrepreneurship",
        region: "africa"
      }
    ],
    // LATIN AMERICA - Regional business coverage
    latinAmerica: [
      {
        name: "BBC Latin America",
        url: "https://feeds.bbci.co.uk/news/world/latin_america/rss.xml",
        category: "latinamerica",
        region: "latinamerica"
      },
      {
        name: "Global Voices Latin America",
        url: "https://globalvoices.org/tag/latin-america/feed/",
        category: "latinamerica",
        region: "latinamerica"
      },
      {
        name: "France24 Americas",
        url: "https://www.france24.com/en/americas/rss",
        category: "latinamerica",
        region: "latinamerica"
      }
    ],
    // ASIA - Asian business and development news
    asia: [
      {
        name: "Channel NewsAsia Business",
        url: "https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml&category=6511",
        category: "asia",
        region: "asia"
      },
      {
        name: "Asian Development Bank",
        url: "https://www.adb.org/rss",
        category: "funding",
        region: "asia"
      },
      {
        name: "BBC Asia-Pacific",
        url: "https://feeds.bbci.co.uk/news/world/asia/rss.xml",
        category: "asia",
        region: "asia"
      }
    ],
    // PHILIPPINES - Specific coverage for Filipino entrepreneurs
    philippines: [
      {
        name: "BusinessNews.com.ph",
        url: "https://www.businessnews.com.ph/feed",
        category: "philippines",
        region: "philippines"
      },
      {
        name: "BusinessWorld Online",
        url: "https://www.bworldonline.com/feed/",
        category: "philippines",
        region: "philippines"
      },
      {
        name: "Rappler Business",
        url: "https://www.rappler.com/business/feed/",
        category: "philippines",
        region: "philippines"
      },
      {
        name: "Philippine Star Business",
        url: "https://www.philstar.com/rss/business",
        category: "philippines",
        region: "philippines"
      }
    ],
    // EUROPE - European business and startup news
    europe: [
      {
        name: "Euronews Business",
        url: "https://www.euronews.com/rss?format=mrss&level=vertical&name=business",
        category: "europe",
        region: "europe"
      },
      {
        name: "BBC Europe Business",
        url: "https://feeds.bbci.co.uk/news/world/europe/rss.xml",
        category: "europe",
        region: "europe"
      },
      {
        name: "France24 Europe",
        url: "https://www.france24.com/en/europe/rss",
        category: "europe",
        region: "europe"
      }
    ],
    // CARIBBEAN - Original regional coverage
    caribbean: [
      {
        name: "Trinidad Express Business",
        url: "https://trinidadexpress.com/business/feed/",
        category: "caribbean",
        region: "caribbean"
      },
      {
        name: "Jamaica Observer Business", 
        url: "https://www.jamaicaobserver.com/business/feed/",
        category: "caribbean",
        region: "caribbean"
      }
    ]
  };

  // NEWS CATEGORIES - Global & Regional Coverage (aligned with frontend)
  getNewsCategories() {
    return [
      { 
        id: "entrepreneurship", 
        name: "Entrepreneurship", 
        description: "Startup news and entrepreneur stories", 
        color: "green", 
        count: 0 
      },
      { 
        id: "funding", 
        name: "Funding", 
        description: "Investment and funding news", 
        color: "blue", 
        count: 0 
      },
      { 
        id: "technology", 
        name: "Technology", 
        description: "Tech innovation and digital transformation", 
        color: "purple", 
        count: 0 
      },
      { 
        id: "markets", 
        name: "Markets", 
        description: "Market analysis and economic news", 
        color: "orange", 
        count: 0 
      },
      { 
        id: "policy", 
        name: "Policy", 
        description: "Business policy and regulation news", 
        color: "red", 
        count: 0 
      },
      // REGIONAL CATEGORIES - Target Market Specific
      { 
        id: "africa", 
        name: "Africa", 
        description: "African business and economic news", 
        color: "green", 
        count: 0 
      },
      { 
        id: "latinamerica", 
        name: "Latin America", 
        description: "Latin American business and market news", 
        color: "orange", 
        count: 0 
      },
      { 
        id: "asia", 
        name: "Asia", 
        description: "Asian business and development news", 
        color: "blue", 
        count: 0 
      },
      { 
        id: "philippines", 
        name: "Philippines", 
        description: "Philippine business and entrepreneur news", 
        color: "purple", 
        count: 0 
      },
      { 
        id: "europe", 
        name: "Europe", 
        description: "European business and startup news", 
        color: "blue", 
        count: 0 
      },
      { 
        id: "caribbean", 
        name: "Caribbean", 
        description: "Caribbean business and economic news", 
        color: "teal", 
        count: 0 
      }
    ];
  }

  // FETCH REAL NEWS ARTICLES from multiple FREE sources
  async getNewsArticles(): Promise<any[]> {
    try {
      const allArticles: any[] = [];

      // Fetch from ALL RSS sources worldwide with timeout and error handling
      const fetchPromises = [
        ...this.rssSources.business,
        ...this.rssSources.africa,
        ...this.rssSources.latinAmerica,
        ...this.rssSources.asia,
        ...this.rssSources.philippines,
        ...this.rssSources.europe,
        ...this.rssSources.caribbean
      ].map(async (source) => {
        try {
          // Create a safe wrapper for RSS parsing to prevent unhandled rejections
          const parseRSS = () => {
            return new Promise(async (resolve, reject) => {
              try {
                const feed = await this.rssParser.parseURL(source.url);
                resolve(feed);
              } catch (err) {
                // Silently catch ALL RSS parsing errors to prevent unhandled rejections
                reject(err);
              }
            });
          };

          // Race with timeout to prevent hanging requests
          const feedResult = await Promise.race([
            parseRSS(),
            new Promise((_, reject) => 
              setTimeout(() => reject(new Error('Timeout')), 8000)
            )
          ]);

          const feed = feedResult as any;
          
          if (!feed || !feed.items) {
            return [];
          }

          return feed.items.slice(0, 5).map((item: any) => ({
            id: this.generateId(item.link || item.guid || ''),
            title: item.title || 'Untitled',
            summary: this.extractSummary(item.contentSnippet || item.content || ''),
            content: item.content || item.contentSnippet || '',
            source: source.name,
            category: source.category,
            region: source.region,
            url: item.link || '#',
            relevanceScore: this.calculateRelevanceScore(item.title || '', source.category),
            tags: this.extractTags(item.title || '', item.contentSnippet || ''),
            readTime: this.estimateReadTime(item.content || item.contentSnippet || ''),
            publishedAt: item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString()
          }));
        } catch (error) {
          // Silently return empty array for failed feeds
          return [];
        }
      });

      const results = await Promise.allSettled(fetchPromises);
      
      // Combine all successful results
      results.forEach(result => {
        if (result.status === 'fulfilled') {
          allArticles.push(...result.value);
        }
      });

      // Sort by published date (newest first) and return top 50
      return allArticles
        .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
        .slice(0, 50);

    } catch (error) {
      console.error("Error fetching news articles:", error);
      
      // Fallback to sample data if all sources fail
      return this.getSampleArticles();
    }
  }

  // TRENDING TOPICS based on article analysis
  async getTrendingTopics(): Promise<string[]> {
    try {
      const articles = await this.getNewsArticles();
      const words = articles
        .flatMap(article => this.extractTags(article.title, article.summary))
        .filter(word => word.length > 3)
        .reduce((acc: Record<string, number>, word) => {
          acc[word] = (acc[word] || 0) + 1;
          return acc;
        }, {});

      return Object.entries(words)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 10)
        .map(([word]) => word);
    } catch (error) {
      console.error("Error generating trending topics:", error);
      return ["Entrepreneurship", "Digital Transformation", "Sustainable Business", "FinTech", "Remote Work"];
    }
  }

  // HELPER METHODS
  private generateId(input: string): string {
    return Buffer.from(input).toString('base64').substring(0, 16);
  }

  private extractSummary(content: string): string {
    // Remove HTML tags and limit to 200 characters
    const cleanText = content.replace(/<[^>]*>/g, '').trim();
    return cleanText.length > 200 ? cleanText.substring(0, 200) + '...' : cleanText;
  }

  private calculateRelevanceScore(title: string, category: string): number {
    const businessKeywords = ['entrepreneur', 'startup', 'business', 'funding', 'investment', 'technology', 'innovation'];
    const matches = businessKeywords.filter(keyword => 
      title.toLowerCase().includes(keyword)
    ).length;
    return Math.min(95, 65 + (matches * 10));
  }

  private extractTags(title: string, content: string): string[] {
    const text = `${title} ${content}`.toLowerCase();
    const keywords = [
      'startup', 'entrepreneur', 'funding', 'investment', 'technology', 'innovation',
      'digital', 'fintech', 'blockchain', 'ai', 'machine learning', 'saas',
      'growth', 'scaling', 'revenue', 'profit', 'market', 'competition',
      'customer', 'product', 'service', 'strategy', 'marketing', 'sales'
    ];
    
    return keywords.filter(keyword => text.includes(keyword));
  }

  private estimateReadTime(content: string): number {
    const wordsPerMinute = 200;
    const wordCount = content.split(/\s+/).length;
    return Math.max(1, Math.ceil(wordCount / wordsPerMinute));
  }

  // FALLBACK SAMPLE DATA (only used if all RSS sources fail)
  private getSampleArticles(): any[] {
    return [
      {
        id: "sample1",
        title: "Global Business News Service Active - FREE Alternative to $449/month News API",
        summary: "FindMyBizName now provides comprehensive global business news coverage for 430.5M underbanked entrepreneurs across Africa, Latin America, Asia, Philippines, Europe & Caribbean markets - saving $449/month vs traditional APIs.",
        content: "Our platform aggregates business news from 25+ reliable global and regional sources including Reuters, BBC regional feeds, African Business Magazine, Asian Development Bank, and local market outlets serving excluded entrepreneur communities worldwide.",
        source: "FindMyBizName Global Platform",
        category: "technology",
        region: "global",
        url: "#",
        relevanceScore: 95,
        tags: ["global-coverage", "cost-savings", "underbanked-markets", "entrepreneurship", "regional-news"],
        readTime: 3,
        publishedAt: new Date().toISOString()
      }
    ];
  }
}

export const newsService = new NewsService();