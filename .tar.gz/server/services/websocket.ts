import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  room: string;
}

interface ConnectedUser {
  ws: WebSocket;
  username: string;
  room: string;
}

export class BizBuzzChatService {
  private wss: WebSocketServer;
  private connectedUsers: Map<string, ConnectedUser> = new Map();
  private messageHistory: Map<string, ChatMessage[]> = new Map();
  
  constructor(server: Server) {
    // Use a different path to avoid conflicts
    this.wss = new WebSocketServer({ 
      server, 
      path: '/ws'
    });
    
    this.setupWebSocketHandlers();
    console.log('🗨️ Biz Buzz Live Community Chat Forum initialized');
  }

  private setupWebSocketHandlers() {
    this.wss.on('connection', (ws: WebSocket) => {
      console.log('New user connected to Biz Buzz');
      
      ws.on('message', (data: Buffer) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleMessage(ws, message);
        } catch (error) {
          console.error('Invalid message format:', error);
        }
      });

      ws.on('close', () => {
        this.handleDisconnection(ws);
      });

      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
      });
    });
  }

  private handleMessage(ws: WebSocket, data: any) {
    switch (data.type) {
      case 'join':
        this.handleJoin(ws, data);
        break;
      case 'chat':
        this.handleChat(ws, data);
        break;
      case 'get_history':
        this.sendChatHistory(ws, data.room);
        break;
    }
  }

  private handleJoin(ws: WebSocket, data: any) {
    const { username, room } = data;
    const userId = this.generateUserId();
    
    this.connectedUsers.set(userId, {
      ws,
      username,
      room: room || 'general'
    });

    // Send welcome message
    ws.send(JSON.stringify({
      type: 'system',
      message: `Welcome to Biz Buzz, ${username}! You're now connected to the entrepreneur community.`,
      room: room || 'general'
    }));

    // Send chat history
    this.sendChatHistory(ws, room || 'general');

    // Notify room about new user
    this.broadcastToRoom(room || 'general', {
      type: 'user_joined',
      username,
      message: `${username} joined the community`,
      timestamp: new Date()
    }, userId);
  }

  private handleChat(ws: WebSocket, data: any) {
    const user = this.findUserByWebSocket(ws);
    if (!user) return;

    const chatMessage: ChatMessage = {
      id: this.generateMessageId(),
      username: user.username,
      message: data.message,
      timestamp: new Date(),
      room: data.room || user.room
    };

    // Store message in history
    const roomHistory = this.messageHistory.get(chatMessage.room) || [];
    roomHistory.push(chatMessage);
    
    // Keep only last 100 messages per room
    if (roomHistory.length > 100) {
      roomHistory.shift();
    }
    
    this.messageHistory.set(chatMessage.room, roomHistory);

    // Broadcast to room
    this.broadcastToRoom(chatMessage.room, {
      type: 'chat',
      ...chatMessage
    });
  }

  private sendChatHistory(ws: WebSocket, room: string) {
    const history = this.messageHistory.get(room) || [];
    ws.send(JSON.stringify({
      type: 'history',
      messages: history.slice(-20), // Send last 20 messages
      room
    }));
  }

  private broadcastToRoom(room: string, message: any, excludeUserId?: string) {
    for (const [userId, user] of Array.from(this.connectedUsers.entries())) {
      if (user.room === room && userId !== excludeUserId && user.ws.readyState === WebSocket.OPEN) {
        user.ws.send(JSON.stringify(message));
      }
    }
  }

  private handleDisconnection(ws: WebSocket) {
    const user = this.findUserByWebSocket(ws);
    if (user) {
      const userId = this.findUserIdByWebSocket(ws);
      if (userId) {
        this.connectedUsers.delete(userId);
        
        // Notify room about user leaving
        this.broadcastToRoom(user.room, {
          type: 'user_left',
          username: user.username,
          message: `${user.username} left the community`,
          timestamp: new Date()
        });
      }
    }
    console.log('User disconnected from Biz Buzz');
  }

  private findUserByWebSocket(ws: WebSocket): ConnectedUser | null {
    for (const user of Array.from(this.connectedUsers.values())) {
      if (user.ws === ws) return user;
    }
    return null;
  }

  private findUserIdByWebSocket(ws: WebSocket): string | null {
    for (const [userId, user] of Array.from(this.connectedUsers.entries())) {
      if (user.ws === ws) return userId;
    }
    return null;
  }

  private generateUserId(): string {
    return `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateMessageId(): string {
    return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  public getConnectedUsersCount(): number {
    return this.connectedUsers.size;
  }

  public getRoomUsers(room: string): string[] {
    const users: string[] = [];
    for (const user of Array.from(this.connectedUsers.values())) {
      if (user.room === room) {
        users.push(user.username);
      }
    }
    return users;
  }
}