// Payment automation service for zero-touch revenue generation
import { storage } from "../storage";

export interface PaymentNotification {
  transactionId: string;
  userEmail: string;
  amount: number;
  currency: string;
  subscriptionPlan: "premium" | "pro";
  paymentMethod: "paypal" | "paddle" | "bank_transfer" | "mobile_money";
  referralCode?: string;
}

export interface AutomationResult {
  success: boolean;
  message: string;
  userId?: number;
  upgradeApplied?: boolean;
  referralProcessed?: boolean;
  commissionGenerated?: number;
}

export class PaymentAutomationService {
  async processPayment(notification: PaymentNotification): Promise<AutomationResult> {
    try {
      console.log("Processing payment automation:", notification);

      // 1. Find or create user
      let user = await storage.getUserByEmail(notification.userEmail);
      
      if (!user) {
        // Create new user account
        user = await storage.createUser({
          username: this.generateUsername(notification.userEmail),
          email: notification.userEmail,
          plan: notification.subscriptionPlan
        });
        console.log("Created new user:", user.id);
      } else {
        // Upgrade existing user
        await storage.updateUserPlan(user.id, notification.subscriptionPlan);
        console.log("Upgraded existing user:", user.id);
      }

      // 2. Process referral if applicable
      let commissionGenerated = 0;
      let referralProcessed = false;

      if (notification.referralCode) {
        const referralResult = await this.processReferralCommission(
          notification.referralCode,
          user.id,
          notification.subscriptionPlan,
          notification.amount.toString()
        );
        
        if (referralResult.success) {
          commissionGenerated = referralResult.commission || 0;
          referralProcessed = true;
          console.log("Referral commission processed:", commissionGenerated);
        }
      }

      // 3. Record transaction
      await storage.recordTransaction({
        userId: user.id,
        transactionId: notification.transactionId,
        amount: notification.amount.toString(),
        currency: notification.currency,
        paymentMethod: notification.paymentMethod,
        subscriptionPlan: notification.subscriptionPlan,
        referralCode: notification.referralCode,
        status: "completed"
      });

      // 4. Send welcome email (automated)
      await this.triggerWelcomeAutomation(user, notification.subscriptionPlan);

      // 5. Log bank transfer details for Republic Bank account integration
      if (notification.paymentMethod === "bank_transfer") {
        console.log("Bank transfer processed - Republic Bank account 1800 3611 7031");
      }

      return {
        success: true,
        message: "Payment processed successfully",
        userId: user.id,
        upgradeApplied: true,
        referralProcessed,
        commissionGenerated
      };

    } catch (error) {
      console.error("Payment automation error:", error);
      return {
        success: false,
        message: `Payment automation failed: ${error.message}`
      };
    }
  }

  private async processReferralCommission(
    referralCode: string,
    newUserId: number,
    plan: string,
    amount: string
  ): Promise<{ success: boolean; commission?: number }> {
    try {
      // Track the referral
      const trackResult = await storage.trackReferral(referralCode, newUserId);
      
      if (!trackResult) {
        return { success: false };
      }

      // Convert to paid subscription
      const commission = await storage.convertReferral(
        trackResult.id,
        plan,
        amount
      );

      return {
        success: true,
        commission: parseFloat(commission.toString())
      };
    } catch (error) {
      console.error("Referral commission error:", error);
      return { success: false };
    }
  }

  private generateUsername(email: string): string {
    const base = email.split('@')[0];
    const timestamp = Date.now().toString().slice(-4);
    return `${base}_${timestamp}`;
  }

  private async triggerWelcomeAutomation(user: any, plan: string): Promise<void> {
    // This would integrate with email automation service
    console.log(`Welcome automation triggered for ${user.email} - ${plan} plan`);
    
    // In production, this would trigger:
    // - Welcome email sequence
    // - Slack notification to owner
    // - Analytics tracking
    // - Onboarding automation
  }

  // PayPal webhook handler
  async handlePayPalWebhook(payload: any): Promise<AutomationResult> {
    try {
      if (payload.event_type === "PAYMENT.CAPTURE.COMPLETED") {
        const payment = payload.resource;
        
        return await this.processPayment({
          transactionId: payment.id,
          userEmail: payment.payer.email_address,
          amount: parseFloat(payment.amount.value),
          currency: payment.amount.currency_code,
          subscriptionPlan: payment.amount.value === "9.99" ? "premium" : "pro",
          paymentMethod: "paypal",
          referralCode: payment.custom_id // Pass referral code via custom_id
        });
      }
      
      return { success: false, message: "Unhandled webhook event" };
    } catch (error) {
      console.error("PayPal webhook error:", error);
      return { success: false, message: error.message };
    }
  }

  // Paddle webhook handler
  async handlePaddleWebhook(payload: any): Promise<AutomationResult> {
    try {
      if (payload.alert_name === "subscription_created") {
        return await this.processPayment({
          transactionId: payload.subscription_id,
          userEmail: payload.email,
          amount: parseFloat(payload.sale_gross),
          currency: payload.currency,
          subscriptionPlan: payload.product_id === "premium_plan" ? "premium" : "pro",
          paymentMethod: "paddle",
          referralCode: payload.passthrough // Pass referral code via passthrough
        });
      }
      
      return { success: false, message: "Unhandled webhook event" };
    } catch (error) {
      console.error("Paddle webhook error:", error);
      return { success: false, message: error.message };
    }
  }

  // Manual payment processor (for bank transfers, mobile money)
  async processManualPayment(
    email: string,
    plan: "premium" | "pro",
    referralCode?: string
  ): Promise<AutomationResult> {
    const amount = plan === "premium" ? 9.99 : 19.99;
    
    return await this.processPayment({
      transactionId: `MANUAL_${Date.now()}`,
      userEmail: email,
      amount,
      currency: "USD",
      subscriptionPlan: plan,
      paymentMethod: "bank_transfer",
      referralCode
    });
  }
}

export const paymentAutomation = new PaymentAutomationService();