interface BrandSentiment {
  overall: 'positive' | 'neutral' | 'negative';
  confidence: number;
  emotions: string[];
  culturalNotes: string[];
}

interface PronunciationAnalysis {
  difficulty: 'easy' | 'medium' | 'hard';
  score: number; // 1-10, 10 being easiest
  syllables: number;
  phoneticSpelling: string;
  notes: string[];
}

interface SEOAnalysis {
  score: number; // 1-100
  searchability: 'excellent' | 'good' | 'fair' | 'poor';
  keywordStrength: number;
  brandability: number;
  notes: string[];
}

interface CompetitorAnalysis {
  uniqueness: number; // 1-100
  marketFit: 'excellent' | 'good' | 'fair' | 'poor';
  similarNames: string[];
  recommendations: string[];
}

export interface BrandAnalysis {
  sentiment: BrandSentiment;
  pronunciation: PronunciationAnalysis;
  seo: SEOAnalysis;
  competitor: CompetitorAnalysis;
  overallScore: number;
}

export class BrandAnalyzerService {
  private positiveWords = [
    'success', 'elite', 'prime', 'smart', 'pro', 'best', 'top', 'swift', 'bright', 'gold',
    'victory', 'excel', 'advance', 'thrive', 'grow', 'rise', 'shine', 'flow', 'boost', 'win'
  ];

  private negativeWords = [
    'fail', 'poor', 'weak', 'slow', 'bad', 'worst', 'ugly', 'broken', 'dead', 'sick',
    'lost', 'wrong', 'hard', 'difficult', 'problem', 'issue', 'trouble', 'crisis', 'pain'
  ];

  private caribbeanCulturalWords = [
    'lime', 'fete', 'mas', 'carnival', 'calypso', 'steel', 'pan', 'doubles', 'roti',
    'coconut', 'beach', 'island', 'tropical', 'sun', 'wave', 'blue', 'coral', 'palm'
  ];

  async analyzeBrand(businessName: string, industry?: string): Promise<BrandAnalysis> {
    const sentiment = this.analyzeSentiment(businessName);
    const pronunciation = this.analyzePronunciation(businessName);
    const seo = this.analyzeSEO(businessName, industry);
    const competitor = this.analyzeCompetitor(businessName, industry);
    
    const overallScore = this.calculateOverallScore(sentiment, pronunciation, seo, competitor);

    return {
      sentiment,
      pronunciation,
      seo,
      competitor,
      overallScore
    };
  }

  private analyzeSentiment(name: string): BrandSentiment {
    const lowerName = name.toLowerCase();
    let positiveScore = 0;
    let negativeScore = 0;
    const emotions: string[] = [];
    const culturalNotes: string[] = [];

    // Check for positive/negative words
    this.positiveWords.forEach(word => {
      if (lowerName.includes(word)) {
        positiveScore += 1;
        emotions.push(`Conveys ${word}`);
      }
    });

    this.negativeWords.forEach(word => {
      if (lowerName.includes(word)) {
        negativeScore += 1;
        emotions.push(`May suggest ${word}`);
      }
    });

    // Check for Caribbean cultural relevance
    this.caribbeanCulturalWords.forEach(word => {
      if (lowerName.includes(word)) {
        culturalNotes.push(`Strong Caribbean connection: "${word}"`);
        positiveScore += 0.5; // Bonus for cultural relevance
      }
    });

    // Analyze name structure for emotional impact
    if (name.length <= 6) emotions.push('Short and punchy');
    if (name.length >= 12) emotions.push('Descriptive and detailed');
    if (/^[A-Z][a-z]+[A-Z]/.test(name)) emotions.push('Professional compound name');

    let overall: BrandSentiment['overall'] = 'neutral';
    let confidence = 0.6;

    if (positiveScore > negativeScore) {
      overall = 'positive';
      confidence = Math.min(0.9, 0.6 + (positiveScore - negativeScore) * 0.1);
    } else if (negativeScore > positiveScore) {
      overall = 'negative';
      confidence = Math.min(0.9, 0.6 + (negativeScore - positiveScore) * 0.1);
    }

    // Add Caribbean-specific cultural notes
    if (culturalNotes.length === 0) {
      culturalNotes.push('Consider adding Caribbean cultural elements for local appeal');
    }

    return {
      overall,
      confidence,
      emotions: emotions.length > 0 ? emotions : ['Neutral emotional impact'],
      culturalNotes
    };
  }

  private analyzePronunciation(name: string): PronunciationAnalysis {
    const syllables = this.countSyllables(name);
    console.log(`[DEBUG] Syllable count for "${name}": ${syllables}`);
    const phoneticSpelling = this.generatePhoneticSpelling(name);
    const notes: string[] = [];
    
    let difficulty: PronunciationAnalysis['difficulty'] = 'medium';
    let score = 7; // Default score

    // Analyze difficulty factors
    if (syllables <= 2) {
      difficulty = 'easy';
      score = 9;
      notes.push('Short and easy to remember');
    } else if (syllables <= 3) {
      difficulty = 'medium';
      score = 7;
      notes.push('Moderate length, good for branding');
    } else {
      difficulty = 'hard';
      score = 5;
      notes.push('Longer name may be harder to remember');
    }

    // Check for difficult letter combinations
    const difficultPatterns = ['sch', 'tch', 'ght', 'tion', 'sion'];
    difficultPatterns.forEach(pattern => {
      if (name.toLowerCase().includes(pattern)) {
        score -= 1;
        notes.push(`Contains "${pattern}" - may be harder to pronounce`);
      }
    });

    // Check for repeating letters
    if (/(.)\1{2,}/.test(name)) {
      score -= 0.5;
      notes.push('Repeated letters may cause confusion');
    }

    // Caribbean pronunciation considerations
    if (/[vh]/.test(name.toLowerCase())) {
      notes.push('V/H sounds clear in Caribbean English');
    }

    score = Math.max(1, Math.min(10, score));

    return {
      difficulty,
      score,
      syllables,
      phoneticSpelling,
      notes
    };
  }

  private analyzeSEO(name: string, industry?: string): SEOAnalysis {
    let score = 50; // Base score
    const notes: string[] = [];
    let keywordStrength = 50;
    let brandability = 50;

    // Length analysis
    if (name.length >= 6 && name.length <= 14) {
      score += 15;
      notes.push('Optimal length for SEO and branding');
    } else if (name.length < 6) {
      score += 10;
      brandability += 20;
      notes.push('Short name - excellent for branding');
    } else {
      score -= 10;
      notes.push('Long name may be harder to rank');
    }

    // Keyword relevance
    if (industry) {
      const industryKeywords = this.getIndustryKeywords(industry);
      industryKeywords.forEach(keyword => {
        if (name.toLowerCase().includes(keyword)) {
          keywordStrength += 20;
          score += 10;
          notes.push(`Contains industry keyword: "${keyword}"`);
        }
      });
    }

    // Domain-like structure
    if (/^[a-zA-Z]+$/.test(name)) {
      score += 10;
      brandability += 15;
      notes.push('Clean structure, no special characters');
    }

    // Memorability factors
    if (name.length <= 8) {
      brandability += 15;
      notes.push('Short names are more memorable');
    }

    // Caribbean market considerations
    if (this.caribbeanCulturalWords.some(word => name.toLowerCase().includes(word))) {
      score += 15;
      notes.push('Caribbean cultural relevance boosts local SEO');
    }

    score = Math.max(1, Math.min(100, score));
    keywordStrength = Math.max(1, Math.min(100, keywordStrength));
    brandability = Math.max(1, Math.min(100, brandability));

    let searchability: SEOAnalysis['searchability'] = 'fair';
    if (score >= 80) searchability = 'excellent';
    else if (score >= 65) searchability = 'good';
    else if (score >= 45) searchability = 'fair';
    else searchability = 'poor';

    return {
      score,
      searchability,
      keywordStrength,
      brandability,
      notes
    };
  }

  private analyzeCompetitor(name: string, industry?: string): CompetitorAnalysis {
    const similarNames: string[] = [];
    const recommendations: string[] = [];
    let uniqueness = 75; // Base uniqueness score

    // Simulate competitor analysis
    const commonPatterns = ['tech', 'digital', 'solutions', 'services', 'group', 'inc', 'pro', 'max'];
    commonPatterns.forEach(pattern => {
      if (name.toLowerCase().includes(pattern)) {
        uniqueness -= 10;
        similarNames.push(`${pattern.charAt(0).toUpperCase() + pattern.slice(1)}Corp`);
        recommendations.push(`Consider alternatives to "${pattern}" for more uniqueness`);
      }
    });

    // Industry-specific competition
    if (industry) {
      const competitors = this.getIndustryCompetitors(industry);
      competitors.forEach(competitor => {
        if (this.calculateSimilarity(name, competitor) > 0.6) {
          uniqueness -= 15;
          similarNames.push(competitor);
        }
      });
    }

    // Caribbean market analysis
    const caribbeanBusinesses = ['CaribTech', 'IslandSolutions', 'TropicalDigital', 'BeachBiz'];
    caribbeanBusinesses.forEach(business => {
      if (this.calculateSimilarity(name, business) > 0.5) {
        uniqueness -= 5;
        similarNames.push(business);
      }
    });

    uniqueness = Math.max(1, Math.min(100, uniqueness));

    let marketFit: CompetitorAnalysis['marketFit'] = 'fair';
    if (uniqueness >= 80) marketFit = 'excellent';
    else if (uniqueness >= 65) marketFit = 'good';
    else if (uniqueness >= 45) marketFit = 'fair';
    else marketFit = 'poor';

    if (recommendations.length === 0) {
      recommendations.push('Name shows good uniqueness in the market');
    }

    return {
      uniqueness,
      marketFit,
      similarNames,
      recommendations
    };
  }

  private calculateOverallScore(
    sentiment: BrandSentiment,
    pronunciation: PronunciationAnalysis,
    seo: SEOAnalysis,
    competitor: CompetitorAnalysis
  ): number {
    const sentimentScore = sentiment.overall === 'positive' ? 85 : sentiment.overall === 'negative' ? 30 : 60;
    const weights = {
      sentiment: 0.25,
      pronunciation: 0.25,
      seo: 0.25,
      competitor: 0.25
    };

    return Math.round(
      sentimentScore * weights.sentiment +
      (pronunciation.score * 10) * weights.pronunciation +
      seo.score * weights.seo +
      competitor.uniqueness * weights.competitor
    );
  }

  private countSyllables(word: string): number {
    // Handle multiple words by splitting and summing
    if (word.includes(' ')) {
      return word.split(' ')
        .filter(w => w.length > 0)
        .reduce((total, w) => total + this.countSyllables(w), 0);
    }

    word = word.toLowerCase().replace(/[^a-z]/g, '');
    if (word.length <= 3) return 1;

    // Remove silent e at the end
    word = word.replace(/e$/, '');
    
    // Count vowel groups (consecutive vowels count as 1 syllable)
    let count = 0;
    let previousWasVowel = false;
    
    for (let i = 0; i < word.length; i++) {
      const isVowel = 'aeiouy'.includes(word[i]);
      if (isVowel && !previousWasVowel) {
        count++;
      }
      previousWasVowel = isVowel;
    }
    
    // Special cases
    if (word.endsWith('le') && word.length > 2 && !'aeiouy'.includes(word[word.length - 3])) {
      count++; // Words ending in consonant + le (like "table", "little")
    }
    
    return Math.max(1, count);
  }

  private generatePhoneticSpelling(name: string): string {
    return name.replace(/ph/gi, 'f')
              .replace(/gh/gi, 'f')
              .replace(/tion/gi, 'shun')
              .replace(/sion/gi, 'zhun')
              .replace(/ch/gi, 'ch')
              .replace(/th/gi, 'th');
  }

  private getIndustryKeywords(industry: string): string[] {
    const keywords: Record<string, string[]> = {
      'technology': ['tech', 'digital', 'cyber', 'data', 'cloud', 'ai', 'smart'],
      'food': ['kitchen', 'flavor', 'taste', 'fresh', 'cook', 'meal', 'dish'],
      'health': ['wellness', 'health', 'care', 'medical', 'fit', 'vital', 'heal'],
      'education': ['learn', 'school', 'knowledge', 'study', 'teach', 'smart', 'brain'],
      'finance': ['money', 'capital', 'invest', 'finance', 'bank', 'wealth', 'pay'],
      'retail': ['shop', 'store', 'buy', 'sale', 'market', 'trade', 'deal']
    };
    return keywords[industry.toLowerCase()] || [];
  }

  private getIndustryCompetitors(industry: string): string[] {
    const competitors: Record<string, string[]> = {
      'technology': ['TechCorp', 'DigitalSolutions', 'CyberTech', 'SmartSystems'],
      'food': ['FlavorMasters', 'FreshKitchen', 'TasteBuilders', 'CookingCorp'],
      'health': ['WellnessPro', 'HealthFirst', 'VitalCare', 'MedTech'],
      'education': ['LearningSolutions', 'SmartEducation', 'KnowledgeHub', 'StudyPro']
    };
    return competitors[industry.toLowerCase()] || [];
  }

  private calculateSimilarity(name1: string, name2: string): number {
    const longer = name1.length > name2.length ? name1 : name2;
    const shorter = name1.length > name2.length ? name2 : name1;
    const editDistance = this.levenshteinDistance(longer.toLowerCase(), shorter.toLowerCase());
    return (longer.length - editDistance) / longer.length;
  }

  private levenshteinDistance(str1: string, str2: string): number {
    const matrix = [];
    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }
    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }
    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }
    return matrix[str2.length][str1.length];
  }
}