import { Request, Response, NextFunction } from 'express';

// Security event logging
interface SecurityEvent {
  type: 'suspicious_activity' | 'rate_limit_exceeded' | 'validation_failed' | 'access_attempt';
  ip: string;
  userAgent?: string;
  endpoint?: string;
  details?: any;
  timestamp: Date;
}

class SecurityMonitor {
  private events: SecurityEvent[] = [];
  private suspiciousIPs = new Set<string>();
  private rateLimitViolations = new Map<string, number>();

  logSecurityEvent(event: Omit<SecurityEvent, 'timestamp'>) {
    const fullEvent: SecurityEvent = {
      ...event,
      timestamp: new Date()
    };
    
    this.events.push(fullEvent);
    
    // Keep only last 1000 events in memory
    if (this.events.length > 1000) {
      this.events.shift();
    }

    // Track suspicious IPs
    if (event.type === 'rate_limit_exceeded' || event.type === 'validation_failed') {
      const violations = this.rateLimitViolations.get(event.ip) || 0;
      this.rateLimitViolations.set(event.ip, violations + 1);
      
      if (violations > 10) {
        this.suspiciousIPs.add(event.ip);
        console.warn(`[SECURITY ALERT] IP ${event.ip} marked as suspicious after ${violations} violations`);
      }
    }

    // Log critical events immediately
    if (event.type === 'suspicious_activity') {
      console.error(`[SECURITY CRITICAL] ${event.type} from ${event.ip}:`, event.details);
    } else {
      console.log(`[SECURITY] ${event.type} from ${event.ip}`);
    }
  }

  isSuspiciousIP(ip: string): boolean {
    return this.suspiciousIPs.has(ip);
  }

  getSecurityStats() {
    const last24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentEvents = this.events.filter(e => e.timestamp > last24h);
    
    return {
      totalEvents: this.events.length,
      eventsLast24h: recentEvents.length,
      suspiciousIPs: Array.from(this.suspiciousIPs),
      rateLimitViolations: Object.fromEntries(this.rateLimitViolations),
      eventsByType: recentEvents.reduce((acc, event) => {
        acc[event.type] = (acc[event.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    };
  }
}

export const securityMonitor = new SecurityMonitor();

// Middleware to detect suspicious activity
export function suspiciousActivityDetector(req: Request, res: Response, next: NextFunction) {
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const userAgent = req.get('User-Agent') || 'unknown';
  
  // Check for suspicious patterns
  const suspiciousPatterns = [
    /\b(script|javascript|vbscript|onload|onerror)\b/i,
    /<[^>]*>/,  // HTML tags
    /union.*select/i,  // SQL injection
    /\.\.\//,  // Path traversal
    /\0/,  // Null bytes
  ];

  // Check request body for suspicious content
  const checkContent = (obj: any): boolean => {
    if (typeof obj === 'string') {
      return suspiciousPatterns.some(pattern => pattern.test(obj));
    }
    if (typeof obj === 'object' && obj !== null) {
      return Object.values(obj).some(checkContent);
    }
    return false;
  };

  if (checkContent(req.body) || checkContent(req.query)) {
    securityMonitor.logSecurityEvent({
      type: 'suspicious_activity',
      ip,
      userAgent,
      endpoint: req.path,
      details: {
        body: req.body,
        query: req.query,
        method: req.method
      }
    });
    
    return res.status(400).json({
      error: 'Request contains potentially malicious content'
    });
  }

  // Block known suspicious IPs
  if (securityMonitor.isSuspiciousIP(ip)) {
    securityMonitor.logSecurityEvent({
      type: 'access_attempt',
      ip,
      userAgent,
      endpoint: req.path,
      details: 'Blocked suspicious IP'
    });
    
    return res.status(403).json({
      error: 'Access denied'
    });
  }

  next();
}

// Middleware to log API access
export function apiAccessLogger(req: Request, res: Response, next: NextFunction) {
  const startTime = Date.now();
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    const logData = {
      ip,
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      duration,
      userAgent: req.get('User-Agent'),
      referer: req.get('Referer')
    };
    
    console.log(`[API] ${req.method} ${req.path} ${res.statusCode} ${duration}ms ${ip}`);
    
    // Log slow requests
    if (duration > 5000) {
      console.warn(`[PERFORMANCE] Slow request: ${req.method} ${req.path} took ${duration}ms`);
    }
    
    // Log error responses
    if (res.statusCode >= 400) {
      securityMonitor.logSecurityEvent({
        type: 'validation_failed',
        ip,
        endpoint: req.path,
        details: logData
      });
    }
  });
  
  next();
}

// Headers for security
export function securityHeaders(req: Request, res: Response, next: NextFunction) {
  // Prevent clickjacking
  res.setHeader('X-Frame-Options', 'DENY');
  
  // Prevent MIME type sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');
  
  // XSS Protection
  res.setHeader('X-XSS-Protection', '1; mode=block');
  
  // Referrer Policy
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Feature Policy
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  
  next();
}