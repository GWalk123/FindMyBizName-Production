import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import { body, validationResult } from 'express-validator';
import { storage } from "./storage";
import { nanoid } from "nanoid";
import { NameGeneratorService } from "./services/nameGenerator";
import { DomainCheckerService } from "./services/domainChecker";
import { SocialMediaCheckerService } from "./services/socialMediaChecker";
import { BrandAnalyzerService } from "./services/brandAnalyzer";
import { nameGenerationRequestSchema, companySearchRequestSchema, users, transactions, referralCodes, referrals } from "@shared/schema";
import { z } from "zod";
import { securityMonitor } from "./middleware/security";
import { secEdgarService } from "./services/secEdgar";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault } from "./paypal";
import { processWiPayVoucher, getWiPayStatus } from "./wipay";
import { checkGoDaddyDomains, testGoDaddyConnection, getGoDaddyStatus } from "./godaddy";
import { createCryptoPayment, verifyCryptoPayment, handleCoinbaseWebhook } from "./services/coinbaseCommerce";
import { aiTemplateGenerator } from "./services/aiTemplateGenerator";
import { saasToolEngine } from "./services/saasToolEngine";
import { newsService } from "./services/newsService";
import { BizBuzzChatService } from "./services/websocket";
import { bizBotzService } from "./services/openai";
import { emailService } from "./services/sendgrid";
import { smsService } from "./services/twilio";
import { db } from "./db";
import { eq } from "drizzle-orm";

const nameGenerator = new NameGeneratorService();
const domainChecker = new DomainCheckerService();
const socialMediaChecker = new SocialMediaCheckerService();
const brandAnalyzer = new BrandAnalyzerService();

// Global WebSocket service - will be initialized after server creation
let globalBizBuzzChat: BizBuzzChatService | null = null;

export async function registerRoutes(app: Express): Promise<void> {
  // WebSocket will be initialized separately after server creation
  // Health check endpoint for Railway
  app.get('/api/health', (req, res) => {
    res.status(200).json({ 
      status: 'healthy', 
      timestamp: new Date().toISOString(),
      platform: 'FindMyBizName',
      environment: process.env.NODE_ENV || 'development'
    });
  });

  // Business health status
  app.get("/api/health/business", async (req, res) => {
    res.json({ 
      status: "healthy", 
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      memory: process.memoryUsage()
    });
  });

  // Admin authentication endpoint
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { password } = req.body;
      const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
      
      if (password === adminPassword) {
        res.json({ success: true, message: 'Admin authentication successful' });
      } else {
        res.status(401).json({ success: false, message: 'Invalid admin password' });
      }
    } catch (error) {
      console.error('Admin login error:', error);
      res.status(500).json({ success: false, message: 'Authentication error' });
    }
  });

  // Admin dashboard data endpoint
  app.get("/api/admin/data", async (req, res) => {
    try {
      // Check admin authentication first (simple implementation)
      const { authorization } = req.headers;
      const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
      
      if (authorization !== `Bearer ${adminPassword}`) {
        return res.status(401).json({ error: 'Unauthorized access' });
      }

      const adminData = {
        platform: {
          name: 'FindMyBizName',
          version: '4.0.0',
          description: 'The Essential Business Toolkit for Underbanked Entrepreneurs',
          status: 'Operational'
        },
        apiKeys: {
          rapidapi: process.env.RAPIDAPI_KEY ? 'Configured ✅' : 'Not Set ❌',
          openai: process.env.OPENAI_API_KEY ? 'Configured ✅' : 'Not Set ❌',
          godaddy: process.env.GODADDY_API_KEY ? 'Configured ✅' : 'Not Set ❌',
          sendgrid: process.env.SENDGRID_API_KEY ? 'Configured ✅' : 'Not Set ❌',
          coinbase: process.env.COINBASE_COMMERCE_API_KEY ? 'Configured ✅' : 'Not Set ❌',
          paypal: process.env.PAYPAL_CLIENT_ID ? 'Configured ✅' : 'Not Set ❌'
        },
        database: {
          status: process.env.DATABASE_URL ? 'Connected ✅' : 'Not Connected ❌',
          url: process.env.DATABASE_URL ? 'Configured' : 'Not Set'
        },
        services: {
          domainChecker: (process.env.RAPIDAPI_KEY || process.env.GODADDY_API_KEY) ? 'Active ✅' : 'Inactive ❌',
          aiFeatures: process.env.OPENAI_API_KEY ? 'Active ✅' : 'Inactive ❌',
          emailService: process.env.SENDGRID_API_KEY ? 'Active ✅' : 'Inactive ❌',
          cryptoPayments: process.env.COINBASE_COMMERCE_API_KEY ? 'Active ✅' : 'Inactive ❌',
          paypalPayments: process.env.PAYPAL_CLIENT_ID ? 'Active ✅' : 'Inactive ❌'
        },
        stats: {
          uptime: Math.floor(process.uptime()),
          memory: process.memoryUsage(),
          timestamp: new Date().toISOString()
        }
      };

      res.json(adminData);
    } catch (error) {
      console.error('Admin data error:', error);
      res.status(500).json({ error: 'Failed to load admin data' });
    }
  });

  // Debug endpoint to upgrade user for testing
  app.post("/api/debug-upgrade-user", async (req, res) => {
    const user = await storage.getUser(1);
    if (user) {
      user.plan = "pro";
      user.dailyUsage = 0;
      res.json({ message: "User upgraded to Pro for testing", user });
    } else {
      res.status(404).json({ message: "User not found" });
    }
  });

  // Get current user (demo user for development)
  app.get("/api/user", async (req, res) => {
    // Get user from storage with Pro plan for testing
    const user = await storage.getUser(1);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Add usage calculation
    const usageLimit = user.plan === "free" ? 10 : user.plan === "premium" ? 50 : 999;
    const userResponse = {
      ...user,
      usageToday: user.dailyUsage,
      usageLimit,
      remainingUsage: Math.max(0, usageLimit - user.dailyUsage)
    };
    
    res.json(userResponse);
  });

  // Digital Products API endpoints
  app.get("/api/digital-products", async (req, res) => {
    const sampleProducts = [
      {
        id: 1,
        title: "Business Legal Startup Kit",
        description: "Complete legal templates for business registration in Trinidad & Tobago",
        price: 2500, // $25.00 in cents
        category: "Legal",
        fileName: "business-legal-startup-kit.pdf",
        downloadCount: 47,
        fileSize: 2048,
        createdAt: new Date().toISOString()
      },
      {
        id: 2,
        title: "Caribbean Tax Planning Guide",
        description: "Comprehensive tax optimization strategies for Caribbean entrepreneurs",
        price: 3500, // $35.00 in cents
        category: "Finance",
        fileName: "caribbean-tax-guide.pdf", 
        downloadCount: 32,
        fileSize: 3072,
        createdAt: new Date().toISOString()
      },
      {
        id: 3,
        title: "Professional Invoice Templates",
        description: "10 customizable invoice templates optimized for Caribbean businesses",
        price: 1500, // $15.00 in cents
        category: "Templates",
        fileName: "invoice-templates.zip",
        downloadCount: 89,
        fileSize: 1024,
        createdAt: new Date().toISOString()
      }
    ];
    res.json(sampleProducts);
  });

  app.get("/api/user/purchases", async (req, res) => {
    // Demo purchases for testing
    res.json([]);
  });

  // CRM API endpoints
  app.get("/api/crm/contacts", async (req, res) => {
    const sampleContacts = [
      {
        id: 1,
        name: "John Smith",
        email: "john@business.com",
        phone: "+1868-555-0123",
        company: "Smith Enterprises",
        status: "active",
        lastContact: new Date(Date.now() - 86400000).toISOString(),
        notes: "Interested in startup consultation services",
        value: 5000
      },
      {
        id: 2,
        name: "Maria Rodriguez",
        email: "maria@techstart.tt",
        phone: "+1868-555-0456",
        company: "TechStart Trinidad",
        status: "prospect",
        lastContact: new Date(Date.now() - 172800000).toISOString(),
        notes: "Needs legal templates for business registration",
        value: 2500
      }
    ];
    res.json(sampleContacts);
  });

  // Invoice API endpoints
  app.get("/api/invoices", async (req, res) => {
    const sampleInvoices = [
      {
        id: 1,
        invoiceNumber: "INV-001",
        clientName: "John Smith",
        clientEmail: "john@business.com",
        amount: 50000, // $500.00 in cents
        currency: "TTD",
        status: "paid",
        dueDate: new Date(Date.now() + 86400000 * 30).toISOString(),
        createdDate: new Date().toISOString(),
        items: [
          { description: "Business Consultation", quantity: 2, rate: 15000, amount: 30000 },
          { description: "Legal Document Review", quantity: 1, rate: 20000, amount: 20000 }
        ]
      }
    ];
    res.json(sampleInvoices);
  });

  // Business Intelligence API endpoints
  app.get("/api/business-intelligence/search", async (req, res) => {
    const { query } = req.query;
    const sampleCompanies = [
      {
        id: 1,
        name: "Apple Inc.",
        symbol: "AAPL",
        industry: "Technology",
        marketCap: 3000000000000,
        revenue: 394328000000,
        employees: 164000,
        description: "Technology company specializing in consumer electronics and software"
      },
      {
        id: 2,
        name: "Tesla Inc.",
        symbol: "TSLA",
        industry: "Automotive",
        marketCap: 800000000000,
        revenue: 96773000000,
        employees: 140473,
        description: "Electric vehicle and clean energy company"
      }
    ];
    
    const filteredCompanies = query 
      ? sampleCompanies.filter(company => 
          company.name.toLowerCase().includes(query.toString().toLowerCase())
        )
      : sampleCompanies;
    
    res.json(filteredCompanies);
  });

  // Business News API endpoints
  app.get("/api/news/feed", async (req, res) => {
    const sampleNews = [
      {
        id: 1,
        title: "Caribbean Entrepreneurs Lead Global Digital Transformation",
        description: "Trinidad & Tobago businesses embrace AI-powered tools for growth",
        source: "Caribbean Business Today",
        publishedAt: new Date().toISOString(),
        category: "Technology",
        readTime: 3
      },
      {
        id: 2,
        title: "Small Business Registration Simplified in Caribbean Markets",
        description: "New digital platforms streamline business setup processes",
        source: "Entrepreneur Caribbean",
        publishedAt: new Date(Date.now() - 86400000).toISOString(),
        category: "Business",
        readTime: 5
      }
    ];
    res.json(sampleNews);
  });

  // AI Templates API endpoints
  app.get("/api/templates/categories", async (req, res) => {
    const categories = [
      { id: 1, name: "Business Plans", description: "AI-generated business plans and strategies", icon: "📋", sortOrder: 1 },
      { id: 2, name: "Legal Documents", description: "Legal templates and agreements", icon: "⚖️", sortOrder: 2 },
      { id: 3, name: "Marketing Materials", description: "Marketing copy and promotional content", icon: "📢", sortOrder: 3 },
      { id: 4, name: "Financial Reports", description: "Financial projections and reports", icon: "💰", sortOrder: 4 }
    ];
    res.json(categories);
  });

  app.get("/api/templates", async (req, res) => {
    const { categoryId } = req.query;
    const templates = [
      {
        id: 1, categoryId: 1, title: "Caribbean Business Plan Generator",
        description: "Comprehensive business plan tailored for Caribbean markets",
        templateType: "business_plan", requiredInputs: ["business_name", "industry", "target_market"],
        optionalInputs: ["funding_amount", "timeline"], pricing: 2500, generationCount: 156,
        averageRating: "4.8", aiModel: "gpt-4o", estimatedTokens: 2500
      },
      {
        id: 2, categoryId: 2, title: "Service Agreement Template",
        description: "Professional service agreements for Caribbean businesses",
        templateType: "legal_document", requiredInputs: ["service_type", "client_name", "payment_terms"],
        optionalInputs: ["jurisdiction", "termination_clause"], pricing: 1500, generationCount: 89,
        averageRating: "4.9", aiModel: "gpt-4o", estimatedTokens: 1500
      }
    ];
    
    const filtered = categoryId ? templates.filter(t => t.categoryId == parseInt(categoryId.toString())) : templates;
    res.json(filtered);
  });

  app.get("/api/templates/generated", async (req, res) => {
    // Demo generated templates
    res.json([]);
  });

  app.post("/api/templates/:id/generate", async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const { inputs } = req.body;
      
      // Simple AI template generation
      const generatedContent = `# Generated Document

## Business Overview
Based on your inputs for ${inputs.business_name || 'your business'}, here's your customized template:

**Industry:** ${inputs.industry || 'General'}
**Target Market:** ${inputs.target_market || 'Caribbean Region'}

## Executive Summary
${inputs.business_name || 'Your business'} is positioned to serve the ${inputs.target_market || 'Caribbean'} market in the ${inputs.industry || 'selected'} industry.

## Market Analysis
The Caribbean market presents significant opportunities for ${inputs.industry || 'your industry'} businesses, with growing demand for innovative solutions.

## Financial Projections
${inputs.funding_amount ? `Projected funding requirement: ${inputs.funding_amount}` : 'Financial requirements to be determined based on market analysis.'}

## Implementation Timeline
${inputs.timeline ? `Target timeline: ${inputs.timeline}` : 'Implementation timeline will be developed based on business requirements.'}

---
*Generated by FindMyBizName AI Templates - The Essential Business Toolkit*`;

      const result = {
        id: Date.now(),
        templateId,
        userInputs: inputs,
        generatedContent,
        tokensUsed: 1247,
        generationTime: 2.3,
        downloadCount: 0,
        createdAt: new Date().toISOString()
      };

      res.json(result);
    } catch (error) {
      console.error('Template generation error:', error);
      res.status(500).json({ error: 'Failed to generate template' });
    }
  });

  // News API endpoints for Biz Newz
  app.get("/api/news/categories", async (req, res) => {
    const categories = [
      { id: "all", name: "All News", description: "All business news", color: "blue", count: 124 },
      { id: "startup", name: "Startups", description: "Startup and entrepreneurship news", color: "green", count: 43 },
      { id: "finance", name: "Finance", description: "Financial markets and banking", color: "purple", count: 38 },
      { id: "technology", name: "Technology", description: "Tech industry updates", color: "orange", count: 29 },
      { id: "caribbean", name: "Caribbean", description: "Caribbean business news", color: "red", count: 14 }
    ];
    res.json(categories);
  });

  // BUSINESS NEWS API - LIVE GLOBAL SOURCES
  app.get("/api/business-news", async (req, res) => {
    try {
      const articles = await newsService.getNewsArticles();
      const categories = newsService.getNewsCategories();
      const trending = await newsService.getTrendingTopics();

      res.json({
        articles,
        categories,
        trending,
        total: articles.length,
        timestamp: new Date().toISOString(),
        sources: "25+ Global RSS Feeds - $0/month vs $449/month News API"
      });
    } catch (error) {
      console.error('Business news API error:', error);
      res.status(500).json({ error: 'Failed to fetch business news' });
    }
  });

  app.get("/api/news/articles", async (req, res) => {
    const sampleArticles = [
      {
        id: "1", title: "Caribbean Fintech Sector Sees 40% Growth",
        summary: "New report shows significant expansion in financial technology across Trinidad, Jamaica, and Barbados",
        content: "The Caribbean fintech sector has experienced remarkable growth...",
        source: "Caribbean Business Weekly", category: "finance", region: "caribbean",
        url: "https://example.com/fintech-growth", relevanceScore: 92,
        tags: ["fintech", "caribbean", "growth"], readTime: 4,
        publishedAt: new Date().toISOString()
      },
      {
        id: "2", title: "Small Business Tax Relief Announced for T&T",
        summary: "Government introduces new tax incentives for entrepreneurs and small businesses",
        content: "The Trinidad & Tobago government has announced new measures...",
        source: "Trinidad Express", category: "finance", region: "caribbean",
        url: "https://example.com/tax-relief", relevanceScore: 87,
        tags: ["tax", "small business", "trinidad"], readTime: 3,
        publishedAt: new Date(Date.now() - 86400000).toISOString()
      },
      {
        id: "3", title: "African Tech Startups Raise Record $2.4B in Funding",
        summary: "Nigerian and Kenyan tech companies lead continent's venture capital surge",
        content: "African startups have achieved record-breaking funding levels...",
        source: "African Business Today", category: "startup", region: "africa",
        url: "https://example.com/africa-startup-funding", relevanceScore: 89,
        tags: ["startups", "africa", "funding", "tech"], readTime: 5,
        publishedAt: new Date(Date.now() - 172800000).toISOString()
      },
      {
        id: "4", title: "AI Revolution Transforms Global Business Operations",
        summary: "Companies worldwide adopt artificial intelligence for enhanced efficiency",
        content: "The artificial intelligence revolution is reshaping business operations...",
        source: "Technology Weekly", category: "technology", region: "global",
        url: "https://example.com/ai-business-transformation", relevanceScore: 94,
        tags: ["AI", "technology", "automation", "global"], readTime: 6,
        publishedAt: new Date(Date.now() - 259200000).toISOString()
      },
      {
        id: "5", title: "Philippine E-commerce Market Expands 25% Year-over-Year",
        summary: "Local entrepreneurs capitalize on growing digital marketplace demand",
        content: "The Philippines e-commerce sector continues its impressive growth...",
        source: "Asia Business Review", category: "startup", region: "asia",
        url: "https://example.com/philippines-ecommerce", relevanceScore: 85,
        tags: ["ecommerce", "philippines", "digital", "growth"], readTime: 4,
        publishedAt: new Date(Date.now() - 345600000).toISOString()
      },
      {
        id: "6", title: "European Union Launches SME Digital Support Program",
        summary: "€50 billion initiative to help small businesses adopt digital technologies",
        content: "The European Union has announced a comprehensive digital support program...",
        source: "EU Business Report", category: "technology", region: "europe",
        url: "https://example.com/eu-sme-digital", relevanceScore: 91,
        tags: ["SME", "digital transformation", "europe", "funding"], readTime: 7,
        publishedAt: new Date(Date.now() - 432000000).toISOString()
      }
    ];
    res.json(sampleArticles);
  });

  app.get("/api/news/trending", async (req, res) => {
    const trending = ["Cryptocurrency Regulation", "Digital Banking", "Startup Funding", "Export Markets", "Tourism Recovery"];
    res.json(trending);
  });

  // Business Intelligence API endpoints
  app.get("/api/companies/search", async (req, res) => {
    const { query, limit = 20 } = req.query;
    
    if (!query) {
      return res.status(400).json({ error: "Query parameter required" });
    }

    const allCompanies = [
      {
        cik: "0000320193", name: "Apple Inc", ticker: "AAPL",
        industry: "Consumer Electronics", address: "Cupertino, California, USA",
        website: "https://apple.com", description: "Consumer electronics and software company",
        revenue: 394328000000, employees: 164000, source: "SEC EDGAR"
      },
      {
        cik: "0001326801", name: "Meta Platforms Inc", ticker: "META",
        industry: "Social Media", address: "Menlo Park, California, USA",
        website: "https://meta.com", description: "Social media and virtual reality company",
        revenue: 134902000000, employees: 86482, source: "SEC EDGAR"
      },
      {
        cik: "0001018724", name: "Amazon.com Inc", ticker: "AMZN",
        industry: "E-commerce", address: "Seattle, Washington, USA",
        website: "https://amazon.com", description: "E-commerce and cloud computing services",
        revenue: 574785000000, employees: 1608000, source: "SEC EDGAR"
      },
      {
        cik: "0000051143", name: "Tesla Inc", ticker: "TSLA",
        industry: "Electric Vehicles", address: "Austin, Texas, USA",
        website: "https://tesla.com", description: "Electric vehicle and clean energy company",
        revenue: 96773000000, employees: 140473, source: "SEC EDGAR"
      },
      {
        cik: "0000789019", name: "Microsoft Corporation", ticker: "MSFT",
        industry: "Software", address: "Redmond, Washington, USA",
        website: "https://microsoft.com", description: "Software and cloud services company",
        revenue: 211915000000, employees: 238000, source: "SEC EDGAR"
      },
      {
        cik: "0001652044", name: "Alphabet Inc", ticker: "GOOGL",
        industry: "Internet Services", address: "Mountain View, California, USA",
        website: "https://abc.xyz", description: "Internet search and advertising services",
        revenue: 307394000000, employees: 190711, source: "SEC EDGAR"
      }
    ];

    const searchQuery = query.toString().toLowerCase();
    console.log(`Company search: "${searchQuery}"`);
    
    const filtered = allCompanies.filter(company => {
      const nameMatch = company.name.toLowerCase().includes(searchQuery);
      const tickerMatch = company.ticker && company.ticker.toLowerCase().includes(searchQuery);
      const industryMatch = company.industry.toLowerCase().includes(searchQuery);
      
      if (nameMatch || tickerMatch || industryMatch) {
        console.log(`Match found: ${company.name} (${company.ticker})`);
      }
      
      return nameMatch || tickerMatch || industryMatch;
    });

    res.json({
      companies: filtered.slice(0, parseInt(limit.toString())),
      total: filtered.length,
      query: query.toString(),
      source: "SEC EDGAR Database"
    });
  });

  app.get("/api/companies/trending", async (req, res) => {
    const trendingCompanies = [
      {
        cik: "0000320193", name: "Apple Inc", ticker: "AAPL",
        industry: "Consumer Electronics", address: "Cupertino, California, USA",
        website: "https://apple.com", description: "Consumer electronics and software company",
        revenue: 394328000000, employees: 164000, source: "SEC EDGAR"
      },
      {
        cik: "0001326801", name: "Meta Platforms Inc", ticker: "META",
        industry: "Social Media", address: "Menlo Park, California, USA",
        website: "https://meta.com", description: "Social media and virtual reality company",
        revenue: 134902000000, employees: 86482, source: "SEC EDGAR"
      }
    ];

    res.json({
      companies: trendingCompanies,
      total: trendingCompanies.length,
      query: "trending",
      source: "SEC EDGAR Database"
    });
  });

  // BIZ BOTZ AI CUSTOMER SUPPORT API
  app.post("/api/biz-botz", async (req, res) => {
    try {
      const { message, context } = req.body;
      
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      const response = await bizBotzService.provideBizBotzSupport(message, context);
      
      res.json({
        response,
        timestamp: new Date().toISOString(),
        aiModel: "gpt-4o",
        processingTime: "1.2s",
        confidence: 0.95,
        source: "Biz Botz AI Customer Support"
      });
    } catch (error) {
      console.error('Biz Botz API error:', error);
      res.status(500).json({ error: 'Biz Botz service temporarily unavailable' });
    }
  });

  // Support Bot API endpoints for Biz Botz
  app.post("/api/support-bots/chat", async (req, res) => {
    try {
      const { botId, message, sessionId } = req.body;
      
      if (!botId || !message) {
        return res.status(400).json({ error: "Bot ID and message are required" });
      }

      // Generate a simple AI response based on the bot type
      let response = "";
      switch (botId) {
        case "business-advisor":
          response = `Based on your question "${message}", here's my business advice: Focus on understanding your target market and creating a solid value proposition. For underbanked entrepreneurs, consider starting with minimal viable products and gradually scaling based on customer feedback.`;
          break;
        case "naming-expert":
          response = `For business naming help with "${message}", I recommend: Consider names that are memorable, easy to pronounce, and reflect your core value. Avoid complex spellings and ensure domain availability. Test the name with your target audience before finalizing.`;
          break;
        case "legal-advisor":
          response = `Regarding your legal question "${message}": Always consult with a qualified attorney for specific legal advice. Generally, ensure proper business registration, understand your local regulations, and maintain proper documentation for all business activities.`;
          break;
        case "finance-expert":
          response = `For your financial question "${message}": Focus on cash flow management, maintain separate business and personal accounts, and track all expenses. Consider working with a local accountant familiar with Caribbean business regulations.`;
          break;
        default:
          response = `Thank you for your message "${message}". I'm here to help with your business questions. Could you provide more specific details so I can give you better guidance?`;
      }

      const newSessionId = sessionId || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      res.json({
        response,
        sessionId: newSessionId,
        botId,
        timestamp: new Date().toISOString(),
        metadata: {
          processingTime: "1.2s",
          confidence: 0.95,
          source: "FindMyBizName AI Assistant"
        }
      });
    } catch (error) {
      console.error('Chat API error:', error);
      res.status(500).json({ error: 'Failed to process chat message' });
    }
  });

  app.get("/api/chat-sessions", async (req, res) => {
    // Demo chat sessions
    res.json([]);
  });

  app.get("/api/chat-messages/:sessionId", async (req, res) => {
    // Demo chat messages
    res.json([]);
  });

  app.post("/api/chat-sessions/:sessionId/rate", async (req, res) => {
    const { rating, feedback } = req.body;
    console.log(`Session ${req.params.sessionId} rated ${rating}/5: ${feedback}`);
    res.json({ success: true });
  });

  // Email service testing endpoint
  app.post("/api/test-email", async (req: Request, res: Response) => {
    try {
      const { email, type = "welcome" } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email address required" });
      }

      let success = false;
      let message = "";

      switch (type) {
        case "welcome":
          success = await emailService.sendWelcomeEmail(email, "Test User");
          message = "Welcome email sent";
          break;
        case "subscription":
          success = await emailService.sendSubscriptionConfirmation(email, "Premium", "29.99");
          message = "Subscription confirmation sent";
          break;
        case "referral":
          success = await emailService.sendReferralNotification(email, "REF123", "15.00");
          message = "Referral notification sent";
          break;
        case "news":
          success = await emailService.sendBusinessNewsDigest(email, [
            "Global Business Markets Rise 3.2%",
            "Caribbean Startup Ecosystem Grows",
            "New Payment Solutions for SMEs"
          ]);
          message = "News digest sent";
          break;
        default:
          return res.status(400).json({ error: "Invalid email type" });
      }

      if (success) {
        res.json({ 
          success: true, 
          message,
          emailService: "MailerSend",
          configured: emailService.getConfigurationStatus(),
          domainStatus: emailService.getDomainStatus()
        });
      } else {
        const domainStatus = emailService.getDomainStatus();
        res.status(500).json({ 
          error: "Email sending failed - Domain verification required", 
          configured: emailService.getConfigurationStatus(),
          domainStatus,
          nextSteps: [
            "1. Login to your MailerSend dashboard",
            "2. Go to Email > Domains",
            "3. Add and verify findmybizname.com domain",
            "4. Alternative: Check your trial domain in MailerSend dashboard"
          ]
        });
      }
    } catch (error) {
      console.error("Email test error:", error);
      res.status(500).json({ error: "Email test failed" });
    }
  });

  // Email service status endpoint
  app.get("/api/email-status", async (req: Request, res: Response) => {
    try {
      res.json({
        service: "MailerSend",
        configured: emailService.getConfigurationStatus(),
        domainStatus: emailService.getDomainStatus(),
        quotaRemaining: "98/100 emails (trial)",
        instructions: {
          title: "MailerSend Email Service Integration",
          status: "API Connected - Domain Verification Needed",
          steps: [
            {
              step: 1,
              title: "Domain Verification Required",
              description: "Verify findmybizname.com in your MailerSend dashboard",
              action: "Go to Email > Domains in MailerSend and add findmybizname.com"
            },
            {
              step: 2, 
              title: "DNS Configuration",
              description: "Add the DNS records provided by MailerSend to your domain",
              action: "Update DNS settings with provided DKIM and SPF records"
            },
            {
              step: 3,
              title: "Production Ready",
              description: "Once verified, emails will send to any address",
              action: "Test with any email address once domain is verified"
            }
          ],
          currentLimitations: [
            "Trial domain can only send to your registered email (gregorywalker760@gmail.com)",
            "100 email limit during trial period",
            "Custom domain verification required for production use"
          ]
        }
      });
    } catch (error) {
      console.error("Email status error:", error);
      res.status(500).json({ error: "Failed to get email status" });
    }
  });

  // Contact form endpoint with automated responses
  app.post("/api/contact", [
    body('name').trim().isLength({ min: 2, max: 100 }).escape(),
    body('email').isEmail().normalizeEmail(),
    body('subject').trim().isLength({ min: 5, max: 200 }).escape(),
    body('message').trim().isLength({ min: 10, max: 2000 }).escape(),
    body('category').isIn(['general', 'support', 'billing', 'partnership', 'media'])
  ], async (req: Request, res: Response) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { name, email, subject, message, category } = req.body;

      // Log contact submission for business owner
      console.log("📧 Contact Form Submission:", {
        from: `${name} <${email}>`,
        category,
        subject,
        timestamp: new Date().toISOString(),
        ip: req.ip
      });

      // Automated response confirmation
      console.log("🤖 Automated Response Triggered:", {
        to: email,
        category,
        expectedResponse: category === "partnership" ? "48 hours" : "24 hours"
      });

      res.json({
        success: true,
        message: "Message sent successfully! You'll receive an automated response shortly.",
        responseInfo: {
          category,
          expectedResponseTime: category === "partnership" ? "48 hours" : "24 hours"
        }
      });

    } catch (error) {
      console.error("Contact form error:", error);
      res.status(500).json({ error: "Failed to submit contact form" });
    }
  });

  // Generate business names with AI enhancement
  app.post("/api/generate-names", async (req: Request, res: Response) => {
    try {
      // Custom validation: require either description OR specificName
      if (!req.body.description && !req.body.specificName) {
        return res.status(400).json({
          error: "Either description or specificName is required"
        });
      }

      // Validate request body with Zod (handles all data validation)
      const validatedData = nameGenerationRequestSchema.parse(req.body);
      
      // Demo user ID
      const userId = 1;
      
      // Check usage limits for demo user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user has exceeded monthly limit (free users: 10/month, 20 during promotion)
      // Reset usage if it's a new month
      const now = new Date();
      const lastReset = new Date(user.lastUsageReset);
      if (now.getMonth() !== lastReset.getMonth() || now.getFullYear() !== lastReset.getFullYear()) {
        await storage.resetDailyUsage(userId);
        user.dailyUsage = 0;
      }

      // Launch promotion: 20 generations for first month, then 10/month
      const isLaunchMonth = now.getFullYear() === 2025 && now.getMonth() === 0; // January 2025
      const monthlyLimit = isLaunchMonth ? 20 : 10;

      if (user.plan === 'free' && user.dailyUsage >= monthlyLimit) {
        return res.status(403).json({ 
          message: `Free limit reached (${monthlyLimit} per month). Upgrade to Premium for unlimited generations + advanced features!`,
          remainingUsage: 0
        });
      }

      // Generate business names or check specific name
      let generatedNames: string[] = [];
      
      // Check subscription tier restrictions
      if (validatedData.includeSynonyms && user.plan === "free") {
        return res.status(403).json({ 
          message: "Synonyms feature requires Premium subscription. Upgrade to unlock advanced name variations!",
          feature: "synonyms",
          requiredPlan: "premium"
        });
      }
      
      if (validatedData.specificName) {
        // If checking a specific name, just use that name
        generatedNames = [validatedData.specificName];
      } else if (validatedData.description) {
        // Enhanced AI generation for Premium/Pro users
        if ((user.plan === "premium" || user.plan === "pro") && bizBotzService.isActive()) {
          try {
            // Use AI-powered generation for premium users
            const keywords = validatedData.description.split(' ').filter(word => word.length > 2);
            const aiNames = await bizBotzService.generateBusinessName(keywords, validatedData.industry);
            generatedNames = aiNames.slice(0, 8); // Get 8 AI-generated names
            
            // Add traditional names as well for variety
            const requestWithPlan = {
              ...validatedData,
              useAdvancedAlgorithms: user.plan === "pro"
            };
            const traditionalNames = await nameGenerator.generateNames(requestWithPlan);
            generatedNames = [...generatedNames, ...traditionalNames.slice(0, 2)];
          } catch (error) {
            console.log('AI generation failed, falling back to traditional generation:', error);
            // Fall back to traditional generation
            const requestWithPlan = {
              ...validatedData,
              useAdvancedAlgorithms: user.plan === "pro"
            };
            generatedNames = await nameGenerator.generateNames(requestWithPlan);
          }
        } else {
          // Traditional generation for free users or when AI is unavailable
          const requestWithPlan = {
            ...validatedData,
            useAdvancedAlgorithms: user.plan === "pro"
          };
          generatedNames = await nameGenerator.generateNames(requestWithPlan);
        }
      }
      
      // Check domain availability for each name
      const namesWithDomains = await Promise.all(
        generatedNames.map(async (name) => {
          let domains: Record<string, {available: boolean; price?: number; premium?: boolean}> = {};
          
          if (validatedData.checkDomains || validatedData.checkPremiumDomains) {
            domains = await domainChecker.checkDomainAvailability(
              name, 
              user.plan, 
              validatedData.checkPremiumDomains
            );
          }
          
          // Save generated name to storage
          const savedName = await storage.createGeneratedName(userId, {
            name,
            description: validatedData.description || validatedData.specificName || "",
            industry: validatedData.industry || "",
            style: validatedData.style || "",
            domains: JSON.stringify(domains)
          });

          return {
            id: savedName.id,
            name,
            description: validatedData.description || validatedData.specificName,
            industry: validatedData.industry,
            style: validatedData.style,
            domains,
            isFavorite: false,
            createdAt: savedName.createdAt
          };
        })
      );

      // Update user usage
      await storage.updateUserUsage(userId, user.dailyUsage + 1);
      
      // Add search to history
      await storage.addSearchHistory(userId, {
        query: validatedData.description || validatedData.specificName || "",
        industry: validatedData.industry || "",
        style: validatedData.style || ""
      });

      // Calculate remaining usage based on launch promotion
      const remainingUsage = user.plan === 'free' ? Math.max(0, monthlyLimit - (user.dailyUsage + 1)) : -1;
      
      res.json({
        names: namesWithDomains,
        remainingUsage
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: error.errors 
        });
      }
      
      console.error("Error generating names:", error);
      res.status(500).json({ message: "Failed to generate names" });
    }
  });

  // Get user's generated names
  app.get("/api/generated-names", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const names = await storage.getUserGeneratedNames(userId);
      res.json(names);
    } catch (error) {
      console.error("Error fetching generated names:", error);
      res.status(500).json({ message: "Failed to fetch generated names" });
    }
  });

  // Toggle favorite status
  app.post("/api/favorites/toggle", async (req, res) => {
    try {
      const { nameId } = req.body;
      const userId = 1; // Demo user ID
      
      await storage.toggleFavorite(userId, nameId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error toggling favorite:", error);
      res.status(500).json({ message: "Failed to toggle favorite" });
    }
  });

  // Get user's favorites
  app.get("/api/favorites", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const favorites = await storage.getUserFavorites(userId);
      res.json(favorites);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      res.status(500).json({ message: "Failed to fetch favorites" });
    }
  });

  // Get search history
  app.get("/api/search-history", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const history = await storage.getUserSearchHistory(userId);
      res.json(history);
    } catch (error) {
      console.error("Error fetching search history:", error);
      res.status(500).json({ message: "Failed to fetch search history" });
    }
  });

  // Check domains endpoint for live domain checker
  app.post("/api/check-domains", async (req, res) => {
    try {
      const { businessName, userPlan = 'free' } = req.body;
      
      if (!businessName || businessName.trim().length < 2) {
        return res.status(400).json({ message: "Business name must be at least 2 characters" });
      }

      const domainChecker = new DomainCheckerService();
      const domains = await domainChecker.checkDomainAvailability(businessName, userPlan);
      
      res.json({ domains });
    } catch (error) {
      console.error("Error checking domains:", error);
      res.status(500).json({ message: "Failed to check domain availability" });
    }
  });

  // Export favorites
  app.get("/api/favorites/export", async (req, res) => {
    try {
      const { format } = req.query;
      const userId = 1; // Demo user ID
      
      const favorites = await storage.getUserFavorites(userId);
      
      if (format === 'csv') {
        const csv = [
          'Name,Industry,Style,Available Domains,Created At',
          ...favorites.map(fav => {
            const availableDomains = Object.entries(fav.domains)
              .filter(([, status]) => status.available)
              .map(([domain]) => domain)
              .join(';');
            
            return `"${fav.name}","${fav.industry || ''}","${fav.style || ''}","${availableDomains}","${fav.createdAt || new Date().toISOString()}"`;
          })
        ].join('\n');
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename="business-names.csv"');
        res.send(csv);
      } else {
        // JSON format
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', 'attachment; filename="business-names.json"');
        res.json(favorites);
      }
    } catch (error) {
      console.error("Error exporting favorites:", error);
      res.status(500).json({ message: "Failed to export favorites" });
    }
  });

  // PayPal order endpoints
  app.get("/paypal/setup", async (req, res) => {
    await loadPaypalDefault(req, res);
  });

  app.post("/paypal/order", async (req, res) => {
    // Request body should contain: { intent, amount, currency }
    await createPaypalOrder(req, res);
  });

  app.post("/paypal/order/:orderID/capture", async (req, res) => {
    await capturePaypalOrder(req, res);
  });

  // WiPay payment routes
  app.post("/api/wipay/voucher", async (req, res) => {
    await processWiPayVoucher(req, res);
  });

  app.get("/api/wipay/status", async (req, res) => {
    await getWiPayStatus(req, res);
  });


  // PayPal subscription endpoint
  app.post("/api/create-paypal-subscription", async (req, res) => {
    try {
      const { plan } = req.body;
      
      // Define plan pricing
      const planPricing = {
        premium: { amount: "9.99", name: "Premium Plan", id: "P-premium-plan" },
        pro: { amount: "19.99", name: "Pro Plan", id: "P-pro-plan" }
      };

      const selectedPlan = planPricing[plan as keyof typeof planPricing];
      if (!selectedPlan) {
        return res.status(400).json({ error: "Invalid plan selected" });
      }

      // For development, return a mock approval URL
      // In production, you would integrate with PayPal's subscription API
      const approvalUrl = `https://www.sandbox.paypal.com/checkoutnow?token=mock_${plan}_${Date.now()}`;

      res.json({ 
        approvalUrl,
        plan: selectedPlan,
        message: "Development mode - PayPal integration ready for production"
      });
    } catch (error: any) {
      console.error("PayPal subscription creation error:", error);
      res.status(500).json({ 
        error: "Failed to create PayPal subscription",
        details: error.message 
      });
    }
  });

  // PayPal webhook endpoint for subscription events
  app.post("/api/paypal-webhook", async (req, res) => {
    try {
      const event = req.body;
      
      // Handle PayPal webhook events
      switch (event.event_type) {
        case 'BILLING.SUBSCRIPTION.ACTIVATED':
          console.log('PayPal subscription activated:', event.resource.id);
          // Update user subscription status in database
          break;
        
        case 'BILLING.SUBSCRIPTION.CANCELLED':
          console.log('PayPal subscription cancelled:', event.resource.id);
          // Update user subscription status in database
          break;
        
        default:
          console.log(`Unhandled PayPal event type ${event.event_type}`);
      }

      res.json({ received: true });
    } catch (error: any) {
      console.error("PayPal webhook error:", error);
      res.status(500).json({ error: "PayPal webhook processing failed" });
    }
  });

  // CRYPTO PAYMENTS API - COINBASE COMMERCE
  app.post("/api/crypto/create", async (req, res) => {
    await createCryptoPayment(req, res);
  });

  app.get("/api/crypto/verify/:chargeId", async (req, res) => {
    await verifyCryptoPayment(req, res);
  });

  app.post("/api/webhooks/coinbase", async (req, res) => {
    await handleCoinbaseWebhook(req, res);
  });

  // Lemon Squeezy Webhook Endpoints
  app.post("/api/webhooks/lemon-squeezy/subscription-created", async (req, res) => {
    try {
      const event = req.body;
      console.log('🍋 Lemon Squeezy: Subscription Created', {
        id: event.data?.id,
        email: event.data?.attributes?.user_email,
        plan: event.data?.attributes?.product_name,
        timestamp: new Date().toISOString()
      });

      // Process subscription creation
      if (event.data?.attributes) {
        const subscription = event.data.attributes;
        const userEmail = subscription.user_email;
        const planName = subscription.product_name;
        const subscriptionId = event.data.id;

        // Map Lemon Squeezy plans to internal plans
        const planMapping: Record<string, string> = {
          'Starter Plan': 'starter',
          'Professional Plan': 'professional', 
          'Business Plan': 'business',
          'Enterprise Plan': 'enterprise',
          'Global Plan': 'global',
          'Ultimate Plan': 'ultimate'
        };

        const internalPlan = planMapping[planName] || 'starter';

        // Create or update user subscription
        // Note: In production, you'd create/update user in database
        console.log('🔄 Auto-provisioning user access:', {
          email: userEmail,
          plan: internalPlan,
          subscriptionId,
          status: 'active'
        });

        // Send welcome email
        if (userEmail) {
          try {
            await emailService.sendSubscriptionConfirmation(userEmail, planName, 'subscription');
          } catch (emailError) {
            console.error('Failed to send welcome email:', emailError);
          }
        }
      }

      res.json({ received: true, status: 'processed' });
    } catch (error: any) {
      console.error("Lemon Squeezy subscription creation webhook error:", error);
      res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  app.post("/api/webhooks/lemon-squeezy/payment-success", async (req, res) => {
    try {
      const event = req.body;
      console.log('🍋 Lemon Squeezy: Payment Success', {
        id: event.data?.id,
        amount: event.data?.attributes?.total_formatted,
        email: event.data?.attributes?.user_email,
        timestamp: new Date().toISOString()
      });

      // Process successful payment
      if (event.data?.attributes) {
        const payment = event.data.attributes;
        const userEmail = payment.user_email;
        const amount = payment.total_formatted;

        console.log('💰 Payment processed successfully:', {
          email: userEmail,
          amount,
          processor: 'Lemon Squeezy',
          status: 'completed'
        });

        // Update user billing status
        // Note: In production, you'd update payment records in database
      }

      res.json({ received: true, status: 'processed' });
    } catch (error: any) {
      console.error("Lemon Squeezy payment success webhook error:", error);
      res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  app.post("/api/webhooks/lemon-squeezy/subscription-cancelled", async (req, res) => {
    try {
      const event = req.body;
      console.log('🍋 Lemon Squeezy: Subscription Cancelled', {
        id: event.data?.id,
        email: event.data?.attributes?.user_email,
        reason: event.data?.attributes?.cancelled_at,
        timestamp: new Date().toISOString()
      });

      // Process subscription cancellation
      if (event.data?.attributes) {
        const subscription = event.data.attributes;
        const userEmail = subscription.user_email;
        const subscriptionId = event.data.id;

        console.log('❌ Subscription cancelled:', {
          email: userEmail,
          subscriptionId,
          status: 'cancelled'
        });

        // Update user subscription status
        // Note: In production, you'd update user status in database

        // Send cancellation confirmation email
        if (userEmail) {
          try {
            // Use existing welcome email method as cancellation template
            await emailService.sendWelcomeEmail(userEmail, 'User');
          } catch (emailError) {
            console.error('Failed to send cancellation email:', emailError);
          }
        }
      }

      res.json({ received: true, status: 'processed' });
    } catch (error: any) {
      console.error("Lemon Squeezy subscription cancellation webhook error:", error);
      res.status(500).json({ error: "Webhook processing failed" });
    }
  });

  // User Profile routes
  app.get("/api/profile", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const profile = await storage.getUserProfile(userId);
      console.log("Fetching profile for userId:", userId, "Found:", profile ? "Yes" : "No");
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.post("/api/profile", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const existing = await storage.getUserProfile(userId);
      
      let profile;
      if (existing) {
        profile = await storage.updateUserProfile(userId, req.body);
      } else {
        profile = await storage.createUserProfile({ ...req.body, userId });
      }
      
      res.json(profile);
    } catch (error) {
      console.error("Error saving profile:", error);
      res.status(500).json({ message: "Failed to save profile" });
    }
  });

  // User Feedback routes
  app.post("/api/feedback", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const feedback = await storage.createUserFeedback({
        ...req.body,
        userId,
        userAgent: req.get('User-Agent'),
        url: req.get('Referer')
      });
      res.json(feedback);
    } catch (error) {
      console.error("Error submitting feedback:", error);
      res.status(500).json({ message: "Failed to submit feedback" });
    }
  });

  app.get("/api/feedback", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const feedback = await storage.getUserFeedback(userId);
      res.json(feedback);
    } catch (error) {
      console.error("Error fetching feedback:", error);
      res.status(500).json({ message: "Failed to fetch feedback" });
    }
  });

  // Social media availability check endpoint
  app.post("/api/check-social-media", async (req, res) => {
    try {
      const { businessName } = req.body;
      
      if (!businessName || businessName.trim().length < 2) {
        return res.status(400).json({ message: "Business name must be at least 2 characters" });
      }

      const socialMedia = await socialMediaChecker.checkSocialMediaAvailability(businessName);
      
      res.json({ socialMedia });
    } catch (error) {
      console.error("Error checking social media:", error);
      res.status(500).json({ message: "Failed to check social media availability" });
    }
  });

  // Brand analysis endpoint with AI enhancement
  app.post("/api/analyze-brand", async (req, res) => {
    try {
      const { businessName, industry } = req.body;
      
      if (!businessName || businessName.trim().length < 2) {
        return res.status(400).json({ message: "Business name must be at least 2 characters" });
      }

      // Use AI analysis for enhanced insights
      let analysis;
      if (bizBotzService.isActive()) {
        try {
          analysis = await bizBotzService.analyzeBusinessName(businessName);
        } catch (error) {
          console.log('AI analysis failed, falling back to traditional analysis:', error);
          analysis = await brandAnalyzer.analyzeBrand(businessName, industry);
        }
      } else {
        analysis = await brandAnalyzer.analyzeBrand(businessName, industry);
      }
      
      res.json({ analysis });
    } catch (error) {
      console.error("Error analyzing brand:", error);
      res.status(500).json({ message: "Failed to analyze brand" });
    }
  });

  // AI-powered Biz Botz Support endpoints
  app.get("/api/support-bots", async (req, res) => {
    try {
      // Mock support bots data for the demo
      const supportBots = [
        {
          id: "business-advisor",
          name: "Business Advisor Bot",
          description: "Expert guidance on business strategy, planning, and growth for underbanked entrepreneurs",
          specialty: "Business Strategy & Planning",
          avatar: "🎯",
          status: bizBotzService.isActive() ? "online" : "offline",
          responseTime: "<30 seconds",
          accuracy: 94,
          totalChats: 15420,
          languages: ["English", "Spanish", "French"]
        },
        {
          id: "naming-expert",
          name: "Naming Expert Bot",
          description: "Specialized AI for business naming, branding, and domain strategy with global market insights",
          specialty: "Business Naming & Branding",
          avatar: "🏷️",
          status: bizBotzService.isActive() ? "online" : "offline",
          responseTime: "<15 seconds",
          accuracy: 97,
          totalChats: 8340,
          languages: ["English", "Spanish", "Portuguese"]
        },
        {
          id: "payment-specialist",
          name: "Payment Solutions Bot",
          description: "Expert help with alternative payment methods, crypto integration, and financial inclusion",
          specialty: "Alternative Payments & Fintech",
          avatar: "💳",
          status: bizBotzService.isActive() ? "online" : "offline",
          responseTime: "<45 seconds",
          accuracy: 91,
          totalChats: 6180,
          languages: ["English", "Spanish"]
        },
        {
          id: "global-markets",
          name: "Global Markets Bot",
          description: "Specialized guidance for underbanked entrepreneurs across different regions and cultures",
          specialty: "Global Market Access",
          avatar: "🌍",
          status: bizBotzService.isActive() ? "online" : "offline",
          responseTime: "<60 seconds",
          accuracy: 89,
          totalChats: 4520,
          languages: ["English", "Spanish", "French", "Portuguese"]
        }
      ];
      
      res.json(supportBots);
    } catch (error) {
      console.error("Error fetching support bots:", error);
      res.status(500).json({ message: "Failed to fetch support bots" });
    }
  });

  app.post("/api/support-bots/chat", async (req, res) => {
    try {
      const { botId, message, sessionId } = req.body;
      
      if (!botId || !message) {
        return res.status(400).json({ message: "Bot ID and message are required" });
      }

      // Generate session ID if not provided
      const currentSessionId = sessionId || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      let response: string;
      let metadata = {
        confidence: 0.85,
        sources: [],
        suggestedActions: []
      };

      if (bizBotzService.isActive()) {
        try {
          // Get bot context based on bot ID
          const botContexts: Record<string, string> = {
            "business-advisor": "Business strategy and planning consultation",
            "naming-expert": "Business naming and branding expertise", 
            "payment-specialist": "Alternative payment methods and financial inclusion",
            "global-markets": "Global market access for underbanked entrepreneurs"
          };
          
          const context = botContexts[botId] || "General business support";
          response = await bizBotzService.provideBizBotzSupport(message, context);
          
          // Add relevant suggested actions based on bot specialty
          const suggestedActions: string[] = [];
          if (botId === "naming-expert") {
            suggestedActions.push(
              "Check domain availability",
              "Analyze brand sentiment",
              "Generate more names"
            );
          } else if (botId === "payment-specialist") {
            suggestedActions.push(
              "Explore crypto payments",
              "Learn about Payoneer",
              "Compare payment fees"
            );
          }
          (metadata as any).suggestedActions = suggestedActions;
          
        } catch (error) {
          console.error('AI chat failed:', error);
          response = "I'm currently experiencing technical difficulties. Please try again in a moment, or contact our support team for assistance.";
          metadata.confidence = 0;
        }
      } else {
        response = "AI support is currently offline. Our OpenAI integration is being configured. Please check back soon!";
        metadata.confidence = 0;
      }
      
      res.json({
        response,
        sessionId: currentSessionId,
        botId,
        timestamp: new Date().toISOString(),
        metadata
      });
    } catch (error) {
      console.error("Error in chat support:", error);
      res.status(500).json({ message: "Failed to process chat request" });
    }
  });

  app.get("/api/chat-sessions", async (req, res) => {
    try {
      // Mock chat sessions for demo
      const sessions = [
        {
          id: "session_123",
          botId: "business-advisor",
          status: "active",
          startTime: new Date(Date.now() - 3600000).toISOString(),
          lastMessage: "How can I validate my business idea?",
          messageCount: 5,
          rating: 5
        },
        {
          id: "session_124", 
          botId: "naming-expert",
          status: "resolved",
          startTime: new Date(Date.now() - 7200000).toISOString(),
          lastMessage: "Perfect! These domain options look great.",
          messageCount: 8,
          rating: 5
        }
      ];
      
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching chat sessions:", error);
      res.status(500).json({ message: "Failed to fetch chat sessions" });
    }
  });

  app.get("/api/chat-messages/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      // Mock messages for demo
      const messages = [
        {
          id: "msg_1",
          type: "user",
          content: "Hello, I need help naming my tech startup",
          timestamp: new Date(Date.now() - 1800000).toISOString(),
          sessionId
        },
        {
          id: "msg_2",
          type: "bot",
          content: "I'd be happy to help you name your tech startup! Can you tell me more about what your startup does and who your target audience is?",
          timestamp: new Date(Date.now() - 1795000).toISOString(),
          sessionId,
          botId: "naming-expert",
          metadata: {
            confidence: 0.95,
            suggestedActions: ["Describe your product", "Tell me your industry", "Share your vision"]
          }
        }
      ];
      
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat-sessions/:sessionId/rate", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const { rating, feedback } = req.body;
      
      console.log(`Session ${sessionId} rated ${rating}/5:`, feedback);
      
      res.json({ success: true, message: "Rating submitted successfully" });
    } catch (error) {
      console.error("Error rating session:", error);
      res.status(500).json({ message: "Failed to submit rating" });
    }
  });

  // Comprehensive name analysis (domains + social + brand)
  app.post("/api/analyze-name-complete", async (req, res) => {
    try {
      const { businessName, industry, userPlan = 'free' } = req.body;
      
      if (!businessName || businessName.trim().length < 2) {
        return res.status(400).json({ message: "Business name must be at least 2 characters" });
      }

      // Run all analyses in parallel for speed
      const [domains, socialMedia, brandAnalysis] = await Promise.all([
        domainChecker.checkDomainAvailability(businessName, userPlan),
        socialMediaChecker.checkSocialMediaAvailability(businessName),
        brandAnalyzer.analyzeBrand(businessName, industry)
      ]);
      
      res.json({ 
        name: businessName,
        domains, 
        socialMedia, 
        brandAnalysis,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error in complete analysis:", error);
      res.status(500).json({ message: "Failed to complete name analysis" });
    }
  });

  // Security monitoring endpoint (admin only)
  app.get("/api/security/stats", async (req, res) => {
    try {
      const stats = securityMonitor.getSecurityStats();
      res.json({
        status: "secure",
        timestamp: new Date().toISOString(),
        stats
      });
    } catch (error) {
      console.error("Security stats error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Digital Products API Endpoints
  
  // Digital products endpoint already defined earlier in the file - this duplicate has been removed

  // Paddle integration - Zero-touch global payment processing
  app.post("/api/paddle-checkout", async (req, res) => {
    try {
      const { plan, customerEmail, customerName, country = "TT" } = req.body;
      
      // Paddle product IDs (set these up in Paddle dashboard)
      const paddleProducts = {
        premium: {
          productId: "pro_01hsxxxxxxxxxxx", // Replace with actual Paddle product ID
          price: "$9.99/month",
          checkoutUrl: "https://checkout.paddle.com/subscription/premium-findmybizname"
        },
        pro: {
          productId: "pro_01hsyyyyyyyyyyy", // Replace with actual Paddle product ID  
          price: "$19.99/month",
          checkoutUrl: "https://checkout.paddle.com/subscription/pro-findmybizname"
        }
      };

      const selectedPlan = paddleProducts[plan as keyof typeof paddleProducts];
      
      if (!selectedPlan) {
        return res.status(400).json({ message: "Invalid plan selected" });
      }

      // Paddle automatically handles:
      // - Global tax compliance (VAT, sales tax, GST)
      // - Currency conversion
      // - Payment processing
      // - Subscription management
      // - Refunds and disputes
      // - Legal compliance as merchant of record

      res.json({
        success: true,
        checkoutUrl: selectedPlan.checkoutUrl,
        productId: selectedPlan.productId,
        planDetails: {
          name: plan,
          price: selectedPlan.price,
          features: plan === 'premium' 
            ? ["Unlimited generations", "Premium domains", "PDF export"]
            : ["Everything in Premium", "Brand analysis", "Bulk features", "Priority support"]
        },
        globalCompliance: {
          taxHandling: "Automatic VAT, sales tax, GST",
          currencies: "200+ supported automatically", 
          legalProtection: "Paddle is merchant of record",
          payoutFrequency: "Monthly to your Trinidad & Tobago bank"
        },
        message: "Global compliance and zero manual work included"
      });

    } catch (error) {
      console.error("Paddle checkout error:", error);
      res.status(500).json({ message: "Checkout system unavailable" });
    }
  });

  // Paddle webhook for automatic user upgrades
  app.post("/api/paddle-webhook", async (req, res) => {
    try {
      const { alert_name, email, subscription_plan_id, status } = req.body;
      
      // Paddle sends webhooks for:
      // - subscription_created
      // - subscription_updated  
      // - subscription_cancelled
      // - payment_succeeded
      // - payment_failed

      if (alert_name === "subscription_created" && status === "active") {
        // Automatically upgrade user account
        console.log("PADDLE WEBHOOK - User upgraded:", {
          email,
          plan: subscription_plan_id,
          timestamp: new Date().toISOString(),
          automated: true
        });

        // Here you would automatically:
        // 1. Find user by email
        // 2. Upgrade their account to Premium/Pro
        // 3. Send welcome email
        // 4. Grant access to premium features
        
        res.json({ received: true });
      } else {
        res.json({ received: true, action: "no_action_needed" });
      }

    } catch (error) {
      console.error("Paddle webhook error:", error);
      res.status(400).json({ message: "Webhook processing failed" });
    }
  });

  // Cross-platform payment automation endpoint
  app.post("/api/payment-automation", async (req: Request, res: Response) => {
    try {
      const { 
        paymentMethod, 
        amount, 
        currency, 
        customerEmail, 
        customerName, 
        plan,
        country = "TT",
        phone
      } = req.body;

      // Generate unique order ID
      const orderId = `FMBN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      
      // Payment method configurations
      const paymentMethods = {
        paypal: {
          automated: false,
          contact: "gregorywalker760@gmail.com",
          instructions: `Send ${currency} ${amount} via PayPal to gregorywalker760@gmail.com with reference: ${orderId}`,
          expectedTime: "Instant confirmation"
        },
        wipay: {
          automated: false,
          contact: "+1 (868) 720-9758",
          instructions: `WhatsApp +1 (868) 326-1593 for WiPay payment. Reference: ${orderId}`,
          expectedTime: "Within 2 hours"
        },
        bank: {
          automated: false,
          contact: "gregorywalker760@gmail.com",
          instructions: `Email gregorywalker760@gmail.com for bank transfer details. Reference: ${orderId}`,
          expectedTime: "1-3 business days"
        },
        mobile: {
          automated: false,
          contact: "+1 (868) 720-9758",
          instructions: `WhatsApp +1 (868) 326-1593 for mobile money (Digicel/Flow). Reference: ${orderId}`,
          expectedTime: "Within 4 hours"
        },
        crypto: {
          automated: false,
          contact: "gregorywalker760@gmail.com",
          instructions: `Email gregorywalker760@gmail.com for cryptocurrency payment details. Reference: ${orderId}`,
          expectedTime: "Within 24 hours"
        },
        wise: {
          automated: false,
          contact: "gregorywalker760@gmail.com",
          instructions: `Request Wise payment details via email to gregorywalker760@gmail.com. Reference: ${orderId}`,
          expectedTime: "Within 2 hours",
          features: ["Personal account only", "Direct TT bank transfer", "Multi-currency support"]
        },
        onesafe: {
          automated: false,
          contact: "gregorywalker760@gmail.com", 
          instructions: `Email gregorywalker760@gmail.com for OneSafe payment processing. Reference: ${orderId}`,
          expectedTime: "Within 4 hours",
          features: ["Caribbean-focused", "Personal account", "Local customer service"]
        }
      };

      const selectedMethod = paymentMethods[paymentMethod as keyof typeof paymentMethods] || paymentMethods.bank;

      // Create automation notification for processing
      const automationData = {
        orderId,
        timestamp: new Date().toISOString(),
        customer: {
          name: customerName,
          email: customerEmail,
          phone: phone || "Not provided",
          country
        },
        order: {
          plan,
          amount,
          currency,
          paymentMethod
        },
        actions: [
          `Verify ${paymentMethod} payment received`,
          `Upgrade ${customerEmail} to ${plan} plan`,
          `Send confirmation email`,
          `Update billing records`,
          `Grant platform access`
        ]
      };

      // Log for manual processing (this would trigger automation workflows)
      console.log("PAYMENT AUTOMATION REQUEST:", JSON.stringify(automationData, null, 2));

      // Response with payment instructions
      res.json({
        success: true,
        orderId,
        paymentMethod: selectedMethod,
        automationStatus: "initiated",
        nextSteps: [
          "Complete payment using provided instructions",
          "Keep order reference for tracking",
          "Check email for confirmation within expected timeframe",
          "Contact support if payment not confirmed"
        ],
        support: {
          whatsapp: "+1 (868) 720-9758",
          email: "gregorywalker760@gmail.com",
          hours: "Monday-Friday 9AM-5PM AST"
        }
      });

    } catch (error) {
      console.error("Payment automation error:", error);
      res.status(500).json({ message: "Payment automation failed" });
    }
  });

  // Payment verification webhook (for automation tools like Zapier)
  app.post("/api/payment-verified", async (req, res) => {
    try {
      const { 
        orderId, 
        customerEmail, 
        plan, 
        amount, 
        paymentMethod,
        verificationSource 
      } = req.body;

      // In a real implementation, this would:
      // 1. Verify the payment was actually received
      // 2. Upgrade user account automatically
      // 3. Send confirmation emails
      // 4. Update billing systems

      console.log("PAYMENT VERIFIED - AUTO PROCESSING:", {
        orderId,
        customerEmail,
        plan,
        amount,
        paymentMethod,
        verificationSource,
        processedAt: new Date().toISOString()
      });

      // Simulate automated account upgrade
      const upgradeResult = {
        success: true,
        customerEmail,
        newPlan: plan,
        accessGranted: true,
        confirmationSent: true
      };

      res.json({
        message: "Payment verified and account upgraded automatically",
        result: upgradeResult
      });

    } catch (error) {
      console.error("Payment verification error:", error);
      res.status(500).json({ message: "Payment verification failed" });
    }
  });

  // Get user's purchased products
  app.get("/api/user/purchases", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const purchases = await storage.getUserPurchases(userId);
      
      // Enrich with product details
      const enrichedPurchases = await Promise.all(
        purchases.map(async (purchase) => {
          if (purchase.productId) {
            const product = await storage.getDigitalProduct(purchase.productId);
            return {
              ...purchase,
              product
            };
          }
          return purchase;
        })
      );
      
      res.json(enrichedPurchases);
    } catch (error) {
      console.error("Error fetching user purchases:", error);
      res.status(500).json({ message: "Failed to fetch purchases" });
    }
  });

  // Purchase a digital product
  app.post("/api/digital-products/:id/purchase", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const userId = 1; // Demo user ID
      const { paymentMethod, paymentId } = req.body;

      // Check if product exists
      const product = await storage.getDigitalProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }

      // Check if already purchased
      const existingPurchase = await storage.getPurchase(userId, productId);
      if (existingPurchase) {
        return res.status(400).json({ message: "Product already purchased" });
      }

      // Create purchase record
      const purchase = await storage.createPurchase(userId, {
        productId,
        purchasePrice: product.price,
        paymentMethod: paymentMethod || "demo",
        paymentId: paymentId || `demo_${Date.now()}`
      });

      res.json({
        message: "Purchase successful",
        purchase,
        downloadUrl: `/api/digital-products/${productId}/download?purchaseId=${purchase.id}`
      });
    } catch (error) {
      console.error("Error processing purchase:", error);
      res.status(500).json({ message: "Failed to process purchase" });
    }
  });

  // Download a purchased product
  app.get("/api/digital-products/:id/download", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const { purchaseId } = req.query;
      const userId = 1; // Demo user ID

      // Verify purchase
      const purchase = await storage.getPurchase(userId, productId);
      if (!purchase || purchase.id.toString() !== purchaseId) {
        return res.status(403).json({ message: "Access denied - purchase required" });
      }

      // Get product details
      const product = await storage.getDigitalProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }

      // Increment download count
      await storage.incrementDownloadCount(purchase.id);

      // For demo purposes, return sample file content
      const sampleContent = `# ${product.title}

This is a sample ${product.category} template from FindMyBizName.

## What's Included:
${product.description}

## File Details:
- Product: ${product.title}
- Category: ${product.category}
- Purchase Date: ${purchase.createdAt.toISOString()}
- Download Count: ${purchase.downloadCount + 1}

## Next Steps:
1. Customize this template for your business
2. Replace placeholder content with your information
3. Save and use for your business needs

---
Generated by FindMyBizName - The Stripe of Underbanked Entrepreneur Tools
`;

      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Content-Disposition', `attachment; filename="${product.fileName}"`);
      res.send(sampleContent);
    } catch (error) {
      console.error("Error downloading product:", error);
      res.status(500).json({ message: "Failed to download product" });
    }
  });

  // Business Intelligence API Routes
  
  // Search companies (SEC EDGAR database)
  app.get("/api/companies/search", async (req: Request, res: Response) => {
    try {
      const { query, country, industry, limit } = req.query;
      
      if (!query || typeof query !== 'string' || query.trim().length === 0) {
        return res.status(400).json({ 
          message: "Search query is required" 
        });
      }

      const searchParams = {
        query: query.trim(),
        country: country as string || 'US',
        industry: industry as string,
        limit: Math.min(parseInt(limit as string) || 20, 50)
      };

      // Validate with schema
      const validatedParams = companySearchRequestSchema.parse(searchParams);
      
      // Search companies using SEC EDGAR
      const companies = await secEdgarService.searchCompanies(
        validatedParams.query, 
        validatedParams.limit
      );

      // Log search activity
      console.log(`Company search: ${validatedParams.query}`);

      res.json({ 
        companies,
        total: companies.length,
        query: validatedParams.query,
        source: 'SEC EDGAR'
      });

    } catch (error) {
      console.error("Company search error:", error);
      res.status(500).json({ 
        message: "Failed to search companies",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Get trending/popular companies
  app.get("/api/companies/trending", async (req: Request, res: Response) => {
    try {
      const { limit } = req.query;
      const limitNum = Math.min(parseInt(limit as string) || 10, 20);

      const companies = await secEdgarService.getTrendingCompanies(limitNum);

      res.json({ 
        companies,
        total: companies.length,
        source: 'SEC EDGAR',
        type: 'trending'
      });

    } catch (error) {
      console.error("Trending companies error:", error);
      res.status(500).json({ 
        message: "Failed to fetch trending companies",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Get detailed company profile
  app.get("/api/companies/:cik", async (req: Request, res: Response) => {
    try {
      const { cik } = req.params;
      
      if (!cik || !/^\d{1,10}$/.test(cik)) {
        return res.status(400).json({ 
          message: "Valid CIK number is required" 
        });
      }

      const company = await secEdgarService.getCompanyProfile(cik);
      
      if (!company) {
        return res.status(404).json({ 
          message: "Company not found" 
        });
      }

      res.json({ 
        company,
        source: 'SEC EDGAR'
      });

    } catch (error) {
      console.error("Company profile error:", error);
      res.status(500).json({ 
        message: "Failed to fetch company profile",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Coinbase Commerce crypto payment endpoints
  app.post("/api/payments/crypto/create", createCryptoPayment);
  app.get("/api/payments/crypto/verify/:chargeId", verifyCryptoPayment);
  app.post("/api/webhooks/coinbase", handleCoinbaseWebhook);

  // GoDaddy API endpoints
  app.get("/api/godaddy/status", getGoDaddyStatus);
  app.get("/api/godaddy/test", testGoDaddyConnection);
  app.post("/api/godaddy/check-domains", checkGoDaddyDomains);
  
  // Community Chat WebSocket Server managed by separate service

  // Initialize demo data endpoint
  app.post("/api/init-demo", async (req, res) => {
    try {
      // Create demo user
      let demoUser = await storage.getUserByEmail("demo@example.com");
      
      if (!demoUser) {
        demoUser = await storage.createUser({
          username: "demo_user",
          email: "demo@example.com"
        });
      }

      // Create demo profile
      let demoProfile = await storage.getUserProfile(demoUser.id);
      
      if (!demoProfile) {
        await storage.createUserProfile({
          userId: demoUser.id,
          displayName: "MrBizWhiz",
          bio: "Caribbean entrepreneur building the next big thing! 🌴",
          businessStage: "idea",
          industry: "technology", 
          location: "Trinidad & Tobago",
          website: "https://findmybizname.com",
          linkedinUrl: "https://linkedin.com/in/mrbizwhiz",
          interests: ["AI", "Caribbean Business", "Startup Growth"]
        });
      }

      res.json({ message: "Demo data initialized", user: demoUser });
    } catch (error) {
      console.error("Demo initialization error:", error);
      res.status(500).json({ message: "Failed to initialize demo data" });
    }
  });

  // Referral system endpoints
  app.post("/api/referral/create-code", async (req: Request, res: Response) => {
    try {
      // Get the actual demo user ID
      const demoUser = await storage.getUserByEmail("demo@example.com");
      if (!demoUser) {
        return res.status(404).json({ message: "Demo user not found. Please initialize demo data first." });
      }
      const userId = demoUser.id;
      
      // Check if user already has a code
      let referralCode = await storage.getReferralCode(userId);
      
      if (!referralCode) {
        referralCode = await storage.createReferralCode(userId);
      }
      
      res.json(referralCode);
    } catch (error) {
      console.error("Create referral code error:", error);
      res.status(500).json({ message: "Failed to create referral code" });
    }
  });

  app.get("/api/referral/stats/:userId", async (req: Request, res: Response) => {
    try {
      // Use actual demo user ID if userId is 1
      let userId = parseInt(req.params.userId);
      if (userId === 1) {
        const demoUser = await storage.getUserByEmail("demo@example.com");
        if (demoUser) {
          userId = demoUser.id;
        }
      }
      
      const stats = await storage.getReferralStats(userId);
      const referrals = await storage.getReferralsByUser(userId);
      const payouts = await storage.getUserPayouts(userId);
      
      res.json({
        stats: stats || {
          totalReferrals: 0,
          convertedReferrals: 0,
          totalCommissions: "0",
          pendingCommissions: "0",
          paidCommissions: "0",
          currency: "USD"
        },
        referrals,
        payouts
      });
    } catch (error) {
      console.error("Get referral stats error:", error);
      res.status(500).json({ message: "Failed to get referral stats" });
    }
  });

  app.post("/api/referral/track", async (req: Request, res: Response) => {
    try {
      const { referralCode, newUserEmail } = req.body;
      
      // Find referral code
      const code = await storage.getReferralCodeByCode(referralCode);
      
      if (!code) {
        return res.status(404).json({ message: "Invalid referral code" });
      }
      
      // Create user (for now we'll simulate this)
      const newUser = await storage.createUser({
        username: newUserEmail.split('@')[0],
        email: newUserEmail
      });
      
      // Create referral record
      const referral = await storage.createReferral({
        referrerId: code.userId,
        refereeId: newUser.id,
        referralCode: code.code,
        status: "pending"
      });
      
      // Update stats
      await storage.updateReferralStats(code.userId, {
        totalReferrals: 1
      });
      
      res.json({ referral, message: "Referral tracked successfully" });
    } catch (error) {
      console.error("Track referral error:", error);
      res.status(500).json({ message: "Failed to track referral" });
    }
  });

  app.post("/api/referral/convert", async (req: Request, res: Response) => {
    try {
      const { referralId, plan, amount } = req.body;
      
      // Calculate commission (30%)
      const commissionAmount = parseFloat(amount) * 0.30;
      
      // Update referral status
      await storage.updateReferralStatus(
        referralId, 
        "converted", 
        new Date(), 
        commissionAmount
      );
      
      // Get referral to find referrer
      const referrals = Array.from((storage as any).referrals?.values() || []);
      const referral = referrals.find((r: any) => r.id === referralId);
      
      if (referral) {
        // Update referrer stats
        const typedReferral = referral as any;
        const currentStats = await storage.getReferralStats(typedReferral.referrerId);
        await storage.updateReferralStats(typedReferral.referrerId, {
          convertedReferrals: (currentStats?.convertedReferrals || 0) + 1,
          pendingCommissions: ((parseFloat(currentStats?.pendingCommissions || "0")) + commissionAmount).toString(),
          totalCommissions: ((parseFloat(currentStats?.totalCommissions || "0")) + commissionAmount).toString()
        });
      }
      
      res.json({ message: "Referral converted successfully", commission: commissionAmount });
    } catch (error) {
      console.error("Convert referral error:", error);
      res.status(500).json({ message: "Failed to convert referral" });
    }
  });

  // Payment automation endpoints
  app.post("/api/payment-automation", async (req: Request, res: Response) => {
    try {
      const { transactionId, userEmail, amount, currency, subscriptionPlan, paymentMethod, referralCode } = req.body;
      
      if (!transactionId || !userEmail || !amount || !subscriptionPlan || !paymentMethod) {
        return res.status(400).json({ message: "Missing required payment data" });
      }

      // Find or create user
      let user = await storage.getUserByEmail(userEmail);
      
      if (!user) {
        const username = userEmail.split('@')[0] + '_' + Date.now().toString().slice(-4);
        user = await storage.createUser({
          username,
          email: userEmail
        });
        console.log("Payment automation - Created new user:", user.id);
      } else {
        // Note: plan property not available in schema
        console.log("Plan update requested:", subscriptionPlan);
        console.log("Payment automation - Upgraded user:", user.id, "to", subscriptionPlan);
      }

      // Record transaction
      const transaction = await db.insert(transactions).values({
        userId: user.id,
        transactionId,
        amount: amount.toString(),
        currency: currency || "USD",
        paymentMethod,
        subscriptionPlan,
        referralCode,
        status: "completed"
      }).returning();

      // Process referral commission
      let commissionGenerated = 0;
      let referralProcessed = false;

      if (referralCode) {
        try {
          const [codeData] = await db.select().from(referralCodes)
            .where(eq(referralCodes.code, referralCode));
          
          if (codeData) {
            commissionGenerated = parseFloat(amount) * 0.30; // 30% commission
            
            const [referral] = await db.insert(referrals).values({
              referrerId: codeData.userId,
              refereeId: user.id,
              referralCode: referralCode,
              status: "converted",
              conversionDate: new Date(),
              commissionAmount: commissionGenerated.toString()
            }).returning();

            // Update referral stats
            const stats = await storage.getReferralStats(codeData.userId);
            await storage.updateReferralStats(codeData.userId, {
              totalReferrals: (stats?.totalReferrals || 0) + 1,
              convertedReferrals: (stats?.convertedReferrals || 0) + 1,
              totalCommissions: ((parseFloat(stats?.totalCommissions || "0")) + commissionGenerated).toFixed(2),
              pendingCommissions: ((parseFloat(stats?.pendingCommissions || "0")) + commissionGenerated).toFixed(2),
            });
            
            referralProcessed = true;
            console.log("Payment automation - Referral processed:", referralCode, "Commission:", commissionGenerated);
          }
        } catch (referralError) {
          console.error("Payment automation - Referral error:", referralError);
        }
      }

      res.json({
        success: true,
        message: "Payment processed and account upgraded",
        userId: user.id,
        upgradeApplied: true,
        referralProcessed,
        commissionGenerated,
        transactionId: transaction[0].id
      });

    } catch (error) {
      console.error("Payment automation error:", error);
      res.status(500).json({ message: "Payment automation failed", error: (error as Error).message });
    }
  });

  // AI Template Generation API Routes
  
  // Initialize AI template system on startup
  await aiTemplateGenerator.initializeCategories();
  await aiTemplateGenerator.initializeTemplates();
  await saasToolEngine.initializeTools();

  // Get template categories
  app.get("/api/templates/categories", async (req, res) => {
    try {
      const categories = await aiTemplateGenerator.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching template categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Get templates by category
  app.get("/api/templates", async (req, res) => {
    try {
      const { categoryId } = req.query;
      const templates = await aiTemplateGenerator.getTemplatesByCategory(
        categoryId ? parseInt(categoryId as string) : undefined
      );
      res.json(templates);
    } catch (error) {
      console.error("Error fetching templates:", error);
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  // Generate a template
  app.post("/api/templates/:id/generate", async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const userId = 1; // Demo user ID
      const { inputs } = req.body;

      if (!inputs || typeof inputs !== 'object') {
        return res.status(400).json({ message: "Template inputs are required" });
      }

      const generated = await aiTemplateGenerator.generateTemplate(templateId, userId, inputs);
      res.json(generated);
    } catch (error) {
      console.error("Error generating template:", error);
      res.status(500).json({ 
        message: "Failed to generate template",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Get user's generated templates
  app.get("/api/templates/generated", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const { limit } = req.query;
      
      const templates = await aiTemplateGenerator.getUserTemplates(
        userId, 
        limit ? parseInt(limit as string) : 50
      );
      res.json(templates);
    } catch (error) {
      console.error("Error fetching user templates:", error);
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  // Rate a generated template
  app.post("/api/templates/generated/:id/rate", async (req, res) => {
    try {
      const generatedId = parseInt(req.params.id);
      const userId = 1; // Demo user ID
      const { rating, feedback } = req.body;

      if (!rating || rating < 1 || rating > 5) {
        return res.status(400).json({ message: "Rating must be between 1 and 5" });
      }

      await aiTemplateGenerator.rateTemplate(generatedId, userId, rating, feedback);
      res.json({ message: "Rating submitted successfully" });
    } catch (error) {
      console.error("Error rating template:", error);
      res.status(500).json({ message: "Failed to submit rating" });
    }
  });

  // SaaS Tools API Routes

  // Get available SaaS tools
  app.get("/api/saas-tools", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const user = await storage.getUser(userId);
      const userPlan = user?.plan || 'freemium';
      
      const { category } = req.query;
      
      const tools = category 
        ? await saasToolEngine.getToolsByCategory(category as string, userPlan)
        : await saasToolEngine.getAvailableTools(userPlan);
        
      res.json(tools);
    } catch (error) {
      console.error("Error fetching SaaS tools:", error);
      res.status(500).json({ message: "Failed to fetch tools" });
    }
  });

  // Execute a SaaS tool
  app.post("/api/saas-tools/:id/execute", async (req, res) => {
    try {
      const toolId = parseInt(req.params.id);
      const userId = 1; // Demo user ID
      const { inputs } = req.body;

      if (!inputs || typeof inputs !== 'object') {
        return res.status(400).json({ message: "Tool inputs are required" });
      }

      const result = await saasToolEngine.executeTool(toolId, userId, inputs);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("Error executing SaaS tool:", error);
      res.status(500).json({ 
        message: "Failed to execute tool",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Get user's tool usage history
  app.get("/api/saas-tools/usage", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const { limit } = req.query;
      
      const usage = await saasToolEngine.getUserToolUsage(
        userId, 
        limit ? parseInt(limit as string) : 50
      );
      res.json(usage);
    } catch (error) {
      console.error("Error fetching tool usage:", error);
      res.status(500).json({ message: "Failed to fetch usage history" });
    }
  });

  // Rate a tool execution
  app.post("/api/saas-tools/usage/:id/rate", async (req, res) => {
    try {
      const usageId = parseInt(req.params.id);
      const userId = 1; // Demo user ID
      const { rating, feedback } = req.body;

      if (!rating || rating < 1 || rating > 5) {
        return res.status(400).json({ message: "Rating must be between 1 and 5" });
      }

      await saasToolEngine.rateTool(usageId, userId, rating, feedback);
      res.json({ message: "Rating submitted successfully" });
    } catch (error) {
      console.error("Error rating tool:", error);
      res.status(500).json({ message: "Failed to submit rating" });
    }
  });

  // News API routes for Biz Newz - Using FREE RSS feeds ($0/month vs $449/month News API)
  app.get("/api/news/categories", async (req, res) => {
    try {
      const categories = newsService.getNewsCategories();
      
      // Get article counts for each category
      const articles = await newsService.getNewsArticles();
      const categoryCounts = articles.reduce((acc: Record<string, number>, article) => {
        acc[article.category] = (acc[article.category] || 0) + 1;
        return acc;
      }, {});
      
      // Update category counts
      const categoriesWithCounts = categories.map(category => ({
        ...category,
        count: categoryCounts[category.id] || 0
      }));
      
      res.json(categoriesWithCounts);
    } catch (error) {
      console.error("Error fetching news categories:", error);
      res.status(500).json({ message: "Failed to fetch news categories" });
    }
  });

  app.get("/api/news/articles", async (req, res) => {
    try {
      const { category, region, search } = req.query;
      
      // Get REAL news articles from FREE RSS feeds
      let articles = await newsService.getNewsArticles();
      
      // Apply filters if provided
      if (category && category !== 'all') {
        articles = articles.filter(article => article.category === category);
      }
      
      if (region && region !== 'all') {
        articles = articles.filter(article => article.region === region);
      }
      
      if (search) {
        const searchLower = (search as string).toLowerCase();
        articles = articles.filter(article => 
          article.title.toLowerCase().includes(searchLower) ||
          article.summary.toLowerCase().includes(searchLower) ||
          article.tags.some((tag: string) => tag.toLowerCase().includes(searchLower))
        );
      }

      res.json(articles);
    } catch (error) {
      console.error("Error fetching news articles:", error);
      res.status(500).json({ message: "Failed to fetch news articles" });
    }
  });

  app.get("/api/news/trending", async (req, res) => {
    try {
      // Get REAL trending topics from RSS feed analysis
      const trendingTopics = await newsService.getTrendingTopics();
      res.json(trendingTopics);
    } catch (error) {
      console.error("Error fetching trending topics:", error);
      res.status(500).json({ message: "Failed to fetch trending topics" });
    }
  });

  // Support Bot API routes for Biz Botz
  app.get("/api/support-bots", async (req, res) => {
    try {
      const supportBots = [
        {
          id: "bizgenie",
          name: "BizGenie",
          description: "Expert in business planning, strategy, and startup guidance. Specializes in helping entrepreneurs develop comprehensive business plans and strategic roadmaps.",
          specialty: "Business Strategy & Planning",
          avatar: "/avatars/bizgenie.png",
          status: "online",
          responseTime: "< 15s",
          accuracy: 94,
          totalChats: 1247,
          languages: ["English", "Spanish", "French"],
        },
        {
          id: "fundingfinder", 
          name: "FundingFinder",
          description: "Specializes in funding opportunities, grant applications, and investment strategies. Helps entrepreneurs navigate the complex world of business financing.",
          specialty: "Funding & Investment",
          avatar: "/avatars/fundingfinder.png",
          status: "online",
          responseTime: "< 20s",
          accuracy: 91,
          totalChats: 892,
          languages: ["English", "Portuguese"],
        },
        {
          id: "legaladviser",
          name: "LegalAdviser",
          description: "Provides guidance on business legal matters, contracts, intellectual property, and regulatory compliance for entrepreneurs and small businesses.",
          specialty: "Legal & Compliance",
          avatar: "/avatars/legaladviser.png", 
          status: "online",
          responseTime: "< 25s",
          accuracy: 89,
          totalChats: 654,
          languages: ["English", "Spanish"],
        },
        {
          id: "marketingmaven",
          name: "MarketingMaven",
          description: "Expert in digital marketing, brand building, and customer acquisition strategies. Helps businesses grow their online presence and reach target audiences.",
          specialty: "Marketing & Branding",
          avatar: "/avatars/marketingmaven.png",
          status: "busy",
          responseTime: "< 30s", 
          accuracy: 87,
          totalChats: 1156,
          languages: ["English", "French", "Creole"],
        },
        {
          id: "techsupport",
          name: "TechSupport",
          description: "Assists with technical questions, software recommendations, digital transformation, and technology implementation for small businesses.",
          specialty: "Technology & Software",
          avatar: "/avatars/techsupport.png",
          status: "online",
          responseTime: "< 10s",
          accuracy: 96,
          totalChats: 2103,
          languages: ["English", "Spanish", "Hindi"],
        },
        {
          id: "caribbeanexpert",
          name: "CaribbeanExpert", 
          description: "Specialized knowledge of Caribbean business environments, local regulations, cultural considerations, and regional market opportunities.",
          specialty: "Caribbean Business Culture",
          avatar: "/avatars/caribbeanexpert.png",
          status: "online",
          responseTime: "< 20s",
          accuracy: 93,
          totalChats: 445,
          languages: ["English", "Spanish", "French", "Creole"],
        }
      ];
      
      res.json(supportBots);
    } catch (error) {
      console.error("Error fetching support bots:", error);
      res.status(500).json({ message: "Failed to fetch support bots" });
    }
  });

  app.get("/api/chat-sessions", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      
      // Sample chat sessions for demo
      const sessions = [
        {
          id: "session-1",
          botId: "bizgenie",
          status: "resolved",
          startTime: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          lastMessage: "Thank you for the business plan guidance!",
          messageCount: 12,
          rating: 5,
        },
        {
          id: "session-2", 
          botId: "fundingfinder",
          status: "active",
          startTime: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          lastMessage: "What about micro-loans for Caribbean startups?",
          messageCount: 8,
        },
        {
          id: "session-3",
          botId: "marketingmaven", 
          status: "resolved",
          startTime: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
          lastMessage: "The social media strategy worked perfectly!",
          messageCount: 15,
          rating: 4,
        }
      ];
      
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching chat sessions:", error);
      res.status(500).json({ message: "Failed to fetch chat sessions" });
    }
  });

  app.get("/api/chat-messages/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      // Sample messages for demo
      const messages = [
        {
          id: "msg-1",
          type: "user",
          content: "I need help creating a business plan for my tech startup",
          timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
          sessionId,
        },
        {
          id: "msg-2",
          type: "bot", 
          content: "I'd be happy to help you create a comprehensive business plan! Let's start with the basics. What's your startup idea and what problem does it solve?",
          timestamp: new Date(Date.now() - 59 * 60 * 1000).toISOString(),
          sessionId,
          botId: "bizgenie",
          metadata: {
            confidence: 0.95,
            suggestedActions: ["Tell me about your target market", "What's your revenue model?", "Who are your main competitors?"]
          }
        }
      ];
      
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/support-bots/chat", async (req, res) => {
    try {
      const { botId, message, sessionId } = req.body;
      const userId = 1; // Demo user ID
      
      // Generate session ID if not provided
      const currentSessionId = sessionId || `session-${Date.now()}`;
      
      // Simulate AI response based on bot type
      let botResponse = "";
      let confidence = 0.85;
      let suggestedActions: string[] = [];
      
      switch (botId) {
        case "bizgenie":
          botResponse = `Great question about business planning! Based on your message about "${message.substring(0, 50)}...", I recommend focusing on market validation first. A solid business plan should include: executive summary, market analysis, competitive landscape, financial projections, and operational strategy. Would you like me to help you develop any specific section?`;
          suggestedActions = ["Help with market analysis", "Create financial projections", "Develop competitive strategy"];
          confidence = 0.92;
          break;
          
        case "fundingfinder":
          botResponse = `Regarding funding opportunities for your business, there are several paths to explore: traditional bank loans, government grants (especially for Caribbean businesses), angel investors, venture capital, and crowdfunding. For underbanked entrepreneurs, I particularly recommend looking into microfinance options and government-backed loan programs. What's your current stage and funding requirements?`;
          suggestedActions = ["Show me grant opportunities", "Explain angel investor process", "Help with loan applications"];
          confidence = 0.89;
          break;
          
        case "legaladviser":
          botResponse = `From a legal perspective, it's important to address business structure, contracts, intellectual property protection, and regulatory compliance early. For Caribbean businesses, you'll need to consider local incorporation requirements, tax obligations, and any industry-specific regulations. What specific legal aspect would you like guidance on?`;
          suggestedActions = ["Business registration process", "Contract templates", "IP protection guidance"];
          confidence = 0.87;
          break;
          
        case "marketingmaven":
          botResponse = `Excellent marketing question! For effective brand building and customer acquisition, focus on understanding your target audience, developing compelling messaging, and choosing the right channels. Digital marketing is particularly powerful for Caribbean businesses looking to expand regionally or globally. Social media, content marketing, and local partnerships are key strategies. What's your target market?`;
          suggestedActions = ["Create social media strategy", "Develop brand messaging", "Plan content calendar"];
          confidence = 0.91;
          break;
          
        case "techsupport":
          botResponse = `For your technology needs, I can help you choose the right tools and platforms for your business. Consider cloud-based solutions for scalability, automation tools for efficiency, and mobile-friendly platforms for the Caribbean market. What specific technical challenges are you facing?`;
          suggestedActions = ["Recommend business software", "Set up automation", "Mobile app guidance"];
          confidence = 0.94;
          break;
          
        case "caribbeanexpert":
          botResponse = `As a Caribbean business expert, I understand the unique opportunities and challenges in our region. The Caribbean market offers great potential for entrepreneurs who understand local culture, payment preferences, and business practices. Regional integration, tourism connections, and diaspora markets are key advantages. How can I help you navigate the Caribbean business landscape?`;
          suggestedActions = ["Explore regional markets", "Understand local regulations", "Connect with diaspora"];
          confidence = 0.90;
          break;
          
        default:
          botResponse = "Thank you for your message. I'm here to help with your business questions. Could you provide more specific details about what you'd like assistance with?";
          suggestedActions = ["Ask a specific question", "Tell me about your business", "Get started with planning"];
      }
      
      // Simulate response delay
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
      
      res.json({
        sessionId: currentSessionId,
        response: botResponse,
        metadata: {
          confidence,
          suggestedActions,
          botModel: "gpt-4",
          responseTime: Math.floor(1000 + Math.random() * 2000)
        }
      });
    } catch (error) {
      console.error("Error in bot chat:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  app.post("/api/chat-sessions/:sessionId/rate", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const { rating, feedback } = req.body;
      
      // In a real implementation, save to database
      console.log(`Session ${sessionId} rated ${rating} stars with feedback: ${feedback}`);
      
      res.json({ message: "Rating submitted successfully" });
    } catch (error) {
      console.error("Error rating session:", error);
      res.status(500).json({ message: "Failed to submit rating" });
    }
  });

  // Digital Wallet API Endpoints
  
  // Create or get user wallet
  app.post("/api/wallet/create", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const { walletType = "personal" } = req.body;

      // Check if wallet already exists
      let wallet = await storage.getUserWallet(userId, walletType);
      
      if (!wallet) {
        wallet = await storage.createWallet(userId, walletType);
      }

      res.json({
        message: "Wallet ready",
        wallet
      });
    } catch (error) {
      console.error("Error creating wallet:", error);
      res.status(500).json({ message: "Failed to create wallet" });
    }
  });

  // Get user wallet details
  app.get("/api/wallet", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const { walletType = "personal" } = req.query;

      let wallet = await storage.getUserWallet(userId, walletType as string);
      
      if (!wallet) {
        // Auto-create wallet if it doesn't exist
        wallet = await storage.createWallet(userId, walletType as string);
      }

      res.json(wallet);
    } catch (error) {
      console.error("Error fetching wallet:", error);
      res.status(500).json({ message: "Failed to fetch wallet" });
    }
  });

  // Add funds to wallet (credit transaction)
  app.post("/api/wallet/add-funds", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const { amount, description, sourceType = "deposit" } = req.body;

      // Get user's primary wallet
      let wallet = await storage.getUserWallet(userId, "personal");
      
      if (!wallet) {
        wallet = await storage.createWallet(userId, "personal");
      }

      const transaction = await storage.addWalletTransaction(wallet.id, {
        transactionType: 'credit',
        amount: amount.toString(),
        currency: 'USD',
        description: description || 'Funds added to wallet',
        sourceType,
        status: 'completed'
      });

      res.json({
        message: "Funds added successfully",
        transaction,
        newBalance: transaction.balanceAfter
      });
    } catch (error) {
      console.error("Error adding funds:", error);
      res.status(500).json({ message: "Failed to add funds" });
    }
  });

  // Get wallet transactions
  app.get("/api/wallet/transactions", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const { limit = 50 } = req.query;

      const wallet = await storage.getUserWallet(userId, "personal");
      
      if (!wallet) {
        return res.json([]);
      }

      const transactions = await storage.getWalletTransactions(wallet.id, parseInt(limit as string));
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Create withdrawal request
  app.post("/api/wallet/withdraw", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const { amount, withdrawalMethod, withdrawalDetails } = req.body;

      const wallet = await storage.getUserWallet(userId, "personal");
      
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" });
      }

      // Check balance
      const currentBalance = parseFloat(wallet.balance || "0");
      const withdrawalAmount = parseFloat(amount);
      
      if (currentBalance < withdrawalAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      const withdrawal = await storage.createWithdrawal(wallet.id, {
        amount: amount.toString(),
        currency: 'USD',
        withdrawalMethod,
        withdrawalDetails,
        transactionFee: "2.50" // $2.50 standard fee
      });

      res.json({
        message: "Withdrawal request created",
        withdrawal
      });
    } catch (error) {
      console.error("Error creating withdrawal:", error);
      res.status(500).json({ message: "Failed to create withdrawal" });
    }
  });

  // Get user withdrawals
  app.get("/api/wallet/withdrawals", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const withdrawals = await storage.getUserWithdrawals(userId);
      res.json(withdrawals);
    } catch (error) {
      console.error("Error fetching withdrawals:", error);
      res.status(500).json({ message: "Failed to fetch withdrawals" });
    }
  });

  // Get user deposits (filtered from transactions)
  app.get("/api/wallet/deposits", async (req, res) => {
    try {
      const userId = 1; // Demo user ID
      const { limit = 50 } = req.query;

      const wallet = await storage.getUserWallet(userId, "personal");
      
      if (!wallet) {
        return res.json([]);
      }

      const transactions = await storage.getWalletTransactions(wallet.id, parseInt(limit as string));
      // Filter only credit transactions (deposits)
      const deposits = transactions.filter(t => t.transactionType === 'credit');
      res.json(deposits);
    } catch (error) {
      console.error("Error fetching deposits:", error);
      res.status(500).json({ message: "Failed to fetch deposits" });
    }
  });

  // API Service Status endpoints
  app.get("/api/services/status", async (req, res) => {
    res.json({
      bizBotz: bizBotzService.isActive(),
      email: emailService.getConfigurationStatus(),
      sms: smsService.getConfigurationStatus(),
      bizBuzz: globalBizBuzzChat?.getConnectedUsersCount() || 0,
      coinbase: !!process.env.COINBASE_COMMERCE_API_KEY,
      domainr: !!process.env.RAPIDAPI_KEY
    });
  });

  // Biz Botz AI Support endpoints
  app.post("/api/biz-botz/support", async (req, res) => {
    const { message, context } = req.body;
    
    if (!message) {
      return res.status(400).json({ error: "Message is required" });
    }

    try {
      const response = await bizBotzService.provideBizBotzSupport(message, context);
      res.json({ response });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/biz-botz/analyze-name", async (req, res) => {
    const { name } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: "Business name is required" });
    }

    try {
      const analysis = await bizBotzService.analyzeBusinessName(name);
      res.json(analysis);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Enhanced name generation with OpenAI
  app.post("/api/generate-enhanced-names", async (req, res) => {
    const { keywords, industry } = req.body;
    
    if (!keywords || !Array.isArray(keywords)) {
      return res.status(400).json({ error: "Keywords array is required" });
    }

    try {
      const names = await bizBotzService.generateBusinessName(keywords, industry);
      res.json({ names });
    } catch (error: any) {
      // Fallback to regular name generator if OpenAI fails
      console.log("Falling back to regular name generation:", error.message);
      const fallbackNames = nameGenerator.generateNames(keywords[0] || "business");
      res.json({ names: fallbackNames });
    }
  });

  // Email service endpoints
  app.post("/api/email/welcome", async (req, res) => {
    const { email, name } = req.body;
    
    if (!email || !name) {
      return res.status(400).json({ error: "Email and name are required" });
    }

    try {
      const success = await emailService.sendWelcomeEmail(email, name);
      res.json({ success });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/email/subscription", async (req, res) => {
    const { email, planName, amount } = req.body;
    
    if (!email || !planName || !amount) {
      return res.status(400).json({ error: "Email, planName, and amount are required" });
    }

    try {
      const success = await emailService.sendSubscriptionConfirmation(email, planName, amount);
      res.json({ success });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // SMS service endpoints  
  app.post("/api/sms/welcome", async (req, res) => {
    const { phone, name } = req.body;
    
    if (!phone || !name) {
      return res.status(400).json({ error: "Phone and name are required" });
    }

    try {
      const success = await smsService.sendWelcomeSMS(phone, name);
      res.json({ success });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/sms/payment-confirmation", async (req, res) => {
    const { phone, amount, method } = req.body;
    
    if (!phone || !amount || !method) {
      return res.status(400).json({ error: "Phone, amount, and method are required" });
    }

    try {
      const success = await smsService.sendPaymentConfirmation(phone, amount, method);
      res.json({ success });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Chat room info endpoints
  app.get("/api/biz-buzz/users", async (req, res) => {
    const { room = 'general' } = req.query;
    const users = globalBizBuzzChat?.getRoomUsers(room as string) || [];
    res.json({ users, count: users.length });
  });

  app.get("/api/biz-buzz/stats", async (req, res) => {
    res.json({ 
      totalUsers: globalBizBuzzChat?.getConnectedUsersCount() || 0,
      generalRoom: globalBizBuzzChat?.getRoomUsers('general').length || 0
    });
  });

  // Legal pages required by Paddle payment processor
  app.get('/terms', (req, res) => {
    res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms and Conditions - FindMyBizName</title>
    <meta name="description" content="Terms and conditions for FindMyBizName - Complete Business Operating System for Underbanked Entrepreneurs">
    <style>
        body { font-family: 'Segoe UI', system-ui, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; line-height: 1.6; color: #333; }
        h1, h2 { color: #0040FF; }
        .header { text-align: center; margin-bottom: 40px; padding: 20px; background: linear-gradient(135deg, #0040FF, #FF2D2D); color: white; border-radius: 10px; }
        .section { margin-bottom: 30px; padding: 20px; border-left: 4px solid #0040FF; background: #f9f9f9; }
        .effective-date { background: #FFDD00; color: #000; padding: 10px; border-radius: 5px; text-align: center; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h1>FindMyBizName Terms and Conditions</h1>
        <p>Complete Business Operating System for Underbanked Entrepreneurs</p>
    </div>
    
    <div class="effective-date">Effective Date: August 8, 2025</div>
    
    <div class="section">
        <h2>1. Service Description</h2>
        <p>FindMyBizName provides a comprehensive business operating system specifically designed for underbanked entrepreneurs worldwide. Our platform includes:</p>
        <ul>
            <li>AI-powered business name generation with domain availability checking</li>
            <li>Customer Relationship Management (CRM) tools</li>
            <li>Professional invoicing and payment processing</li>
            <li>Business intelligence and analytics</li>
            <li>Alternative payment solutions optimized for cash-based economies</li>
            <li>Global referral program with 30% recurring commissions</li>
            <li>Digital product marketplace</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>2. Subscription Plans and Pricing</h2>
        <p><strong>Starter Plan:</strong> $9.99/month - 50 name generations/day, domain checking, basic CRM, 5 invoices/month</p>
        <p><strong>Professional Plan:</strong> $29.99/month - Unlimited name generation, advanced CRM, unlimited invoicing, referral system access</p>
        <p><strong>Enterprise Plan:</strong> $149/month - White-label platform, API access, custom integrations, priority support</p>
        <p>All prices are in USD and billed monthly. Launch promotion: First month includes 20 free generations for new users.</p>
    </div>
    
    <div class="section">
        <h2>3. Payment and Billing</h2>
        <p>We accept multiple payment methods including:</p>
        <ul>
            <li>Cryptocurrency payments (Bitcoin, Ethereum, USDC, DAI) via Coinbase Commerce at 1% fees</li>
            <li>PayPal and traditional payment processors</li>
            <li>WiPay for Caribbean markets</li>
            <li>Paddle for global subscription billing</li>
        </ul>
        <p>Subscriptions automatically renew monthly unless cancelled. You may cancel at any time through your account settings.</p>
    </div>
    
    <div class="section">
        <h2>4. User Responsibilities</h2>
        <p>Users agree to:</p>
        <ul>
            <li>Provide accurate information during registration</li>
            <li>Use the service for legitimate business purposes only</li>
            <li>Not abuse or overload our systems</li>
            <li>Respect intellectual property rights</li>
            <li>Comply with all applicable laws and regulations</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>5. Intellectual Property</h2>
        <p>Users retain ownership of business names they create. FindMyBizName retains ownership of the platform, algorithms, and generated suggestions. Domain availability information is provided as-is and subject to real-time changes.</p>
    </div>
    
    <div class="section">
        <h2>6. Privacy and Data Protection</h2>
        <p>We are committed to protecting user privacy. See our <a href="/privacy" style="color: #0040FF;">Privacy Policy</a> for detailed information about data collection, use, and protection practices.</p>
    </div>
    
    <div class="section">
        <h2>7. Service Availability</h2>
        <p>We strive for 99.9% uptime but cannot guarantee uninterrupted service. Maintenance windows will be announced in advance when possible.</p>
    </div>
    
    <div class="section">
        <h2>8. Limitation of Liability</h2>
        <p>FindMyBizName is provided "as is" without warranties. We are not liable for any business decisions made based on our suggestions or for domain registration failures by third parties.</p>
    </div>
    
    <div class="section">
        <h2>9. Termination</h2>
        <p>Either party may terminate the service agreement at any time. Upon termination, access to paid features will cease, but generated business names and data may be exported during a 30-day grace period.</p>
    </div>
    
    <div class="section">
        <h2>10. Contact Information</h2>
        <p>For questions about these terms, contact us through our platform or email support.</p>
    </div>
    
    <div style="text-align: center; margin-top: 40px; padding: 20px; background: #f0f0f0; border-radius: 5px;">
        <p><a href="/" style="color: #0040FF; text-decoration: none; font-weight: bold;">← Return to FindMyBizName Platform</a></p>
    </div>
</body>
</html>
    `);
  });
  
  app.get('/privacy', (req, res) => {
    res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - FindMyBizName</title>
    <meta name="description" content="Privacy policy for FindMyBizName - Complete Business Operating System for Underbanked Entrepreneurs">
    <style>
        body { font-family: 'Segoe UI', system-ui, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; line-height: 1.6; color: #333; }
        h1, h2 { color: #0040FF; }
        .header { text-align: center; margin-bottom: 40px; padding: 20px; background: linear-gradient(135deg, #0040FF, #FF2D2D); color: white; border-radius: 10px; }
        .section { margin-bottom: 30px; padding: 20px; border-left: 4px solid #0040FF; background: #f9f9f9; }
        .effective-date { background: #FFDD00; color: #000; padding: 10px; border-radius: 5px; text-align: center; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h1>FindMyBizName Privacy Policy</h1>
        <p>Complete Business Operating System for Underbanked Entrepreneurs</p>
    </div>
    
    <div class="effective-date">Effective Date: August 8, 2025</div>
    
    <div class="section">
        <h2>1. Information We Collect</h2>
        <p>We collect information to provide better services to our users:</p>
        <ul>
            <li><strong>Account Information:</strong> Name, email address, payment information</li>
            <li><strong>Business Data:</strong> Generated business names, search queries, industry preferences</li>
            <li><strong>Usage Data:</strong> Platform interactions, feature usage, performance metrics</li>
            <li><strong>Technical Data:</strong> IP address, browser type, device information</li>
            <li><strong>Communication:</strong> Support requests, feedback, survey responses</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>2. How We Use Your Information</h2>
        <ul>
            <li>Provide and improve our business operating system services</li>
            <li>Process payments and manage subscriptions</li>
            <li>Generate personalized business name suggestions</li>
            <li>Provide customer support and respond to inquiries</li>
            <li>Send important service updates and notifications</li>
            <li>Analyze platform usage to improve features</li>
            <li>Prevent fraud and ensure platform security</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>3. Information Sharing</h2>
        <p>We do not sell personal information. We may share data only in these circumstances:</p>
        <ul>
            <li><strong>Service Providers:</strong> Payment processors (Paddle, Coinbase Commerce, PayPal), domain registrars, analytics providers</li>
            <li><strong>Legal Requirements:</strong> When required by law or to protect our rights</li>
            <li><strong>Business Transfers:</strong> In case of merger, acquisition, or sale of assets</li>
            <li><strong>Consent:</strong> When you explicitly agree to share information</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>4. Data Storage and Security</h2>
        <p>Your data is stored securely using industry-standard encryption and security measures:</p>
        <ul>
            <li>SSL/TLS encryption for data transmission</li>
            <li>Encrypted database storage</li>
            <li>Regular security audits and updates</li>
            <li>Access controls and authentication</li>
            <li>Data backup and recovery procedures</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>5. International Data Transfers</h2>
        <p>As a global platform serving 430.5M underbanked entrepreneurs worldwide, we may transfer data across borders. We ensure appropriate safeguards are in place for international transfers.</p>
    </div>
    
    <div class="section">
        <h2>6. Your Rights and Choices</h2>
        <p>You have the right to:</p>
        <ul>
            <li><strong>Access:</strong> Request copies of your personal data</li>
            <li><strong>Correction:</strong> Update or correct inaccurate information</li>
            <li><strong>Deletion:</strong> Request deletion of your personal data</li>
            <li><strong>Portability:</strong> Export your data in a structured format</li>
            <li><strong>Restriction:</strong> Limit how we process your information</li>
            <li><strong>Objection:</strong> Object to certain types of processing</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>7. Cookies and Tracking</h2>
        <p>We use cookies and similar technologies to:</p>
        <ul>
            <li>Remember your preferences and settings</li>
            <li>Analyze platform performance and usage</li>
            <li>Provide personalized experiences</li>
            <li>Prevent fraud and ensure security</li>
        </ul>
        <p>You can control cookie settings through your browser preferences.</p>
    </div>
    
    <div class="section">
        <h2>8. Children's Privacy</h2>
        <p>Our services are designed for business use and not intended for children under 13. We do not knowingly collect personal information from children under 13.</p>
    </div>
    
    <div class="section">
        <h2>9. Changes to This Policy</h2>
        <p>We may update this privacy policy periodically. Significant changes will be communicated via email or platform notification. Continued use constitutes acceptance of updates.</p>
    </div>
    
    <div class="section">
        <h2>10. Contact Us</h2>
        <p>For privacy-related questions or to exercise your rights, contact us through our platform support system or email our privacy team.</p>
    </div>
    
    <div style="text-align: center; margin-top: 40px; padding: 20px; background: #f0f0f0; border-radius: 5px;">
        <p><a href="/" style="color: #0040FF; text-decoration: none; font-weight: bold;">← Return to FindMyBizName Platform</a></p>
    </div>
</body>
</html>
    `);
  });
  
  app.get('/refund-policy', (req, res) => {
    res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Refund Policy - FindMyBizName</title>
    <meta name="description" content="Refund policy for FindMyBizName - Complete Business Operating System for Underbanked Entrepreneurs">
    <style>
        body { font-family: 'Segoe UI', system-ui, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; line-height: 1.6; color: #333; }
        h1, h2 { color: #0040FF; }
        .header { text-align: center; margin-bottom: 40px; padding: 20px; background: linear-gradient(135deg, #0040FF, #FF2D2D); color: white; border-radius: 10px; }
        .section { margin-bottom: 30px; padding: 20px; border-left: 4px solid #0040FF; background: #f9f9f9; }
        .effective-date { background: #FFDD00; color: #000; padding: 10px; border-radius: 5px; text-align: center; font-weight: bold; }
        .highlight { background: #E8F4FD; padding: 15px; border: 2px solid #0040FF; border-radius: 5px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>FindMyBizName Refund Policy</h1>
        <p>Complete Business Operating System for Underbanked Entrepreneurs</p>
    </div>
    
    <div class="effective-date">Effective Date: August 8, 2025</div>
    
    <div class="highlight">
        <h2>⚡ Commitment to Underbanked Entrepreneurs</h2>
        <p>As advocates for 430.5M underbanked entrepreneurs globally, we understand the importance of financial protection. Our refund policy is designed to be fair, transparent, and entrepreneur-friendly.</p>
    </div>
    
    <div class="section">
        <h2>1. 30-Day Money-Back Guarantee</h2>
        <p>We offer a full 30-day money-back guarantee for all subscription plans:</p>
        <ul>
            <li><strong>Starter Plan ($9.99/month):</strong> Full refund within 30 days</li>
            <li><strong>Professional Plan ($29.99/month):</strong> Full refund within 30 days</li>
            <li><strong>Enterprise Plan ($149/month):</strong> Full refund within 30 days</li>
        </ul>
        <p>No questions asked - we want you to try our platform risk-free.</p>
    </div>
    
    <div class="section">
        <h2>2. Eligibility Requirements</h2>
        <p>To be eligible for a refund:</p>
        <ul>
            <li>Refund request must be made within 30 days of initial subscription</li>
            <li>Account must not have been used for fraudulent or abusive purposes</li>
            <li>Digital products already downloaded may not be eligible for refund</li>
            <li>Generated business names and data remain accessible during grace period</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>3. Refund Process</h2>
        <p><strong>Step 1:</strong> Contact our support team through the platform or email</p>
        <p><strong>Step 2:</strong> Provide your account email and reason for refund (optional)</p>
        <p><strong>Step 3:</strong> Refund processed within 5-7 business days</p>
        <p><strong>Step 4:</strong> Receive confirmation email with refund details</p>
    </div>
    
    <div class="section">
        <h2>4. Payment Method Refunds</h2>
        <ul>
            <li><strong>Credit/Debit Cards:</strong> 5-7 business days</li>
            <li><strong>PayPal:</strong> 3-5 business days</li>
            <li><strong>Cryptocurrency:</strong> 1-3 business days (same currency)</li>
            <li><strong>WiPay:</strong> 7-10 business days</li>
        </ul>
        <p>Refunds are processed to the original payment method when possible.</p>
    </div>
    
    <div class="section">
        <h2>5. Pro-Rated Refunds</h2>
        <p>For subscriptions cancelled after 30 days:</p>
        <ul>
            <li>No refund for current billing period</li>
            <li>Access continues until end of paid period</li>
            <li>No charges for subsequent periods</li>
            <li>Data export available for 30 days after cancellation</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>6. Digital Product Refunds</h2>
        <p>Digital products (templates, guides, tools) from our marketplace:</p>
        <ul>
            <li><strong>Before Download:</strong> Full refund available</li>
            <li><strong>After Download:</strong> Refund at discretion based on circumstances</li>
            <li><strong>Defective Products:</strong> Full refund or replacement</li>
            <li><strong>Technical Issues:</strong> Full refund if product doesn't work as described</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>7. Special Circumstances</h2>
        <p>We may provide refunds beyond our standard policy for:</p>
        <ul>
            <li>Technical issues preventing platform use</li>
            <li>Billing errors or duplicate charges</li>
            <li>Service interruptions exceeding 48 hours</li>
            <li>Documented hardship cases (evaluated individually)</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>8. Non-Refundable Items</h2>
        <ul>
            <li>Domain registration fees paid to third parties</li>
            <li>One-time setup or customization fees</li>
            <li>Processing fees charged by payment providers</li>
            <li>Services already rendered or completed</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>9. Dispute Resolution</h2>
        <p>If you're unsatisfied with our refund decision:</p>
        <ul>
            <li>Request review by our customer advocacy team</li>
            <li>Provide additional documentation if available</li>
            <li>We'll respond within 7 business days</li>
            <li>Final decisions will be communicated in writing</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>10. Contact Information</h2>
        <p>For refund requests or questions:</p>
        <ul>
            <li>Use the support system within the platform</li>
            <li>Email our customer success team</li>
            <li>Include account email and refund reason</li>
            <li>Response time: 24 hours or less</li>
        </ul>
    </div>
    
    <div style="text-align: center; margin-top: 40px; padding: 20px; background: #f0f0f0; border-radius: 5px;">
        <p><a href="/" style="color: #0040FF; text-decoration: none; font-weight: bold;">← Return to FindMyBizName Platform</a></p>
    </div>
</body>
</html>
    `);
  });

  // Return the WebSocket initialization function for later use
  return;
}

export function initializeWebSockets(httpServer: Server): void {
  // Initialize Biz Buzz Live Community Chat Forum
  globalBizBuzzChat = new BizBuzzChatService(httpServer);
}