import { Request, Response } from 'express';

interface GoDaddyDomainCheck {
  domain: string;
  available: boolean;
  definitive: boolean;
  price?: number;
  currency?: string;
  period?: number;
}

interface GoDaddyAvailabilityResponse {
  available: boolean;
  domain: string;
  definitive: boolean;
  price?: number;
  currency?: string;
  period?: number;
}

class GoDaddyService {
  private readonly baseUrl = process.env.GODADDY_ENVIRONMENT === 'production' 
    ? 'https://api.godaddy.com/v1'
    : 'https://api.ote-godaddy.com/v1';

  private getHeaders() {
    const apiKey = process.env.GODADDY_API_KEY;
    const apiSecret = process.env.GODADDY_API_SECRET;
    
    if (!apiKey || !apiSecret) {
      throw new Error('GoDaddy API credentials not configured');
    }

    return {
      'Authorization': `sso-key ${apiKey}:${apiSecret}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
  }

  async checkDomainAvailability(domain: string): Promise<GoDaddyDomainCheck> {
    try {
      console.log(`Checking domain availability for: ${domain}`);
      
      const response = await fetch(
        `${this.baseUrl}/domains/available?domain=${domain}&checkType=FAST&forTransfer=false`,
        {
          method: 'GET',
          headers: this.getHeaders()
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`GoDaddy API Error: ${response.status} - ${errorText}`);
        throw new Error(`GoDaddy API Error: ${response.status}`);
      }

      const data: GoDaddyAvailabilityResponse = await response.json();
      console.log('GoDaddy API Response:', data);

      // Get pricing information if domain is available
      let price, currency, period;
      if (data.available) {
        try {
          const priceResponse = await fetch(
            `${this.baseUrl}/domains/${domain}/purchase`,
            {
              method: 'GET',
              headers: this.getHeaders()
            }
          );

          if (priceResponse.ok) {
            const priceData = await priceResponse.json();
            price = priceData.price;
            currency = priceData.currency || 'USD';
            period = priceData.period || 1;
          }
        } catch (priceError) {
          console.warn('Could not fetch pricing data:', priceError);
        }
      }

      return {
        domain,
        available: data.available,
        definitive: data.definitive,
        price,
        currency,
        period
      };
    } catch (error) {
      console.error('GoDaddy domain check error:', error);
      throw new Error(`Failed to check domain availability: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async checkMultipleDomains(domains: string[]): Promise<GoDaddyDomainCheck[]> {
    try {
      // Process domains in batches to avoid rate limiting
      const results: GoDaddyDomainCheck[] = [];
      const batchSize = 5;
      
      for (let i = 0; i < domains.length; i += batchSize) {
        const batch = domains.slice(i, i + batchSize);
        const batchPromises = batch.map(domain => this.checkDomainAvailability(domain));
        const batchResults = await Promise.allSettled(batchPromises);
        
        batchResults.forEach((result, index) => {
          if (result.status === 'fulfilled') {
            results.push(result.value);
          } else {
            console.error(`Failed to check domain ${batch[index]}:`, result.reason);
            results.push({
              domain: batch[index],
              available: false,
              definitive: false
            });
          }
        });

        // Add small delay between batches
        if (i + batchSize < domains.length) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }

      return results;
    } catch (error) {
      console.error('GoDaddy multiple domain check error:', error);
      throw new Error('Failed to check multiple domains');
    }
  }

  async testConnection(): Promise<{ success: boolean; message: string; environment: string }> {
    try {
      const testDomain = 'google.com'; // Known taken domain
      const result = await this.checkDomainAvailability(testDomain);
      
      return {
        success: true,
        message: `Connection successful. Test domain ${testDomain} is ${result.available ? 'available' : 'taken'} (${result.definitive ? 'definitive' : 'preliminary'} check)`,
        environment: process.env.GODADDY_ENVIRONMENT || 'ote'
      };
    } catch (error) {
      return {
        success: false,
        message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        environment: process.env.GODADDY_ENVIRONMENT || 'ote'
      };
    }
  }
}

export const goDaddyService = new GoDaddyService();

// Route handlers for GoDaddy integration
export async function checkGoDaddyDomains(req: Request, res: Response) {
  try {
    const { name, tlds } = req.body;
    
    if (!name || !tlds || !Array.isArray(tlds)) {
      return res.status(400).json({ 
        success: false,
        error: 'Name and TLDs array are required' 
      });
    }

    // Generate domain names by combining business name with TLDs
    const sanitizedName = name.toLowerCase().replace(/[^a-z0-9]/g, '');
    const domains = tlds.map((tld: string) => `${sanitizedName}${tld.startsWith('.') ? tld : '.' + tld}`);
    
    console.log('Checking domains:', domains);
    
    const results = await goDaddyService.checkMultipleDomains(domains);
    
    res.json({ 
      success: true,
      results,
      checked_domains: domains.length
    });
  } catch (error) {
    console.error('Domain check error:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to check domains',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}

export async function testGoDaddyConnection(req: Request, res: Response) {
  try {
    const result = await goDaddyService.testConnection();
    
    res.json({
      success: result.success,
      message: result.message,
      environment: result.environment,
      api_configured: !!(process.env.GODADDY_API_KEY && process.env.GODADDY_API_SECRET),
      base_url: process.env.GODADDY_ENVIRONMENT === 'production' 
        ? 'https://api.godaddy.com/v1'
        : 'https://api.ote-godaddy.com/v1'
    });
  } catch (error) {
    console.error('GoDaddy test connection error:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to test connection',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}

export async function getGoDaddyStatus(req: Request, res: Response) {
  try {
    const hasCredentials = !!(process.env.GODADDY_API_KEY && process.env.GODADDY_API_SECRET);
    
    res.json({
      configured: hasCredentials,
      environment: process.env.GODADDY_ENVIRONMENT || 'ote',
      api_url: process.env.GODADDY_ENVIRONMENT === 'production' 
        ? 'https://api.godaddy.com/v1'
        : 'https://api.ote-godaddy.com/v1',
      description: 'GoDaddy Domain Registration and Management',
      features: [
        'Real-time domain availability checking',
        'Domain pricing information',
        'Bulk domain checks',
        'Domain registration (with customer info)'
      ]
    });
  } catch (error) {
    console.error('GoDaddy status error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get GoDaddy status'
    });
  }
}