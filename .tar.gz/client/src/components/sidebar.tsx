import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Check, Download } from "lucide-react";
import { useFavorites } from "@/hooks/use-favorites";
import { useQuery } from "@tanstack/react-query";
import { SearchHistory } from "@shared/schema";

export default function Sidebar() {
  const { favorites, exportFavorites } = useFavorites();
  
  const { data: searchHistory = [] } = useQuery<SearchHistory[]>({
    queryKey: ["/api/search-history"],
    queryFn: async () => {
      const response = await fetch('/api/search-history');
      if (!response.ok) throw new Error('Failed to fetch search history');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });

  const handleExport = async () => {
    try {
      await exportFavorites("json");
    } catch (error) {
      console.error("Failed to export favorites:", error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Favorites */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
            <Heart className="w-5 h-5 text-red-500" />
            <span>Favorites</span>
            <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">
              {favorites.length}
            </span>
          </h3>
          
          <div className="space-y-3">
            {favorites.slice(0, 5).map((favorite) => (
              <div key={favorite.id} className="p-3 bg-gray-50 rounded-lg">
                <div className="font-medium text-gray-900">{favorite.name}</div>
                <div className="text-sm text-gray-600">
                  {Object.entries(favorite.domains).find(([_, domain]: any) => domain.available)?.[0] || 'No domains'} available
                </div>
              </div>
            ))}
            
            {favorites.length === 0 && (
              <div className="text-center py-4 text-gray-500 text-sm">
                No favorites yet. Heart some names to save them here!
              </div>
            )}
          </div>
          
          {favorites.length > 0 && (
            <Button 
              variant="outline" 
              className="w-full mt-4"
              onClick={handleExport}
            >
              <Download className="w-4 h-4 mr-2" />
              Export Favorites
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Upgrade Prompt */}
      <Card className="gradient-primary text-white">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-2">Unlock Premium Features</h3>
          <ul className="text-sm space-y-2 mb-4 opacity-90">
            <li className="flex items-center space-x-2">
              <Check className="w-4 h-4" />
              <span>Unlimited name generation</span>
            </li>
            <li className="flex items-center space-x-2">
              <Check className="w-4 h-4" />
              <span>Premium domains (.ai, .co)</span>
            </li>
            <li className="flex items-center space-x-2">
              <Check className="w-4 h-4" />
              <span>Advanced logo previews</span>
            </li>
            <li className="flex items-center space-x-2">
              <Check className="w-4 h-4" />
              <span>Trademark screening</span>
            </li>
          </ul>
          <Button variant="secondary" className="w-full bg-white text-primary hover:bg-gray-50">
            Start Free Trial
          </Button>
          <p className="text-xs text-center mt-2 opacity-75">7 days free, then $9.99/month</p>
        </CardContent>
      </Card>

      {/* Recent Searches */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Searches</h3>
          <div className="space-y-2">
            {searchHistory.slice(0, 5).map((search) => (
              <Button
                key={search.id}
                variant="ghost"
                className="w-full text-left justify-start h-auto p-2 text-sm text-gray-600 hover:bg-gray-50"
              >
                {search.query}
              </Button>
            ))}
            
            {searchHistory.length === 0 && (
              <div className="text-center py-4 text-gray-500 text-sm">
                Your recent searches will appear here
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
