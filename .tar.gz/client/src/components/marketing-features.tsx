import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Crown, 
  Zap, 
  TrendingUp, 
  CheckCircle, 
  Users, 
  Globe, 
  Shield,
  Star,
  Clock,
  Target
} from "lucide-react";
import { Link } from "wouter";
import { useAnalytics } from "@/components/analytics-tracker";

export function UrgencyBanner() {
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 45,
    seconds: 30
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="bg-gradient-to-r from-red-500 to-orange-500 text-white mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Clock className="w-6 h-6" />
            <div>
              <h3 className="font-bold">Limited Time: 50% Off Premium!</h3>
              <p className="text-sm opacity-90">
                Get unlimited business names for just $4.99/month
              </p>
            </div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">
              {String(timeLeft.hours).padStart(2, '0')}:
              {String(timeLeft.minutes).padStart(2, '0')}:
              {String(timeLeft.seconds).padStart(2, '0')}
            </div>
            <div className="text-xs opacity-75">Hours left</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function FeatureComparison() {
  const features = [
    { 
      name: "Business Names Generated",
      free: "10/day",
      premium: "Unlimited",
      pro: "Unlimited + AI Insights"
    },
    {
      name: "Domain Extensions",
      free: ".com, .net, .org",
      premium: "All TLDs + Premium (.ai, .co)",
      pro: "All TLDs + Premium + Bulk Check"
    },
    {
      name: "Export Options",
      free: "None",
      premium: "CSV, JSON",
      pro: "CSV, JSON, PDF Reports"
    },
    {
      name: "Logo Preview",
      free: "Basic",
      premium: "HD Preview",
      pro: "HD + Custom Colors"
    },
    {
      name: "Trademark Check",
      free: "None",
      premium: "Basic",
      pro: "Full Report + Alerts"
    },
    {
      name: "Support",
      free: "Community",
      premium: "Email Support",
      pro: "Priority + Phone"
    }
  ];

  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle className="text-center">Choose Your Plan</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left p-2">Features</th>
                <th className="text-center p-2">Free</th>
                <th className="text-center p-2 bg-blue-50">
                  <Badge variant="secondary">Most Popular</Badge>
                  <div className="font-semibold">Premium</div>
                  <div className="text-sm text-green-600">$9.99/month</div>
                </th>
                <th className="text-center p-2">
                  <div className="font-semibold">Pro</div>
                  <div className="text-sm text-purple-600">$19.99/month</div>
                </th>
              </tr>
            </thead>
            <tbody>
              {features.map((feature, index) => (
                <tr key={index} className="border-b">
                  <td className="p-2 font-medium">{feature.name}</td>
                  <td className="p-2 text-center text-gray-600">{feature.free}</td>
                  <td className="p-2 text-center bg-blue-50 font-medium text-blue-800">{feature.premium}</td>
                  <td className="p-2 text-center font-medium text-purple-800">{feature.pro}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex justify-center space-x-4 mt-6">
          <Link href="/subscribe?plan=premium">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
              Start Premium Trial
            </Button>
          </Link>
          <Link href="/subscribe?plan=pro">
            <Button size="lg" variant="outline" className="border-purple-600 text-purple-600">
              Upgrade to Pro
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

export function TrustSignals() {
  const signals = [
    {
      icon: <Shield className="w-8 h-8 text-green-600" />,
      title: "Secure Payments",
      description: "PayPal integration with 256-bit SSL encryption"
    },
    {
      icon: <Users className="w-8 h-8 text-blue-600" />,
      title: "430.5M Underbanked Entrepreneurs",
      description: "Serving global entrepreneurs with $5T purchasing power"
    },
    {
      icon: <Star className="w-8 h-8 text-yellow-600" />,
      title: "4.9/5 Rating",
      description: "Based on 500+ verified reviews"
    },
    {
      icon: <Globe className="w-8 h-8 text-purple-600" />,
      title: "Caribbean Business",
      description: "Built in Trinidad & Tobago for global reach"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {signals.map((signal, index) => (
        <Card key={index} className="text-center p-4">
          <CardContent className="p-2">
            <div className="flex justify-center mb-2">{signal.icon}</div>
            <h3 className="font-semibold mb-1">{signal.title}</h3>
            <p className="text-sm text-gray-600">{signal.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export function CallToActionSection() {
  const { trackUpgradeClick } = useAnalytics();

  const handleCTAClick = (source: string) => {
    trackUpgradeClick(`cta_${source}`);
  };

  return (
    <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white mb-8">
      <CardContent className="p-8 text-center">
        <Crown className="w-16 h-16 mx-auto mb-4 text-yellow-300" />
        <h2 className="text-3xl font-bold mb-4">
          Ready to Launch Your Dream Business?
        </h2>
        <p className="text-xl mb-6 opacity-90">
          Join 430.5 million underbanked entrepreneurs worldwide with $5T purchasing power building their business dreams
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/subscribe?plan=premium">
            <Button 
              size="lg" 
              className="bg-white text-blue-600 hover:bg-gray-100 text-lg px-8"
              onClick={() => handleCTAClick('main')}
            >
              <Zap className="w-5 h-5 mr-2" />
              Start Premium Today
            </Button>
          </Link>
          <Button 
            size="lg" 
            variant="outline" 
            className="border-white text-white hover:bg-white/10 text-lg px-8"
            onClick={() => handleCTAClick('free_trial')}
          >
            Try Free First
          </Button>
        </div>
        <div className="mt-4 text-sm opacity-75">
          ✓ Cancel anytime ✓ 30-day money back guarantee ✓ Instant access
        </div>
      </CardContent>
    </Card>
  );
}

interface MoneyBackGuaranteeProps {
  className?: string;
}

export function MoneyBackGuarantee({ className = "" }: MoneyBackGuaranteeProps) {
  return (
    <Card className={`border-green-200 bg-green-50 ${className}`}>
      <CardContent className="p-6 text-center">
        <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-green-800 mb-2">
          30-Day Money Back Guarantee
        </h3>
        <p className="text-green-700">
          Not satisfied? Get a full refund within 30 days, no questions asked. 
          We're confident you'll love FindMyBizName!
        </p>
      </CardContent>
    </Card>
  );
}

export function LocalBusinessFocus() {
  return (
    <Card className="border-blue-200 bg-blue-50 mb-6">
      <CardContent className="p-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
            <Target className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-blue-900">Perfect for Caribbean Businesses</h3>
            <p className="text-blue-800">
              Built in Trinidad & Tobago with PayPal integration. 
              Generate names that work locally and globally.
            </p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span>Local market insights</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span>Global domain availability</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span>PayPal TTD support</span>
          </div>
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span>Caribbean startup focus</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}