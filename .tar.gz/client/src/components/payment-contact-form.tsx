import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Mail, Phone } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PaymentContactFormProps {
  isOpen: boolean;
  onClose: () => void;
  paymentMethod: 'bank-transfer' | 'mobile-money';
  plan: string;
  amount: string;
}

export default function PaymentContactForm({ 
  isOpen, 
  onClose, 
  paymentMethod, 
  plan, 
  amount 
}: PaymentContactFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    country: '',
    preferredContact: 'whatsapp'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Create the message for WhatsApp or email
      const paymentMethodName = paymentMethod === 'bank-transfer' ? 'WiPay/Bank Transfer' : 'Mobile Money';
      const message = `New ${paymentMethodName} Request:
      
Name: ${formData.name}
Email: ${formData.email}
Phone: ${formData.phone}
Country: ${formData.country}
Plan: ${plan} (${amount}/month)
Payment Method: ${paymentMethodName}
Preferred Contact: ${formData.preferredContact}

Please send WiPay personal account details or Republic Bank transfer instructions for ${plan} subscription.`;

      // Send to WhatsApp or email based on preference
      if (formData.preferredContact === 'whatsapp') {
        const whatsappUrl = `https://wa.me/18687209758?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
      } else {
        const emailUrl = `mailto:sales@findmybizname.com?subject=${encodeURIComponent(`${paymentMethodName} Request - ${plan} Plan`)}&body=${encodeURIComponent(message)}`;
        window.open(emailUrl, '_blank');
      }

      toast({
        title: "Request Sent!",
        description: `Your ${paymentMethodName.toLowerCase()} request has been sent. You'll receive payment details within 1 hour.`,
      });

      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send request. Please try again or contact us directly.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const paymentMethodTitle = paymentMethod === 'bank-transfer' 
    ? 'WiPay & Bank Transfer Payment' 
    : 'Mobile Money Request';

  const paymentMethodDescription = paymentMethod === 'bank-transfer'
    ? 'Pay via WiPay personal account or direct bank transfer to Republic Bank Trinidad & Tobago'
    : 'Get mobile money details for M-Pesa, GCash, MTN, Digicel, Flow or other providers';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md mx-4">
        <CardHeader className="relative">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute right-2 top-2 h-6 w-6 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
          <CardTitle className="text-lg">{paymentMethodTitle}</CardTitle>
          <p className="text-sm text-gray-600">{paymentMethodDescription}</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                required
                placeholder="Your full name"
              />
            </div>

            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                required
                placeholder="your@email.com"
              />
            </div>

            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                required
                placeholder="+1 (868) 123-4567"
              />
            </div>

            <div>
              <Label htmlFor="country">Country/Region</Label>
              <Input
                id="country"
                type="text"
                value={formData.country}
                onChange={(e) => setFormData(prev => ({ ...prev, country: e.target.value }))}
                required
                placeholder="Trinidad & Tobago, Kenya, Philippines, etc."
              />
            </div>

            <div>
              <Label>Preferred Contact Method</Label>
              <div className="flex gap-2 mt-2">
                <Button
                  type="button"
                  variant={formData.preferredContact === 'whatsapp' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFormData(prev => ({ ...prev, preferredContact: 'whatsapp' }))}
                  className="flex items-center gap-2"
                >
                  <Phone className="h-4 w-4" />
                  WhatsApp
                </Button>
                <Button
                  type="button"
                  variant={formData.preferredContact === 'email' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFormData(prev => ({ ...prev, preferredContact: 'email' }))}
                  className="flex items-center gap-2"
                >
                  <Mail className="h-4 w-4" />
                  Email
                </Button>
              </div>
            </div>

            <div className="bg-gray-50 p-3 rounded-lg text-sm">
              <strong>Plan Details:</strong>
              <div className="text-gray-600">
                {plan} Plan - {amount}/month
              </div>
              <div className="text-gray-600 mt-1">
                Payment Method: {paymentMethod === 'bank-transfer' ? 'Bank Transfer' : 'Mobile Money'}
              </div>
            </div>

            <div className="space-y-3">
              <Button
                type="submit"
                className="w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Sending Request...' : 'Send Payment Request'}
              </Button>
              <Button
                type="button"
                variant="outline"
                className="w-full"
                onClick={onClose}
              >
                Cancel
              </Button>
            </div>

            <p className="text-xs text-center text-gray-500">
              You'll receive payment instructions within 1 hour during business hours (9 AM - 6 PM AST)
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}