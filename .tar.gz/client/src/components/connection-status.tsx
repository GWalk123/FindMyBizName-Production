import { useState, useEffect } from 'react';
import { AlertCircle, Wifi, WifiOff } from 'lucide-react';

export default function ConnectionStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isServerReachable, setIsServerReachable] = useState(true);

  // Check online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Periodically check server connectivity with exponential backoff
  useEffect(() => {
    let retryCount = 0;
    const maxRetries = 3;
    
    const checkServer = async () => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000); // 8 second timeout
        
        const response = await fetch('/api/health', {
          method: 'GET',
          cache: 'no-cache',
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
          setIsServerReachable(true);
          retryCount = 0; // Reset retry count on success
        } else {
          throw new Error('Server not responding correctly');
        }
      } catch (error) {
        console.log('Health check failed, attempt:', retryCount + 1);
        
        if (retryCount < maxRetries) {
          retryCount++;
          // Exponential backoff: wait 2^retryCount seconds before retrying
          const retryDelay = Math.min(2000 * Math.pow(2, retryCount), 10000);
          setTimeout(() => {
            checkServer().catch(() => {
              // Silent catch to prevent unhandled promise rejection
            });
          }, retryDelay);
        } else {
          setIsServerReachable(false);
          retryCount = 0; // Reset for next interval
        }
      }
    };

    // Check immediately
    checkServer().catch(() => {
      // Silent catch to prevent unhandled promise rejection
    });

    // Then check every 30 seconds
    const interval = setInterval(() => {
      retryCount = 0; // Reset retry count for each interval
      checkServer().catch(() => {
        // Silent catch to prevent unhandled promise rejection
      });
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  // Don't show anything if everything is working fine
  if (isOnline && isServerReachable) {
    return null;
  }

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-yellow-500 text-white px-4 py-2 text-sm flex items-center justify-center gap-2">
      {!isOnline ? (
        <>
          <WifiOff className="h-4 w-4" />
          <span>No internet connection. Please check your network.</span>
        </>
      ) : !isServerReachable ? (
        <>
          <AlertCircle className="h-4 w-4" />
          <span>Connection to server unstable. Retrying...</span>
        </>
      ) : null}
    </div>
  );
}