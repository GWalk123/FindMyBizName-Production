import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Star, Award, TrendingUp, Globe, MessageCircle } from "lucide-react";
import type { GeneratedNameWithDomains } from "@shared/schema";

interface NameScorerProps {
  names: GeneratedNameWithDomains[];
}

interface NameScore {
  overall: number;
  memorability: number;
  availability: number;
  brandability: number;
  pronunciation: number;
  length: number;
}

export default function NameScorer({ names }: NameScorerProps) {
  const [selectedName, setSelectedName] = useState<GeneratedNameWithDomains | null>(null);

  const calculateNameScore = (name: GeneratedNameWithDomains): NameScore => {
    const businessName = name.name;
    
    // Domain availability score
    const totalDomains = Object.keys(name.domains).length;
    const availableDomains = Object.values(name.domains).filter(d => d.available).length;
    const availability = totalDomains > 0 ? Math.round((availableDomains / totalDomains) * 100) : 0;
    
    // Length score (shorter is better for branding)
    const length = businessName.length <= 8 ? 95 : 
                  businessName.length <= 12 ? 80 :
                  businessName.length <= 16 ? 65 : 45;
    
    // Memorability score
    const vowels = (businessName.match(/[aeiou]/gi) || []).length;
    const consonants = businessName.length - vowels;
    const balance = Math.abs(vowels - consonants) / businessName.length;
    const memorability = Math.round(Math.max(50, 100 - (balance * 100) - (businessName.length - 6) * 3));
    
    // Brandability score
    let brandability = 70;
    if (/^[A-Z][a-z]+$/.test(businessName)) brandability += 10; // Proper case
    if (businessName.includes('x') || businessName.includes('z')) brandability += 10; // Unique letters
    if (!(/\d/.test(businessName))) brandability += 10; // No numbers
    if (businessName.length <= 10) brandability += 10; // Short enough
    brandability = Math.min(100, brandability);
    
    // Pronunciation score
    const difficultCombos = ['sch', 'tch', 'dge', 'ght', 'pht', 'xtr', 'str'];
    let pronunciation = 90;
    difficultCombos.forEach(combo => {
      if (businessName.toLowerCase().includes(combo)) pronunciation -= 15;
    });
    if (/[bcdfghjklmnpqrstvwxyz]{3,}/.test(businessName.toLowerCase())) pronunciation -= 10;
    pronunciation = Math.max(30, pronunciation);
    
    // Overall score
    const overall = Math.round((availability + length + memorability + brandability + pronunciation) / 5);
    
    return {
      overall,
      memorability,
      availability,
      brandability,
      pronunciation,
      length
    };
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreGrade = (score: number) => {
    if (score >= 90) return 'A+';
    if (score >= 80) return 'A';
    if (score >= 70) return 'B';
    if (score >= 60) return 'C';
    return 'D';
  };

  const getScoreProgressColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const scoredNames = names.map(name => ({
    ...name,
    score: calculateNameScore(name)
  })).sort((a, b) => b.score.overall - a.score.overall);

  if (names.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <Award className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Name Scorer</h3>
          <p className="text-gray-500">Generate some names to see their scores</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Award className="w-5 h-5" />
          <span>Name Performance Scores</span>
          <Badge variant="secondary">{names.length} names analyzed</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-gray-600 bg-blue-50 p-3 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <TrendingUp className="w-4 h-4 text-blue-600" />
            <span className="font-medium">How we score names:</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
            <div>• <strong>Domain Availability:</strong> More available = higher score</div>
            <div>• <strong>Length:</strong> 6-8 chars ideal for branding</div>
            <div>• <strong>Memorability:</strong> Vowel/consonant balance</div>
            <div>• <strong>Pronunciation:</strong> Easy to say = better recall</div>
            <div>• <strong>Brandability:</strong> Unique, professional appeal</div>
          </div>
        </div>

        <div className="space-y-3">
          {scoredNames.slice(0, 10).map((name, index) => (
            <div
              key={name.id}
              className={`border rounded-lg p-4 cursor-pointer transition-all ${
                selectedName?.id === name.id ? 'border-blue-500 bg-blue-50' : 'hover:border-gray-300'
              }`}
              onClick={() => setSelectedName(selectedName?.id === name.id ? null : name)}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2">
                    <Badge variant={index < 3 ? "default" : "secondary"} className="text-xs">
                      #{index + 1}
                    </Badge>
                    {index === 0 && <Badge variant="outline" className="text-xs bg-yellow-100">🏆 Top Pick</Badge>}
                  </div>
                  <h4 className="font-semibold text-lg">{name.name}</h4>
                </div>
                
                <div className="flex items-center space-x-3">
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${getScoreColor(name.score.overall)}`}>
                      {getScoreGrade(name.score.overall)}
                    </div>
                    <div className="text-xs text-gray-500">{name.score.overall}/100</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-5 gap-3 mb-3">
                <div className="text-center">
                  <div className="text-xs text-gray-500 mb-1">Domains</div>
                  <div className={`text-sm font-medium ${getScoreColor(name.score.availability)}`}>
                    {name.score.availability}%
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-gray-500 mb-1">Length</div>
                  <div className={`text-sm font-medium ${getScoreColor(name.score.length)}`}>
                    {name.score.length}%
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-gray-500 mb-1">Memory</div>
                  <div className={`text-sm font-medium ${getScoreColor(name.score.memorability)}`}>
                    {name.score.memorability}%
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-gray-500 mb-1">Brand</div>
                  <div className={`text-sm font-medium ${getScoreColor(name.score.brandability)}`}>
                    {name.score.brandability}%
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-gray-500 mb-1">Speech</div>
                  <div className={`text-sm font-medium ${getScoreColor(name.score.pronunciation)}`}>
                    {name.score.pronunciation}%
                  </div>
                </div>
              </div>

              <div className="mb-3">
                <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                  <span>Overall Score</span>
                  <span>{name.score.overall}/100</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${getScoreProgressColor(name.score.overall)}`}
                    style={{ width: `${name.score.overall}%` }}
                  />
                </div>
              </div>

              {selectedName?.id === name.id && (
                <div className="border-t pt-3 space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-medium text-sm mb-2 flex items-center space-x-1">
                        <Globe className="w-4 h-4" />
                        <span>Domain Analysis</span>
                      </h5>
                      <div className="space-y-1">
                        {Object.entries(name.domains).slice(0, 4).map(([tld, status]) => (
                          <div key={tld} className="flex items-center justify-between text-xs">
                            <span>.{tld}</span>
                            <Badge 
                              variant={status.available ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {status.available ? 'Available' : 'Taken'}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h5 className="font-medium text-sm mb-2 flex items-center space-x-1">
                        <MessageCircle className="w-4 h-4" />
                        <span>Branding Insights</span>
                      </h5>
                      <div className="text-xs text-gray-600 space-y-1">
                        <div>• {name.name.length} characters ({name.name.length <= 8 ? 'Perfect' : name.name.length <= 12 ? 'Good' : 'Long'} length)</div>
                        <div>• {Object.values(name.domains).filter(d => d.available).length} domains available</div>
                        <div>• {name.score.pronunciation >= 80 ? 'Easy' : name.score.pronunciation >= 60 ? 'Moderate' : 'Difficult'} to pronounce</div>
                        <div>• {name.score.memorability >= 80 ? 'Highly' : name.score.memorability >= 60 ? 'Moderately' : 'Less'} memorable</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {scoredNames.length > 10 && (
          <div className="text-center text-sm text-gray-500 pt-4 border-t">
            Showing top 10 highest-scoring names • {scoredNames.length - 10} more available
          </div>
        )}
      </CardContent>
    </Card>
  );
}