import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, Clock } from "lucide-react";
import { Link } from "wouter";
import { useState, useEffect } from "react";

export default function PricingSection() {
  const [isYearly, setIsYearly] = useState(false); // Default to monthly to show $19.99 Pro plan clearly
  const [timeLeft, setTimeLeft] = useState({ hours: 47, minutes: 23, seconds: 45 });
  
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  return (
    <div id="pricing" className="mt-16">
      <Card>
        <CardContent className="p-8">
          {/* Launch Promotion Banner with Countdown */}
          <div className="mb-8 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-lg p-4 text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <span className="text-2xl">🎉</span>
              <h3 className="text-lg font-bold">Launch Special - First 500 Customers Only!</h3>
              <span className="text-2xl">🎉</span>
            </div>
            <div className="flex items-center justify-center space-x-2 mb-3">
              <Clock className="w-4 h-4" />
              <div className="font-mono font-bold">
                {String(timeLeft.hours).padStart(2, '0')}:
                {String(timeLeft.minutes).padStart(2, '0')}:
                {String(timeLeft.seconds).padStart(2, '0')}
              </div>
              <span className="text-sm">remaining</span>
            </div>
            <p className="text-sm opacity-90">
              Save up to <strong>58% off</strong> regular pricing - underbanked entrepreneurs only
            </p>
            <p className="text-xs opacity-80 mt-1">Compare: Professional naming services cost $100-2000 per project</p>
          </div>

          {/* Social Proof */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center space-x-2 bg-blue-50 px-4 py-2 rounded-full">
              <span className="text-blue-600 font-medium">🇹🇹 Trusted by 500+ underbanked entrepreneurs</span>
            </div>
            <p className="text-sm text-gray-600 mt-2">
              "Generated 50+ names in minutes vs $300 freelancer!" - Local T&T Business Owner
            </p>
          </div>

          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Business Plan</h2>
            <p className="text-lg text-gray-600">AI-powered business naming with premium tools</p>
            
            {/* Monthly/Yearly Toggle */}
            <div className="flex items-center justify-center mt-6 mb-4">
              <span className={`text-sm ${!isYearly ? 'text-gray-900 font-medium' : 'text-gray-500'}`}>Monthly</span>
              <button
                onClick={() => setIsYearly(!isYearly)}
                className="mx-3 relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                <span
                  className={`${
                    isYearly ? 'translate-x-6 bg-blue-600' : 'translate-x-1 bg-gray-400'
                  } inline-block h-4 w-4 transform rounded-full transition-transform`}
                />
              </button>
              <span className={`text-sm ${isYearly ? 'text-gray-900 font-medium' : 'text-gray-500'}`}>
                Yearly
                <span className="ml-1 text-green-600 font-medium">Save 17%</span>
                <div className="text-xs text-blue-600">Most entrepreneurs choose this</div>
              </span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
            {/* Freemium Plan */}
            <Card className="border-gray-200">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Freemium</h3>
                  <div className="text-3xl font-bold text-gray-900">$0</div>
                  <div className="text-gray-600">forever</div>
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-2">
                    <Check className="w-4 h-4 text-green-500" />
                    <span className="text-gray-700">10 name generations per month</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-4 h-4 text-green-500" />
                    <span className="text-gray-700">Basic domain checking (.com)</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-4 h-4 text-green-500" />
                    <span className="text-gray-700">Community chat access</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-4 h-4 text-green-500" />
                    <span className="text-gray-700">Email support</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full">
                  Current Plan
                </Button>
              </CardContent>
            </Card>

            {/* Premium Plan */}
            <Card className="border-gray-200">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Premium</h3>
                  {!isYearly ? (
                    <>
                      <div className="text-3xl font-bold text-blue-600">$9.99</div>
                      <div className="text-gray-600">per month</div>
                    </>
                  ) : (
                    <>
                      <div className="text-3xl font-bold text-green-600">$99</div>
                      <div className="text-gray-600">per year</div>
                      <div className="text-xs text-green-600 font-medium">17% OFF</div>
                    </>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Unlimited name generations</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Premium domains (.ai, .co, .io)</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Brand analysis suite</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">PDF export & favorites</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Priority email support</span>
                  </li>
                </ul>
                <div className="space-y-3">
                  <Link href={`/subscribe?plan=premium${isYearly ? '-yearly' : ''}`}>
                    <Button className="w-full">
                      {isYearly ? 'Start Premium Yearly' : 'Start Premium Trial'}
                    </Button>
                  </Link>
                  <Link href="/alternative-payments">
                    <Button variant="outline" className="w-full text-sm">
                      💳 Pay with Visa/MasterCard or Local Caribbean Methods
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Pro Plan - Most Popular */}
            <Card className="border-2 border-primary relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <span className="bg-primary text-white px-3 py-1 rounded-full text-xs font-medium">Most Popular</span>
              </div>
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Pro</h3>
                  {!isYearly ? (
                    <>
                      <div className="text-3xl font-bold text-blue-600">$19.99</div>
                      <div className="text-gray-600">per month</div>
                    </>
                  ) : (
                    <>
                      <div className="text-3xl font-bold text-green-600">$199</div>
                      <div className="text-gray-600">per year</div>
                      <div className="text-xs text-green-600 font-medium">17% OFF</div>
                    </>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Everything in Premium</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">CRM with WhatsApp integration</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Invoice generator with QR codes</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Advanced domain checking (25+ TLDs)</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Business Intelligence (SEC data)</span>
                  </li>
                </ul>
                <div className="space-y-3">
                  <Link href={`/subscribe?plan=pro${isYearly ? '-yearly' : ''}`}>
                    <Button className="w-full">
                      {isYearly ? 'Start Yearly Pro' : 'Upgrade to Pro'}
                    </Button>
                  </Link>
                  <Link href="/alternative-payments">
                    <Button variant="outline" className="w-full text-sm">
                      💳 Pay with Visa/MasterCard or Local Caribbean Methods
                    </Button>
                  </Link>
                </div>
                <div className="text-xs text-gray-500 text-center mt-3">
                  Compare: Basic CRM systems cost $15-25/user/month
                </div>
              </CardContent>
            </Card>

            {/* Professional Plan */}
            <Card className="border-gray-200">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Professional</h3>
                  {!isYearly ? (
                    <>
                      <div className="text-3xl font-bold text-blue-600">$29.99</div>
                      <div className="text-gray-600">per month</div>
                    </>
                  ) : (
                    <>
                      <div className="text-3xl font-bold text-green-600">$299</div>
                      <div className="text-gray-600">per year</div>
                      <div className="text-xs text-green-600 font-medium">17% OFF</div>
                    </>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Everything in Growth</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Business Intelligence (SEC data)</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Advanced analytics dashboard</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Premium domain checking (50+ TLDs)</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Email marketing automation</span>
                  </li>
                </ul>
                <div className="space-y-3">
                  <Link href={`/subscribe?plan=professional${isYearly ? '-yearly' : ''}`}>
                    <Button className="w-full">
                      {isYearly ? 'Start Yearly Pro' : 'Upgrade to Professional'}
                    </Button>
                  </Link>
                  <Link href="/alternative-payments">
                    <Button variant="outline" className="w-full text-sm">
                      💳 Pay with Visa/MasterCard or Local Caribbean Methods
                    </Button>
                  </Link>
                </div>
                <div className="text-xs text-gray-500 text-center mt-3">
                  Compare: Professional CRM systems cost $25-50/user/month
                </div>
              </CardContent>
            </Card>

            {/* Business Plan */}
            <Card className="border-gray-200">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Business</h3>
                  {!isYearly ? (
                    <>
                      <div className="text-3xl font-bold text-blue-600">$59.99</div>
                      <div className="text-gray-600">per month</div>
                    </>
                  ) : (
                    <>
                      <div className="text-3xl font-bold text-green-600">$599</div>
                      <div className="text-gray-600">per year</div>
                      <div className="text-xs text-green-600 font-medium">17% OFF</div>
                    </>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Everything in Professional</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Advanced Analytics Dashboard</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Multi-user team access</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Email marketing automation</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Priority phone support</span>
                  </li>
                </ul>
                <div className="space-y-3">
                  <Link href={`/subscribe?plan=business${isYearly ? '-yearly' : ''}`}>
                    <Button className="w-full">
                      {isYearly ? 'Start Yearly Business' : 'Upgrade to Business'}
                    </Button>
                  </Link>
                  <Link href="/alternative-payments">
                    <Button variant="outline" className="w-full text-sm">
                      💳 Pay with Visa/MasterCard or Local Caribbean Methods
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Premium Plan */}
            <Card className="border-gray-200">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Premium</h3>
                  {!isYearly ? (
                    <>
                      <div className="text-3xl font-bold text-blue-600">$99.99</div>
                      <div className="text-gray-600">per month</div>
                    </>
                  ) : (
                    <>
                      <div className="text-3xl font-bold text-green-600">$999</div>
                      <div className="text-gray-600">per year</div>
                      <div className="text-xs text-green-600 font-medium">17% OFF</div>
                    </>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Everything in Business</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">White-label customization</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">API access and integrations</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Custom domain branding</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Dedicated account manager</span>
                  </li>
                </ul>
                <div className="space-y-3">
                  <Link href={`/subscribe?plan=premium${isYearly ? '-yearly' : ''}`}>
                    <Button className="w-full">
                      {isYearly ? 'Start Yearly Premium' : 'Upgrade to Premium'}
                    </Button>
                  </Link>
                  <Link href="/alternative-payments">
                    <Button variant="outline" className="w-full text-sm">
                      💳 Pay with Visa/MasterCard or Local Caribbean Methods
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Enterprise Plan */}
            <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Enterprise</h3>
                  {!isYearly ? (
                    <>
                      <div className="text-3xl font-bold text-purple-600">$149</div>
                      <div className="text-gray-600">per month</div>
                    </>
                  ) : (
                    <>
                      <div className="text-3xl font-bold text-purple-600">$1,499</div>
                      <div className="text-gray-600">per year</div>
                      <div className="text-xs text-green-600 font-medium">17% OFF</div>
                    </>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Everything in Premium</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Unlimited team members</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Custom integrations & APIs</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">Advanced security & compliance</span>
                  </li>
                  <li className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">24/7 priority support</span>
                  </li>
                </ul>
                <div className="space-y-3">
                  <Link href={`/subscribe?plan=enterprise${isYearly ? '-yearly' : ''}`}>
                    <Button className="w-full bg-purple-600 hover:bg-purple-700">
                      {isYearly ? 'Start Yearly Enterprise' : 'Contact Sales'}
                    </Button>
                  </Link>
                  <Link href="/alternative-payments">
                    <Button variant="outline" className="w-full text-sm">
                      💳 Pay with Visa/MasterCard or Local Caribbean Methods
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Cost Comparison Section */}
          <div className="mt-12 bg-gray-50 rounded-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">
              Compare: Traditional vs FindMyBizName
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-red-500 border border-red-600 rounded-lg p-4">
                <h4 className="font-semibold text-white mb-3">💸 Traditional Naming Services</h4>
                <ul className="space-y-2 text-sm text-white">
                  <li>• Freelance naming: $100-300</li>
                  <li>• Branding agencies: $500-2000</li>
                  <li>• Manual domain checking</li>
                  <li>• Limited name variations</li>
                  <li>• No instant results</li>
                </ul>
                <div className="mt-3 text-lg font-bold text-white">
                  Total: $100-2000 per project
                </div>
              </div>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="font-semibold text-green-900 mb-3">✅ FindMyBizName Premium</h4>
                <ul className="space-y-2 text-sm text-green-800">
                  <li>• Unlimited name generation</li>
                  <li>• Instant results (seconds)</li>
                  <li>• Automated PDF reports</li>
                  <li>• Premium domain access</li>
                  <li>• Advanced AI algorithms</li>
                </ul>
                <div className="mt-3 text-lg font-bold text-green-900">
                  Total: $9.99-149/month (~$67-1000 TTD)
                </div>
              </div>
            </div>
            <div className="text-center mt-4">
              <span className="text-2xl font-bold text-green-600">Save 70-95% vs traditional services!</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Coming Soon Preview Section */}
      <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200">
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">🚀 Coming Soon: Full Business Platform</h3>
            <p className="text-gray-600">Expanding from business naming to complete business management</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-2">📊 Advanced Analytics</h4>
              <p className="text-sm text-gray-600">Financial reporting, cash flow forecasting, and business insights dashboard</p>
              <div className="text-xs text-blue-600 mt-2">Q1 2026</div>
            </div>
            
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-2">📦 Inventory Management</h4>
              <p className="text-sm text-gray-600">Track products, manage stock levels, and automate reorder alerts</p>
              <div className="text-xs text-blue-600 mt-2">Q2 2026</div>
            </div>
            
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-2">👥 Team Workspace</h4>
              <p className="text-sm text-gray-600">Multi-user accounts, role permissions, and collaboration tools</p>
              <div className="text-xs text-blue-600 mt-2">Q2 2026</div>
            </div>
            
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-2">🏢 Multi-Location</h4>
              <p className="text-sm text-gray-600">Manage multiple business locations from one unified dashboard</p>
              <div className="text-xs text-blue-600 mt-2">Q3 2026</div>
            </div>
            
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-2">🔌 Custom API</h4>
              <p className="text-sm text-gray-600">Enterprise API access for custom integrations and automation</p>
              <div className="text-xs text-blue-600 mt-2">Q3 2026</div>
            </div>
            
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-2">📧 Email Campaigns</h4>
              <p className="text-sm text-gray-600">Automated email marketing and customer engagement tools</p>
              <div className="text-xs text-blue-600 mt-2">Q4 2026</div>
            </div>
          </div>
          
          <div className="text-center">
            <div className="bg-yellow-100 border border-yellow-300 rounded-lg p-4 mb-4">
              <p className="text-sm text-yellow-800">
                <strong>Early Bird Promise:</strong> Current Premium subscribers stay at $9.99/month even when we add new features. Pro subscribers stay at $19.99/month and get first access to new tools as they launch.
              </p>
              <p className="text-xs text-yellow-700 mt-2">
                Price protection guaranteed through 2026. New features added to existing plans at no extra charge.
              </p>
            </div>
            <Button 
              variant="outline" 
              className="mr-3"
              onClick={() => window.open(`mailto:gregorywalker760@gmail.com?subject=Join Waitlist for Future Features&body=Hi, I'm interested in joining the waitlist to hear about new features as they're released. Please keep me updated!`, '_blank')}
            >
              Join Waitlist for Updates
            </Button>
            <Link href="/subscribe">
              <Button>
                Lock in Early Bird Pricing
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Alternative Payment Options */}
      <Card className="mt-8 bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
        <CardContent className="p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            💳 No Credit Card? No Problem!
          </h3>
          <p className="text-gray-700 mb-4">
            We accept T&T Debit Cards, WiPay, Bank Transfer, Mobile Money, Endcash, and other Caribbean payment methods
          </p>
          <div className="flex gap-3 justify-center max-w-md mx-auto">
            <Button 
              onClick={() => window.open(`https://wa.me/18687209758?text=Hi! I want to subscribe but prefer alternative payment methods like WiPay or bank transfer. Can you help?`, '_blank')}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              WhatsApp Us
            </Button>
            <Button 
              onClick={() => window.open(`mailto:gregorywalker760@gmail.com?subject=Alternative Payment Options&body=Hi, I'm interested in subscribing but prefer to pay with WiPay, bank transfer, or mobile money. Please send me payment instructions.`, '_blank')}
              variant="outline"
            >
              Email Us
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
