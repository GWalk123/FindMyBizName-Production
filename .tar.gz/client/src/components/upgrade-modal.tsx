import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown, Sparkles, X } from "lucide-react";
import { Link } from "wouter";

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  feature: 'brandAnalysis' | 'nameImprovement';
  usageRemaining: number;
}

export default function UpgradeModal({ isOpen, onClose, feature, usageRemaining }: UpgradeModalProps) {
  if (!isOpen) return null;

  const featureNames = {
    brandAnalysis: 'Brand Analysis',
    nameImprovement: 'Name Improvement'
  };

  const featureBenefits = {
    brandAnalysis: [
      'Comprehensive sentiment analysis',
      'Caribbean market insights',
      'Pronunciation difficulty scoring',
      'SEO optimization analysis',
      'Competitor uniqueness check',
      'Social media handle checking'
    ],
    nameImprovement: [
      'Professional name variants',
      'Authority enhancement suggestions',
      'Tech-forward modernization',
      'Caribbean localization',
      'Simplified branding options',
      'Scoring and recommendations'
    ]
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <Card className="w-full max-w-md mx-4">
        <CardHeader className="relative">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute right-2 top-2 h-6 w-6 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
          <CardTitle className="flex items-center gap-2">
            <Crown className="h-5 w-5 text-yellow-600" />
            Upgrade Required
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-2">
              You've used {usageRemaining === 0 ? 'all' : 'most of'} your free {featureNames[feature]} credits.
            </p>
            <Badge variant="outline" className="text-red-600 border-red-200">
              {usageRemaining} credits remaining
            </Badge>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-sm">Premium Features Include:</h4>
            <ul className="space-y-1">
              {featureBenefits[feature].slice(0, 3).map((benefit, idx) => (
                <li key={idx} className="flex items-center gap-2 text-sm">
                  <Sparkles className="h-3 w-3 text-purple-600" />
                  {benefit}
                </li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="text-center p-3 border rounded-lg">
              <div className="font-semibold text-sm">Premium</div>
              <div className="text-xs text-gray-600">$9.99/month</div>
              <div className="text-xs text-green-600">
                {feature === 'brandAnalysis' ? '50/month' : '100/month'}
              </div>
            </div>
            <div className="text-center p-3 border rounded-lg bg-purple-50">
              <div className="font-semibold text-sm flex items-center justify-center gap-1">
                <Crown className="h-3 w-3 text-yellow-600" />
                Pro
              </div>
              <div className="text-xs text-gray-600">$19.99/month</div>
              <div className="text-xs text-green-600">Unlimited</div>
            </div>
          </div>

          <div className="space-y-2">
            <Link href="/subscribe">
              <Button className="w-full bg-purple-600 hover:bg-purple-700" onClick={onClose}>
                Upgrade Now
              </Button>
            </Link>
            <Button variant="outline" className="w-full" onClick={onClose}>
              Maybe Later
            </Button>
          </div>

          <p className="text-xs text-center text-gray-500">
            Start building your brand with premium insights. Cancel anytime.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}