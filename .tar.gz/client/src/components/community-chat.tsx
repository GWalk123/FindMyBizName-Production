import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, Users, Send, X, Minimize2, Maximize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  userType: 'entrepreneur' | 'supporter' | 'premium';
}

interface ConnectedUser {
  id: string;
  username: string;
  userType: 'entrepreneur' | 'supporter' | 'premium';
  location?: string;
}

export function CommunityChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [connectedUsers, setConnectedUsers] = useState<ConnectedUser[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Fetch user profile for permanent username
  const { data: userProfile, isLoading: profileLoading } = useQuery<any>({
    queryKey: ['/api/profile'],
    queryFn: async () => {
      const response = await fetch('/api/profile');
      if (!response.ok) throw new Error('Failed to fetch user profile');
      return response.json();
    },
    retry: false,
    staleTime: 10 * 60 * 1000, // 10 minutes
    refetchOnWindowFocus: false,
  });

  // Auto-scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // WebSocket connection management
  useEffect(() => {
    if (isOpen && !ws && !profileLoading) {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      const websocket = new WebSocket(wsUrl);
      setConnectionStatus('connecting');

      websocket.onopen = () => {
        setConnectionStatus('connected');
        setWs(websocket);
        
        // Join community chat room with profile data
        const username = userProfile?.displayName || 'MrBizWhiz';
        const location = userProfile?.location || 'Caribbean';
        
        try {
          websocket.send(JSON.stringify({
            type: 'join_community',
            username,
            userType: 'entrepreneur',
            location
          }));
        } catch (error) {
          console.log('WebSocket send error:', error);
        }
      };

      websocket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          switch (data.type) {
            case 'community_message':
              setMessages(prev => [...prev, {
                id: data.id,
                username: data.username,
                message: data.message,
                timestamp: new Date(data.timestamp),
                userType: data.userType
              }]);
              break;
            
          case 'user_joined':
            setConnectedUsers(prev => [...prev, data.user]);
            setMessages(prev => [...prev, {
              id: Date.now().toString(),
              username: 'System',
              message: `${data.user.username} joined the community chat`,
              timestamp: new Date(),
              userType: 'supporter'
            }]);
            break;
            
          case 'user_left':
            setConnectedUsers(prev => prev.filter(user => user.id !== data.userId));
            break;
            
          case 'users_update':
            setConnectedUsers(data.users);
            break;
        }
        } catch (error) {
          console.log('Error parsing WebSocket message:', error);
        }
      };

      websocket.onerror = () => {
        setConnectionStatus('disconnected');
        toast({
          title: "Connection Error",
          description: "Unable to connect to community chat. Please try again.",
          variant: "destructive",
        });
      };

      websocket.onclose = () => {
        setConnectionStatus('disconnected');
        setWs(null);
      };
    }

    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, [isOpen, profileLoading, userProfile]);

  const sendMessage = () => {
    if (!newMessage.trim() || !ws || connectionStatus !== 'connected') return;

    try {
      ws.send(JSON.stringify({
        type: 'community_message',
        message: newMessage.trim()
      }));
      setNewMessage('');
    } catch (error) {
      console.log('Error sending message:', error);
      toast({
        title: "Message Failed",
        description: "Unable to send message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const getUserTypeColor = (userType: string) => {
    switch (userType) {
      case 'premium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'supporter': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      default: return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (!isOpen) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <div className="relative group">
          <Button
            onClick={() => setIsOpen(true)}
            className="rounded-full h-14 w-14 shadow-lg bg-blue-600 hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800 transition-all duration-200 hover:scale-105"
          >
            <MessageCircle className="h-6 w-6" />
            <span className="sr-only">Open Biz Buzz</span>
          </Button>
          
          {/* Tooltip */}
          <div className="absolute bottom-full right-0 mb-2 px-3 py-1 bg-gray-900 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
            Biz Buzz - Chat with entrepreneurs
            <div className="absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
          </div>
          
          {/* Online Users Badge */}
          {connectedUsers.length > 0 && (
            <Badge className="absolute -top-2 -left-2 bg-green-500 text-white animate-pulse">
              {connectedUsers.length}
            </Badge>
          )}
          
          {/* "Biz Buzz" label that appears on hover */}
          <div className="absolute bottom-full right-full mr-2 mb-4 px-2 py-1 bg-blue-600 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-all duration-200 transform group-hover:translate-x-0 translate-x-2">
            Biz Buzz
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Card className={`shadow-xl transition-all duration-300 ${
        isMinimized ? 'w-80 h-16' : 'w-80 h-96'
      }`}>
        <CardHeader className="pb-2 cursor-pointer" onClick={() => setIsMinimized(!isMinimized)}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <CardTitle className="text-sm">Biz Buzz</CardTitle>
              <div className="flex items-center gap-1">
                <div className={`w-2 h-2 rounded-full ${
                  connectionStatus === 'connected' ? 'bg-green-500' : 
                  connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
                }`} />
                <span className="text-xs text-muted-foreground">
                  {connectedUsers.length} online
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsMinimized(!isMinimized);
                }}
              >
                {isMinimized ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsOpen(false);
                  if (ws) ws.close();
                }}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        {!isMinimized && (
          <CardContent className="p-3 pt-0 flex flex-col h-full">
            {connectionStatus === 'disconnected' && (
              <div className="text-center py-2 text-sm text-muted-foreground bg-red-50 dark:bg-red-900/20 rounded mb-2">
                Disconnected - Click to reconnect
              </div>
            )}
            
            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto space-y-2 mb-3 max-h-60">
              {messages.length === 0 ? (
                <div className="text-center py-4 text-sm text-muted-foreground">
                  <MessageCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>Welcome to Biz Buzz!</p>
                  <p className="text-xs">Connect with entrepreneurs worldwide</p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div key={msg.id} className="text-sm">
                    <div className="flex items-center gap-1 mb-1">
                      <Badge variant="outline" className={`text-xs px-1 py-0 ${getUserTypeColor(msg.userType)}`}>
                        {msg.username}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {formatTime(msg.timestamp)}
                      </span>
                    </div>
                    <p className="text-xs pl-2 border-l-2 border-gray-200 dark:border-gray-700">
                      {msg.message}
                    </p>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="flex gap-2">
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Share your experience..."
                disabled={connectionStatus !== 'connected'}
                className="text-sm"
              />
              <Button
                onClick={sendMessage}
                disabled={!newMessage.trim() || connectionStatus !== 'connected'}
                size="sm"
              >
                <Send className="h-3 w-3" />
              </Button>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}