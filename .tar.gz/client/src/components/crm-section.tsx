import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Phone, Mail, MessageCircle, User } from "lucide-react";

interface Contact {
  id: number;
  name: string;
  email?: string;
  phone?: string;
  company?: string;
  notes?: string;
  tags: string[];
  lastContact?: Date;
}

export default function CRMSection() {
  const [contacts, setContacts] = useState<Contact[]>([
    {
      id: 1,
      name: "Sarah Johnson",
      email: "sarah@example.com",
      phone: "+1 (868) 555-0123",
      company: "Local Tech Solutions",
      notes: "Interested in business naming for her new startup",
      tags: ["prospect", "tech"],
      lastContact: new Date("2025-07-05")
    },
    {
      id: 2,
      name: "Marcus Williams",
      phone: "+1 (868) 555-0456",
      company: "Williams Construction",
      notes: "Looking for rebranding services",
      tags: ["client", "construction"],
      lastContact: new Date("2025-07-03")
    }
  ]);

  const [showAddForm, setShowAddForm] = useState(false);
  const [newContact, setNewContact] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    notes: ""
  });

  const handleAddContact = () => {
    if (!newContact.name) return;
    
    const contact: Contact = {
      id: Date.now(),
      ...newContact,
      tags: ["prospect"],
      lastContact: new Date()
    };
    
    setContacts([contact, ...contacts]);
    setNewContact({ name: "", email: "", phone: "", company: "", notes: "" });
    setShowAddForm(false);
  };

  const getWhatsAppUrl = (phone: string, name: string) => {
    const cleanPhone = phone.replace(/[^\d+]/g, '');
    const message = `Hello ${name}! Following up from FindMyBizName...`;
    return `https://wa.me/${cleanPhone.replace('+', '')}?text=${encodeURIComponent(message)}`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Customer Contacts</h2>
          <p className="text-gray-600 dark:text-gray-400">Manage your business relationships</p>
        </div>
        <Button onClick={() => setShowAddForm(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Contact
        </Button>
      </div>

      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Contact</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                placeholder="Contact Name *"
                value={newContact.name}
                onChange={(e) => setNewContact(prev => ({ ...prev, name: e.target.value }))}
              />
              <Input
                placeholder="Email"
                type="email"
                value={newContact.email}
                onChange={(e) => setNewContact(prev => ({ ...prev, email: e.target.value }))}
              />
              <Input
                placeholder="Phone (+1 868 555-0123)"
                value={newContact.phone}
                onChange={(e) => setNewContact(prev => ({ ...prev, phone: e.target.value }))}
              />
              <Input
                placeholder="Company"
                value={newContact.company}
                onChange={(e) => setNewContact(prev => ({ ...prev, company: e.target.value }))}
              />
            </div>
            <Textarea
              placeholder="Notes about this contact..."
              value={newContact.notes}
              onChange={(e) => setNewContact(prev => ({ ...prev, notes: e.target.value }))}
              rows={3}
            />
            <div className="flex gap-2">
              <Button onClick={handleAddContact} disabled={!newContact.name}>
                Add Contact
              </Button>
              <Button variant="outline" onClick={() => setShowAddForm(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {contacts.map((contact) => (
          <Card key={contact.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-blue-600" />
                  <CardTitle className="text-lg">{contact.name}</CardTitle>
                </div>
                <div className="flex gap-1">
                  {contact.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
              {contact.company && (
                <CardDescription>{contact.company}</CardDescription>
              )}
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                {contact.email && (
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4 text-gray-500" />
                    <a href={`mailto:${contact.email}`} className="text-blue-600 hover:underline">
                      {contact.email}
                    </a>
                  </div>
                )}
                {contact.phone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <a href={`tel:${contact.phone}`} className="text-blue-600 hover:underline">
                      {contact.phone}
                    </a>
                  </div>
                )}
              </div>

              {contact.notes && (
                <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
                  {contact.notes}
                </p>
              )}

              {contact.lastContact && (
                <p className="text-xs text-gray-500">
                  Last contact: {contact.lastContact.toLocaleDateString()}
                </p>
              )}

              {contact.phone && (
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full flex items-center gap-2"
                  onClick={() => window.open(getWhatsAppUrl(contact.phone!, contact.name), '_blank')}
                >
                  <MessageCircle className="w-4 h-4" />
                  WhatsApp
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {contacts.length === 0 && (
        <Card>
          <CardContent className="py-8 text-center">
            <User className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              No contacts yet
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Start building your customer database
            </p>
            <Button onClick={() => setShowAddForm(true)}>Add Your First Contact</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}