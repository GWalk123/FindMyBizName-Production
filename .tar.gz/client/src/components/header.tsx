import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Link } from "wouter";
import { ChevronDown, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";

export default function Header() {
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      const response = await fetch('/api/user');
      if (!response.ok) throw new Error('Failed to fetch user data');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });
  
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleDropdownToggle = (dropdown: string) => {
    setActiveDropdown(activeDropdown === dropdown ? null : dropdown);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
    setActiveDropdown(null);
  };

  // Simple header color setup - no intervals
  useEffect(() => {
    const header = document.getElementById('main-header');
    if (header) {
      header.style.backgroundColor = '#0040FF';
      header.style.borderBottom = '1px solid #0033CC';
    }
  }, []);

  return (
    <header 
      id="main-header"
      style={{ 
        backgroundColor: '#0040FF',
        borderBottom: '1px solid #0033CC',
        background: '#0040FF',
        position: 'sticky',
        top: '0',
        zIndex: '50',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <div className="flex items-center space-x-2 cursor-pointer">
                <img 
                  src="/findmybizname-gmail-logo.svg" 
                  alt="FindMyBizName Business Toolkit" 
                  className="w-8 h-8"
                />
                <span className="text-xl font-semibold text-white">FindMyBizName</span>
              </div>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} className="text-white" /> : <Menu size={24} className="text-white" />}
          </button>
          
          <nav className="hidden md:flex items-center space-x-8">
            {/* Home Link */}
            <Link href="/">
              <div className="text-blue-100 hover:text-white transition-colors cursor-pointer">
                Home
              </div>
            </Link>
            
            {/* AI Templates - Direct Link */}
            <Link href="/ai-templates">
              <div className="text-blue-100 hover:text-white transition-colors cursor-pointer flex items-center gap-2">
                AI Templates
                <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded">🤖 AI</span>
              </div>
            </Link>
            
            {/* Biz Newz - Direct Link */}
            <Link href="/biz-newz">
              <div className="text-blue-100 hover:text-white transition-colors cursor-pointer flex items-center gap-2">
                Biz Newz
                <span className="bg-amber-100 text-amber-700 text-xs px-2 py-1 rounded">📰 NEWS</span>
              </div>
            </Link>
            
            {/* Biz Botz - Direct Link */}
            <Link href="/biz-botz">
              <div className="text-blue-100 hover:text-white transition-colors cursor-pointer flex items-center gap-2">
                Biz Botz
                <span className="bg-cyan-100 text-cyan-700 text-xs px-2 py-1 rounded">🤖 CHAT</span>
              </div>
            </Link>
            
            {/* Business Intelligence - Direct Link */}
            <Link href="/business-intelligence">
              <div className="text-blue-100 hover:text-white transition-colors cursor-pointer flex items-center gap-2">
                Business Intelligence
                <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">NEW</span>
              </div>
            </Link>
            
            {/* Biz Buzz - Direct Link */}
            <Link href="/community">
              <div className="text-blue-100 hover:text-white transition-colors cursor-pointer flex items-center gap-2">
                Biz Buzz
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded">💬</span>
              </div>
            </Link>
            
            {/* Profile - Direct Link */}
            <Link href="/profile">
              <div className="text-blue-100 hover:text-white transition-colors cursor-pointer flex items-center gap-2">
                Profile
                <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded">👤</span>
              </div>
            </Link>
            
            {/* Referrals - Direct Link */}
            <Link href="/referrals">
              <div className="text-blue-100 hover:text-white transition-colors cursor-pointer flex items-center gap-2">
                Referrals
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded">30%</span>
              </div>
            </Link>
            
            {/* Digital Wallet - Direct Link */}
            <Link href="/wallet">
              <div className="text-blue-100 hover:text-white transition-colors cursor-pointer flex items-center gap-2">
                Wallet
                <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">💰 WALLET</span>
              </div>
            </Link>
            
            {/* Product Dropdown */}
            <div className="relative">
              <button
                onClick={() => handleDropdownToggle('product')}
                className="flex items-center text-blue-100 hover:text-white transition-colors"
              >
                Product
                <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              {activeDropdown === 'product' && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg py-2 z-50">
                  <Link href="/features">
                    <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer" onClick={() => setActiveDropdown(null)}>Features</div>
                  </Link>
                  <Link href="/pricing">
                    <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer" onClick={() => setActiveDropdown(null)}>Pricing</div>
                  </Link>
                  <Link href="/api">
                    <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer" onClick={() => setActiveDropdown(null)}>API Documentation</div>
                  </Link>
                  <Link href="/brand-analysis">
                    <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer" onClick={() => setActiveDropdown(null)}>Brand Analysis Suite</div>
                  </Link>
                  <Link href="/name-improver">
                    <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer" onClick={() => setActiveDropdown(null)}>
                      <div className="flex items-center justify-between">
                        Name Improvement Engine
                        <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded">New</span>
                      </div>
                    </div>
                  </Link>
                  <Link href="/digital-products">
                    <div className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 cursor-pointer" onClick={() => setActiveDropdown(null)}>
                      <div className="flex items-center justify-between">
                        Product Downloads
                        <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded">💰</span>
                      </div>
                    </div>
                  </Link>

                </div>
              )}
            </div>

          </nav>
          
          <div className="flex items-center space-x-4">
            {user && (
              <div className="hidden sm:flex items-center space-x-2 text-sm text-blue-100">
                <span>{user.dailyUsage}</span>
                <span>/</span>
                <span>{user.plan === "free" ? "10 free uses today" : "unlimited"}</span>
              </div>
            )}
            <Link href="/subscribe">
              <Button className="bg-primary hover:bg-primary/90">
                Upgrade to Pro
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      {mobileMenuOpen && (
        <div 
          className="md:hidden bg-superman-blue border-t border-blue-700"
          style={{ 
            backgroundColor: '#0040FF',
            borderTop: '1px solid #0033CC'
          }}
        >
          <div className="px-4 py-2 space-y-1">
            {/* Home Link */}
            <Link href="/">
              <div className="block py-2 text-blue-100 hover:text-white font-semibold border-b border-blue-500" onClick={closeMobileMenu}>
                🏠 Home
              </div>
            </Link>
            
            {/* AI Templates - Direct Link */}
            <Link href="/ai-templates">
              <div className="block py-2 text-blue-100 hover:text-white font-semibold border-b border-blue-500" onClick={closeMobileMenu}>
                🤖 AI Templates
                <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded ml-2">AI</span>
              </div>
            </Link>
            
            {/* Biz Newz - Direct Link */}
            <Link href="/biz-newz">
              <div className="block py-2 text-blue-100 hover:text-white font-semibold border-b border-blue-500" onClick={closeMobileMenu}>
                📰 Biz Newz
                <span className="bg-amber-100 text-amber-700 text-xs px-2 py-1 rounded ml-2">NEWS</span>
              </div>
            </Link>
            
            {/* Biz Botz - Direct Link */}
            <Link href="/biz-botz">
              <div className="block py-2 text-blue-100 hover:text-white font-semibold border-b border-blue-500" onClick={closeMobileMenu}>
                🤖 Biz Botz
                <span className="bg-cyan-100 text-cyan-700 text-xs px-2 py-1 rounded ml-2">CHAT</span>
              </div>
            </Link>
            
            {/* Business Intelligence - Direct Link */}
            <Link href="/business-intelligence">
              <div className="block py-2 text-blue-100 hover:text-white font-semibold border-b border-blue-500" onClick={closeMobileMenu}>
                📊 Business Intelligence
                <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded ml-2">NEW</span>
              </div>
            </Link>
            
            {/* Biz Buzz - Direct Link */}
            <Link href="/community">
              <div className="block py-2 text-blue-100 hover:text-white font-semibold border-b border-blue-500" onClick={closeMobileMenu}>
                💬 Biz Buzz
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded ml-2">CHAT</span>
              </div>
            </Link>
            
            {/* Profile - Direct Link */}
            <Link href="/profile">
              <div className="block py-2 text-blue-100 hover:text-white font-semibold border-b border-blue-500" onClick={closeMobileMenu}>
                👤 Profile
                <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded ml-2">NEW</span>
              </div>
            </Link>
            
            {/* Referrals - Direct Link */}
            <Link href="/referrals">
              <div className="block py-2 text-blue-100 hover:text-white font-semibold border-b border-blue-500" onClick={closeMobileMenu}>
                💰 Referrals
                <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded ml-2">30%</span>
              </div>
            </Link>
            
            {/* Digital Wallet - Direct Link */}
            <Link href="/wallet">
              <div className="block py-2 text-blue-100 hover:text-white font-semibold border-b border-blue-500" onClick={closeMobileMenu}>
                💰 Wallet
                <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded ml-2">WALLET</span>
              </div>
            </Link>
            
            <div className="py-2">
              <div className="font-semibold text-gray-900 mb-2">Product</div>
              <div className="ml-4 space-y-1">
                <Link href="/features">
                  <div className="block py-2 text-gray-600 hover:text-gray-900" onClick={closeMobileMenu}>Features</div>
                </Link>
                <Link href="/pricing">
                  <div className="block py-2 text-gray-600 hover:text-gray-900" onClick={closeMobileMenu}>Pricing</div>
                </Link>
                <Link href="/api">
                  <div className="block py-2 text-gray-600 hover:text-gray-900" onClick={closeMobileMenu}>API Documentation</div>
                </Link>
                <Link href="/brand-analysis">
                  <div className="block py-2 text-gray-600 hover:text-gray-900" onClick={closeMobileMenu}>Brand Analysis Suite</div>
                </Link>
                <Link href="/name-improver">
                  <div className="block py-2 text-gray-600 hover:text-gray-900" onClick={closeMobileMenu}>
                    <div className="flex items-center justify-between">
                      Name Improvement Engine
                      <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded ml-2">New</span>
                    </div>
                  </div>
                </Link>
                <Link href="/digital-products">
                  <div className="block py-2 text-gray-600 hover:text-gray-900" onClick={closeMobileMenu}>
                    <div className="flex items-center justify-between">
                      Product Downloads
                      <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded ml-2">💰</span>
                    </div>
                  </div>
                </Link>
              </div>
            </div>
            
            
            <div className="py-4 border-t border-gray-200">
              <Link href="/subscribe">
                <Button className="w-full bg-primary hover:bg-primary/90" onClick={closeMobileMenu}>
                  Upgrade to Pro
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
      
      {/* Click outside to close dropdowns */}
      {activeDropdown && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setActiveDropdown(null)}
        />
      )}
    </header>
  );
}
