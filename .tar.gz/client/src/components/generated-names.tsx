import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Heart, Crown, Lock, Download, Zap } from "lucide-react";
import { useFavorites } from "@/hooks/use-favorites";
import { useQuery } from "@tanstack/react-query";
import { type GeneratedNameWithDomains, type User } from "@shared/schema";
import UpgradeModal from "@/components/upgrade-modal";

interface GeneratedNamesProps {
  names: GeneratedNameWithDomains[];
  onPreviewLogo: (name: string) => void;
}

export default function GeneratedNames({ names, onPreviewLogo }: GeneratedNamesProps) {
  // Early return with fallback UI if no names
  if (!names || !Array.isArray(names) || names.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Generated Names (0)</h3>
          <div className="text-center py-8 text-gray-500" style={{color: '#6b7280', fontSize: '16px'}}>
            Generate some business names to see them here!
          </div>
        </CardContent>
      </Card>
    );
  }
  const [domainFilter, setDomainFilter] = useState("all");
  const [sortBy, setSortBy] = useState("relevance");
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const { toggleFavorite, favorites } = useFavorites();
  
  // Get user data for premium feature gating
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      const response = await fetch('/api/user');
      if (!response.ok) throw new Error('Failed to fetch user data');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });

  const handleExportAttempt = () => {
    if (user?.plan === 'free') {
      setShowUpgradeModal(true);
      return;
    }
    exportToPDF();
  };

  const exportToPDF = () => {
    const printContent = `
      <html>
        <head>
          <title>FindMyBizName - Generated Business Names</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; margin-bottom: 30px; }
            .name-item { margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 8px; }
            .name { font-size: 18px; font-weight: bold; color: #333; }
            .domains { margin-top: 10px; }
            .domain { display: inline-block; margin-right: 15px; padding: 4px 8px; background: #f0f0f0; border-radius: 4px; font-size: 12px; }
            .available { background: #d4edda; color: #155724; }
            .taken { background: #f8d7da; color: #721c24; }
            .premium { background: #fff3cd; color: #856404; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>FindMyBizName - Generated Business Names</h1>
            <p>Generated on ${new Date().toLocaleDateString()}</p>
          </div>
          ${sortedNames.map(name => `
            <div class="name-item">
              <div class="name">${name.name}</div>
              ${name.description ? `<p>${name.description}</p>` : ''}
              <div class="domains">
                ${Object.entries(name.domains).map(([tld, domain]: any) => `
                  <span class="domain ${domain.available ? 'available' : domain.premium ? 'premium' : 'taken'}">
                    .${tld} ${domain.available ? '✓ Available' : domain.premium ? '⭐ Premium' : '✗ Taken'}
                    ${domain.price ? ` - $${domain.price}/year` : ''}
                  </span>
                `).join('')}
              </div>
            </div>
          `).join('')}
        </body>
      </html>
    `;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const getStyleColor = (style?: string) => {
    switch (style) {
      case "Modern & Tech": return "bg-blue-100 text-blue-800";
      case "Classic & Professional": return "bg-purple-100 text-purple-800";
      case "Creative & Unique": return "bg-amber-100 text-amber-800";
      case "Short & Punchy": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getAvailabilityStatus = (domains: Record<string, any>) => {
    const hasAvailable = Object.values(domains).some((domain: any) => domain.available);
    if (hasAvailable) {
      return { text: "Available", color: "bg-green-100 text-green-800" };
    }
    const hasPremium = Object.values(domains).some((domain: any) => domain.premium);
    if (hasPremium) {
      return { text: "Premium Only", color: "bg-red-100 text-red-800" };
    }
    return { text: "Checking...", color: "bg-gray-100 text-gray-800" };
  };

  const getDomainPrice = (domains: Record<string, any>) => {
    const availableDomains = Object.entries(domains)
      .filter(([_, domain]: any) => domain.available)
      .sort(([_, a]: any, [__, b]: any) => a.price - b.price);
    
    if (availableDomains.length > 0) {
      const [tld, domain] = availableDomains[0] as [string, any];
      return `${tld} - $${domain.price}/year`;
    }
    return "";
  };

  // Validate names prop to prevent crashes
  const validNames = Array.isArray(names) ? names : [];
  
  const filteredNames = validNames.filter(name => {
    if (domainFilter === "available") {
      return Object.values(name.domains).some((domain: any) => domain.available === true);
    }
    if (domainFilter === "premium") {
      return Object.values(name.domains).some((domain: any) => domain.premium === true);
    }
    return true;
  });

  const sortedNames = [...filteredNames].sort((a, b) => {
    if (sortBy === "length") {
      return a.name.length - b.name.length;
    }
    if (sortBy === "price") {
      const getLowestPrice = (domains: Record<string, any>) => {
        const prices = Object.values(domains)
          .filter((domain: any) => domain.available && domain.price)
          .map((domain: any) => domain.price);
        return prices.length > 0 ? Math.min(...prices) : Infinity;
      };
      return getLowestPrice(a.domains) - getLowestPrice(b.domains);
    }
    return 0; // relevance - keep original order
  });

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold text-gray-900">Generated Names ({sortedNames.length})</h3>
          <div className="flex items-center space-x-3">
            {/* Export Button */}
            {sortedNames.length > 0 && (
              <>
                {user?.plan === "free" ? (
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="border-blue-300 text-blue-600 hover:bg-blue-50"
                    onClick={handleExportAttempt}
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Export PDF
                    <Lock className="w-3 h-3 ml-1" />
                  </Button>
                ) : (
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="border-green-300 text-green-600 hover:bg-green-50"
                    onClick={exportToPDF}
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Export PDF
                  </Button>
                )}
              </>
            )}
            <Select value={domainFilter} onValueChange={setDomainFilter}>
              <SelectTrigger className="w-36">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Domains</SelectItem>
                <SelectItem value="available">Available Only</SelectItem>
                <SelectItem value="premium">Premium Domains</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Sort by Relevance</SelectItem>
                <SelectItem value="length">Sort by Length</SelectItem>
                <SelectItem value="price">Sort by Domain Price</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="space-y-4">
          {sortedNames.map((nameData, index) => {
            if (!nameData || typeof nameData.name !== 'string') {
              return null;
            }
            
            const availabilityStatus = getAvailabilityStatus(nameData.domains);
            const isFavorite = favorites.some(fav => fav.name === nameData.name);
            
            return (
              <div key={`name-${index}-${nameData.name}`} className="p-6 border-2 border-gray-200 rounded-xl hover:border-blue-400 hover:shadow-lg transition-all duration-300 bg-white" style={{backgroundColor: '#ffffff'}}>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full animate-pulse"></div>
                        <h4 className="font-bold text-xl text-gray-900 tracking-wide" style={{color: '#000000 !important', fontSize: '20px', fontWeight: 'bold'}}>{nameData.name}</h4>
                      </div>
                      <Badge className={`${availabilityStatus.color} font-semibold px-3 py-1 text-sm`}>
                        {availabilityStatus.text}
                      </Badge>
                      {nameData.style && (
                        <Badge className={`${getStyleColor(nameData.style)} font-medium px-2 py-1 text-xs`}>
                          {nameData.style}
                        </Badge>
                      )}
                      <Badge className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1">
                        <Zap className="w-3 h-3 mr-1" />
                        AI Generated
                      </Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                      {Object.entries(nameData.domains).map(([tld, domain]: any) => (
                        <div key={tld} className={`flex items-center justify-between p-3 rounded-lg border ${
                          domain.available 
                            ? 'bg-green-50 border-green-200' 
                            : 'bg-gray-50 border-gray-200'
                        }`} style={{backgroundColor: domain.available ? '#f0fdf4' : '#f9fafb'}}>
                          <div className="flex items-center space-x-2">
                            <span className={`w-3 h-3 rounded-full ${
                              domain.available ? 'bg-green-500 animate-pulse' : 'bg-gray-400'
                            }`}></span>
                            <span className="font-medium text-gray-900" style={{color: '#000000 !important', fontWeight: '600'}}>
                              {nameData.name.toLowerCase()}.{tld}
                            </span>
                          </div>
                          <div className="text-right">
                            {domain.available ? (
                              <div>
                                <span className="font-bold text-green-700">${domain.price}/year</span>
                                <div className="text-xs text-green-600">Available</div>
                              </div>
                            ) : (
                              <span className="text-red-600 font-medium text-xs">Taken</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleFavorite(nameData)}
                      className={isFavorite ? "text-red-500 hover:text-red-600" : "text-gray-400 hover:text-red-500"}
                    >
                      <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
                    </Button>
                    <Button onClick={() => onPreviewLogo(nameData.name)}>
                      Preview Logo
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        {sortedNames.length === 0 && names.length > 0 && (
          <div className="text-center py-8 text-gray-500">
            No names match your current filters. Try adjusting the filter options.
          </div>
        )}
        
        {names.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            Generate some business names to see them here!
          </div>
        )}
      </CardContent>
      
      {/* Upgrade Modal */}
      <UpgradeModal 
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        feature="brandAnalysis"
        usageRemaining={0}
      />
    </Card>
  );
}
