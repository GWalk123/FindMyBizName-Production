import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";

interface LogoPreviewModalProps {
  businessName: string;
  isOpen: boolean;
  onClose: () => void;
}

export default function LogoPreviewModal({ businessName, isOpen, onClose }: LogoPreviewModalProps) {
  const getInitials = (name: string) => {
    const words = name.split(/(?=[A-Z])/);
    if (words.length >= 2) {
      return words[0][0] + words[1][0];
    }
    return name.slice(0, 2);
  };

  const logoOptions = [
    {
      id: 1,
      name: "Corporate Blue",
      bgColor: "bg-primary",
      textColor: "text-white",
      shape: "rounded-lg",
      initials: getInitials(businessName),
      description: "Professional square design",
    },
    {
      id: 2,
      name: "Growth Green", 
      bgColor: "bg-green-500",
      textColor: "text-white",
      shape: "rounded-full",
      initials: businessName[0],
      description: "Modern circular style",
    },
    {
      id: 3,
      name: "Creative Purple",
      bgColor: "bg-purple-500",
      textColor: "text-white", 
      shape: "rounded-lg",
      initials: getInitials(businessName),
      description: "Innovative square format",
    },
    {
      id: 4,
      name: "Energy Gold",
      bgColor: "bg-amber-500",
      textColor: "text-white",
      shape: "rounded-full",
      initials: businessName[0],
      description: "Bold circular design",
    },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Logo Preview - {businessName}</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
          {logoOptions.map((option) => (
            <div key={option.id} className="text-center p-8 bg-gray-50 rounded-lg">
              <div className={`w-20 h-20 mx-auto mb-4 ${option.bgColor} ${option.shape} flex items-center justify-center`}>
                <span className={`${option.textColor} font-bold text-2xl`}>
                  {option.initials}
                </span>
              </div>
              <div className="text-2xl font-bold text-gray-900">{businessName}</div>
              <div className="text-gray-700 font-medium mt-1">{option.name}</div>
              <div className="text-gray-500 text-sm mt-1">{option.description}</div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-amber-50 rounded-lg border border-amber-200">
          <div className="flex items-center space-x-2 text-amber-800">
            <Star className="w-5 h-5" />
            <span className="font-medium">
              Upgrade to Premium for professional logo variations and download options
            </span>
          </div>
        </div>

        <div className="flex justify-end space-x-3 mt-6">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          <Button className="bg-primary hover:bg-primary/90">
            Upgrade for Full Features
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
