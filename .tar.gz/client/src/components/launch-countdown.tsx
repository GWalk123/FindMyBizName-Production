import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Rocket, Clock, Target, Zap } from "lucide-react";

export default function LaunchCountdown() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  // Launch target: Custom domain deployment
  const launchDate = new Date('2025-07-29T00:00:00Z'); // Tomorrow

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = launchDate.getTime() - now;

      if (distance > 0) {
        setTimeLeft({
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000)
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-gradient-to-r from-red-600 via-blue-600 to-yellow-500 p-1 rounded-lg mb-6">
      <Card className="bg-white">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Rocket className="w-5 h-5 text-red-600" />
              <span className="font-bold bg-gradient-to-r from-blue-600 to-red-600 bg-clip-text text-transparent">
                Official Launch Countdown
              </span>
            </div>
            <Badge className="bg-yellow-400 text-red-800 animate-pulse">
              LIVE
            </Badge>
          </div>
          
          <div className="grid grid-cols-4 gap-2 mt-3">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{timeLeft.days}</div>
              <div className="text-xs text-gray-600">DAYS</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{timeLeft.hours}</div>
              <div className="text-xs text-gray-600">HOURS</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">{timeLeft.minutes}</div>
              <div className="text-xs text-gray-600">MINS</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{timeLeft.seconds}</div>
              <div className="text-xs text-gray-600">SECS</div>
            </div>
          </div>

          <div className="mt-3 text-center">
            <div className="text-sm font-medium text-gray-700">
              🌍 Serving 400+MM Underbanked Entrepreneurs Globally
            </div>
            <div className="text-xs text-gray-500 mt-1">
              Ready for immediate deployment at findmybizname.com
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}