import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add global error handler to prevent crashes
window.addEventListener('error', (event) => {
  console.warn('Global error caught:', event.error);
  event.preventDefault();
});

window.addEventListener('unhandledrejection', (event) => {
  // Only log in development mode to reduce noise
  try {
    if ((import.meta as any).env?.MODE === 'development') {
      console.warn('Promise rejection handled:', event.reason?.message || event.reason);
    }
  } catch {
    // Silently handle any env access issues
  }
  
  // Prevent default to stop the error from crashing the app
  event.preventDefault();
});

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Root element not found");
}

createRoot(rootElement).render(<App />);
