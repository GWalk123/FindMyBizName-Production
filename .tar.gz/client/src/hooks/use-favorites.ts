import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type GeneratedNameWithDomains } from "@shared/schema";

export function useFavorites() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: favorites = [], isLoading } = useQuery<GeneratedNameWithDomains[]>({
    queryKey: ["/api/favorites"],
    queryFn: async () => {
      const response = await fetch('/api/favorites');
      if (!response.ok) throw new Error('Failed to fetch favorites');
      return response.json();
    },
    retry: false,
    refetchOnWindowFocus: false,
  });

  const toggleFavoriteMutation = useMutation({
    mutationFn: async (nameData: GeneratedNameWithDomains) => {
      try {
        const response = await apiRequest("POST", "/api/favorites/toggle", {
          nameId: nameData.id,
        });
        return response.json();
      } catch (error) {
        console.warn('Toggle favorite error:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/generated-names"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update favorite. Please try again.",
        variant: "destructive",
      });
    },
  });

  const exportFavorites = async (format: "json" | "csv" = "json") => {
    try {
      const response = await fetch(`/api/export/favorites?format=${format}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error(`Export failed with status: ${response.status}`);
      }
      
      if (!response.ok) {
        throw new Error("Export failed");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `favorites.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Export Successful",
        description: `Favorites exported as ${format.toUpperCase()} file.`,
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export favorites. Please try again.",
        variant: "destructive",
      });
    }
  };

  return {
    favorites,
    isLoading,
    toggleFavorite: toggleFavoriteMutation.mutate,
    exportFavorites,
  };
}
