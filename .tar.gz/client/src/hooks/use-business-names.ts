import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type NameGenerationRequest, type GeneratedNameWithDomains } from "@shared/schema";

interface GenerateNamesResponse {
  names: GeneratedNameWithDomains[];
  remainingUsage: number;
}

export function useBusinessNames() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const generateNames = useMutation({
    mutationFn: async (request: NameGenerationRequest): Promise<GenerateNamesResponse> => {
      try {
        const response = await apiRequest("POST", "/api/generate-names", request);
        return response; // apiRequest already parses JSON
      } catch (error) {
        console.warn('Name generation error:', error);
        throw error;
      }
    },
    onSuccess: (data) => {
      // Invalidate related queries
      queryClient.invalidateQueries({ queryKey: ["/api/generated-names"] });
      queryClient.invalidateQueries({ queryKey: ["/api/search-history"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      
      console.log('Name generation success:', data);
      
      if (data.names && data.names.length > 0) {
        toast({
          title: "Names Generated!",
          description: `Generated ${data.names.length} business names successfully.`,
        });
      }
    },
    onError: (error: any) => {
      if (error.message.includes("429")) {
        toast({
          title: "Daily Limit Reached",
          description: "Upgrade to Premium for unlimited name generation.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Generation Failed",
          description: "Failed to generate business names. Please try again.",
          variant: "destructive",
        });
      }
    },
  });

  return {
    generateNames: generateNames.mutateAsync,
    isGenerating: generateNames.isPending,
  };
}
