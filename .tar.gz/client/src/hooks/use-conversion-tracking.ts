import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { type User } from "@shared/schema";

interface ConversionEvent {
  type: 'generation' | 'favorite' | 'domain_check' | 'logo_preview' | 'export_attempt';
  timestamp: Date;
  data?: any;
}

export function useConversionTracking() {
  const [events, setEvents] = useState<ConversionEvent[]>([]);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [upgradeTrigger, setUpgradeTrigger] = useState<'limit_reached' | 'domain_check' | 'export_attempt' | 'logo_preview' | 'usage_streak'>('limit_reached');

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      const response = await fetch('/api/user');
      if (!response.ok) throw new Error('Failed to fetch user data');
      return response.json();
    },
    retry: false,
    refetchOnWindowFocus: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes (renamed from cacheTime in v5)
  });

  // Track conversion events
  const trackEvent = (type: ConversionEvent['type'], data?: any) => {
    const event: ConversionEvent = {
      type,
      timestamp: new Date(),
      data
    };
    
    setEvents(prev => [...prev.slice(-20), event]); // Keep last 20 events
    
    // Check for conversion triggers
    checkConversionTriggers([...events, event]);
  };

  // Check various conversion triggers
  const checkConversionTriggers = (eventHistory: ConversionEvent[]) => {
    if (!user || user.plan !== "free") return;

    const recentEvents = eventHistory.filter(
      event => Date.now() - event.timestamp.getTime() < 24 * 60 * 60 * 1000 // Last 24 hours
    );

    // Trigger 1: Near monthly limit (promotion: 20, regular: 10)
    const currentDate = new Date();
    const isLaunchMonth = currentDate.getFullYear() === 2025 && currentDate.getMonth() === 0;
    const monthlyLimit = isLaunchMonth ? 20 : 10;
    const triggerPoint = Math.floor(monthlyLimit * 0.7); // Trigger at 70% of limit
    
    if (user.dailyUsage >= triggerPoint) {
      triggerUpgrade('limit_reached');
      return;
    }

    // Trigger 2: Multiple domain checks (interested in domains)
    const domainChecks = recentEvents.filter(e => e.type === 'domain_check');
    if (domainChecks.length >= 3) {
      triggerUpgrade('domain_check');
      return;
    }

    // Trigger 3: Multiple favorites (serious about names)
    const favorites = recentEvents.filter(e => e.type === 'favorite');
    if (favorites.length >= 5) {
      triggerUpgrade('usage_streak');
      return;
    }

    // Trigger 4: Logo preview attempts (brand building interest)
    const logoAttempts = recentEvents.filter(e => e.type === 'logo_preview');
    if (logoAttempts.length >= 2) {
      triggerUpgrade('logo_preview');
      return;
    }

    // Trigger 5: Usage streak (3+ consecutive days)
    if (hasUsageStreak(eventHistory)) {
      triggerUpgrade('usage_streak');
      return;
    }
  };

  // Check for usage streak
  const hasUsageStreak = (eventHistory: ConversionEvent[]) => {
    const today = new Date();
    const daysToCheck = 3;
    
    for (let i = 0; i < daysToCheck; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(today.getDate() - i);
      
      const dayEvents = eventHistory.filter(event => {
        const eventDate = new Date(event.timestamp);
        return eventDate.toDateString() === checkDate.toDateString();
      });
      
      if (dayEvents.length === 0) return false;
    }
    
    return true;
  };

  // Trigger upgrade modal with specific context
  const triggerUpgrade = (trigger: typeof upgradeTrigger) => {
    // Don't show if already shown recently
    const lastShown = localStorage.getItem('lastUpgradeModalShown');
    if (lastShown && Date.now() - parseInt(lastShown) < 2 * 60 * 60 * 1000) return; // 2 hours

    setUpgradeTrigger(trigger);
    setShowUpgradeModal(true);
    localStorage.setItem('lastUpgradeModalShown', Date.now().toString());
  };

  // Manual triggers for specific actions
  const triggerExportUpgrade = () => triggerUpgrade('export_attempt');
  const triggerDomainUpgrade = () => triggerUpgrade('domain_check');
  const triggerLogoUpgrade = () => triggerUpgrade('logo_preview');

  return {
    trackEvent,
    showUpgradeModal,
    setShowUpgradeModal,
    upgradeTrigger,
    triggerExportUpgrade,
    triggerDomainUpgrade,
    triggerLogoUpgrade,
    userStats: {
      dailyUsage: user?.dailyUsage || 0,
      remainingUsage: Math.max(0, 10 - (user?.dailyUsage || 0)),
      isNearLimit: (user?.dailyUsage || 0) >= 8,
      isAtLimit: (user?.dailyUsage || 0) >= 10
    }
  };
}