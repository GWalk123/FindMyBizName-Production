import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, Users, MessageCircle, Globe } from 'lucide-react';
import SEOHead from '@/components/seo-head';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: string;
  userType: 'entrepreneur' | 'supporter' | 'premium';
}

interface ConnectedUser {
  id: string;
  username: string;
  userType: 'entrepreneur' | 'supporter' | 'premium';
  location?: string;
}

export default function BizBuzz() {
  const [isConnected, setIsConnected] = useState(false);
  const [username, setUsername] = useState('');
  const [currentMessage, setCurrentMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [connectedUsers, setConnectedUsers] = useState<ConnectedUser[]>([]);
  const [userLocation, setUserLocation] = useState('');
  const wsRef = useRef<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const connectToChat = () => {
    if (!username.trim()) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onopen = () => {
      setIsConnected(true);
      wsRef.current?.send(JSON.stringify({
        type: 'join_community',
        username: username.trim(),
        userType: 'entrepreneur',
        location: userLocation || undefined
      }));
    };

    wsRef.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'community_message':
          setMessages(prev => [...prev, {
            id: data.id,
            username: data.username,
            message: data.message,
            timestamp: data.timestamp,
            userType: data.userType
          }]);
          break;
        case 'users_update':
          setConnectedUsers(data.users);
          break;
        case 'user_joined':
          setConnectedUsers(prev => {
            const existing = prev.find(u => u.id === data.user.id);
            if (existing) return prev;
            return [...prev, data.user];
          });
          break;
        case 'user_left':
          setConnectedUsers(prev => prev.filter(u => u.id !== data.userId));
          break;
      }
    };

    wsRef.current.onclose = () => {
      setIsConnected(false);
      setConnectedUsers([]);
    };

    wsRef.current.onerror = (error) => {
      console.error('WebSocket error:', error);
      setIsConnected(false);
    };
  };

  const sendMessage = () => {
    if (!currentMessage.trim() || !wsRef.current || !isConnected) return;

    wsRef.current.send(JSON.stringify({
      type: 'community_message',
      message: currentMessage.trim()
    }));

    setCurrentMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const getUserTypeColor = (userType: string) => {
    switch (userType) {
      case 'supporter': return 'bg-blue-100 text-blue-800';
      case 'premium': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-green-100 text-green-800';
    }
  };

  const disconnectFromChat = () => {
    wsRef.current?.close();
    setIsConnected(false);
    setMessages([]);
    setConnectedUsers([]);
  };

  return (
    <>
      <SEOHead 
        title="Biz Buzz - Live Community Chat Forum | FindMyBizName"
        description="Connect with entrepreneurs worldwide in our live community chat forum. Network, share ideas, and build business relationships in real-time."
        keywords="entrepreneur chat, business community, networking, live chat, business forum"
      />
      
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            <MessageCircle className="inline-block w-10 h-10 mr-3 text-blue-600" />
            Biz Buzz
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Live Community Chat Forum for Underbanked Entrepreneurs Worldwide
          </p>
          <div className="flex items-center justify-center gap-6 mt-4 text-sm text-gray-500">
            <span className="flex items-center gap-1">
              <Globe className="w-4 h-4" />
              Global Community
            </span>
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              {connectedUsers.length} Online
            </span>
          </div>
        </div>

        <div className="max-w-6xl mx-auto grid md:grid-cols-4 gap-6">
          {/* Chat Area */}
          <div className="md:col-span-3">
            <Card className="h-[600px] flex flex-col">
              <CardHeader className="flex-shrink-0">
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Community Chat
                  {isConnected && (
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Connected
                    </Badge>
                  )}
                </CardTitle>
                <CardDescription>
                  Real-time conversations with entrepreneurs from around the world
                </CardDescription>
              </CardHeader>

              <CardContent className="flex-grow flex flex-col p-0">
                {!isConnected ? (
                  <div className="flex-grow flex flex-col justify-center items-center p-6 space-y-4">
                    <div className="w-full max-w-md space-y-4">
                      <Input
                        placeholder="Enter your name"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="text-center"
                      />
                      <Input
                        placeholder="Your location (optional)"
                        value={userLocation}
                        onChange={(e) => setUserLocation(e.target.value)}
                        className="text-center"
                      />
                      <Button 
                        onClick={connectToChat}
                        className="w-full"
                        disabled={!username.trim()}
                      >
                        Join Community Chat
                      </Button>
                    </div>
                    <div className="text-center text-sm text-gray-500 max-w-md">
                      <p>Connect with entrepreneurs worldwide. Share ideas, get advice, and build your network.</p>
                    </div>
                  </div>
                ) : (
                  <>
                    <ScrollArea className="flex-grow px-6">
                      <div className="space-y-4 py-4">
                        {messages.map((msg) => (
                          <div key={msg.id} className="flex flex-col space-y-1">
                            <div className="flex items-center gap-2">
                              <Badge 
                                variant="outline" 
                                className={getUserTypeColor(msg.userType)}
                              >
                                {msg.username}
                              </Badge>
                              <span className="text-xs text-gray-500">
                                {new Date(msg.timestamp).toLocaleTimeString()}
                              </span>
                            </div>
                            <p className="text-gray-800 ml-2">{msg.message}</p>
                          </div>
                        ))}
                        <div ref={messagesEndRef} />
                      </div>
                    </ScrollArea>

                    <div className="flex-shrink-0 p-4 border-t">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Type your message..."
                          value={currentMessage}
                          onChange={(e) => setCurrentMessage(e.target.value)}
                          onKeyPress={handleKeyPress}
                          className="flex-grow"
                        />
                        <Button 
                          onClick={sendMessage}
                          disabled={!currentMessage.trim()}
                          size="icon"
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Connected Users */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Online ({connectedUsers.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-32">
                  <div className="space-y-2">
                    {connectedUsers.map((user) => (
                      <div key={user.id} className="flex items-center justify-between">
                        <div className="flex flex-col">
                          <span className="font-medium text-sm">{user.username}</span>
                          {user.location && (
                            <span className="text-xs text-gray-500">{user.location}</span>
                          )}
                        </div>
                        <Badge 
                          variant="outline" 
                          className={getUserTypeColor(user.userType)}
                        >
                          {user.userType}
                        </Badge>
                      </div>
                    ))}
                    {connectedUsers.length === 0 && (
                      <p className="text-sm text-gray-500 text-center">
                        No one online yet
                      </p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Chat Guidelines */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Community Guidelines</CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-2">
                <ul className="list-disc list-inside space-y-1 text-gray-600">
                  <li>Be respectful and supportive</li>
                  <li>Share business ideas and experiences</li>
                  <li>Help fellow entrepreneurs</li>
                  <li>Keep discussions business-focused</li>
                  <li>No spam or self-promotion</li>
                </ul>
              </CardContent>
            </Card>

            {isConnected && (
              <Button 
                onClick={disconnectFromChat}
                variant="outline"
                className="w-full"
              >
                Disconnect
              </Button>
            )}
          </div>
        </div>

        {/* Feature Description */}
        <div className="max-w-4xl mx-auto mt-12 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Real-Time Global Entrepreneur Community
          </h2>
          <p className="text-gray-600 mb-6">
            Biz Buzz is your 24/7 connection to entrepreneurs worldwide. Get instant feedback, 
            share experiences, find collaborators, and build meaningful business relationships 
            in our live community chat forum.
          </p>
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            <div className="text-center">
              <Globe className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <h3 className="font-semibold mb-1">Global Network</h3>
              <p className="text-sm text-gray-600">Connect with entrepreneurs from every continent</p>
            </div>
            <div className="text-center">
              <MessageCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <h3 className="font-semibold mb-1">Real-Time Chat</h3>
              <p className="text-sm text-gray-600">Instant messaging with live community members</p>
            </div>
            <div className="text-center">
              <Users className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <h3 className="font-semibold mb-1">Business Support</h3>
              <p className="text-sm text-gray-600">Get advice and share knowledge with peers</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}