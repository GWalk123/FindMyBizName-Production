import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Bot, 
  Send, 
  MessageCircle, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Star,
  ThumbsUp,
  ThumbsDown,
  Copy,
  Download
} from "lucide-react";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: string;
  botId?: string;
  sessionId: string;
  metadata?: {
    confidence?: number;
    sources?: string[];
    suggestedActions?: string[];
  };
}

interface SupportBot {
  id: string;
  name: string;
  description: string;
  specialty: string;
  avatar: string;
  status: 'online' | 'busy' | 'offline';
  responseTime: string;
  accuracy: number;
  totalChats: number;
  languages: string[];
}

interface ChatSession {
  id: string;
  botId: string;
  status: 'active' | 'resolved' | 'escalated';
  startTime: string;
  lastMessage: string;
  messageCount: number;
  rating?: number;
}

export default function BizBotz() {
  const [selectedBot, setSelectedBot] = useState<string>("");
  const [currentMessage, setCurrentMessage] = useState("");
  const [chatSessions, setChatSessions] = useState<Record<string, ChatMessage[]>>({});
  const [activeSession, setActiveSession] = useState<string>("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: supportBots = [], isLoading: botsLoading, error: botsError } = useQuery<SupportBot[]>({
    queryKey: ["/api/support-bots"],
    retry: 3,
    refetchOnWindowFocus: false,
    staleTime: 5 * 60 * 1000,
    select: (data) => {
      console.log('Raw API response:', data);
      console.log('Data length:', data?.length);
      console.log('Data type:', typeof data);
      return Array.isArray(data) ? data : [];
    }
  });

  const { data: sessions = [], isLoading: sessionsLoading } = useQuery<ChatSession[]>({
    queryKey: ["/api/chat-sessions"],
  });

  const { data: messages = [], isLoading: messagesLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat-messages", activeSession],
    enabled: !!activeSession,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async ({ botId, message, sessionId }: { botId: string; message: string; sessionId?: string }) => {
      return await apiRequest("POST", "/api/support-bots/chat", { 
        botId, 
        message, 
        sessionId 
      });
    },
    onSuccess: (response) => {
      const data = response as any; // Type assertion for API response
      queryClient.invalidateQueries({ queryKey: ["/api/chat-messages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions"] });
      setCurrentMessage("");
      
      // Update local state immediately for better UX
      const newMessages = [
        { id: `user-${Date.now()}`, type: 'user' as const, content: currentMessage, timestamp: new Date().toISOString(), sessionId: data.sessionId },
        { id: `bot-${Date.now()}`, type: 'bot' as const, content: data.response, timestamp: new Date().toISOString(), sessionId: data.sessionId, botId: selectedBot, metadata: data.metadata }
      ];
      
      setChatSessions(prev => ({
        ...prev,
        [data.sessionId]: [...(prev[data.sessionId] || []), ...newMessages]
      }));
      
      if (!activeSession) {
        setActiveSession(data.sessionId);
      }
    },
    onError: (error) => {
      toast({
        title: "Message Failed",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const rateSessionMutation = useMutation({
    mutationFn: async ({ sessionId, rating, feedback }: { sessionId: string; rating: number; feedback?: string }) => {
      return await apiRequest("POST", `/api/chat-sessions/${sessionId}/rate`, { rating, feedback });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions"] });
      toast({
        title: "Rating Submitted",
        description: "Thank you for your feedback!",
      });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatSessions[activeSession]]);

  const handleSendMessage = () => {
    console.log('Sending message:', currentMessage, 'to bot:', selectedBot);
    if (!currentMessage.trim() || !selectedBot) {
      console.log('Message blocked - empty message or no bot selected');
      return;
    }
    
    sendMessageMutation.mutate({
      botId: selectedBot,
      message: currentMessage,
      sessionId: activeSession || undefined
    });
  };

  const startNewChat = (botId: string) => {
    console.log('Starting new chat with bot:', botId);
    setSelectedBot(botId);
    setActiveSession("");
    setCurrentMessage("");
  };

  const getBotStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-100 text-green-800';
      case 'busy': return 'bg-yellow-100 text-yellow-800';
      case 'offline': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const currentMessages = activeSession ? (chatSessions[activeSession] || messages) : [];
  const selectedBotData = supportBots.find(bot => bot.id === selectedBot);
  
  // Debug logging
  console.log('Support Bots:', supportBots);
  console.log('Selected Bot:', selectedBot);
  console.log('Active Session:', activeSession);
  console.log('Current Messages:', currentMessages);

  if (botsLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="h-96 bg-gray-200 rounded-lg"></div>
            <div className="lg:col-span-2 h-96 bg-gray-200 rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Biz Botz 🤖
        </h1>
        <p className="text-gray-600">
          AI-powered customer support available 24/7 for all your business questions
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Bot Selection Sidebar */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold mb-4">Available Support Bots</h3>
          
          {supportBots.map((bot) => (
            <Card 
              key={bot.id} 
              className={`cursor-pointer transition-all ${
                selectedBot === bot.id ? 'ring-2 ring-primary border-primary' : 'hover:shadow-md'
              }`}
              onClick={() => startNewChat(bot.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-superman-blue rounded-full flex items-center justify-center">
                      <Bot className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{bot.name}</CardTitle>
                      <CardDescription className="text-sm">{bot.specialty}</CardDescription>
                    </div>
                  </div>
                  <Badge className={getBotStatusColor(bot.status)}>
                    {bot.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{bot.description}</p>
                
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>~{bot.responseTime} response</span>
                  <span>{bot.accuracy}% accuracy</span>
                </div>
                
                <div className="flex items-center gap-1 mt-2">
                  <Star className="h-3 w-3 text-yellow-500 fill-current" />
                  <span className="text-xs text-gray-600">{bot.totalChats} chats</span>
                </div>
                
                <div className="flex flex-wrap gap-1 mt-2">
                  {bot.languages.slice(0, 3).map((lang, index) => (
                    <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                      {lang}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}

          {/* Recent Sessions */}
          {sessions.length > 0 && (
            <div className="mt-6">
              <h4 className="text-md font-medium mb-3">Recent Chats</h4>
              <div className="space-y-2">
                {sessions.slice(0, 5).map((session) => (
                  <div
                    key={session.id}
                    className={`p-3 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                      activeSession === session.id ? 'bg-blue-50 border-blue-200' : ''
                    }`}
                    onClick={() => setActiveSession(session.id)}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">
                        {supportBots.find(b => b.id === session.botId)?.name || 'Bot'}
                      </span>
                      <Badge variant={session.status === 'resolved' ? 'default' : 'secondary'}>
                        {session.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600 line-clamp-1">{session.lastMessage}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-gray-500">
                        {formatTime(session.startTime)}
                      </span>
                      <span className="text-xs text-gray-500">
                        {session.messageCount} messages
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Chat Interface */}
        <div className="lg:col-span-2">
          <Card className="h-[600px] flex flex-col">
            {selectedBot ? (
              <>
                {/* Chat Header */}
                <CardHeader className="border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                        <Bot className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{selectedBotData?.name}</h4>
                        <p className="text-sm text-gray-600">{selectedBotData?.specialty}</p>
                      </div>
                    </div>
                    <Badge className={getBotStatusColor(selectedBotData?.status || 'offline')}>
                      {selectedBotData?.status}
                    </Badge>
                  </div>
                </CardHeader>

                {/* Messages */}
                <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                  {currentMessages.length === 0 && (
                    <div className="text-center py-8">
                      <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        Start a conversation
                      </h3>
                      <p className="text-gray-600">
                        Ask me anything about your business needs. I'm here to help!
                      </p>
                    </div>
                  )}

                  {currentMessages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          message.type === 'user'
                            ? 'bg-primary text-white'
                            : 'bg-gray-100 text-gray-900'
                        }`}
                      >
                        <p className="text-sm">{message.content}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className={`text-xs ${
                            message.type === 'user' ? 'text-primary-100' : 'text-gray-500'
                          }`}>
                            {formatTime(message.timestamp)}
                          </span>
                          
                          {message.type === 'bot' && message.metadata?.confidence && (
                            <span className="text-xs text-gray-500">
                              {Math.round(message.metadata.confidence * 100)}% confidence
                            </span>
                          )}
                        </div>
                        
                        {message.type === 'bot' && message.metadata?.suggestedActions && (
                          <div className="mt-2 space-y-1">
                            {message.metadata.suggestedActions.map((action, index) => (
                              <Button
                                key={index}
                                size="sm"
                                variant="outline"
                                className="text-xs h-6"
                                onClick={() => setCurrentMessage(action)}
                              >
                                {action}
                              </Button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  
                  {sendMessageMutation.isPending && (
                    <div className="flex justify-start">
                      <div className="bg-gray-100 rounded-lg p-3">
                        <div className="flex items-center space-x-2">
                          <div className="animate-pulse flex space-x-1">
                            <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                          </div>
                          <span className="text-sm text-gray-600">Thinking...</span>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div ref={messagesEndRef} />
                </CardContent>

                {/* Message Input */}
                <div className="border-t p-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your message..."
                      value={currentMessage}
                      onChange={(e) => setCurrentMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      disabled={sendMessageMutation.isPending}
                    />
                    <Button 
                      onClick={handleSendMessage}
                      disabled={!currentMessage.trim() || sendMessageMutation.isPending}
                      size="sm"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                    <span>Press Enter to send</span>
                    <span>Response time: ~{selectedBotData?.responseTime}</span>
                  </div>
                </div>
              </>
            ) : (
              <CardContent className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Select a Support Bot
                  </h3>
                  <p className="text-gray-600">
                    Choose a specialized bot from the sidebar to start getting help with your business questions.
                  </p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>

      {/* Back to Home */}
      <div className="mt-8 text-center">
        <Link href="/">
          <Button variant="outline">
            ← Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}