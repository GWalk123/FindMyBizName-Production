import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Code, Key, Zap, Shield, BookOpen, ExternalLink } from "lucide-react";
import SEOHead from "@/components/seo-head";

export default function API() {
  const endpoints = [
    {
      method: "POST",
      endpoint: "/api/generate-names",
      description: "Generate business names with domain checking",
      parameters: [
        { name: "description", type: "string", required: true, description: "Business description" },
        { name: "industry", type: "string", required: true, description: "Industry category" },
        { name: "style", type: "string", required: true, description: "Name style preference" },
        { name: "includeSynonyms", type: "boolean", required: false, description: "Include synonym variations" },
        { name: "checkDomains", type: "boolean", required: false, description: "Check domain availability" }
      ],
      response: {
        names: "GeneratedName[]",
        remainingUsage: "number"
      }
    },
    {
      method: "GET",
      endpoint: "/api/user",
      description: "Get current user information and usage",
      parameters: [],
      response: {
        id: "number",
        username: "string",
        plan: "string",
        usageToday: "number",
        usageLimit: "number",
        remainingUsage: "number"
      }
    },
    {
      method: "POST",
      endpoint: "/api/favorites/toggle",
      description: "Add or remove a name from favorites",
      parameters: [
        { name: "nameId", type: "number", required: true, description: "Generated name ID" }
      ],
      response: {
        success: "boolean",
        isFavorite: "boolean"
      }
    },
    {
      method: "GET",
      endpoint: "/api/favorites",
      description: "Get user's favorite names",
      parameters: [],
      response: {
        favorites: "GeneratedName[]"
      }
    }
  ];

  const rateLimits = [
    { plan: "Free", requests: "100/hour", burst: "10/minute" },
    { plan: "Premium", requests: "1,000/hour", burst: "50/minute" },
    { plan: "Pro", requests: "10,000/hour", burst: "200/minute" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <SEOHead 
        title="API Documentation - FindMyBizName Developer Access"
        description="Integrate FindMyBizName's AI business name generation into your applications. RESTful API with real-time domain checking and Caribbean market optimization."
      />
      
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4" variant="outline">
            <Code className="w-4 h-4 mr-2" />
            Developer API
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            FindMyBizName API
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Integrate powerful AI business name generation and domain checking 
            directly into your applications with our RESTful API.
          </p>
        </div>

        {/* Quick Start */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5" />
              Quick Start
            </CardTitle>
            <CardDescription>
              Get up and running with the FindMyBizName API in minutes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-600 dark:text-blue-400 font-bold">1</span>
                </div>
                <h3 className="font-semibold mb-2">Get API Key</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Sign up for Premium or Pro plan to receive your API key
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-600 dark:text-blue-400 font-bold">2</span>
                </div>
                <h3 className="font-semibold mb-2">Make Request</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Send authenticated requests to our endpoints
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-blue-600 dark:text-blue-400 font-bold">3</span>
                </div>
                <h3 className="font-semibold mb-2">Build Amazing</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Create powerful naming tools for your users
                </p>
              </div>
            </div>
            <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4">
              <h4 className="font-semibold mb-2">Base URL</h4>
              <code className="text-sm">https://opportunity-hunter-gregorywalker76.replit.app/api</code>
            </div>
          </CardContent>
        </Card>

        {/* Authentication */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="w-5 h-5" />
              Authentication
            </CardTitle>
            <CardDescription>
              Secure your API requests with bearer token authentication
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="curl" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="curl">cURL</TabsTrigger>
                <TabsTrigger value="javascript">JavaScript</TabsTrigger>
                <TabsTrigger value="python">Python</TabsTrigger>
              </TabsList>
              <TabsContent value="curl">
                <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4">
                  <pre className="text-sm overflow-x-auto">
{`curl -X POST https://opportunity-hunter-gregorywalker76.replit.app/api/generate-names \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "description": "Modern coffee shop",
    "industry": "Food & Beverage",
    "style": "Modern & Tech"
  }'`}
                  </pre>
                </div>
              </TabsContent>
              <TabsContent value="javascript">
                <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4">
                  <pre className="text-sm overflow-x-auto">
{`const response = await fetch('https://opportunity-hunter-gregorywalker76.replit.app/api/generate-names', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    description: 'Modern coffee shop',
    industry: 'Food & Beverage',
    style: 'Modern & Tech'
  })
});

const data = await response.json();`}
                  </pre>
                </div>
              </TabsContent>
              <TabsContent value="python">
                <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4">
                  <pre className="text-sm overflow-x-auto">
{`import requests

headers = {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
}

data = {
    'description': 'Modern coffee shop',
    'industry': 'Food & Beverage',
    'style': 'Modern & Tech'
}

response = requests.post(
    'https://opportunity-hunter-gregorywalker76.replit.app/api/generate-names',
    headers=headers,
    json=data
)`}
                  </pre>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Endpoints */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle>API Endpoints</CardTitle>
            <CardDescription>
              Complete reference for all available endpoints
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {endpoints.map((endpoint, index) => (
                <div key={index} className="border rounded-lg p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Badge variant={endpoint.method === "GET" ? "default" : "secondary"}>
                      {endpoint.method}
                    </Badge>
                    <code className="text-sm bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                      {endpoint.endpoint}
                    </code>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">{endpoint.description}</p>
                  
                  {endpoint.parameters.length > 0 && (
                    <div className="mb-4">
                      <h4 className="font-semibold mb-2">Parameters</h4>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left py-2">Name</th>
                              <th className="text-left py-2">Type</th>
                              <th className="text-left py-2">Required</th>
                              <th className="text-left py-2">Description</th>
                            </tr>
                          </thead>
                          <tbody>
                            {endpoint.parameters.map((param, i) => (
                              <tr key={i} className="border-b">
                                <td className="py-2 font-mono">{param.name}</td>
                                <td className="py-2">{param.type}</td>
                                <td className="py-2">{param.required ? "Yes" : "No"}</td>
                                <td className="py-2">{param.description}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                  
                  <div>
                    <h4 className="font-semibold mb-2">Response</h4>
                    <div className="bg-gray-100 dark:bg-gray-800 rounded p-3">
                      <pre className="text-sm">
                        {JSON.stringify(endpoint.response, null, 2)}
                      </pre>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Rate Limits */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Rate Limits
            </CardTitle>
            <CardDescription>
              API usage limits by subscription plan
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3">Plan</th>
                    <th className="text-left py-3">Requests/Hour</th>
                    <th className="text-left py-3">Burst Limit</th>
                  </tr>
                </thead>
                <tbody>
                  {rateLimits.map((limit, index) => (
                    <tr key={index} className="border-b">
                      <td className="py-3 font-semibold">{limit.plan}</td>
                      <td className="py-3">{limit.requests}</td>
                      <td className="py-3">{limit.burst}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-4 p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                <strong>Note:</strong> Rate limits are enforced per API key. 
                Contact us for enterprise plans with higher limits.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* SDKs and Libraries */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              SDKs & Libraries
            </CardTitle>
            <CardDescription>
              Official and community-maintained libraries
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="border rounded-lg p-4">
                <h4 className="font-semibold mb-2">JavaScript/Node.js</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                  Official SDK for JavaScript and Node.js applications
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  Contact Sales
                </Button>
              </div>
              <div className="border rounded-lg p-4">
                <h4 className="font-semibold mb-2">Python</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                  Python SDK for easy integration
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  Contact Sales
                </Button>
              </div>
              <div className="border rounded-lg p-4">
                <h4 className="font-semibold mb-2">PHP</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                  PHP library for web applications
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  Contact Sales
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardContent className="text-center py-12">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Build with Our API?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Get your API key and start integrating today
            </p>
            <div className="space-x-4">
              <Button size="lg" variant="secondary">
                Get API Key
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-blue-600">
                <ExternalLink className="w-4 h-4 mr-2" />
                View Examples
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}