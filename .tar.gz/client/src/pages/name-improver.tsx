import NameImprover from "@/components/name-improver";


export default function NameImproverPage() {
  return (
    <>
      
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 py-8 pt-56 md:pt-8">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Get Better Business Name Suggestions
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Your business is only as good as its name. Enter your current name and discover 
              professionally improved alternatives with higher market appeal.
            </p>
          </div>
          
          <NameImprover />
          
          <div className="mt-12 text-center">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-2xl font-semibold mb-6 text-gray-800">
                Why Better Names Matter
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold text-lg mb-2 text-purple-600">First Impressions</h3>
                  <p className="text-gray-600">Your name is the first thing customers see. Make it count with professional, memorable branding.</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold text-lg mb-2 text-purple-600">Market Appeal</h3>
                  <p className="text-gray-600">Names optimized for Caribbean markets build instant trust and cultural connection.</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <h3 className="font-semibold text-lg mb-2 text-purple-600">Growth Ready</h3>
                  <p className="text-gray-600">Future-proof names that scale with your business and adapt to market changes.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}