import { GoDaddyDomainChecker } from '@/components/godaddy-domain-checker';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function GoDaddyTest() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            GoDaddy API Integration Test
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2">
            Test your GoDaddy API credentials and domain checking functionality
          </p>
        </div>

        <GoDaddyDomainChecker />

        <Card>
          <CardHeader>
            <CardTitle>Setup Instructions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 dark:text-blue-200 mb-2">
                Environment Variables Required:
              </h4>
              <ul className="text-sm text-blue-800 dark:text-blue-300 space-y-1">
                <li>• <code className="bg-blue-100 dark:bg-blue-800 px-1 rounded">GODADDY_API_KEY</code> - Your GoDaddy API key</li>
                <li>• <code className="bg-blue-100 dark:bg-blue-800 px-1 rounded">GODADDY_API_SECRET</code> - Your GoDaddy API secret</li>
                <li>• <code className="bg-blue-100 dark:bg-blue-800 px-1 rounded">GODADDY_ENVIRONMENT=ote</code> - Test environment</li>
              </ul>
            </div>

            <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
              <h4 className="font-medium text-yellow-900 dark:text-yellow-200 mb-2">
                OTE Test Environment:
              </h4>
              <ul className="text-sm text-yellow-800 dark:text-yellow-300 space-y-1">
                <li>• All domain checks are simulated (test data)</li>
                <li>• No real domain purchases will occur</li>
                <li>• Perfect for development and testing</li>
                <li>• Request production access after testing</li>
              </ul>
            </div>

            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
              <h4 className="font-medium text-green-900 dark:text-green-200 mb-2">
                Integration Benefits:
              </h4>
              <ul className="text-sm text-green-800 dark:text-green-300 space-y-1">
                <li>• Direct registrar access (no third-party delays)</li>
                <li>• Real-time domain availability checking</li>
                <li>• Revenue opportunity through domain sales</li>
                <li>• One-click domain purchase integration</li>
                <li>• Replace expensive Domainr API costs</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}