import Header from "@/components/header";
import NameGenerator from "@/components/name-generator";
import GeneratedNames from "@/components/generated-names";
import Sidebar from "@/components/sidebar";
import PricingSection from "@/components/pricing-section";
import Footer from "@/components/footer";
import LogoPreviewModal from "@/components/logo-preview-modal";
import UpgradeModal from "@/components/upgrade-modal";
import LiveDomainChecker from "@/components/live-domain-checker";
import NameScorer from "@/components/name-scorer";
import SEOHead from "@/components/seo-head";
import AnalyticsTracker, { useAnalytics } from "@/components/analytics-tracker";
import { LimitReachedBanner, SocialProof, TestimonialBanner, UpgradePrompt } from "@/components/conversion-optimization";
import { UrgencyBanner, TrustSignals, CallToActionSection, MoneyBackGuarantee, LocalBusinessFocus } from "@/components/marketing-features";
import { useConversionTracking } from "@/hooks/use-conversion-tracking";
// import { CommunityChat } from "@/components/community-chat";

import LaunchAnalytics from "@/components/launch-analytics";
import LaunchCountdown from "@/components/launch-countdown";
import PerformanceMonitor from "@/components/performance-monitor";
import DeploymentReadyBanner from "@/components/deployment-ready-banner";
import CRMSection from "@/components/crm-section";
import InvoiceGenerator from "@/components/invoice-generator";
import AIGenerationOverlay from "@/components/ai-generation-overlay";
import { useState, useEffect } from "react";
import { type GeneratedNameWithDomains } from "@shared/schema";
import { useStaggeredLoading } from "@/hooks/use-staggered-loading";
import { LoadingProgress } from "@/components/loading-progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, Users, Globe, TrendingUp, Volume2, Crown, FileText, UserCheck, BarChart3, Zap } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const [generatedNames, setGeneratedNames] = useState<GeneratedNameWithDomains[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedName, setSelectedName] = useState<string | null>(null);
  const [showLogoModal, setShowLogoModal] = useState(false);
  const [showUpgradePrompt, setShowUpgradePrompt] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<'naming' | 'crm' | 'invoicing' | 'analytics'>('naming');
  const [showAIOverlay, setShowAIOverlay] = useState(false);
  const { trackPageView, trackNameGeneration } = useAnalytics();
  
  // Staggered loading system
  const { registerComponent, isComponentReady, getLoadingProgress, loadingState } = useStaggeredLoading();
  
  // Register components with priority levels
  registerComponent('core-ui', { priority: 0 }); // Load immediately
  registerComponent('name-generator', { priority: 1 }); // 500ms delay  
  registerComponent('domain-checker', { priority: 2 }); // 1000ms delay
  registerComponent('analytics', { priority: 3 }); // 1500ms delay
  registerComponent('performance-monitor', { priority: 4 }); // 2000ms delay
  
  // Enhanced conversion tracking
  const {
    trackEvent,
    showUpgradeModal,
    setShowUpgradeModal,
    upgradeTrigger,
    triggerExportUpgrade,
    triggerDomainUpgrade,
    triggerLogoUpgrade,
    userStats
  } = useConversionTracking();

  useEffect(() => {
    try {
      trackPageView('home');
    } catch (error) {
      console.warn('Analytics tracking error:', error);
    }
  }, [trackPageView]);

  const handleNamesGenerated = (names: GeneratedNameWithDomains[]) => {
    console.log('Home: handleNamesGenerated called with:', names?.length, 'names');
    console.log('First name:', names?.[0]?.name);
    setGeneratedNames(names || []);
    setShowAIOverlay(false); // Hide overlay when names are ready
    
    if (names.length > 0) {
      trackNameGeneration(names[0].industry || 'unknown', names[0].style || 'unknown');
      trackEvent('generation', { count: names.length, industry: names[0].industry });
    }
  };
  
  const handleGenerationStart = () => {
    setShowAIOverlay(true);
  };

  const handlePreviewLogo = (name: string) => {
    setSelectedName(name);
    setShowLogoModal(true);
    trackEvent('logo_preview', { name });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <SEOHead 
        title="FindMyBizName - The Essential Business Toolkit for Sole Traders, SMEs and Underbanked Entrepreneurs Worldwide"
        description="The Essential Business Toolkit for 430.5 Million Underbanked Entrepreneurs Worldwide with $5T Purchasing Power. AI naming, domain checking, CRM, invoicing, and payment systems designed for cash-based economies."
        keywords="business operating system, underbanked entrepreneurs, cash-based economy, business platform, AI naming, domain checker, CRM, invoicing, Trinidad Tobago, Caribbean business tools"
      />
      <LoadingProgress 
        progress={getLoadingProgress()} 
        loadingState={loadingState}
      />
      <AnalyticsTracker />
      <Header />
      
      {/* SUPERMAN HERO BANNER - FORCED CACHE BREAK */}
      <div 
        className="text-white py-8" 
        style={{ 
          marginTop: '64px',
          background: 'linear-gradient(45deg, #0040FF 0%, #FF0000 100%)',
          boxShadow: '0 4px 20px rgba(255, 215, 0, 0.3)'
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 
            className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-black tracking-tight leading-tight"
            style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}
          >
THE ESSENTIAL BUSINESS TOOLKIT FOR SOLE TRADERS, SMEs AND UNDERBANKED ENTREPRENEURS WORLDWIDE
          </h1>
          <p 
            className="mt-2 text-sm sm:text-base md:text-lg font-bold"
            style={{ 
              color: '#FFD700',
              textShadow: '1px 1px 2px rgba(0,0,0,0.7)',
              fontSize: '1.25rem'
            }}
          >
            Your business is only as good as its name
          </p>
        </div>
      </div>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Deployment Ready Banner */}
        <DeploymentReadyBanner />
        
        {/* Launch Countdown */}
        <LaunchCountdown />
        
        {/* Professional Platform Display */}
        
        {/* Urgency Banner */}
        <UrgencyBanner />

        {/* Local Business Focus */}
        <LocalBusinessFocus />

        {/* Social Proof */}
        <SocialProof className="mb-8" />

        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="mb-4">
            <span 
              className="inline-block px-4 py-2 rounded-full text-sm font-bold mb-4"
              style={{ 
                background: '#FFD700',
                color: '#DC143C',
                border: '2px solid #0040FF',
                boxShadow: '0 2px 10px rgba(255, 215, 0, 0.5)'
              }}
            >
              🦸‍♂️ The First Global Solution for Underbanked Entrepreneur Tools 🦸‍♂️
            </span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Complete Business Platform for Underbanked Entrepreneurs
          </h1>
          <p className="text-xl text-gray-600 mb-4 max-w-3xl mx-auto">
            AI-powered naming, domain checking, CRM, invoicing, and payment systems designed specifically for cash-based economies and underbanked entrepreneurs worldwide.
          </p>
          <div className="mb-6">
            <p className="text-lg font-semibold text-blue-600 italic">
              "I'm not only the founder. I'm also an Underbanked Entrepreneur."
            </p>
            <p className="text-sm text-gray-500 mt-1">
              - Built by founders who understand your challenges
            </p>
          </div>
          <div className="border-2 rounded-lg p-6 max-w-3xl mx-auto mb-8 shadow-lg" style={{ 
            background: 'linear-gradient(135deg, hsl(48, 100%, 55%) 0%, hsl(0, 85%, 45%) 100%)', 
            borderColor: 'hsl(48, 100%, 45%)',
            boxShadow: '0 8px 32px hsla(220, 100%, 40%, 0.2)'
          }}>
            <div className="text-center">
              <div className="flex items-center justify-center space-x-6 mb-3">
                <div className="px-3 py-1 rounded-full" style={{ 
                  backgroundColor: 'hsl(220, 100%, 35%)',
                  color: 'white',
                  boxShadow: '0 4px 15px hsla(220, 100%, 35%, 0.3)'
                }}>
                  <span className="font-semibold text-sm">🇹🇹 Trinidad & Tobago Built</span>
                </div>
                <div className="px-3 py-1 rounded-full" style={{ 
                  backgroundColor: 'hsl(0, 85%, 40%)',
                  color: 'white',
                  boxShadow: '0 4px 15px hsla(0, 85%, 40%, 0.3)'
                }}>
                  <span className="font-semibold text-sm">💳 Local Payment Support</span>
                </div>
              </div>
              <p className="text-gray-800 font-medium">
                Pay with T&T Debit Cards, WiPay, Bank Transfer, or Mobile Money - No Credit Card Required!
              </p>
              <p className="text-sm text-gray-600 mt-2">
                Perfect for Caribbean businesses with global domain availability
              </p>
            </div>
          </div>
        </div>

        {/* New Features Banner */}
        <div className="border-2 rounded-lg p-6 max-w-5xl mx-auto mb-8 shadow-lg" style={{ 
          background: 'linear-gradient(135deg, hsl(220, 100%, 40%) 0%, hsl(0, 85%, 45%) 50%, hsl(48, 100%, 55%) 100%)', 
          borderColor: 'hsl(220, 100%, 35%)',
          boxShadow: '0 12px 40px hsla(220, 100%, 40%, 0.25)'
        }}>
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              <Crown className="w-6 h-6 text-white mr-2" />
              <h3 className="text-xl font-bold text-white">NEW: Premium Brand Analysis Suite</h3>
              <Badge className="ml-2" style={{ 
                backgroundColor: 'hsl(48, 100%, 55%)', 
                color: 'black',
                border: '2px solid hsl(48, 100%, 45%)'
              }}>Just Released</Badge>
            </div>
            <p className="text-white mb-4 font-semibold">
              Go beyond basic name generation with our enterprise-level analysis tools
            </p>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
              <div className="flex flex-col items-center">
                <Users className="w-8 h-8 text-white mb-1" />
                <span className="text-sm font-semibold text-white">Social Media</span>
                <span className="text-xs text-gray-200">Handle Checker</span>
              </div>
              <div className="flex flex-col items-center">
                <Star className="w-8 h-8 text-purple-600 mb-1" />
                <span className="text-sm font-semibold text-purple-800">Brand Sentiment</span>
                <span className="text-xs text-purple-600">Analysis</span>
              </div>
              <div className="flex flex-col items-center">
                <Volume2 className="w-8 h-8 text-purple-600 mb-1" />
                <span className="text-sm font-semibold text-purple-800">Pronunciation</span>
                <span className="text-xs text-purple-600">Scoring</span>
              </div>
              <div className="flex flex-col items-center">
                <TrendingUp className="w-8 h-8 text-purple-600 mb-1" />
                <span className="text-sm font-semibold text-purple-800">SEO</span>
                <span className="text-xs text-purple-600">Optimization</span>
              </div>
              <div className="flex flex-col items-center">
                <Globe className="w-8 h-8 text-purple-600 mb-1" />
                <span className="text-sm font-semibold text-purple-800">Competitor</span>
                <span className="text-xs text-purple-600">Analysis</span>
              </div>
            </div>
            <Link href="/brand-analysis">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                Try Brand Analysis Suite
              </Button>
            </Link>
          </div>
        </div>

        {/* Trust Signals */}
        <TrustSignals />

        {/* Testimonial Banner */}
        <TestimonialBanner />

        {/* Usage Limit Banner */}
        <LimitReachedBanner remainingUsage={userStats.remainingUsage} />

        {/* Business Tools Navigation */}
        <div className="max-w-6xl mx-auto mb-8">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold text-center mb-6">Complete Business Platform</h2>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                variant={activeSection === 'naming' ? 'default' : 'outline'}
                onClick={() => setActiveSection('naming')}
                className="flex items-center gap-2"
              >
                <Zap className="w-4 h-4" />
                Business Naming
              </Button>
              <Button
                variant={activeSection === 'crm' ? 'default' : 'outline'}
                onClick={() => setActiveSection('crm')}
                className="flex items-center gap-2"
              >
                <UserCheck className="w-4 h-4" />
                Customer CRM
              </Button>
              <Button
                variant={activeSection === 'invoicing' ? 'default' : 'outline'}
                onClick={() => setActiveSection('invoicing')}
                className="flex items-center gap-2"
              >
                <FileText className="w-4 h-4" />
                Smart Invoicing
              </Button>
              <Button
                variant={activeSection === 'analytics' ? 'default' : 'outline'}
                onClick={() => setActiveSection('analytics')}
                className="flex items-center gap-2"
              >
                <BarChart3 className="w-4 h-4" />
                Business Analytics
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {activeSection === 'naming' && (
              <>
                <NameGenerator 
                  onNamesGenerated={handleNamesGenerated}
                  isLoading={isLoading}
                  setIsLoading={setIsLoading}
                  onGenerationStart={handleGenerationStart}
                />
                
                {generatedNames.length > 0 && (
                  <>
                    <NameScorer names={generatedNames} />
                    <GeneratedNames 
                      names={generatedNames}
                      onPreviewLogo={handlePreviewLogo}
                    />
                  </>
                )}
                
                {isComponentReady('domain-checker') && <LiveDomainChecker />}
              </>
            )}

            {activeSection === 'crm' && <CRMSection />}
            
            {activeSection === 'invoicing' && <InvoiceGenerator />}
            
            {activeSection === 'analytics' && (
              <div className="bg-white rounded-lg shadow-md p-8 text-center">
                <BarChart3 className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Business Analytics Dashboard</h3>
                <p className="text-gray-600 mb-4">
                  Track your business performance, revenue trends, and growth metrics
                </p>
                <Badge className="bg-green-100 text-green-800 mb-4">Ready for Pro Users</Badge>
                <p className="text-sm text-gray-500">
                  Visual dashboards with cash flow forecasting, expense tracking, and performance insights
                </p>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Sidebar />
          </div>
        </div>

        {/* Pricing Section */}
        <PricingSection />

        {/* Call to Action Section */}
        <CallToActionSection />

        {/* Money Back Guarantee */}
        <MoneyBackGuarantee className="mb-8" />
      </main>

      <Footer />

      {/* Logo Preview Modal */}
      {showLogoModal && selectedName && (
        <LogoPreviewModal
          businessName={selectedName}
          isOpen={showLogoModal}
          onClose={() => setShowLogoModal(false)}
        />
      )}

      {/* Upgrade Prompts */}
      {showUpgradePrompt && (
        <UpgradePrompt
          trigger={showUpgradePrompt as any}
          onClose={() => setShowUpgradePrompt(null)}
        />
      )}

      {/* Smart Upgrade Modal */}
      <UpgradeModal
        isOpen={showUpgradeModal}
        onClose={() => setShowUpgradeModal(false)}
        feature={upgradeTrigger === 'export_attempt' ? 'nameImprovement' : 'brandAnalysis'}
        usageRemaining={userStats.remainingUsage}
      />

      {/* Community Chat Widget - Temporarily disabled to fix preview */}
      {/* <CommunityChat /> */}
      
      {/* Launch Analytics Dashboard */}
      {isComponentReady('analytics') && <LaunchAnalytics />}
      
      {/* Performance Monitor */}
      {isComponentReady('performance-monitor') && <PerformanceMonitor />}
      
      {/* AI Generation Overlay */}
      <AIGenerationOverlay 
        isVisible={showAIOverlay}
        onComplete={() => setShowAIOverlay(false)}
      />
    </div>
  );
}
