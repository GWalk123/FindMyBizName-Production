import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Star, Zap, Crown } from "lucide-react";
import SEOHead from "@/components/seo-head";
import PayPalButton from "@/components/paypal-button";
import { useState } from "react";

export default function Pricing() {
  const [showPayment, setShowPayment] = useState<string | null>(null);

  const plans = [
    {
      name: "Freemium",
      price: "$0",
      period: "forever",
      description: "Test our platform quality",
      icon: <Zap className="w-6 h-6" />,
      features: [
        "10 business name generations per month",
        "Basic domain checking (.com only)",
        "Community chat access",
        "Basic name styles",
        "Email support"
      ],
      limitations: [
        "Limited monthly generations",
        "No business tools access",
        "Basic support only"
      ],
      cta: "Get Started Free",
      current: true
    },
    {
      name: "Premium",
      price: "$9.99",
      period: "per month",
      description: "Unlimited naming + premium domains",
      icon: <Star className="w-6 h-6" />,
      features: [
        "Unlimited name generations",
        "Premium domains (.ai, .co, .io)",
        "Brand analysis suite",
        "PDF export & favorites",
        "Priority email support",
        "Social media handle checker"
      ],
      cta: "Start Premium Plan",
      trialDays: 7
    },
    {
      name: "Pro",
      price: "$19.99",
      period: "per month",
      description: "Complete business platform",
      icon: <Crown className="w-6 h-6" />,
      popular: true,
      features: [
        "Everything in Premium",
        "CRM with WhatsApp integration",
        "Invoice generator with QR codes",
        "Business Intelligence (SEC data)",
        "Advanced domain checking (50+ TLDs)",
        "Name improvement suggestions"
      ],
      cta: "Start Pro Plan",
      trialDays: 7,
      cryptoFriendly: true
    },
    {
      name: "Professional",
      price: "$29.99",
      period: "per month",
      description: "Complete business platform",
      icon: <Crown className="w-6 h-6" />,
      features: [
        "Everything in Growth",
        "Business Intelligence (SEC data)",
        "Advanced analytics dashboard",
        "Premium domain checking (50+ TLDs)",
        "Email marketing automation"
      ],
      cta: "Start Professional"
    },
    {
      name: "Business",
      price: "$59.99",
      period: "per month",
      description: "Team collaboration tools",
      icon: <Crown className="w-6 h-6" />,
      features: [
        "Everything in Professional",
        "Advanced Analytics Dashboard",
        "Multi-user team access",
        "Email marketing automation",
        "Priority phone support"
      ],
      cta: "Start Business Plan"
    },
    {
      name: "Premium",
      price: "$99.99",
      period: "per month",
      description: "White-label solutions",
      icon: <Crown className="w-6 h-6" />,
      features: [
        "Everything in Business",
        "White-label customization",
        "API access and integrations",
        "Custom domain branding",
        "Dedicated account manager"
      ],
      cta: "Start Premium Plan"
    },
    {
      name: "Enterprise",
      price: "$149",
      period: "per month",
      description: "Enterprise-grade platform",
      icon: <Crown className="w-6 h-6" />,
      features: [
        "Everything in Premium",
        "Unlimited team members",
        "Custom integrations & APIs",
        "Advanced security & compliance",
        "24/7 priority support",
        "White-label customization",
        "Dedicated account manager",
        "Custom training sessions"
      ],
      cta: "Contact Sales"
    }
  ];

  const faqs = [
    {
      q: "Can I cancel anytime?",
      a: "Yes! You can cancel your subscription anytime from your PayPal account. No questions asked."
    },
    {
      q: "Is PayPal available in Trinidad & Tobago?",
      a: "Absolutely! FindMyBizName is specifically optimized for PayPal payments in Trinidad & Tobago with TTD currency support."
    },
    {
      q: "Do you offer refunds?",
      a: "Yes, we offer a 30-day money-back guarantee. If you're not satisfied, contact us for a full refund."
    },
    {
      q: "What domains can I check?",
      a: "Free users can check .com, .net, .org. Premium users get access to 50+ TLDs including .ai, .co, .app, .dev, and more."
    },
    {
      q: "Is my data secure?",
      a: "Absolutely. We use enterprise-level security with 256-bit SSL encryption and are GDPR compliant."
    },
    {
      q: "Can I upgrade or downgrade?",
      a: "Yes, you can change your plan anytime. Upgrades take effect immediately, downgrades at the next billing cycle."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      {/* Force deployment refresh - Version: July 8, 2025 */}
      <SEOHead 
        title="Pricing - FindMyBizName Plans & Features"
        description="Choose the perfect FindMyBizName plan for your business. Free forever option or premium plans starting at $9.99/month with PayPal support in Trinidad & Tobago."
      />
      
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4" variant="outline">
            <Star className="w-4 h-4 mr-2" />
            30-Day Money Back Guarantee
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Complete Business Platform Pricing
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8">
            Start free and upgrade when you need more power. All plans include 
            our Caribbean-optimized payment integration with global support.
          </p>
          
          {/* Limited Time Offer */}
          <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-lg p-4 mb-8 max-w-md mx-auto">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Zap className="w-5 h-5" />
              <span className="font-semibold">Limited Time: 50% Off Premium!</span>
            </div>
            <p className="text-sm opacity-90">Get unlimited business names for just $4.99/month</p>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, index) => (
            <Card key={index} className={`relative ${plan.popular ? 'border-blue-500 shadow-xl scale-105' : ''}`}>
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500">
                  Most Popular
                </Badge>
              )}
              
              <CardHeader className="text-center">
                <div className="flex items-center justify-center mb-4">
                  <div className={`p-3 rounded-full ${plan.popular ? 'bg-blue-500 text-white' : 'bg-gray-100 dark:bg-gray-800'}`}>
                    {plan.icon}
                  </div>
                </div>
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <CardDescription>{plan.description}</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-gray-500 ml-2">/{plan.period}</span>
                </div>
                {plan.trialDays && (
                  <Badge variant="outline" className="mt-2">
                    {plan.trialDays} days free trial
                  </Badge>
                )}
              </CardHeader>
              
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                {plan.limitations && (
                  <div className="mb-6">
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Limitations:</p>
                    <ul className="space-y-1">
                      {plan.limitations.map((limitation, i) => (
                        <li key={i} className="text-sm text-gray-500 dark:text-gray-500">
                          • {limitation}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <div className="space-y-3">
                  {plan.current ? (
                    <Button className="w-full bg-gray-400" disabled>
                      Current Plan
                    </Button>
                  ) : plan.name === "Freemium" ? (
                    <Button className="w-full">
                      Get Started Free
                    </Button>
                  ) : showPayment === plan.name ? (
                    <div className="space-y-2">
                      <PayPalButton 
                        amount={plan.price.replace('$', '')}
                        currency="USD"
                        intent="CAPTURE"
                        planName={plan.name}
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setShowPayment(null)}
                        className="w-full"
                      >
                        Cancel
                      </Button>
                    </div>
                  ) : (
                    <Button 
                      className={`w-full ${plan.popular ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
                      onClick={() => setShowPayment(plan.name)}
                    >
                      {plan.cta}
                    </Button>
                  )}
                  
                  {plan.cryptoFriendly && (
                    <div className="text-center">
                      <Badge variant="outline" className="bg-orange-50 border-orange-200">
                        🪙 Crypto Payments Available
                      </Badge>
                      <p className="text-xs text-gray-500 mt-1">Bitcoin, Ethereum, USDC, DAI (1% fee)</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Feature Comparison Table */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="text-center">Feature Comparison</CardTitle>
            <CardDescription className="text-center">
              See what's included in each plan
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Feature</th>
                    <th className="text-center py-3 px-4">Free</th>
                    <th className="text-center py-3 px-4">Premium</th>
                    <th className="text-center py-3 px-4">Pro</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-3 px-4">Monthly Generations</td>
                    <td className="text-center py-3 px-4">10</td>
                    <td className="text-center py-3 px-4">Unlimited</td>
                    <td className="text-center py-3 px-4">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Domain TLDs</td>
                    <td className="text-center py-3 px-4">3 basic</td>
                    <td className="text-center py-3 px-4">50+</td>
                    <td className="text-center py-3 px-4">50+</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Logo Previews</td>
                    <td className="text-center py-3 px-4">Basic</td>
                    <td className="text-center py-3 px-4">Advanced</td>
                    <td className="text-center py-3 px-4">Advanced</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">API Access</td>
                    <td className="text-center py-3 px-4">✗</td>
                    <td className="text-center py-3 px-4">✓</td>
                    <td className="text-center py-3 px-4">✓ Enhanced</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Support</td>
                    <td className="text-center py-3 px-4">Email</td>
                    <td className="text-center py-3 px-4">Priority</td>
                    <td className="text-center py-3 px-4">Dedicated</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* FAQ Section */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="text-center">Frequently Asked Questions</CardTitle>
            <CardDescription className="text-center">
              Everything you need to know about our pricing
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              {faqs.map((faq, index) => (
                <div key={index}>
                  <h4 className="font-semibold mb-2">{faq.q}</h4>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">{faq.a}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>



        {/* SUPERMAN CTA SECTION - CACHE BUSTER */}
        <Card 
          className="text-white"
          style={{ 
            background: 'linear-gradient(135deg, #0040FF 0%, #DC143C 100%)',
            border: '3px solid #FFD700'
          }}
        >
          <CardContent className="text-center py-12">
            <h2 className="text-3xl font-bold mb-4" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}>
              🦸‍♂️ Ready to Build Your Business Empire? 🦸‍♂️
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Join 430.5 million underbanked entrepreneurs worldwide with $5T purchasing power building their business dreams
            </p>
            <div className="space-x-4">
              <Button 
                size="lg" 
                style={{ 
                  background: '#FFD700',
                  color: '#000',
                  border: '2px solid #DC143C',
                  fontWeight: 'bold'
                }}
                className="hover:opacity-90"
              >
                ⚡ Start Free Today ⚡
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="text-white border-white hover:bg-white hover:text-blue-600"
                style={{ borderWidth: '2px' }}
              >
                Try Premium Free
              </Button>
            </div>
            <p className="text-sm opacity-75 mt-4">
              No credit card required • Cancel anytime • 30-day money back guarantee
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}