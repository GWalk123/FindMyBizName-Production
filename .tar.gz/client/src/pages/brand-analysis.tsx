import BrandAnalysis from "@/components/brand-analysis";
import SEOHead from "@/components/seo-head";

export default function BrandAnalysisPage() {
  return (
    <>
      <SEOHead
        title="Brand Analysis Suite | FindMyBizName"
        description="Comprehensive brand analysis including social media handle checking, SEO optimization, pronunciation scoring, and competitor analysis for Caribbean businesses."
      />
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-4 py-8 mobile-safe-top md:pt-12">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Brand Analysis Suite
              </h1>
              <p className="text-lg text-gray-600 dark:text-gray-300">
                Get comprehensive insights into your business name with our advanced analysis tools
              </p>
            </div>
            
            <BrandAnalysis />
          </div>
        </div>
      </div>
    </>
  );
}