import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, CreditCard, MessageCircle, Mail, Phone, ArrowLeft } from "lucide-react";
import SEOHead from "@/components/seo-head";

interface Product {
  id: number;
  title: string;
  price: number;
  category: string;
  description: string;
}

export default function PurchaseInstructions() {
  const [, setLocation] = useLocation();
  
  // Get product info from URL params or localStorage
  const urlParams = new URLSearchParams(window.location.search);
  const productData = urlParams.get('product');
  
  let product: Product | null = null;
  if (productData) {
    try {
      product = JSON.parse(decodeURIComponent(productData));
    } catch (e) {
      console.error('Error parsing product data:', e);
    }
  }

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat('en-TT', {
      style: 'currency',
      currency: 'TTD',
      minimumFractionDigits: 0
    }).format(cents / 100);
  };

  const whatsappMessage = product 
    ? `Hi! I'd like to purchase "${product.title}" for ${formatPrice(product.price)}. Please send me payment instructions.`
    : "Hi! I'd like to purchase a digital product from FindMyBizName. Please send me details.";

  const emailSubject = product 
    ? `Purchase Request: ${product.title}`
    : "Digital Product Purchase Request";

  const emailBody = product
    ? `Hello,\n\nI would like to purchase "${product.title}" for ${formatPrice(product.price)}.\n\nPlease send me payment instructions for:\n- Bank transfer\n- Mobile money\n- Credit/Debit card\n\nThank you!`
    : "Hello,\n\nI would like to purchase a digital product from FindMyBizName. Please send me payment options.\n\nThank you!";

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
        <SEOHead 
          title="Purchase Instructions - FindMyBizName"
          description="Complete your digital product purchase with multiple payment options"
        />
        <div className="container mx-auto px-4">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-red-600">Product Not Found</CardTitle>
              <CardDescription>
                The product information is missing. Please go back and try again.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => setLocation('/digital-products')} variant="outline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Products
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <SEOHead 
        title={`Purchase ${product.title} - FindMyBizName`}
        description={`Complete your purchase of ${product.title} with flexible Caribbean payment options`}
      />
      
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="mb-8">
          <Button 
            onClick={() => setLocation('/digital-products')} 
            variant="ghost" 
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Products
          </Button>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Product Summary */}
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl">{product.title}</CardTitle>
                  <CardDescription>{product.description}</CardDescription>
                </div>
                <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  {product.category}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary mb-4">
                {formatPrice(product.price)}
              </div>
              <div className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                <div className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Instant download after payment
                </div>
                <div className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Trinidad & Tobago customized
                </div>
                <div className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Professional quality templates
                </div>
                <div className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Email support included
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Instructions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="h-5 w-5 mr-2" />
                Complete Your Purchase
              </CardTitle>
              <CardDescription>
                Choose your preferred payment method. We'll process your order and send download links within 24 hours.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* WhatsApp Option */}
              <div className="p-4 border rounded-lg">
                <h3 className="font-semibold text-green-600 dark:text-green-400 mb-2 flex items-center">
                  <MessageCircle className="h-4 w-4 mr-2" />
                  WhatsApp (Fastest)
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                  Message us for instant payment assistance
                </p>
                <Button 
                  asChild 
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <a 
                    href={`https://wa.me/18687209758?text=${encodeURIComponent(whatsappMessage)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Message on WhatsApp
                  </a>
                </Button>
              </div>

              {/* Email Option */}
              <div className="p-4 border rounded-lg">
                <h3 className="font-semibold text-blue-600 dark:text-blue-400 mb-2 flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  Email Instructions
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                  Get detailed payment options via email
                </p>
                <Button 
                  asChild 
                  variant="outline" 
                  className="w-full"
                >
                  <a 
                    href={`mailto:sales@findmybizname.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`}
                  >
                    <Mail className="h-4 w-4 mr-2" />
                    Send Email Request
                  </a>
                </Button>
              </div>

              {/* Phone Option */}
              <div className="p-4 border rounded-lg">
                <h3 className="font-semibold text-purple-600 dark:text-purple-400 mb-2 flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  Phone Support
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                  Call for personal assistance
                </p>
                <Button 
                  asChild 
                  variant="outline" 
                  className="w-full"
                >
                  <a href="tel:+18687209758">
                    <Phone className="h-4 w-4 mr-2" />
                    Call +1 (868) 720-9758
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payment Methods Accepted */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="text-lg">Payment Methods Accepted</CardTitle>
            <CardDescription>
              We support all major payment methods for Caribbean entrepreneurs
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="text-center p-4 border rounded-lg">
                <h4 className="font-semibold mb-2">Bank Transfer</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  All T&T banks supported
                </p>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <h4 className="font-semibold mb-2">Mobile Money</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  Digicel, Flow, bmobile
                </p>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <h4 className="font-semibold mb-2">Credit/Debit Cards</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  Visa, MasterCard
                </p>
              </div>
              <div className="text-center p-4 border rounded-lg">
                <h4 className="font-semibold mb-2">Digital Wallets</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  PayPal, Endcash
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Process Timeline */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="text-lg">What Happens Next?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold text-sm mr-4">
                  1
                </div>
                <div>
                  <h4 className="font-semibold">Contact Us</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Choose WhatsApp, email, or phone to request payment instructions
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold text-sm mr-4">
                  2
                </div>
                <div>
                  <h4 className="font-semibold">Receive Payment Details</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    We'll send you secure payment instructions within 2 hours
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold text-sm mr-4">
                  3
                </div>
                <div>
                  <h4 className="font-semibold">Complete Payment</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Pay using your preferred method (bank transfer, mobile money, card)
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0 w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 font-bold text-sm mr-4">
                  4
                </div>
                <div>
                  <h4 className="font-semibold">Download Your Product</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Receive download links via email within 24 hours of payment confirmation
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}