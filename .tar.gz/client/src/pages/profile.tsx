import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { z } from 'zod';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { User, Building, Globe, Linkedin, Twitter, Instagram, MapPin, Heart, HelpCircle } from 'lucide-react';

const profileSchema = z.object({
  displayName: z.string().min(2, 'Display name must be at least 2 characters').max(100).optional(),
  bio: z.string().max(500, 'Bio must be under 500 characters').optional(),
  businessName: z.string().max(200, 'Business name must be under 200 characters').optional(),
  businessStage: z.enum(['idea', 'startup', 'growing', 'established']).optional(),
  industry: z.string().max(100).optional(),
  location: z.string().max(100).optional(),
  website: z.string().url('Please enter a valid URL').or(z.literal('')).optional(),
  linkedinUrl: z.string().url('Please enter a valid LinkedIn URL').or(z.literal('')).optional(),
  twitterHandle: z.string().max(50).optional(),
  instagramHandle: z.string().max(50).optional(),
  interests: z.array(z.string()).optional(),
  lookingFor: z.string().max(1000).optional(),
  canHelp: z.string().max(1000).optional(),
  isPublic: z.boolean().optional(),
});

type ProfileFormData = z.infer<typeof profileSchema>;

const businessStages = [
  { value: 'idea', label: 'Idea Stage' },
  { value: 'startup', label: 'Early Startup' },
  { value: 'growing', label: 'Growing Business' },
  { value: 'established', label: 'Established Company' },
];

const industries = [
  'Technology', 'E-commerce', 'Healthcare', 'Finance', 'Education', 'Real Estate',
  'Food & Beverage', 'Fashion', 'Travel', 'Consulting', 'Manufacturing', 'Other'
];

const suggestedInterests = [
  'Networking', 'Funding', 'Marketing', 'Technology', 'Leadership', 'Partnerships',
  'Mentorship', 'Innovation', 'Scaling', 'Caribbean Markets', 'E-commerce', 'Digital Marketing'
];

export default function Profile() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);

  const { data: profile, isLoading } = useQuery({
    queryKey: ['/api/profile'],
  });

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      displayName: '',
      bio: '',
      businessName: '',
      businessStage: undefined,
      industry: '',
      location: '',
      website: '',
      linkedinUrl: '',
      twitterHandle: '',
      instagramHandle: '',
      interests: [],
      lookingFor: '',
      canHelp: '',
      isPublic: true,
    },
  });

  useEffect(() => {
    if (profile) {
      form.reset({
        displayName: profile.displayName || '',
        bio: profile.bio || '',
        businessName: profile.businessName || '',
        businessStage: profile.businessStage || undefined,
        industry: profile.industry || '',
        location: profile.location || '',
        website: profile.website || '',
        linkedinUrl: profile.linkedinUrl || '',
        twitterHandle: profile.twitterHandle || '',
        instagramHandle: profile.instagramHandle || '',
        interests: profile.interests || [],
        lookingFor: profile.lookingFor || '',
        canHelp: profile.canHelp || '',
        isPublic: profile.isPublic ?? true,
      });
      setSelectedInterests(profile.interests || []);
    }
  }, [profile, form]);

  const saveProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      return apiRequest('POST', '/api/profile', { ...data, interests: selectedInterests });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been saved successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProfileFormData) => {
    saveProfileMutation.mutate(data);
  };

  const addInterest = (interest: string) => {
    if (!selectedInterests.includes(interest)) {
      setSelectedInterests([...selectedInterests, interest]);
    }
  };

  const removeInterest = (interest: string) => {
    setSelectedInterests(selectedInterests.filter(i => i !== interest));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-6 h-6" />
              User Profile
            </CardTitle>
            <CardDescription>
              Create your entrepreneur profile to connect with the community and showcase your business
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                
                {/* Personal Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Personal Information</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="displayName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Display Name</FormLabel>
                          <FormControl>
                            <Input placeholder="How you want to be known" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            Location
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="City, Country" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="bio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bio</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Tell us about yourself and your entrepreneurial journey..." 
                            className="h-24"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                {/* Business Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Business Information</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="businessName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Building className="w-4 h-4" />
                            Business Name
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="Your business or startup name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="businessStage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Stage</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select your business stage" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {businessStages.map((stage) => (
                                <SelectItem key={stage.value} value={stage.value}>
                                  {stage.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="industry"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Industry</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your industry" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {industries.map((industry) => (
                              <SelectItem key={industry} value={industry}>
                                {industry}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator />

                {/* Social Links */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Social Links</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="website"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Globe className="w-4 h-4" />
                            Website
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="https://yourwebsite.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="linkedinUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Linkedin className="w-4 h-4" />
                            LinkedIn
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="https://linkedin.com/in/yourprofile" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="twitterHandle"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Twitter className="w-4 h-4" />
                            Twitter Handle
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="@yourusername" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="instagramHandle"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="flex items-center gap-1">
                            <Instagram className="w-4 h-4" />
                            Instagram Handle
                          </FormLabel>
                          <FormControl>
                            <Input placeholder="@yourusername" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <Separator />

                {/* Interests & Goals */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Interests & Goals</h3>
                  
                  <div>
                    <Label className="flex items-center gap-1 mb-2">
                      <Heart className="w-4 h-4" />
                      Interests
                    </Label>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {selectedInterests.map((interest) => (
                        <Badge 
                          key={interest} 
                          variant="secondary"
                          className="cursor-pointer"
                          onClick={() => removeInterest(interest)}
                        >
                          {interest} ×
                        </Badge>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {suggestedInterests
                        .filter(interest => !selectedInterests.includes(interest))
                        .map((interest) => (
                        <Badge 
                          key={interest} 
                          variant="outline"
                          className="cursor-pointer hover:bg-primary hover:text-primary-foreground"
                          onClick={() => addInterest(interest)}
                        >
                          + {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <FormField
                    control={form.control}
                    name="lookingFor"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center gap-1">
                          <HelpCircle className="w-4 h-4" />
                          What are you looking for?
                        </FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="What kind of help, connections, or opportunities are you seeking?"
                            className="h-20"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="canHelp"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How can you help others?</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="What expertise, connections, or support can you offer to other entrepreneurs?"
                            className="h-20"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-center pt-8 pb-4">
                  <Button 
                    type="submit" 
                    disabled={saveProfileMutation.isPending}
                    className="w-full max-w-md bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 text-lg"
                    size="lg"
                  >
                    {saveProfileMutation.isPending ? (
                      <div className="flex items-center gap-2">
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                        Saving...
                      </div>
                    ) : (
                      'Save Profile'
                    )}
                  </Button>
                </div>

              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}