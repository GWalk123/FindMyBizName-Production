import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Settings, 
  Zap, 
  CreditCard, 
  Globe, 
  BarChart3, 
  Users, 
  FileText, 
  Bot,
  MessageSquare,
  TrendingUp,
  Shield,
  Database,
  CheckCircle,
  UserCheck
} from "lucide-react";

export default function AdminPanel() {
  const { toast } = useToast();
  const [testResults, setTestResults] = useState<Record<string, any>>({});
  const [isLoading, setIsLoading] = useState<Record<string, boolean>>({});
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [adminData, setAdminData] = useState<any>(null);
  const [authToken, setAuthToken] = useState("");

  const handleAdminLogin = async () => {
    try {
      setIsLoading(prev => ({ ...prev, auth: true }));
      const result = await apiRequest('POST', '/api/admin/login', { password });
      
      if (result && result.success) {
        setIsAuthenticated(true);
        setAuthToken(password); // Simple token implementation
        toast({
          title: "Admin Access Granted",
          description: "✅ Successfully authenticated as administrator",
        });
        loadAdminData(password);
      }
    } catch (error) {
      toast({
        title: "Authentication Failed",
        description: "Invalid admin password",
        variant: "destructive",
      });
    } finally {
      setIsLoading(prev => ({ ...prev, auth: false }));
    }
  };

  const loadAdminData = async (token: string) => {
    try {
      const data = await apiRequest('GET', '/api/admin/data', undefined, { Authorization: `Bearer ${token}` });
      setAdminData(data);
    } catch (error) {
      toast({
        title: "Error Loading Admin Data",
        description: "Failed to load admin dashboard data",
        variant: "destructive",
      });
    }
  };

  const testFeature = async (feature: string, endpoint: string, data?: any) => {
    setIsLoading(prev => ({ ...prev, [feature]: true }));
    try {
      const method = data ? 'POST' : 'GET';
      const result = await apiRequest(method, endpoint, data);
      setTestResults(prev => ({ ...prev, [feature]: result }));
      toast({
        title: `${feature} Test`,
        description: "✅ Test completed successfully",
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      setTestResults(prev => ({ ...prev, [feature]: { error: errorMessage } }));
      toast({
        title: `${feature} Test Failed`,
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(prev => ({ ...prev, [feature]: false }));
    }
  };

  const adminTests = [
    {
      name: "AI Name Generation",
      icon: Zap,
      test: () => testFeature("nameGen", "/api/generate-names", { 
        description: "Tech startup focused on AI solutions",
        industry: "technology",
        style: "modern"
      }),
      description: "Test AI business name generation with domain checking"
    },
    {
      name: "Domain Checker",
      icon: Globe,
      test: () => testFeature("domains", "/api/godaddy/check-domains", {
        domains: ["example-test-domain.com"]
      }),
      description: "Test GoDaddy domain availability checking"
    },
    {
      name: "Brand Analysis Suite",
      icon: CheckCircle,
      test: () => testFeature("brandAnalysis", "/api/brand/analyze", {
        name: "TechFlow"
      }),
      description: "Test social media handles, trademark checking"
    },
    {
      name: "Business Intelligence",
      icon: BarChart3,
      test: () => testFeature("bizIntel", "/api/companies/search", {
        query: "apple"
      }),
      description: "Test SEC EDGAR company database (500K+ companies)"
    },
    {
      name: "Biz Newz Feed",
      icon: TrendingUp,
      test: () => testFeature("news", "/api/news/articles"),
      description: "Test live business news aggregation"
    },
    {
      name: "Biz Botz (AI Support)",
      icon: Bot,
      test: () => testFeature("aiSupport", "/api/biz-botz/chat", {
        message: "Hello, I need help with my business plan",
        botId: "business-advisor"
      }),
      description: "Test AI-powered customer support system"
    },
    {
      name: "Biz Buzz (Community)",
      icon: MessageSquare,
      test: () => testFeature("community", "/api/health"),
      description: "Test community chat forum (currently disabled)"
    },
    {
      name: "CRM System",
      icon: Users,
      test: () => testFeature("crm", "/api/crm/contacts"),
      description: "Test customer relationship management"
    },
    {
      name: "Invoice Generator",
      icon: FileText,
      test: () => testFeature("invoices", "/api/invoices/generate", {
        clientName: "Test Client",
        amount: 1000,
        description: "Professional services"
      }),
      description: "Test professional PDF invoice generation"
    },
    {
      name: "Digital Products",
      icon: Shield,
      test: () => testFeature("products", "/api/digital-products"),
      description: "Test digital products marketplace"
    },
    {
      name: "Referral System",
      icon: Users,
      test: () => testFeature("referrals", "/api/referral/stats/1"),
      description: "Test 30% commission referral network"
    },
    {
      name: "AI Templates",
      icon: FileText,
      test: () => testFeature("aiTemplates", "/api/templates/categories"),
      description: "Test AI-powered business document generator"
    },
    {
      name: "Payment Processing",
      icon: CreditCard,
      test: () => testFeature("payments", "/api/paypal/setup"),
      description: "Test multi-gateway payment systems"
    },
    {
      name: "User Profiles",
      icon: UserCheck,
      test: () => testFeature("profiles", "/api/user"),
      description: "Test entrepreneur networking profiles"
    },
    {
      name: "Analytics Dashboard",
      icon: BarChart3,
      test: () => testFeature("analytics", "/api/analytics/dashboard"),
      description: "Test business performance tracking"
    },
    {
      name: "Database Health",
      icon: Database,
      test: () => testFeature("database", "/api/health"),
      description: "Test database connectivity and performance"
    }
  ];

  // Authentication screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md w-full mx-4 p-8">
          <div className="text-center mb-6">
            <Shield className="h-12 w-12 text-red-600 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900">Admin Access Required</h1>
            <p className="text-gray-600 mt-2">Enter admin password to access the control panel</p>
          </div>
          
          <div className="space-y-4">
            <Input
              type="password"
              placeholder="Admin Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAdminLogin()}
            />
            
            <Button 
              onClick={handleAdminLogin}
              disabled={isLoading.auth || !password}
              className="w-full bg-red-600 hover:bg-red-700"
            >
              {isLoading.auth ? "Authenticating..." : "Access Admin Panel"}
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Settings className="h-8 w-8 text-blue-600" />
              <h1 className="text-3xl font-bold text-gray-900">Admin Control Panel</h1>
              <Badge variant="destructive" className="bg-red-600">ADMIN ACCESS</Badge>
            </div>
            <Button 
              variant="outline" 
              onClick={() => {
                setIsAuthenticated(false);
                setPassword("");
                setAdminData(null);
              }}
            >
              Logout
            </Button>
          </div>
          <p className="text-gray-600">
            Test and monitor all FindMyBizName platform features. You have Pro-level access to all business tools.
          </p>
        </div>

        {adminData && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <Card className="p-6">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                Platform Status
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Name:</span>
                  <span className="font-medium">{adminData.platform.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Version:</span>
                  <span className="font-medium">{adminData.platform.version}</span>
                </div>
                <div className="flex justify-between">
                  <span>Status:</span>
                  <Badge variant="outline" className="text-green-600">{adminData.platform.status}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Uptime:</span>
                  <span className="font-medium">{adminData.stats.uptime}s</span>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Settings className="h-5 w-5 text-blue-600" />
                API Configuration
              </h3>
              <div className="space-y-2 text-sm">
                {Object.entries(adminData.apiKeys).map(([key, status]) => (
                  <div key={key} className="flex justify-between">
                    <span className="capitalize">{key}:</span>
                    <span className="font-medium">{status as string}</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Database className="h-5 w-5 text-purple-600" />
                Service Status
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Database:</span>
                  <span className="font-medium">{adminData.database.status}</span>
                </div>
                {Object.entries(adminData.services).map(([key, status]) => (
                  <div key={key} className="flex justify-between">
                    <span className="capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}:</span>
                    <span className="font-medium">{status as string}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {adminTests.map((test) => {
            const Icon = test.icon;
            const loading = isLoading[test.name.toLowerCase().replace(/\s+/g, '')];
            const result = testResults[test.name.toLowerCase().replace(/\s+/g, '')];
            
            return (
              <Card key={test.name} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center gap-3 mb-4">
                  <Icon className="h-6 w-6 text-blue-600" />
                  <h3 className="font-semibold text-gray-900">{test.name}</h3>
                </div>
                
                <p className="text-sm text-gray-600 mb-4">{test.description}</p>
                
                <Button 
                  onClick={test.test}
                  disabled={loading}
                  className="w-full mb-3"
                  variant={result?.error ? "destructive" : result ? "default" : "outline"}
                >
                  {loading ? "Testing..." : result?.error ? "Failed - Retry" : result ? "✅ Tested" : "Run Test"}
                </Button>
                
                {result && (
                  <div className="text-xs bg-gray-100 p-2 rounded max-h-20 overflow-y-auto">
                    {result.error ? (
                      <span className="text-red-600">Error: {result.error}</span>
                    ) : (
                      <span className="text-green-600">✅ Success: {JSON.stringify(result).substring(0, 100)}...</span>
                    )}
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Quick Feature Access
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-medium mb-2">Direct Platform Access:</h3>
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/features" target="_blank">Business Intelligence Suite</a>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/biz-newz" target="_blank">Live Business News Feed</a>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/biz-botz" target="_blank">Biz Botz (AI Support)</a>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/biz-buzz" target="_blank">Biz Buzz (Community)</a>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/ai-templates" target="_blank">AI Templates</a>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/digital-products" target="_blank">Digital Products Marketplace</a>
                </Button>
              </div>
            </div>
            <div>
              <h3 className="font-medium mb-2">Payment Testing:</h3>
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/test-crypto-payment" target="_blank">Test Crypto Payments</a>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/alternative-payments" target="_blank">Test All Payment Methods</a>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <a href="/godaddy-test" target="_blank">Test GoDaddy API</a>
                </Button>
              </div>
            </div>
          </div>
        </Card>

        <div className="mt-8 text-center">
          <Badge variant="outline" className="text-green-600 border-green-600">
            Platform Status: FULLY OPERATIONAL
          </Badge>
          <p className="text-sm text-gray-600 mt-2">
            All systems ready to serve 430.5M underbanked entrepreneurs globally
          </p>
        </div>
      </div>
    </div>
  );
}