import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, FileText, Zap, Star, Download, Sparkles } from "lucide-react";

interface TemplateCategory {
  id: number;
  name: string;
  description: string;
  icon: string;
  sortOrder: number;
}

interface AiTemplate {
  id: number;
  categoryId: number;
  title: string;
  description: string;
  templateType: string;
  requiredInputs: string[];
  optionalInputs: string[];
  pricing: number;
  generationCount: number;
  averageRating: string;
  aiModel: string;
  estimatedTokens: number;
}

interface GeneratedTemplate {
  id: number;
  templateId: number;
  userInputs: Record<string, any>;
  generatedContent: string;
  tokensUsed: number;
  generationTime: number;
  downloadCount: number;
  createdAt: string;
}

export default function AITemplates() {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<AiTemplate | null>(null);
  const [templateInputs, setTemplateInputs] = useState<Record<string, string>>({});
  const [showGenerated, setShowGenerated] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch template categories
  const { data: categories = [] } = useQuery<TemplateCategory[]>({
    queryKey: ["/api/templates/categories"],
    queryFn: async () => {
      const response = await fetch('/api/templates/categories');
      if (!response.ok) throw new Error('Failed to fetch template categories');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });

  // Fetch templates by category
  const { data: templates = [] } = useQuery<AiTemplate[]>({
    queryKey: ["/api/templates", { categoryId: selectedCategory }],
    queryFn: async () => {
      const response = await fetch(`/api/templates?categoryId=${selectedCategory}`);
      if (!response.ok) throw new Error('Failed to fetch templates');
      return response.json();
    },
    enabled: selectedCategory !== null,
    retry: 1,
    refetchOnWindowFocus: false,
  });

  // Fetch user's generated templates
  const { data: generatedTemplates = [] } = useQuery<GeneratedTemplate[]>({
    queryKey: ["/api/templates/generated"],
    queryFn: async () => {
      const response = await fetch('/api/templates/generated');
      if (!response.ok) throw new Error('Failed to fetch generated templates');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });

  // Template generation mutation
  const generateMutation = useMutation({
    mutationFn: async ({ templateId, inputs }: { templateId: number; inputs: Record<string, string> }) => {
      return await apiRequest("POST", `/api/templates/${templateId}/generate`, { inputs });
    },
    onSuccess: () => {
      toast({
        title: "Template Generated!",
        description: "Your AI-powered template has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/templates/generated"] });
      setShowGenerated(true);
      setSelectedTemplate(null);
      setTemplateInputs({});
    },
    onError: (error: Error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (field: string, value: string) => {
    setTemplateInputs(prev => ({ ...prev, [field]: value }));
  };

  const handleGenerateTemplate = () => {
    if (!selectedTemplate) return;

    // Validate required inputs
    const missingInputs = selectedTemplate.requiredInputs.filter(
      field => !templateInputs[field] || templateInputs[field].trim() === ''
    );

    if (missingInputs.length > 0) {
      toast({
        title: "Missing Required Fields",
        description: `Please fill in: ${missingInputs.join(', ')}`,
        variant: "destructive",
      });
      return;
    }

    generateMutation.mutate({
      templateId: selectedTemplate.id,
      inputs: templateInputs
    });
  };

  const formatPrice = (cents: number) => {
    if (cents === 0) return "Free";
    return `$${(cents / 100).toFixed(2)}`;
  };

  const renderTemplateInputs = () => {
    if (!selectedTemplate) return null;

    const allInputs = [...selectedTemplate.requiredInputs, ...selectedTemplate.optionalInputs];

    return (
      <div className="space-y-4">
        <div className="border-t pt-4">
          <h4 className="font-semibold mb-3">Template Configuration</h4>
          <div className="grid gap-4">
            {allInputs.map((field) => {
              const isRequired = selectedTemplate.requiredInputs.includes(field);
              const fieldLabel = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
              
              return (
                <div key={field} className="space-y-2">
                  <Label htmlFor={field}>
                    {fieldLabel}
                    {isRequired && <span className="text-red-500 ml-1">*</span>}
                  </Label>
                  {field.toLowerCase().includes('description') || field.toLowerCase().includes('message') ? (
                    <Textarea
                      id={field}
                      placeholder={`Enter ${fieldLabel.toLowerCase()}`}
                      value={templateInputs[field] || ''}
                      onChange={(e) => handleInputChange(field, e.target.value)}
                      className="min-h-[80px]"
                    />
                  ) : (
                    <Input
                      id={field}
                      placeholder={`Enter ${fieldLabel.toLowerCase()}`}
                      value={templateInputs[field] || ''}
                      onChange={(e) => handleInputChange(field, e.target.value)}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>
        
        <div className="flex gap-3 pt-4 border-t">
          <Button
            onClick={handleGenerateTemplate}
            disabled={generateMutation.isPending}
            className="flex-1"
          >
            {generateMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Template
              </>
            )}
          </Button>
          <Button variant="outline" onClick={() => setSelectedTemplate(null)}>
            Cancel
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            AI Template Generator
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Generate professional business documents instantly using advanced AI. 
            From business plans to legal contracts - powered by multiple AI models.
          </p>
        </div>

        <Tabs value={showGenerated ? "generated" : "create"} onValueChange={(v) => setShowGenerated(v === "generated")}>
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-8">
            <TabsTrigger value="create" className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Create New
            </TabsTrigger>
            <TabsTrigger value="generated" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              My Templates ({generatedTemplates.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="create" className="space-y-6">
            {!selectedTemplate ? (
              <>
                {/* Category Selection */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                  {categories.map((category) => (
                    <Card 
                      key={category.id}
                      className={`cursor-pointer transition-all hover:shadow-lg ${
                        selectedCategory === category.id ? 'ring-2 ring-blue-500 bg-blue-50 dark:bg-blue-900' : ''
                      }`}
                      onClick={() => setSelectedCategory(category.id)}
                    >
                      <CardHeader className="text-center">
                        <div className="w-12 h-12 mx-auto mb-2 bg-blue-100 dark:bg-blue-800 rounded-full flex items-center justify-center">
                          <FileText className="w-6 h-6 text-blue-600 dark:text-blue-300" />
                        </div>
                        <CardTitle className="text-lg">{category.name}</CardTitle>
                        <CardDescription className="text-sm">{category.description}</CardDescription>
                      </CardHeader>
                    </Card>
                  ))}
                </div>

                {/* Template Selection */}
                {selectedCategory && (
                  <div className="space-y-4">
                    <h3 className="text-2xl font-semibold text-center mb-6">
                      Choose Your Template
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {templates.map((template) => (
                        <Card key={template.id} className="hover:shadow-lg transition-shadow">
                          <CardHeader>
                            <div className="flex justify-between items-start">
                              <div>
                                <CardTitle className="text-xl mb-2">{template.title}</CardTitle>
                                <CardDescription className="mb-3">{template.description}</CardDescription>
                              </div>
                              <Badge variant={template.pricing === 0 ? "secondary" : "default"}>
                                {formatPrice(template.pricing)}
                              </Badge>
                            </div>
                            
                            <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4" />
                                {parseFloat(template.averageRating).toFixed(1)}
                              </div>
                              <div>
                                {template.generationCount} generated
                              </div>
                              <div>
                                {template.aiModel}
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              <div className="text-sm">
                                <span className="font-medium">Required: </span>
                                {template.requiredInputs.length} fields
                              </div>
                              <div className="text-sm">
                                <span className="font-medium">Est. tokens: </span>
                                {template.estimatedTokens}
                              </div>
                              <Button 
                                onClick={() => setSelectedTemplate(template)}
                                className="w-full"
                              >
                                Configure Template
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : (
              /* Template Configuration */
              <Card className="max-w-2xl mx-auto">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5" />
                    {selectedTemplate.title}
                  </CardTitle>
                  <CardDescription>{selectedTemplate.description}</CardDescription>
                  <div className="flex items-center gap-4 text-sm">
                    <Badge>{formatPrice(selectedTemplate.pricing)}</Badge>
                    <span>{selectedTemplate.aiModel}</span>
                    <span>~{selectedTemplate.estimatedTokens} tokens</span>
                  </div>
                </CardHeader>
                <CardContent>
                  {renderTemplateInputs()}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="generated" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold mb-2">Your Generated Templates</h2>
              <p className="text-gray-600 dark:text-gray-300">
                Access and download all your AI-generated business documents
              </p>
            </div>

            {generatedTemplates.length === 0 ? (
              <Card className="max-w-md mx-auto text-center">
                <CardContent className="py-12">
                  <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No Templates Yet</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    Generate your first AI-powered template to get started
                  </p>
                  <Button onClick={() => setShowGenerated(false)}>
                    Create Template
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {generatedTemplates.map((template) => (
                  <Card key={template.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg">Generated Template #{template.id}</CardTitle>
                      <CardDescription>
                        Created: {new Date(template.createdAt).toLocaleDateString()}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="text-sm space-y-1">
                          <div><span className="font-medium">Tokens used:</span> {template.tokensUsed}</div>
                          <div><span className="font-medium">Generation time:</span> {template.generationTime}ms</div>
                          <div><span className="font-medium">Downloads:</span> {template.downloadCount}</div>
                        </div>
                        
                        <div className="border rounded p-3 bg-gray-50 dark:bg-gray-800">
                          <p className="text-sm text-gray-600 dark:text-gray-300 line-clamp-3">
                            {template.generatedContent.substring(0, 150)}...
                          </p>
                        </div>
                        
                        <div className="flex gap-2">
                          <Button size="sm" className="flex-1">
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                          <Button size="sm" variant="outline">
                            View
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}