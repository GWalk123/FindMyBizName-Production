import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Share2, DollarSign, Users, TrendingUp, Globe } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ReferralStats {
  totalReferrals: number;
  convertedReferrals: number;
  totalCommissions: string;
  pendingCommissions: string;
  paidCommissions: string;
  currency: string;
}

interface Referral {
  id: number;
  refereeId: number;
  referralCode: string;
  status: string;
  conversionDate?: string;
  commissionAmount?: string;
  createdAt: string;
}

interface ReferralCode {
  id: number;
  code: string;
  isActive: boolean;
  createdAt: string;
}

export default function ReferralsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [shareUrl, setShareUrl] = useState("");

  // Get or create referral code
  const { data: referralCode, isLoading: codeLoading } = useQuery({
    queryKey: ["/api/referral/create-code"],
    queryFn: async () => {
      const response = await fetch('/api/referral/create-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to create referral code');
      return response.json();
    },
    retry: 1,
    refetchOnWindowFocus: false,
  });

  // Get referral stats
  const { data: referralData, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/referral/stats/1"],
    queryFn: async () => {
      const response = await fetch('/api/referral/stats/1');
      if (!response.ok) throw new Error('Failed to fetch referral stats');
      return response.json();
    },
    enabled: !!referralCode,
    retry: 1,
    refetchOnWindowFocus: false,
  });

  // Track referral mutation
  const trackReferralMutation = useMutation({
    mutationFn: (data: { referralCode: string; newUserEmail: string }) =>
      apiRequest("POST", "/api/referral/track", data),
    onSuccess: () => {
      toast({
        title: "Referral Tracked",
        description: "Successfully tracked new referral!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/referral/stats/1"] });
    },
  });

  useEffect(() => {
    if (referralCode && (referralCode as any).code) {
      const baseUrl = window.location.origin;
      setShareUrl(`${baseUrl}/?ref=${(referralCode as any).code}`);
    }
  }, [referralCode]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard",
    });
  };

  const shareOnSocial = (platform: string) => {
    const text = "🚀 Start your business with the perfect name! Get AI-powered business naming + domain checking for FREE. Join 1000+ entrepreneurs already building their dreams!";
    const url = shareUrl;
    
    const shareUrls = {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
      whatsapp: `https://wa.me/?text=${encodeURIComponent(text + " " + url)}`
    };

    window.open(shareUrls[platform as keyof typeof shareUrls], '_blank');
  };

  if (codeLoading || statsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const stats = (referralData as any)?.stats || {
    totalReferrals: 0,
    convertedReferrals: 0,
    totalCommissions: "0",
    pendingCommissions: "0",
    paidCommissions: "0",
    currency: "USD"
  };

  const conversionRate = stats.totalReferrals > 0 ? 
    ((stats.convertedReferrals / stats.totalReferrals) * 100).toFixed(1) : "0";

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Globe className="h-12 w-12 text-blue-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
              Global Referral Program
            </h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Earn 30% recurring commissions serving 125-200 million underbanked entrepreneurs among the world's 594 million entrepreneurs globally
          </p>
          <div className="mt-4 text-lg font-semibold text-blue-600">
            Caribbean • Africa • Southeast Asia • Latin America • South Asia
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Referrals</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalReferrals}</div>
              <p className="text-xs text-muted-foreground">
                People you've referred
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{conversionRate}%</div>
              <p className="text-xs text-muted-foreground">
                {stats.convertedReferrals} of {stats.totalReferrals} converted
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Commissions</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${stats.pendingCommissions}</div>
              <p className="text-xs text-muted-foreground">
                Awaiting payout
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Earned</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${stats.totalCommissions}</div>
              <p className="text-xs text-muted-foreground">
                Lifetime earnings
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="share" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="share">Share & Earn</TabsTrigger>
            <TabsTrigger value="referrals">My Referrals</TabsTrigger>
            <TabsTrigger value="payouts">Payouts</TabsTrigger>
          </TabsList>

          <TabsContent value="share" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Referral Link</CardTitle>
                <CardDescription>
                  Share this link to earn 30% recurring commissions on all paid subscriptions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex space-x-2">
                  <Input
                    value={shareUrl || "Loading your referral link..."}
                    readOnly
                    className="flex-1 font-mono text-sm"
                    placeholder="Your referral link will appear here"
                  />
                  <Button
                    onClick={() => copyToClipboard(shareUrl)}
                    variant="outline"
                    disabled={!shareUrl}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>

                {shareUrl && (
                  <div className="mt-2 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                    <p className="text-sm text-green-700 dark:text-green-300">
                      ✅ <strong>Your referral link is ready!</strong> Share it to start earning 30% recurring commissions.
                    </p>
                  </div>
                )}

                <div className="space-y-3">
                  <p className="text-sm font-medium">Share on social media:</p>
                  <div className="flex space-x-2">
                    <Button
                      onClick={() => shareOnSocial('twitter')}
                      variant="outline"
                      size="sm"
                      className="bg-blue-500 text-white hover:bg-blue-600"
                    >
                      Twitter
                    </Button>
                    <Button
                      onClick={() => shareOnSocial('facebook')}
                      variant="outline"
                      size="sm"
                      className="bg-blue-600 text-white hover:bg-blue-700"
                    >
                      Facebook
                    </Button>
                    <Button
                      onClick={() => shareOnSocial('linkedin')}
                      variant="outline"
                      size="sm"
                      className="bg-blue-700 text-white hover:bg-blue-800"
                    >
                      LinkedIn
                    </Button>
                    <Button
                      onClick={() => shareOnSocial('whatsapp')}
                      variant="outline"
                      size="sm"
                      className="bg-green-500 text-white hover:bg-green-600"
                    >
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Commission Structure - Complete 7-Tier System</CardTitle>
                <CardDescription>
                  30% recurring commissions on all subscription tiers - Transparent, automatic payouts for global market coverage
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">Starter (Free)</h4>
                    <p className="text-sm text-muted-foreground">Your commission: $0.00/month</p>
                    <p className="text-xs text-gray-500">Free tier - no commission</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Premium ($9.99/month)</h4>
                    <p className="text-sm text-muted-foreground">Your commission: $3.00/month</p>
                    <p className="text-xs text-green-600">30% recurring</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Pro ($19.99/month)</h4>
                    <p className="text-sm text-muted-foreground">Your commission: $6.00/month</p>
                    <p className="text-xs text-green-600">30% recurring</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Business ($29.99/month)</h4>
                    <p className="text-sm text-muted-foreground">Your commission: $9.00/month</p>
                    <p className="text-xs text-green-600">30% recurring</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Scale ($49.99/month)</h4>
                    <p className="text-sm text-muted-foreground">Your commission: $15.00/month</p>
                    <p className="text-xs text-green-600">30% recurring</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Growth ($99.99/month)</h4>
                    <p className="text-sm text-muted-foreground">Your commission: $30.00/month</p>
                    <p className="text-xs text-green-600">30% recurring</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold">Enterprise ($149.00/month)</h4>
                    <p className="text-sm text-muted-foreground">Your commission: $44.70/month</p>
                    <p className="text-xs text-green-600">30% recurring</p>
                  </div>
                </div>
                <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg border border-green-200">
                  <h4 className="font-semibold text-green-800 dark:text-green-300 mb-2">💰 Maximum Earning Potential</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p><strong>Per Enterprise Referral:</strong> $44.70/month</p>
                      <p><strong>Annual per referral:</strong> $536.40/year</p>
                    </div>
                    <div>
                      <p><strong>10 Enterprise referrals:</strong> $447/month</p>
                      <p><strong>Annual with 10 referrals:</strong> $5,364/year</p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <p className="text-sm">
                    💡 <strong>Recurring commissions:</strong> Earn every month as long as your referrals stay subscribed.
                    Perfect for building passive income in underbanked markets worldwide serving 125-200 million underbanked entrepreneurs.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="referrals" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Referral History</CardTitle>
                <CardDescription>
                  Track your referrals and their conversion status
                </CardDescription>
              </CardHeader>
              <CardContent>
                {(referralData as any)?.referrals?.length > 0 ? (
                  <div className="space-y-3">
                    {(referralData as any).referrals.map((referral: Referral) => (
                      <div key={referral.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">Referral #{referral.id}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(referral.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge variant={referral.status === 'converted' ? 'default' : 'secondary'}>
                            {referral.status}
                          </Badge>
                          {referral.commissionAmount && (
                            <p className="text-sm text-green-600 mt-1">
                              +${referral.commissionAmount}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">
                    No referrals yet. Start sharing your link to earn commissions!
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payouts" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Payout History</CardTitle>
                <CardDescription>
                  Track your commission payouts and payment methods
                </CardDescription>
              </CardHeader>
              <CardContent>
                {(referralData as any)?.payouts?.length > 0 ? (
                  <div className="space-y-3">
                    {(referralData as any).payouts.map((payout: any) => (
                      <div key={payout.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">${payout.amount}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(payout.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant={payout.status === 'processed' ? 'default' : 'secondary'}>
                          {payout.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">
                      No payouts yet. Minimum payout is $50.
                    </p>
                    <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Supported Payment Methods:</h4>
                      <ul className="text-sm space-y-1">
                        <li>🏦 Bank Transfer (All Countries)</li>
                        <li>📱 Mobile Money (Africa, Caribbean, Asia)</li>
                        <li>💳 PayPal (Global)</li>
                        <li>💰 Payoneer Transfer (150+ Countries)</li>
                      </ul>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}