import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, DollarSign, Clock, CheckCircle } from "lucide-react";
import SEOHead from "@/components/seo-head";

export default function Refund() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <SEOHead 
        title="Refund Policy - FindMyBizName Money-Back Guarantee"
        description="Learn about FindMyBizName's 7-day money-back guarantee and refund process. Fair refund policy for our Trinidad & Tobago business platform."
      />
      
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4" variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Last Updated: July 9, 2025
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Refund Policy
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            We stand behind our AI-powered business naming platform with a fair and transparent refund policy.
          </p>
        </div>

        {/* Key Points Overview */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <Card>
            <CardContent className="pt-6 text-center">
              <Clock className="w-8 h-8 text-blue-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">7-Day Guarantee</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Full refund within 7 days of subscription purchase
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6 text-center">
              <DollarSign className="w-8 h-8 text-green-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Full Refund</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                100% refund, no questions asked within refund period
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6 text-center">
              <CheckCircle className="w-8 h-8 text-purple-600 mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Easy Process</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Simple refund request via email or WhatsApp support
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>1. Refund Eligibility</CardTitle>
              <CardDescription>
                When you can request a full refund
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-400">
                We offer a <strong>7-day money-back guarantee</strong> for all Premium ($9.99/month) 
                and Pro ($19.99/month) subscription plans.
              </p>
              
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                <h4 className="font-semibold mb-2 text-green-800 dark:text-green-200">Eligible for Full Refund:</h4>
                <ul className="list-disc list-inside text-green-700 dark:text-green-300 space-y-1">
                  <li>Subscription purchased within the last 7 days</li>
                  <li>Unsatisfied with the service quality or features</li>
                  <li>Technical issues preventing platform usage</li>
                  <li>Change of business plans or circumstances</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>2. Refund Process</CardTitle>
              <CardDescription>
                How to request your refund
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 dark:text-gray-400">
                Requesting a refund is simple and straightforward:
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
                  <div>
                    <h4 className="font-semibold">Contact Support</h4>
                    <p className="text-gray-600 dark:text-gray-400">
                      Email us at <strong>sales@findmybizname.com</strong> or WhatsApp +1 (868) 720-9758
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
                  <div>
                    <h4 className="font-semibold">Provide Details</h4>
                    <p className="text-gray-600 dark:text-gray-400">
                      Include your account email, subscription plan, and reason for refund
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
                  <div>
                    <h4 className="font-semibold">Receive Confirmation</h4>
                    <p className="text-gray-600 dark:text-gray-400">
                      We'll confirm your refund request within 24 hours
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">4</div>
                  <div>
                    <h4 className="font-semibold">Processing Time</h4>
                    <p className="text-gray-600 dark:text-gray-400">
                      Refunds processed within 3-5 business days to original payment method
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>3. Payment Method Refunds</CardTitle>
              <CardDescription>
                How refunds are processed based on payment method
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Credit/Debit Cards (Paddle/PayPal)</h4>
                  <p className="text-gray-600 dark:text-gray-400">
                    Refunds credited back to your original card within 3-5 business days.
                  </p>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Bank Transfers (Caribbean)</h4>
                  <p className="text-gray-600 dark:text-gray-400">
                    Direct refund to your bank account within 1-3 business days for Trinidad & Tobago customers.
                  </p>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">Mobile Money</h4>
                  <p className="text-gray-600 dark:text-gray-400">
                    Refunds processed back to your mobile money account within 24 hours.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>4. Non-Refundable Items</CardTitle>
              <CardDescription>
                Services not eligible for refund
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg">
                <h4 className="font-semibold mb-2 text-amber-800 dark:text-amber-200">Not Eligible for Refund:</h4>
                <ul className="list-disc list-inside text-amber-700 dark:text-amber-300 space-y-1">
                  <li>Digital product downloads after download completion</li>
                  <li>Subscriptions used for more than 7 days</li>
                  <li>Refund requests after account deletion</li>
                  <li>Services terminated due to Terms of Service violations</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>5. Contact Information</CardTitle>
              <CardDescription>
                Get help with refunds and billing questions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-2">Email Support</h4>
                  <p className="text-gray-600 dark:text-gray-400">
                    <strong>sales@findmybizname.com</strong><br />
                    Response within 24 hours
                  </p>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-2">WhatsApp Support</h4>
                  <p className="text-gray-600 dark:text-gray-400">
                    <strong>+1 (868) 720-9758</strong><br />
                    Caribbean timezone support
                  </p>
                </div>
              </div>
              
              <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <p className="text-blue-800 dark:text-blue-200">
                  <strong>Our Commitment:</strong> We're committed to your satisfaction. If you're not happy with 
                  FindMyBizName within your first 7 days, we'll make it right with a full refund.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer Notice */}
        <div className="text-center mt-16 p-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <p className="text-gray-600 dark:text-gray-400">
            This refund policy is governed by the laws of Trinidad & Tobago. 
            For questions about this policy, contact us at sales@findmybizname.com
          </p>
        </div>
      </div>
    </div>
  );
}