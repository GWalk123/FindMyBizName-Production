import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useBusinessNames } from "@/hooks/use-business-names";
import { type GeneratedNameWithDomains } from "@shared/schema";

export default function TestNameGeneration() {
  const [description, setDescription] = useState("coffee shop");
  const [results, setResults] = useState<GeneratedNameWithDomains[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  // Direct API call since we're testing
  const generateNames = async (params: any) => {
    const response = await fetch('/api/generate-names', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    return await response.json();
  };

  const handleTest = async () => {
    setIsLoading(true);
    try {
      const result = await generateNames({
        description,
        industry: "Technology",
        checkDomains: true
      });
      console.log('API Response:', result);
      setResults(result.names || []);
    } catch (error) {
      console.error("Test failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>🧪 Name Generation Test</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex gap-4">
            <Input 
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your business..."
              className="flex-1"
            />
            <Button 
              onClick={handleTest}
              disabled={isLoading || !description.trim()}
            >
              {isLoading ? "Generating..." : "Test Generate"}
            </Button>
          </div>

          {results.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Generated Names ({results.length})</h3>
              {results.map((name, index) => (
                <div key={index} className="p-4 border-2 border-blue-300 rounded-lg bg-blue-50">
                  <div className="flex items-center gap-2 mb-3">
                    <h4 className="text-2xl font-bold text-blue-900">{name.name}</h4>
                    <Badge className="bg-green-600">✓ AI Generated</Badge>
                  </div>
                  
                  {name.domains ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {Object.entries(name.domains).map(([tld, domain]: any) => (
                        <div 
                          key={tld} 
                          className={`p-3 rounded-lg text-center font-bold ${
                            domain.available ? 'bg-green-200 text-green-900 border-2 border-green-400' : 'bg-red-200 text-red-900 border-2 border-red-400'
                          }`}
                        >
                          <div className="font-bold text-lg">{name.name}.{tld}</div>
                          <div className="text-sm">
                            {domain.available ? (
                              <span className="text-green-800">✓ Available ${domain.price}/yr</span>
                            ) : (
                              <span className="text-red-800">✗ Taken</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-gray-600">Domain checking in progress...</div>
                  )}
                </div>
              ))}
            </div>
          )}

          {results.length === 0 && !isLoading && (
            <div className="text-center py-8 text-gray-500">
              <p className="text-lg mb-4">🧪 Name Generation Testing Interface</p>
              <p>Click "Test Generate" to see AI-powered business names with domain checking</p>
              <p className="text-sm mt-2">This tests the backend API directly to verify functionality</p>
            </div>
          )}

          {isLoading && (
            <div className="text-center py-8">
              <div className="animate-spin w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-lg font-semibold text-blue-600">Generating names and checking domains...</p>
              <p className="text-sm text-gray-600 mt-2">This may take 10-15 seconds</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}