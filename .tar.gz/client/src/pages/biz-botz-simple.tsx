import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Bot, Send, Star } from "lucide-react";
import { Link } from "wouter";
import SEOHead from "@/components/seo-head";

export default function BizBotzSimple() {
  const [selectedBot, setSelectedBot] = useState<string>("");
  const [currentMessage, setCurrentMessage] = useState("");
  const [messages, setMessages] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Static bot data to ensure reliability
  const supportBots = [
    {
      id: "business-advisor",
      name: "Business Advisor Bot",
      description: "Expert guidance on business strategy, planning, and growth for underbanked entrepreneurs",
      specialty: "Business Strategy & Planning",
      status: "online",
      responseTime: "<30 seconds",
      accuracy: 94,
      totalChats: 15420,
      languages: ["English", "Spanish", "French"]
    },
    {
      id: "naming-expert",
      name: "Naming Expert Bot", 
      description: "Specialized AI for business naming, branding, and domain strategy with global market insights",
      specialty: "Business Naming & Branding",
      status: "online",
      responseTime: "<15 seconds",
      accuracy: 97,
      totalChats: 8340,
      languages: ["English", "Spanish", "Portuguese"]
    },
    {
      id: "payment-specialist",
      name: "Payment Solutions Bot",
      description: "Expert help with alternative payment methods, crypto integration, and financial inclusion",
      specialty: "Alternative Payments & Fintech", 
      status: "online",
      responseTime: "<45 seconds",
      accuracy: 91,
      totalChats: 6180,
      languages: ["English", "Spanish"]
    },
    {
      id: "global-markets",
      name: "Global Markets Bot",
      description: "Specialized guidance for underbanked entrepreneurs across different regions and cultures",
      specialty: "Global Market Access",
      status: "online", 
      responseTime: "<60 seconds",
      accuracy: 89,
      totalChats: 4520,
      languages: ["English", "Spanish", "French", "Portuguese"]
    }
  ];

  const handleBotSelect = (botId: string) => {
    console.log('Bot clicked:', botId);
    setSelectedBot(botId);
    setMessages([]);
  };

  const handleSendMessage = async () => {
    if (!currentMessage.trim() || !selectedBot) return;

    const userMessage = {
      type: 'user',
      content: currentMessage,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const response = await fetch('/api/support-bots/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          botId: selectedBot,
          message: currentMessage,
          sessionId: `session-${Date.now()}`
        })
      });

      const data = await response.json();
      
      const botMessage = {
        type: 'bot',
        content: data.response,
        timestamp: new Date().toISOString(),
        metadata: data.metadata
      };

      setMessages(prev => [...prev, botMessage]);
      setCurrentMessage("");
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const selectedBotData = supportBots.find(bot => bot.id === selectedBot);

  return (
    <div className="container mx-auto px-4 py-8">
      <SEOHead 
        title="Biz Botz - AI Customer Support | FindMyBizName"
        description="24/7 AI-powered customer support for entrepreneurs worldwide"
        keywords="AI customer support, business advice, entrepreneur support"
      />

      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Biz Botz 🤖
        </h1>
        <p className="text-gray-600">
          AI-powered customer support available 24/7 for all your business questions
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Bot Selection */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold mb-4">Available Support Bots (4)</h3>
          
          {supportBots.map((bot) => (
            <Card 
              key={bot.id}
              className={`cursor-pointer transition-all hover:shadow-lg ${
                selectedBot === bot.id ? 'ring-2 ring-blue-500 bg-blue-50' : ''
              }`}
              onClick={() => handleBotSelect(bot.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                      <Bot className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{bot.name}</CardTitle>
                      <p className="text-sm text-gray-600">{bot.specialty}</p>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800">
                    {bot.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">{bot.description}</p>
                
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>~{bot.responseTime} response</span>
                  <span>{bot.accuracy}% accuracy</span>
                </div>
                
                <div className="flex items-center gap-1 mt-2">
                  <Star className="h-3 w-3 text-yellow-500 fill-current" />
                  <span className="text-xs text-gray-600">{bot.totalChats.toLocaleString()} chats</span>
                </div>
                
                <div className="flex flex-wrap gap-1 mt-2">
                  {bot.languages.slice(0, 3).map((lang, index) => (
                    <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                      {lang}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Chat Interface */}
        <div className="lg:col-span-2">
          <Card className="h-[600px] flex flex-col">
            {selectedBot ? (
              <>
                {/* Chat Header */}
                <CardHeader className="border-b">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                      <Bot className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold">{selectedBotData?.name}</h4>
                      <p className="text-sm text-gray-600">{selectedBotData?.specialty}</p>
                    </div>
                  </div>
                </CardHeader>

                {/* Messages */}
                <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.length === 0 && (
                    <div className="text-center py-8">
                      <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        Start a conversation
                      </h3>
                      <p className="text-gray-600">
                        Ask me anything about your business needs. I'm here to help!
                      </p>
                    </div>
                  )}

                  {messages.map((message, index) => (
                    <div
                      key={index}
                      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[80%] rounded-lg p-3 ${
                        message.type === 'user' 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-gray-100 text-gray-900'
                      }`}>
                        <p className="text-sm">{message.content}</p>
                        <div className="text-xs mt-2 opacity-70">
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    </div>
                  ))}

                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-gray-100 rounded-lg p-3">
                        <div className="animate-pulse">Thinking...</div>
                      </div>
                    </div>
                  )}
                </CardContent>

                {/* Message Input */}
                <div className="border-t p-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your message..."
                      value={currentMessage}
                      onChange={(e) => setCurrentMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      disabled={isLoading}
                    />
                    <Button 
                      onClick={handleSendMessage}
                      disabled={!currentMessage.trim() || isLoading}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <CardContent className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Select a Support Bot
                  </h3>
                  <p className="text-gray-600">
                    Choose a specialized bot from the sidebar to start getting help.
                  </p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>

      {/* Back to Home */}
      <div className="mt-8 text-center">
        <Link href="/">
          <Button variant="outline">
            ← Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
}