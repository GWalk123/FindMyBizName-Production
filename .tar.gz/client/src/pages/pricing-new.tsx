import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Zap, Crown, Building } from "lucide-react";
import { Link } from "wouter";
import SEOHead from "@/components/seo-head";

export default function PricingNew() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <SEOHead 
        title="Complete Business Platform Pricing - FindMyBizName"
        description="Start free and upgrade to our complete business platform. Caribbean-optimized with global support."
      />
      
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <Badge className="mb-4" variant="outline">
            <Star className="w-4 h-4 mr-2" />
            30-Day Money Back Guarantee
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Complete Business Platform Pricing
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8">
            Start free and upgrade when you need more power. All plans include 
            our Caribbean-optimized payment integration with global support.
          </p>
        </div>

        {/* Coming Soon Preview Section */}
        <Card className="mb-16 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200">
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">🚀 Coming Soon: Complete Business Platform (2026)</h3>
              <p className="text-gray-600">Expanding from business naming to complete business management</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-2">📊 Advanced Analytics</h4>
                <p className="text-sm text-gray-600">Financial reporting, cash flow forecasting, and business insights dashboard</p>
                <div className="text-xs text-blue-600 mt-2">Q1 2026</div>
              </div>
              
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-2">📦 Inventory Management</h4>
                <p className="text-sm text-gray-600">Track products, manage stock levels, and automate reorder alerts</p>
                <div className="text-xs text-blue-600 mt-2">Q2 2026</div>
              </div>
              
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-2">👥 Team Workspace</h4>
                <p className="text-sm text-gray-600">Multi-user accounts, role permissions, and collaboration tools</p>
                <div className="text-xs text-blue-600 mt-2">Q2 2026</div>
              </div>
              
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-2">🏢 Multi-Location</h4>
                <p className="text-sm text-gray-600">Manage multiple business locations from one unified dashboard</p>
                <div className="text-xs text-blue-600 mt-2">Q3 2026</div>
              </div>
              
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-2">🔌 Custom API</h4>
                <p className="text-sm text-gray-600">Enterprise API access for custom integrations and automation</p>
                <div className="text-xs text-blue-600 mt-2">Q3 2026</div>
              </div>
              
              <div className="bg-white rounded-lg p-4 border border-gray-200">
                <h4 className="font-semibold text-gray-900 mb-2">📧 Email Campaigns</h4>
                <p className="text-sm text-gray-600">Automated email marketing and customer engagement tools</p>
                <div className="text-xs text-blue-600 mt-2">Q4 2026</div>
              </div>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-100 text-blue-800 px-4 py-2 rounded-lg inline-block mb-4">
                <strong>Early Bird Promise:</strong> Lock in today's pricing through 2026!
              </div>
              <p className="text-sm text-gray-600">
                Premium stays $9.99/month, Pro stays $19.99/month - even as new features are added
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Current Plans */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <Card className="relative">
            <CardHeader className="text-center">
              <div className="flex items-center justify-center mb-4">
                <div className="p-3 rounded-full bg-gray-100 dark:bg-gray-800">
                  <Zap className="w-6 h-6" />
                </div>
              </div>
              <CardTitle className="text-2xl">Premium</CardTitle>
              <CardDescription>Perfect for entrepreneurs</CardDescription>
              <div className="mt-4">
                <span className="text-4xl font-bold">$9.99</span>
                <span className="text-gray-500 ml-2">/month</span>
              </div>
            </CardHeader>
            
            <CardContent>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>Unlimited name generations</span>
                </li>
                <li className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>Premium domains (.ai, .co, .io)</span>
                </li>
                <li className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>Brand analysis suite</span>
                </li>
                <li className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>PDF export & favorites</span>
                </li>
              </ul>
              
              <Link href="/subscribe?plan=premium">
                <Button className="w-full">Start Premium</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="relative border-blue-500 shadow-xl">
            <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500">
              Most Popular
            </Badge>
            
            <CardHeader className="text-center">
              <div className="flex items-center justify-center mb-4">
                <div className="p-3 rounded-full bg-blue-500 text-white">
                  <Crown className="w-6 h-6" />
                </div>
              </div>
              <CardTitle className="text-2xl">Pro</CardTitle>
              <CardDescription>Complete business tools</CardDescription>
              <div className="mt-4">
                <span className="text-4xl font-bold">$19.99</span>
                <span className="text-gray-500 ml-2">/month</span>
              </div>
            </CardHeader>
            
            <CardContent>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>Everything in Premium</span>
                </li>
                <li className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>CRM system with WhatsApp</span>
                </li>
                <li className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>Invoice generator with QR codes</span>
                </li>
                <li className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>Business Intelligence (SEC data)</span>
                </li>
              </ul>
              
              <Link href="/subscribe?plan=pro">
                <Button className="w-full">Start Pro</Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Feature Comparison Table */}
        <Card className="mb-16">
          <CardHeader>
            <CardTitle className="text-center">Feature Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="py-3 px-4 text-left">Feature</th>
                    <th className="py-3 px-4 text-center">Free</th>
                    <th className="py-3 px-4 text-center">Premium</th>
                    <th className="py-3 px-4 text-center">Pro</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-3 px-4">Monthly Generations</td>
                    <td className="text-center py-3 px-4">10</td>
                    <td className="text-center py-3 px-4">Unlimited</td>
                    <td className="text-center py-3 px-4">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Domain TLDs</td>
                    <td className="text-center py-3 px-4">3 basic</td>
                    <td className="text-center py-3 px-4">50+</td>
                    <td className="text-center py-3 px-4">50+</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Brand Analysis</td>
                    <td className="text-center py-3 px-4">3 uses</td>
                    <td className="text-center py-3 px-4">Unlimited</td>
                    <td className="text-center py-3 px-4">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Business Tools</td>
                    <td className="text-center py-3 px-4">✗</td>
                    <td className="text-center py-3 px-4">✗</td>
                    <td className="text-center py-3 px-4">✓</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}